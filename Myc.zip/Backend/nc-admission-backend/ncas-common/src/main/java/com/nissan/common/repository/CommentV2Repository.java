package com.nissan.common.repository;

import com.nissan.common.entity.Comment;
import com.nissan.common.entity.CommentV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface CommentV2Repository
    extends JpaRepository<CommentV2, Long>, QuerydslPredicateExecutor<CommentV2> {

  CommentV2 findByOrdersId(Long orderId);
}
