package com.nissan.common.repository;

import com.nissan.common.entity.Reason;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReasonRepository
    extends JpaRepository<Reason, Long>, QuerydslPredicateExecutor<Reason> {
  List<Reason> findByLangCode(String lang);
}
