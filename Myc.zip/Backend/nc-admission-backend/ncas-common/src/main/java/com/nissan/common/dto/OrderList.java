package com.nissan.common.dto;

import java.util.ArrayList;
import java.util.List;

public class OrderList {
  List<Object> orderInfo = new ArrayList<Object>();

  public List<Object> getOrderInfo() {
    return orderInfo;
  }

  public void setOrderInfo(List<Object> orderInfo) {
    this.orderInfo = orderInfo;
  }

  @Override
  public String toString() {
    return "OrderList{" +
            "orderInfo=" + orderInfo +
            '}';
  }
}
