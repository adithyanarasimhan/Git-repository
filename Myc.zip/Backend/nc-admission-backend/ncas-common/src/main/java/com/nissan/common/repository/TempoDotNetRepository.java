package com.nissan.common.repository;

import com.nissan.common.entity.TempoDotNet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface TempoDotNetRepository
    extends JpaRepository<TempoDotNet, Long>, QuerydslPredicateExecutor<TempoDotNet> {
    TempoDotNet findByCaCompanyCode(String caCompanyCode);
    TempoDotNet findByProfitDealerCompanyCodeWithBlockCode(String profitDealerCompanyCodeWithBlockCode);
    TempoDotNet findByProfitDealerCompanyCode(String profitDealerCompanyCode);
}
