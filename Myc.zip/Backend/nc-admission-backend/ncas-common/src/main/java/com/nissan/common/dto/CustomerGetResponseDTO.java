package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class CustomerGetResponseDTO {
  private String packagePlan;
  private String packagePlanName;
  private Long adminFee;
  private Long amount;
  private List cardBrand;
  private Long stepCount;
  private String source;
  private String email;
  private List prefectureName;
  private String naviName;
  private String paymentStatus;
}
