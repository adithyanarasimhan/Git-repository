package com.nissan.common.service.impl;

import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.service.CustomerService;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import com.nissan.common.util.FormatValue;
import org.apache.http.client.utils.URIBuilder;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

  public static final int NFS = 4;
  public static final int NFS_JP = 8;
  public static final String NFS_PAYMENT = "nfs";
  public static final String CREDIT_PAYMENT = "credit-card";
  public static final String DEALER = "dealer";
  public static final String HOME = "home";
  private static final Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(CustomerServiceImpl.class);

  @Autowired private CustomerRepository customerRepository;

  @Autowired private PaymentRepository paymentRepository;

  @Autowired private UserRepository userRepository;

  @Autowired private CardBrandRepository cardBrandRepository;

  @Autowired private PackagePlanRepository packagePlanRepository;

  @Autowired private OrdersRepository ordersRepository;

  @Autowired private AdmissionRepository admissionRepository;

  @Autowired private AdmissionV2Repository admissionV2Repository;

  @Autowired private ActivityLogRepository activityLogRepository;

  @Autowired private PaymentMethodRepository paymentMethodRepository;

  @Autowired ActivityUtil activityUtil;

  @Value("${spring.google.key}")
  private String zipCodeKey;

  @Override
  @Transactional
  public CustomerResponseDTO updateCustomerById(
      CustomerDTO customerDto, String userName, String langCode) throws Exception {
    logger.info("Inside update customer by id");
    Customer customerEntity = null;
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"user id= "+ userName);
    User user = userRepository.findById(Long.valueOf(userName)).get();
    logger.info("User Id:" + user.getId());
    Customer customer = customerRepository.findCustomerByUserId(user.getId());
    if (customer == null) {
      return null;
    } else {
      customerEntity = checkIndividualCorporate(customerDto, customer, user, langCode);
      return getCustomerResponse(customerEntity);
    }
  }

  private CustomerResponseDTO getCustomerResponse(Customer customer) {
    if (customer == null) {
      return null;
    }
    CustomerResponseDTO customerResponse = new CustomerResponseDTO();
    customerResponse.setAddress1(customer.getAddress1());
    customerResponse.setAddress2(customer.getAddress2());
    customerResponse.setCorporateName(customer.getCorporateName());
    customerResponse.setCustomerType(customer.getCustomerType());
    customerResponse.setEmail(customer.getEmail());
    customerResponse.setFamilyName(customer.getFamilyName());
    customerResponse.setFamilyNameKatakana(customer.getFamilyNameKatakana());
    customerResponse.setFirstName(customer.getFirstName());
    customerResponse.setFirstNameKatakana(customer.getFirstNameKatakana());
    customerResponse.setOfficePosition(customer.getOfficePosition());
    customerResponse.setPhoneNumber(
        appendCustomerDetails(customer.getPhoneNumber1())
            + appendCustomerDetails(customer.getPhoneNumber2())
            + appendCustomerDetails(customer.getPhoneNumber3()));
    customerResponse.setOptionalPhoneNumber(
        appendCustomerDetails(customer.getOptionalPhoneNumber1())
            + appendCustomerDetails(customer.getOptionalPhoneNumber2())
            + appendCustomerDetails(customer.getOptionalPhoneNumber3()));
    customerResponse.setRepresentativeName(customer.getRepresentativeName());
    customerResponse.setRepresentativeNameKatakana(customer.getRepresentativeNameKatakana());
    customerResponse.setStepCount(customer.getStepCount());
    customerResponse.setZipCode(
        appendCustomerDetails(customer.getZipCode1())
            + appendCustomerDetails(customer.getZipCode2()));
    return customerResponse;
  }

  private String appendCustomerDetails(String value) {
    if (value == null) {
      return "";
    } else {
      return value.toString();
    }
  }

  @Override
  @Transactional
  public Customer saveCustomer(OtpDto otpDto, String userName, String langCode) {
    logger.info("Inside save customer");
    Customer customer = null;
    try {
      User user = userRepository.findById(Long.valueOf(userName)).get();
      Optional<Customer> oldCustomer = customerRepository.findByUserId(user.getId());
      if (!oldCustomer.isPresent()) {
        customer = new Customer();
        logger.info("user id : " + user.getId());
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"user name before update :"+ user.getUsername() );
        customer.setEmail(otpDto.getEmail());
        customer.setUser(user);
        customer.setLangCode(langCode);
        customer.setStepCount(1L);
        logger.info("before save user");
        User updatedUser = userRepository.save(user);
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"updatedUserName :"+ updatedUser.getUsername() );
        customer.setActive(true);
        if (otpDto.getSource().equals(DEALER)) {
          customer.setSource(DEALER);
        } else {
          customer.setSource(HOME);
        }
        customer = customerRepository.save(customer);
      } else {
        customer = oldCustomer.get();
        customer.setEmail(otpDto.getEmail());
        return customerRepository.save(customer);
      }
    } catch (Exception e) {
      logger.info("Error in save customer : " + e.getMessage());
      customer = null;
    }
    return customer;
  }

  @Override
  public CustomerSummaryDto fetchCustomerByUserAndLangCode(String userName, String lang) {
    logger.info("inside CustomerServiceImpl fetchCustomerByUserAndLangCode");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"user id is= "+ userName);
    CustomerSummaryDto customerSummaryDto = new CustomerSummaryDto();
    User user = userRepository.findById(Long.valueOf(userName)).get();
    Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
    if (customer != null) {
      customerSummaryDto.setFirstName(customer.getFirstName());
      customerSummaryDto.setFamilyName(customer.getFamilyName());
      customerSummaryDto.setCustomerType(customer.getCustomerType());
      customerSummaryDto.setFirstNameKatakana(customer.getFirstNameKatakana());
      customerSummaryDto.setFamilyNameKatakana(customer.getFamilyNameKatakana());
      customerSummaryDto.setAddress1(customer.getAddress1());
      customerSummaryDto.setAddress2(customer.getAddress2());
      customerSummaryDto.setEmail(customer.getEmail());
      customerSummaryDto.setPhoneNumber(
          appendCustomerDetails(customer.getPhoneNumber1())
              + appendCustomerDetails(customer.getPhoneNumber2())
              + appendCustomerDetails(customer.getPhoneNumber3()));
      customerSummaryDto.setOptionalPhoneNumber(
          appendCustomerDetails(customer.getOptionalPhoneNumber1())
              + appendCustomerDetails(customer.getOptionalPhoneNumber2())
              + appendCustomerDetails(customer.getOptionalPhoneNumber3()));
      customerSummaryDto.setCorporateName(customer.getCorporateName());
      customerSummaryDto.setRepresentativeName(customer.getRepresentativeName());
      customerSummaryDto.setRepresentativeNameKatakana(customer.getRepresentativeNameKatakana());
      customerSummaryDto.setOfficePosition(customer.getOfficePosition());
      Payment payment = paymentRepository.fetchByCustomerId(customer.getId());
      customerSummaryDto.setZipCode(
          appendCustomerDetails(customer.getZipCode1())
              + appendCustomerDetails(customer.getZipCode2()));
      if (payment != null) {
        customerSummaryDto.setNameOnCard(payment.getCardName());
        CardBrand cardBrand = cardBrandRepository.fetchByLangCodeAndId(payment.getCardBrand());
        customerSummaryDto.setCardType(cardBrand.getName());
        customerSummaryDto.setExpiryDate(
            payment.getExpiryMonth().toString() + "/" + payment.getExpiryYear().toString());
        String cardNumber =
            isNotNullOrEmpty(payment.getCardNumber1())
                + isNotNullOrEmpty(payment.getCardNumber2())
                + isNotNullOrEmpty(payment.getCardNumber3())
                + isNotNullOrEmpty(payment.getCardNumber4());
        if (cardNumber != null && !cardNumber.isEmpty() && !cardNumber.equals("")) {
          cardNumber.replaceAll("\\d(?=(?:\\D*\\d){4})", "*");
          customerSummaryDto.setCardNumber(cardNumber);
        }
      }
    }

    Admission admission = admissionRepository.fetchByUserId(user.getId());
    if (admission != null) {
      Orders order = ordersRepository.findByAdmissionId(admission.getId());
      if (order != null) {
        if (order.getPackagePlan() != null) {
          customerSummaryDto.setPackagePlan(order.getPackagePlan().getPackagePlanName());
          customerSummaryDto.setAmount(order.getPackagePlan().getPrice());
        }
        if (order.getModel() != null) {
          customerSummaryDto.setModel(order.getModel().getModelName());
          customerSummaryDto.setImgUrl(order.getModel().getUrl());
        }
        if (order.getGrade() != null) {
          customerSummaryDto.setGrade(order.getGrade().getGradeName());
        }
        if (order.getNavi() != null)
          customerSummaryDto.setNaviType(order.getNavi().getDisplayName());
        customerSummaryDto.setAdmissionType(order.getAdmissionType());
        customerSummaryDto.setVehicleTransfer(order.getVehicleTransfer());
        customerSummaryDto.setVinNumber(order.getVinNumber());
        if (order.getOptions() != null) {
          customerSummaryDto.setOptionsName(order.getOptions().getDisplayName());
        }
      }
    }
    return customerSummaryDto;
  }

  private String isNotNullOrEmpty(String cardNumber) {
    if (cardNumber == null) {
      return "";
    } else {
      return cardNumber;
    }
  }

  private Customer checkIndividualCorporate(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    Customer updatedCustomer;
    if (customerDto.getCustomerType() == 0) {
      updatedCustomer = setIndividualValues(customerDto, customer, user, langCode);
    } else {
      updatedCustomer = setCorporateValues(customerDto, customer, user, langCode);
    }
    return updatedCustomer;
  }

  private Customer setCorporateValues(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    logger.info("Setting corporate values");

    customer.setCorporateName(customerDto.getCorporateName());
    customer.setOfficePosition(customerDto.getOfficePosition());
    customer.setRepresentativeName(customerDto.getRepresentativeName());
    customer.setRepresentativeNameKatakana(customerDto.getRepresentativeNameKatakana());
    customer.setAddress1(customerDto.getAddress1());
    customer.setAddress2(customerDto.getAddress2());

    /** setting individual values as null when customer is corporate */
    customer.setFamilyName(null);
    customer.setFamilyNameKatakana(null);
    customer.setFirstName(null);
    customer.setFirstNameKatakana(null);

    return setCommonValues(customerDto, customer, user, langCode);
  }

  private Customer setIndividualValues(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    logger.info("Setting individual values");
    customer.setFamilyName(customerDto.getFamilyName());
    customer.setFamilyNameKatakana(customerDto.getFamilyNameKatakana());
    customer.setFirstName(customerDto.getFirstName());
    customer.setFirstNameKatakana(customerDto.getFirstNameKatakana());
    customer.setAddress1(customerDto.getAddress1());
    customer.setAddress2(customerDto.getAddress2());
    /** setting corporate values as null when customer is individual */
    customer.setCorporateName(null);
    customer.setOfficePosition(null);
    customer.setRepresentativeName(null);
    customer.setRepresentativeNameKatakana(null);

    return setCommonValues(customerDto, customer, user, langCode);
  }

  private Customer setCommonValues(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    customer.setCustomerType(customerDto.getCustomerType());
    //  customer.setStepCount(customerDto.getStepCount());
    Map<String, String> zip = FormatValue.formatZipCode(customerDto.getZipCode());
    customer.setZipCode1(zip.get("firstThreeDigits"));
    customer.setZipCode2(zip.get("lastFourDigits"));

    if (customerDto.getPhoneNumber().length() == 11) {
      Map<String, String> phone = FormatValue.formatPhoneNumber(customerDto.getPhoneNumber());
      customer.setPhoneNumber1(phone.get("firstThreeDigits"));
      customer.setPhoneNumber2(phone.get("middleFourDigits"));
      customer.setPhoneNumber3(phone.get("lastFourDigits"));
    } else {
      Map<String, String> phone =
          FormatValue.formatPhoneNumberTenDigits(customerDto.getPhoneNumber());
      customer.setPhoneNumber1(phone.get("firstThreeDigits"));
      customer.setPhoneNumber2(phone.get("middleFourDigits"));
      customer.setPhoneNumber3(phone.get("lastFourDigits"));
    }

    if (customerDto.getOptionalPhoneNumber() != null
        && !customerDto.getOptionalPhoneNumber().isEmpty()
        && !customerDto.getOptionalPhoneNumber().equals("")) {
      if (customerDto.getOptionalPhoneNumber().length() == 11) {
        Map<String, String> optionalPhone =
            FormatValue.formatPhoneNumber(customerDto.getOptionalPhoneNumber());
        customer.setOptionalPhoneNumber1(optionalPhone.get("firstThreeDigits"));
        customer.setOptionalPhoneNumber2(optionalPhone.get("middleFourDigits"));
        customer.setOptionalPhoneNumber3(optionalPhone.get("lastFourDigits"));
      } else {
        Map<String, String> optionalPhone =
            FormatValue.formatPhoneNumberTenDigits(customerDto.getOptionalPhoneNumber());
        customer.setOptionalPhoneNumber1(optionalPhone.get("firstThreeDigits"));
        customer.setOptionalPhoneNumber2(optionalPhone.get("middleFourDigits"));
        customer.setOptionalPhoneNumber3(optionalPhone.get("lastFourDigits"));
      }
    }
    logger.info("Updating customer details");

    Customer updatedCustomer = customerRepository.save(customer);
    return updatedCustomer;
  }

  @Override
  @Transactional
  public CustomerGetResponseDTO fetchCustomerPlanDetails(String userName, String langCode)
      throws Exception {
    CustomerGetResponseDTO customerGetResponseDTO = new CustomerGetResponseDTO();
    try {
      logger.info("Fetching customer details");
      List<CardBrandDTO> listOfCardsDto = new ArrayList<>();
      User user = userRepository.findById(Long.valueOf(userName)).get();
      Admission admission = admissionRepository.fetchByUserId(user.getId());
      if (admission != null) {
        Orders orders = ordersRepository.findByAdmissionId(admission.getId());
        if (orders != null && orders.getPackagePlan() != null) {
          customerGetResponseDTO.setAmount(orders.getPackagePlan().getPrice());
          customerGetResponseDTO.setPackagePlan(orders.getPackagePlan().getDisplayName());
          customerGetResponseDTO.setPackagePlanName(orders.getPackagePlan().getPackagePlanName());
        }
        if(orders != null && orders.getNavi() != null) {
          customerGetResponseDTO.setNaviName(orders.getNavi().getNaviName());
        }
      }

      List<CardBrand> listOfCards = cardBrandRepository.findByLangCode(langCode);
      if (!listOfCards.isEmpty()) {
        listOfCards.forEach(
            cardBrand -> {
              CardBrandDTO cardBrandDTO = new CardBrandDTO();
              cardBrandDTO.setId(cardBrand.getId());
              cardBrandDTO.setName(cardBrand.getName());
              listOfCardsDto.add(cardBrandDTO);
            });
      }
      customerGetResponseDTO.setCardBrand(listOfCards);

      Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
      if (customer != null) {
        customerGetResponseDTO.setStepCount(customer.getStepCount());
        customerGetResponseDTO.setSource(customer.getSource());
        customerGetResponseDTO.setEmail(customer.getEmail());
      }
    } catch (Exception e) {
      throw new Exception("Error in fetching details : " + e.getMessage());
    }
    return customerGetResponseDTO;
  }

  private void saveAdmission(User user, String langCode) {
    Admission admission = admissionRepository.fetchByUserId(user.getId());
    if (admission == null) {
      throw new ResourceNotFoundException("Admission not found");
    } else {
      // admission.setStatus(Constants.STATUS_CUSTOMER_FILLING);
      // admission.setStatusJp(Constants.STATUS_CUSTOMER_FILLING_JP);
      // admissionRepository.save(admission);
    }
  }

  private String jsonStringConverter(String stringResponse) {
    String[] parts = stringResponse.split("&");
    String jsonString = "{\"";
    for (int i = 0; i < parts.length; i++) {
      jsonString += parts[i].replace("=", "\":\"");
      jsonString += (i < parts.length - 1) ? "\", \"" : "";
    }
    return jsonString += "\"}";
  }

  private SimpleClientHttpRequestFactory getClientHttpRequestFactory() {
    SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
    /** Connect timeout */
    clientHttpRequestFactory.setConnectTimeout(95000);

    /** Read timeout */
    clientHttpRequestFactory.setReadTimeout(95000);
    return clientHttpRequestFactory;
  }

  private static String generateRandom(int length) {
    Random random = new Random();
    char[] digits = new char[length];
    digits[0] = (char) (random.nextInt(9) + '1');
    for (int i = 1; i < length; i++) {
      digits[i] = (char) (random.nextInt(10) + '0');
    }
    return new String(digits);
  }

  @Override
  @Transactional
  public CustomerInfoDTO fetchCustomerNcNameMob(String token, String langCode) throws Exception {
    logger.info("Inside fetch customer info Name and Mon number");
    Customer customerEntity = null;
    User user = userRepository.findByEncodedToken(token);
    Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
    if (customer == null) {
      return null;
    } else {
      CustomerInfoDTO customerInfoDTO = new CustomerInfoDTO();
      /** get first name if customer is individual */
      if (customer.getCustomerType() == 0) {
        if (langCode.equals("en")) {
          customerInfoDTO.setCustomerName(customer.getFirstName());
        } else {
          customerInfoDTO.setCustomerName(customer.getFamilyName() + customer.getFirstName());
        }
      } else {
        customerInfoDTO.setCustomerName(
            customer.getCorporateName() + customer.getRepresentativeName());
      }
      String phoneNumber =
          appendCustomerDetails(customer.getPhoneNumber1())
              + appendCustomerDetails(customer.getPhoneNumber2())
              + appendCustomerDetails(customer.getPhoneNumber3());
      customerInfoDTO.setMobileNumber(phoneNumber.replaceAll("\\d(?=(?:\\D*\\d){4})", "*"));
      return customerInfoDTO;
    }
  }

  @Override
  public ZipCodeResponseDTO fetchPrefecture(String zipCode, String langCode) throws Exception {
    String adminArea1 = "";
    String adminArea2 = "";
    String locality = "";
    String subLocality1 = "";
    String subLocality2 = "";
    Map<String, String> address1Map = new HashMap<>();
    logger.info("Inside fetch prefecture for customer");
    ZipCodeResponseDTO zipCodeResponseDTO = new ZipCodeResponseDTO();
    UriComponents builder = null;
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Zip code entered is "+ zipCode);
    if (langCode.equals("en")) {
      builder = UriComponentsBuilder.fromHttpUrl("https://maps.googleapis.com/maps/api/geocode/json")
              .queryParam("address", zipCode)
              .queryParam("sensor","true")
              .queryParam("key",zipCodeKey)
              .queryParam("language","en")
              .queryParam("components","country:JP").build();
    } else if (langCode.equals("jp")) {
      builder = UriComponentsBuilder.fromHttpUrl("https://maps.googleapis.com/maps/api/geocode/json")
              .queryParam("address", zipCode)
              .queryParam("sensor","true")
              .queryParam("key",zipCodeKey)
              .queryParam("language","ja")
              .queryParam("components","country:JP").build();
    }
    RestTemplate restTemplate = new RestTemplate();
    restTemplate.setRequestFactory(getClientHttpRequestFactory());
    ResponseEntity<String> response = restTemplate.getForEntity(builder.toUriString(), String.class);
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"The prefecture response is"+ response);
    ObjectMapper mapper = new ObjectMapper();
    JsonNode array = mapper.readValue(response.getBody(), JsonNode.class);
    if (array.path("status").textValue().equals("OK")) {
      JsonNode object = array.path("results").path(0);
      JsonNode addressLocality = object.path("address_components");
      if (addressLocality == null) {
        throw new ResourceNotFoundException("No Address Locality found");
      }
      logger.info("Beginning json node iteration");
      Iterator<JsonNode> iter = addressLocality.iterator();
      setPrefectureValues(address1Map, iter);
      if (langCode.equals("jp")) {
        zipCodeResponseDTO.setAddress1(
            address1Map.entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
                .map(i -> i.getValue())
                .collect(Collectors.joining("")));
      } else {
        zipCodeResponseDTO.setAddress1(
            address1Map.entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
                .map(i -> i.getValue())
                .collect(Collectors.joining(",")));
      }
    } else if (array.path("status").textValue().equals("ZERO_RESULTS")) {
      throw new ResourceNotFoundException("No details found for the given zip code ");
    } else if (array.path("status").textValue().equals("OVER_DAILY_LIMIT")) {
      throw new ResourceNotFoundException("API key missing or Billing not enabled");
    } else if (array.path("status").textValue().equals("REQUEST_DENIED")) {
      throw new ResourceNotFoundException("Request denied");
    } else if (array.path("status").textValue().equals("INVALID_REQUEST")) {
      throw new ResourceNotFoundException("Invalid request");
    }
    return zipCodeResponseDTO;
  }

  private void setPrefectureValues(Map<String, String> address1Map, Iterator<JsonNode> iter) {
    String adminArea1;
    String adminArea2;
    String locality;
    String subLocality1;
    String subLocality2;
    String subLocality3;
    String subLocality4;
    while (iter.hasNext()) {
      logger.info("Inside iterator");
      JsonNode jsonNodeItr = iter.next();
      logger.info("Type administative are type" + Arrays.asList(jsonNodeItr.path("types")));
      Iterator<JsonNode> elements = jsonNodeItr.get("types").elements();
      List<String> list = new ArrayList<>();
      elements.forEachRemaining(n -> list.add(n.asText()));
      // List<String> list=Arrays.asList(String.valueOf(jsonNodeItr.path("types")));
      for (String typeValues : list) {
        if (typeValues.matches("administrative_area_level_1")) {
          logger.info("Inside if condition AdminArea1");
          adminArea1 = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("g-adminArea1", adminArea1);
          logger.info("Admiinstrative1 area name" + adminArea1);
        }
        if ((typeValues.matches("administrative_area_level_2"))) {
          logger.info("Inside if condition AdminArea2");
          adminArea2 = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("f-adminArea2", adminArea2);
          logger.info("Admiinstrative2 area name" + adminArea2);
        }
        if ((typeValues.matches("locality"))) {
          logger.info("Inside if condition locality");
          locality = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("e-locality", locality);
          logger.info("Locality name" + locality);
        }
        if ((typeValues.matches("sublocality_level_1"))) {
          logger.info("Inside if condition subLocality1");
          subLocality1 = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("d-subLocality1", subLocality1);
          logger.info("SubLocality1 area name" + subLocality1);
        }
        if ((typeValues.matches("sublocality_level_2"))) {
          logger.info("Inside if condition subLocality2");
          subLocality2 = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("c-subLocality2", subLocality2);
          logger.info("Sublocality2 area name" + subLocality2);
        }
        if ((typeValues.matches("sublocality_level_3"))) {
          logger.info("Inside if condition subLocality3");
          subLocality3 = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("b-subLocality3", subLocality3);
          logger.info("Sublocality3 area name" + subLocality3);
        }
        if ((typeValues.matches("sublocality_level_4"))) {
          logger.info("Inside if condition subLocality4");
          subLocality4 = replaceNullFirstParamaeters(jsonNodeItr.path("long_name").textValue());
          address1Map.put("a-subLocality4", subLocality4);
          logger.info("Sublocality3 area name" + subLocality4);
        }
      }
    }
  }

  @Override
  @Transactional
  public TempPwdDTO fetchTemporaryPwd(String token, String langCode) throws Exception {
    logger.info("Inside fetch customer temporary password");
    TempPwdDTO tempPwdDTO = new TempPwdDTO();
    User user = userRepository.findByEncodedToken(token);
    Admission admission = admissionRepository.fetchByUserId(Long.valueOf(user.getId()));
    AdmissionV2 admissionv2 = null;
    if (admission == null ) {
      admissionv2 = admissionV2Repository.fetchByUserId(Long.valueOf(user.getId()));
      if (admissionv2 != null) {
        tempPwdDTO.setTempPassword(admissionv2.getNcPassword());
        return tempPwdDTO;
      }
    }  else {
      tempPwdDTO.setTempPassword(admission.getNcPassword());
      return tempPwdDTO;
    }
    return null;
  }

  private String replaceNullFirstParamaeters(String value) {
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }

  private String replaceNullSecondParamaeters(String value) {
    if (value == null) {
      return "";
    } else {
      return "," + value;
    }
  }
}
