package com.nissan.common.dto;

import lombok.Data;

@Data
public class CardBrandDTO {
  private Long id;
  private String name;
}
