package com.nissan.common.dto;

import lombok.Data;

@Data
public class ActivityLogResponseDTO {
  private String message;
  private String type;
  private String time;
}
