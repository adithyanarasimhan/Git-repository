package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class PackagePlansDTO {
    private long id;
    private String name;
    private String displayName;
    private long price;
    private String checkSheetPattern;
    private String tcPattern;
    private List<AvailableColorDTO> availableColors;
}
