package com.nissan.common.repository;

import com.nissan.common.dto.DownloadCsvActiveVinListDTO;
import com.nissan.common.entity.VinDetails;
import com.nissan.common.dto.DownloadCsvTakeActionVinListDTO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.sql.Timestamp;
import java.util.List;

public interface VinDetailsRepository extends JpaRepository<VinDetails, Long>, QuerydslPredicateExecutor<VinDetails> {
    VinDetails findByVin(String vin);

    @Query(value = "select * from vin_details where model_id=?1", nativeQuery = true)
    List<VinDetails> findByModel(Long id);

    @Query(
            "SELECT new com.nissan.common.dto.DownloadCsvActiveVinListDTO (v.enrollmentDate,da.ncJoinDate,v.status,da.id,d.dealerShipCode,d.companyName,d.dealershipName,d.profitCaCompanyCode,d.phoneNumber,d.caName,d.caCode,'','',m.modelName,pc.packagePlanName,pc.price,v.vin,v.cwNaviId,v.carPlan,v.flagType,v.source,v.ivi,v.icc,da.ncId,da.ncPassword,da.ncPasswordExpirationDate) FROM VinDetails v LEFT JOIN DemoCarModel  m on v.model=m.id LEFT JOIN  DemoCarPackagePlan pc on pc.id=v.packagePlan LEFT JOIN DemoCarAdmission da on da.id=v.admission LEFT JOIN DealerEntity d on d.dealerId=v.dealer WHERE v.createdDate >= :start and v.createdDate <= :end")
    List<DownloadCsvActiveVinListDTO> fetchActiveVinDetails(Timestamp start, Timestamp end);


    VinDetails findByVinAndStatusNotIn(String vin, List<String> status);

    List<VinDetails> findByStatusInAndIviTrue(List<String> status);

    List<VinDetails> findByIviTrue();

    List<VinDetails> findByStatus(String status);

    @Modifying
    @Query(value = "delete  from vin_details where id=?1", nativeQuery = true)
    void deleteVinById(Long id);
}
