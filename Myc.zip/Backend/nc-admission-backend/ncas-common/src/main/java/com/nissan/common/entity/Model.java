package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Table(name = "model")
@EntityListeners(AuditingEntityListener.class)
public class Model extends Auditable<String> implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "model_name")
  private String modelName;

  @Column(name = "display_name")
  private String displayName;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "category")
  private String category;

  @Column(name = "url")
  private String url;

  @Column(name = "model_display_order")
  private Long modelDisplayOrder;

  @Column(name = "active")
  private Boolean active;
}
