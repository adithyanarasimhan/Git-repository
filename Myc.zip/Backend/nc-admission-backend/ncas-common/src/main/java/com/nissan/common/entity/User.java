package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Set;

@Entity
@Data
@Table(name = "user", schema = "nissan_admin")
@EntityListeners(AuditingEntityListener.class)
public class User extends Auditable<String> {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "user_name")
  private String username;

  @Column(name = "password")
  private String password;

  @Column(name = "enabled")
  private boolean enabled;

  @Column(name = "token_expired")
  private boolean tokenExpired;

  @Column(name = "token")
  private String token;

  @Column(name = "encoded_token")
  private String encodedToken;

  @Column(name = "is_valid_token")
  private Boolean isValidToken;

  @Column(name = "saml_session_index")
  private String samlSessionIndex;

  @Column(name = "source")
  private String source;

  @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinTable(
      name = "user_role",
      joinColumns = {@JoinColumn(name = "user_id")},
      inverseJoinColumns = {@JoinColumn(name = "role_id")})
  private Set<Role> roles;
}
