package com.nissan.common.repository;

import com.nissan.common.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
  Role findRoleByName(String name);
}
