package com.nissan.common.repository;

import com.nissan.common.dto.*;
import com.nissan.common.entity.Admission;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.entity.DealerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface AdmissionV2Repository
    extends JpaRepository<AdmissionV2, Long>, QuerydslPredicateExecutor<AdmissionV2> {
  @Query(
      "SELECT distinct new com.nissan.common.dto.RecentAdmissionResponseDTO('old',a.id, a.createdDate, o.caName, m.displayName, g.displayName,n.naviName, n.displayName,o.vehicleTransfer, o.vinNumber, pc.packagePlanName, pc.price, pc.adminFee, py.name, py.displayName, u.id, op.optionsName, c.firstName, c.familyName, u.firstName, o.ordersNumber, c.corporateName, c.customerType, c.address1, c.address2, c.zipCode1, c.zipCode2, 1, u.encodedToken, CASE WHEN com.id>0 THEN com.comment ELSE NULL END as comment, CASE WHEN com.id>0 THEN com.reasonId ELSE NULL END as reasonId,o.cwNaviId,o.colorCode,o.colorName,o.registrationDate, o.oldVinNumber, o.vehicleType) FROM AdmissionV2 a JOIN OrdersV2 o on a.id=o.admission LEFT JOIN ModelV2 m on o.model=m.id LEFT JOIN GradeV2 g on g.id=o.grade LEFT JOIN NaviV2 n on n.id=o.navi LEFT JOIN PackagePlanV2 pc on pc.id=o.packagePlan LEFT JOIN PaymentMethod py on py.id=o.paymentMethod LEFT JOIN User u on u.id=a.user LEFT JOIN OptionsV2 op on op.id=o.options LEFT JOIN Customer c on c.user=u.id LEFT JOIN CommentV2 com on com.orders=o.id WHERE a.active=true AND a.createdDate BETWEEN :startDate AND :endDate AND a.dealer=:dealer ORDER BY a.id DESC")
  List<RecentAdmissionResponseDTO> fetchRecentAdmissions(
      DealerEntity dealer, Timestamp startDate, Timestamp endDate);

  @Query(value = "select * from admissionv2 where id=?1", nativeQuery = true)
  AdmissionV2 fetchById(Long Id);

  @Query(value = "select * from admissionv2 where user_id=?1", nativeQuery = true)
  AdmissionV2 fetchByUserId(Long userId);

  List<AdmissionV2> findByNcIdNotNullAndStatusNot(String status);

  @Query(
          "SELECT new com.nissan.common.dto.VehicleTransferRecordV2Dto(o,d,c,pm,da) FROM AdmissionV2 a JOIN OrdersV2 o on a.id=o.admission LEFT JOIN DealerAddress da on da.admission=a.id LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  VehicleTransferRecordV2Dto fetchVehicleTransferRecord(AdmissionV2 admission);

  @Query(
          "SELECT new com.nissan.common.dto.WithDrawDTO(o,d,c,pm,da) FROM AdmissionV2 a JOIN OrdersV2 o on a.id=o.admission LEFT JOIN DealerAddress da on da.admission=a.id LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  WithDrawDTO fetchWithDrawRecord(AdmissionV2 admission);

  @Query(
          "SELECT new com.nissan.common.dto.RetryPaymentV2DTO(o,d,c,pm,da) FROM AdmissionV2 a JOIN OrdersV2 o on a.id=o.admission LEFT JOIN DealerAddress da on da.admission=a.id LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  RetryPaymentV2DTO fetchBankIdResettingRecord(AdmissionV2 admission);

  @Query(
          "SELECT new com.nissan.common.dto.VinResetDTO(o,d,c,pm) FROM AdmissionV2 a JOIN OrdersV2 o on a.id=o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  VinResetDTO fetchVinResettingRecord(AdmissionV2 admission);

  @Query(
          "SELECT new com.nissan.common.dto.NfsPaymentRecordV2Dto(o,d,c,pm,da) FROM AdmissionV2 a JOIN OrdersV2 o on a.id= o.admission LEFT JOIN DealerAddress da on da.admission=a.id LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  NfsPaymentRecordV2Dto fetchNfsPaymentRecord(AdmissionV2 admission);

  @Query(
          "SELECT new com.nissan.common.dto.DigitalAdmissionRecordV2Dto(o,d,c,pm,npm,da) FROM AdmissionV2 a JOIN OrdersV2 o on a.id= o.admission LEFT JOIN DealerAddress da on da.admission=a.id LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id  LEFT JOIN NicosPayment npm on npm.customer=c.id WHERE a=:admission")
  DigitalAdmissionRecordV2Dto fetchDigitalAdmissionRecord(AdmissionV2 admission);
}
