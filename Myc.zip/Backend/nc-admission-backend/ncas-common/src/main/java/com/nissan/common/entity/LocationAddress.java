package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "location_address")
@EntityListeners(AuditingEntityListener.class)
public class LocationAddress extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "prefecture_code")
  private String prefectureCode;

  @Column(name = "city_code")
  private String cityCode;

  @Column(name = "area_code")
  private String areaCode;

  @Column(name = "prefecture_name")
  private String prefectureName;

  @Column(name = "city_name1")
  private String cityName1;

  @Column(name = "city_name2")
  private String cityName2;

  @Column(name = "city_name3")
  private String cityName3;

  @Column(name = "kana")
  private String kana;
}
