package com.nissan.common.dto;

import com.nissan.common.entity.DemoCarModel;
import com.nissan.common.entity.DemoCarPackagePlan;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class ActiveVinListDto {
    private String ncJoinDate;
    private DemoCarModel model;
    private String vin;
    private String status;
    private String carPlan;
    private DemoCarPackagePlan packagePlan;
    private String companyName;
    private String dealershipName;
    private String caNameLending;
    private String caName;
    private Long ncasNumber;
    private Boolean ivi;
    private String flagType;
    private String flagTypeDisplayName;
    private String source;
    private String sourceDisplayName;
    private String expirationMonthNc;
    private String statusDisplayName;
    private LocalDateTime enrollmentDate;
    private boolean icc;
}
