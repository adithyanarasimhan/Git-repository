package com.nissan.common.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "bank_details")
public class BankDetails {

    @Id
    private Long id;

    @Column(name = "bank_code")
    private Long bankCode;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "branch_shop_code")
    private Long branchShopCode;

    @Column(name = "branch_shop_name")
    private String branchShopName;
}
