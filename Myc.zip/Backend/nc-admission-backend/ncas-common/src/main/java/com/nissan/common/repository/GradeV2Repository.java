package com.nissan.common.repository;

import com.nissan.common.entity.GradeV2;
import com.nissan.common.entity.ModelV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface GradeV2Repository extends JpaRepository<GradeV2, Long>, QuerydslPredicateExecutor<GradeV2> {
    @Query(value = "SELECT * FROM gradev2 WHERE model_id =?1", nativeQuery = true)
    List<GradeV2> getGradesByModelId(Long modelId);

    List<GradeV2> findByModelAndVehicleTypeIn(ModelV2 model, Set<String> vehicleType);

    GradeV2 findByModelIdAndCwGradeNameAndLangCode(Long modelId, String cwGradeName, String langCode);
}
