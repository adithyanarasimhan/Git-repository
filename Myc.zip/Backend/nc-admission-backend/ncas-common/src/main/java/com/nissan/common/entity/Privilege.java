package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "privilege")
@EntityListeners(AuditingEntityListener.class)
public class Privilege extends Auditable<String> {
  @Id
  @Column(name = "privilege_id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "privilege_Sequence")
  @SequenceGenerator(
      name = "privilege_Sequence",
      sequenceName = "PRIVILEGE_SEQ",
      allocationSize = 1)
  private Long id;

  @Column(name = "name")
  private String name;
}
