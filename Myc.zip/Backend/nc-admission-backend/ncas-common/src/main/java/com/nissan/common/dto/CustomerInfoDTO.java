package com.nissan.common.dto;

import lombok.Data;

@Data
public class CustomerInfoDTO {
    private String customerName;
    private String mobileNumber;

}
