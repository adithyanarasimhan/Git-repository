package com.nissan.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.nissan.common.util.CustomerValidator;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

@Data
@CustomerValidator.List({
  @CustomerValidator(
      fieldName = "customerType",
      fieldValue = "0",
      dependFieldName = {
        "firstName",
        "firstNameKatakana",
        "familyName",
        "familyNameKatakana",
        "address1",
        "phoneNumber",
        "zipCode"
      }),
  @CustomerValidator(
      fieldName = "customerType",
      fieldValue = "1",
      dependFieldName = {
        "corporateName",
        "officePosition",
        "representativeName",
        "representativeNameKatakana",
        "address1",
        "phoneNumber",
        "zipCode"
      })
})
public class CustomerDTO {

  @Size(max = 20)
  private String familyName;

  @Size(max = 20)
  private String familyNameKatakana;

  @Size(max = 20)
  private String firstName;

  @Size(max = 20)
  private String firstNameKatakana;

  @Size(max = 100)
  private String address1;

  @Size(max = 50)
  private String address2;

  @Size(max = 11)
  private String phoneNumber;

  @Size(max = 11)
  private String optionalPhoneNumber;

  @Size(max = 7)
  private String zipCode;

  @Size(max = 40)
  private String corporateName;

  @Size(max = 50)
  private String officePosition;

  @Size(max = 50)
  private String representativeName;

  @Size(max = 50)
  private String representativeNameKatakana;

  @Email(message = "Please enter a valid email id")
  private String email;

  private Long customerType;
  private Long stepCount;
  private Long userId;
  @JsonIgnore
  private Long Id;
}
