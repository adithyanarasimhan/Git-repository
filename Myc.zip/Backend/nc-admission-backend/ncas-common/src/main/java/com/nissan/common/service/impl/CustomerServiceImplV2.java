package com.nissan.common.service.impl;

import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.service.CustomerServiceV2;
import com.nissan.common.service.MapionService;
import com.nissan.common.util.FormatValue;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.nissan.common.util.Constants.*;

@Service
public class CustomerServiceImplV2 implements CustomerServiceV2 {

  private static final Logger logger = LoggerFactory.getLogger(CustomerServiceImplV2.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(CustomerServiceImplV2.class);

  @Autowired private CustomerRepository customerRepository;

  @Autowired private PaymentRepository paymentRepository;

  @Autowired private UserRepository userRepository;

  @Autowired private CardBrandRepository cardBrandRepository;

  @Autowired private AdmissionV2Repository admissionV2Repository;

  @Autowired private OrdersV2Repository ordersV2Repository;

  @Autowired private NicosPaymentRepository nicosPaymentRepository;

  @Autowired private DealerAddressRepository dealerAddressRepository;

  @Autowired private PaymentMethodRepository paymentMethodRepository;

  @Autowired private LocationAddressRepository locationAddressRepository;

  @Autowired private MapionService mapionService;

  @Override
  @Transactional
  public CustomerGetResponseDTO fetchCustomerPlanDetailsV2(String userName, String langCode)
      throws Exception {
    CustomerGetResponseDTO customerGetResponseDTO = new CustomerGetResponseDTO();
    try {
      logger.info("Fetching customer details");
      List<CardBrandDTO> listOfCardsDto = new ArrayList<>();
      User user = userRepository.findById(Long.valueOf(userName)).get();
      AdmissionV2 admission = admissionV2Repository.fetchByUserId(user.getId());
      if (admission != null) {
        OrdersV2 ordersV2 = ordersV2Repository.findByAdmissionId(admission.getId());
        logger.info("source : {}", ordersV2.getSource());
        customerGetResponseDTO.setSource(ordersV2.getSource());
        if (ordersV2 != null && ordersV2.getPackagePlan() != null) {
          PackagePlanV2 packagePlanV2 = ordersV2.getPackagePlan();
          customerGetResponseDTO.setAmount(packagePlanV2.getPrice());
          customerGetResponseDTO.setPackagePlan(packagePlanV2.getDisplayName());
          customerGetResponseDTO.setPackagePlanName(packagePlanV2.getPackagePlanName());
          customerGetResponseDTO.setAdminFee(packagePlanV2.getAdminFee());
        }
        if (ordersV2 != null && ordersV2.getNavi() != null) {
          customerGetResponseDTO.setNaviName(ordersV2.getNavi().getNaviName());
        }
        List<CardBrand> listOfCards = cardBrandRepository.findByLangCode(langCode);
        if (!listOfCards.isEmpty()) {
          listOfCards.forEach(
              cardBrand -> {
                CardBrandDTO cardBrandDTO = new CardBrandDTO();
                cardBrandDTO.setId(cardBrand.getId());
                cardBrandDTO.setName(cardBrand.getName());
                listOfCardsDto.add(cardBrandDTO);
              });
        }
        customerGetResponseDTO.setCardBrand(listOfCards);

        Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
        if (customer != null) {
          customerGetResponseDTO.setStepCount(customer.getStepCount());
          customerGetResponseDTO.setEmail(customer.getEmail());
        }

        /** Setting NICOS payment status FAILED for retry payment */
        if (ordersV2.getPaymentMethod() != null
            && PAYMENT_METHOD_BANK.equals(ordersV2.getPaymentMethod().getName())) {
          NicosPayment nicosPayment = nicosPaymentRepository.findByCustomerId(customer.getId());
          if (nicosPayment != null) {
            if (PAYMENT_COMPLETE.equals(nicosPayment.getPaymentStatus())) {
              customerGetResponseDTO.setPaymentStatus(SUCCESS);
            } else {
              customerGetResponseDTO.setPaymentStatus(FAILED);
            }
          }
        }

        List<String> listPrefecture = locationAddressRepository.getPrefecture();
        if (!listPrefecture.isEmpty()) {
          customerGetResponseDTO.setPrefectureName(listPrefecture);
        }
      }

    } catch (Exception e) {
      throw new Exception("Error in fetching details : " + e.getMessage());
    }
    return customerGetResponseDTO;
  }

  @Override
  public CustomerSummaryDTOV2 fetchCustomerByUserAndLangCodeV2(String userName, String lang) {
    logger.info("inside CustomerServiceImpl fetchCustomerByUserAndLangCode");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"user id is= "+ userName );
    CustomerSummaryDTOV2 customerSummaryDto = new CustomerSummaryDTOV2();
    User user = userRepository.findById(Long.valueOf(userName)).get();
    Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
    if (customer != null) {
      customerSummaryDto.setFirstName(customer.getFirstName());
      customerSummaryDto.setFamilyName(customer.getFamilyName());
      customerSummaryDto.setCustomerType(customer.getCustomerType());
      customerSummaryDto.setFirstNameKatakana(customer.getFirstNameKatakana());
      customerSummaryDto.setFamilyNameKatakana(customer.getFamilyNameKatakana());
      customerSummaryDto.setAddress1(customer.getAddress1());
      customerSummaryDto.setAddress2(customer.getAddress2());
      customerSummaryDto.setEmail(customer.getEmail());
      customerSummaryDto.setPhoneNumber(
          appendCustomerDetails(customer.getPhoneNumber1())
              + appendCustomerDetails(customer.getPhoneNumber2())
              + appendCustomerDetails(customer.getPhoneNumber3()));
      customerSummaryDto.setOptionalPhoneNumber(
          appendCustomerDetails(customer.getOptionalPhoneNumber1())
              + appendCustomerDetails(customer.getOptionalPhoneNumber2())
              + appendCustomerDetails(customer.getOptionalPhoneNumber3()));
      customerSummaryDto.setCorporateName(customer.getCorporateName());
      customerSummaryDto.setRepresentativeName(customer.getRepresentativeName());
      customerSummaryDto.setRepresentativeNameKatakana(customer.getRepresentativeNameKatakana());
      customerSummaryDto.setOfficePosition(customer.getOfficePosition());
      Payment payment = paymentRepository.fetchByCustomerId(customer.getId());
      customerSummaryDto.setZipCode(
          appendCustomerDetails(customer.getZipCode1())
              + appendCustomerDetails(customer.getZipCode2()));
      if (payment != null) {
        customerSummaryDto.setNameOnCard(payment.getCardName());
        CardBrand cardBrand = cardBrandRepository.fetchByLangCodeAndId(payment.getCardBrand());
        customerSummaryDto.setCardType(cardBrand.getName());
        customerSummaryDto.setExpiryDate(
            payment.getExpiryMonth().toString() + "/" + payment.getExpiryYear().toString());
        String cardNumber =
            isNotNullOrEmpty(payment.getCardNumber1())
                + isNotNullOrEmpty(payment.getCardNumber2())
                + isNotNullOrEmpty(payment.getCardNumber3())
                + isNotNullOrEmpty(payment.getCardNumber4());
        if (cardNumber != null && !cardNumber.isEmpty() && !cardNumber.equals("")) {
          cardNumber.replaceAll("\\d(?=(?:\\D*\\d){4})", "*");
          customerSummaryDto.setCardNumber(cardNumber);
        }
      }
    }

    AdmissionV2 admission = admissionV2Repository.fetchByUserId(user.getId());
    if (admission != null) {
      OrdersV2 order = ordersV2Repository.findByAdmissionId(admission.getId());
      customerSummaryDto.setFileName(admission.getDocumentName());
      if (order != null) {
        if (order != null && order.getPackagePlan() != null) {
          PackagePlanV2 packagePlanV2 = order.getPackagePlan();
          customerSummaryDto.setPackagePlan(packagePlanV2.getDisplayName());
          customerSummaryDto.setAmount(packagePlanV2.getPrice());
          customerSummaryDto.setAdminFee(packagePlanV2.getAdminFee());
          DealerAddressDTO dealerAddressDTO = createDealerAddress(admission.getId());
          if (dealerAddressDTO != null) {
            customerSummaryDto.setDealerAddressDTO(dealerAddressDTO);
          }
        }
        customerSummaryDto.setVinNumber(order.getVinNumber());
        if (order.getModel() != null) {
          customerSummaryDto.setModel(order.getModel().getDisplayName());
          if (order.getColor() == null) {
            customerSummaryDto.setImgUrl(order.getModel().getUrl());
          } else {
            customerSummaryDto.setImgUrl(order.getColor().getImageURL());
          }
        }
        if (order.getGrade() != null) {
          customerSummaryDto.setGrade(order.getGrade().getDisplayName());
        }
        if (order.getNavi() != null) {
          customerSummaryDto.setNaviType(order.getNavi().getDisplayName());
        }
        if (order.getOptions() != null) {
          customerSummaryDto.setOptionsName(order.getOptions().getDisplayName());
        }
        if (order.getVehicleTransfer() != null) {
          customerSummaryDto.setVehicleTransfer(order.getVehicleTransfer());
        }
        if (order.getOldVinNumber() != null) {
          customerSummaryDto.setOldVinNumber(order.getOldVinNumber());
        }
      }
    }
    return customerSummaryDto;
  }

  private DealerAddressDTO createDealerAddress(Long id) {
    DealerAddressDTO addressDTO = null;
    DealerAddress dealerAddress = dealerAddressRepository.findByAdmissionId(id);
    if (dealerAddress != null) {
      addressDTO = new DealerAddressDTO();
      addressDTO.setCompanyCode(dealerAddress.getCompanyCode());
      addressDTO.setCompanyName(dealerAddress.getCompanyName());
      addressDTO.setDealerName(dealerAddress.getDealershipName());
      addressDTO.setDealershipCode(dealerAddress.getDealershipCode());
      addressDTO.setPrefectureName(dealerAddress.getPrefectureName());
      addressDTO.setAddress(dealerAddress.getDealershipAddress());
      addressDTO.setPhoneNumber(dealerAddress.getPhoneNumber());
      if (StringUtils.isNotEmpty(dealerAddress.getZipCode())) {
        addressDTO.setZipCode(dealerAddress.getZipCode());
      } else {
        addressDTO.setPrefecture(dealerAddress.getPrefecture());
        addressDTO.setCity1(dealerAddress.getCity1());
        addressDTO.setCity2(dealerAddress.getCity2());
      }
      addressDTO.setRadius(dealerAddress.getRadius());
      addressDTO.setVisitDate(dealerAddress.getVisitDate());
      addressDTO.setVisitTime(dealerAddress.getVisitTime());
      addressDTO.setRegularClosingDay1(dealerAddress.getRegularClosingDay1());
      addressDTO.setRegularClosingDay2(dealerAddress.getRegularClosingDay2());
      addressDTO.setTotalDistance(dealerAddress.getTotalDistance());
      addressDTO.setLatitude(dealerAddress.getLatitude());
      addressDTO.setLongitude(dealerAddress.getLongitude());
      addressDTO.setLabel(dealerAddress.getLabel());
    }
    return addressDTO;
  }

  private String isNotNullOrEmpty(String cardNumber) {
    if (cardNumber == null) {
      return "";
    } else {
      return cardNumber;
    }
  }

  private String appendCustomerDetails(String value) {
    if (value == null) {
      return "";
    } else {
      return value.toString();
    }
  }

  @Override
  @Transactional
  public CustomerResponseDTO updateCustomerById(
      CustomerDTO customerDto, String userName, String langCode) throws Exception {
    logger.info("Inside update customer by id");
    Customer customerEntity = null;
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"user id= "+ userName);
    User user = userRepository.findById(Long.valueOf(userName)).get();
    logger.info("User Id:" + user.getId());
    Customer customer = customerRepository.findCustomerByUserId(user.getId());
    if (customer == null) {
      return null;
    } else {
      customerEntity = checkIndividualCorporate(customerDto, customer, user, langCode);
      return getCustomerResponse(customerEntity);
    }
  }

  private Customer checkIndividualCorporate(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    Customer updatedCustomer;
    if (customerDto.getCustomerType() == 0) {
      updatedCustomer = setIndividualValues(customerDto, customer, user, langCode);
    } else {
      updatedCustomer = setCorporateValues(customerDto, customer, user, langCode);
    }
    return updatedCustomer;
  }

  private Customer setCorporateValues(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    logger.info("Setting corporate values");

    customer.setCorporateName(customerDto.getCorporateName());
    customer.setOfficePosition(customerDto.getOfficePosition());
    customer.setRepresentativeName(customerDto.getRepresentativeName());
    customer.setRepresentativeNameKatakana(customerDto.getRepresentativeNameKatakana());
    customer.setAddress1(customerDto.getAddress1());
    customer.setAddress2(customerDto.getAddress2());

    /** setting individual values as null when customer is corporate */
    customer.setFamilyName(null);
    customer.setFamilyNameKatakana(null);
    customer.setFirstName(null);
    customer.setFirstNameKatakana(null);

    return setCommonValues(customerDto, customer, user, langCode);
  }

  @Transactional
  private Customer setIndividualValues(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    logger.info("Setting individual values");
    customer.setFamilyName(customerDto.getFamilyName());
    customer.setFamilyNameKatakana(customerDto.getFamilyNameKatakana());
    customer.setFirstName(customerDto.getFirstName());
    customer.setFirstNameKatakana(customerDto.getFirstNameKatakana());
    customer.setAddress1(customerDto.getAddress1());
    customer.setAddress2(customerDto.getAddress2());
    /** setting corporate values as null when customer is individual */
    customer.setCorporateName(null);
    customer.setOfficePosition(null);
    customer.setRepresentativeName(null);
    customer.setRepresentativeNameKatakana(null);

    // Set customer details in ordersv2 entity for dynamic filter
    AdmissionV2 admissionV2 = admissionV2Repository.fetchByUserId(user.getId());
    OrdersV2 ordersV2 = ordersV2Repository.findByAdmissionId(admissionV2.getId());

    ordersV2.setCustomerName(customerDto.getFirstName());
    ordersV2.setCustomerNameKana(customerDto.getFirstNameKatakana());
    ordersV2.setCustomerPhoneNumber(customerDto.getPhoneNumber());
    ordersV2.setCustomerZipCode(customerDto.getZipCode());

    ordersV2Repository.save(ordersV2);

    return setCommonValues(customerDto, customer, user, langCode);
  }

  private Customer setCommonValues(
      CustomerDTO customerDto, Customer customer, User user, String langCode) {
    customer.setCustomerType(customerDto.getCustomerType());
    //  customer.setStepCount(customerDto.getStepCount());
    Map<String, String> zip = FormatValue.formatZipCode(customerDto.getZipCode());
    customer.setZipCode1(zip.get("firstThreeDigits"));
    customer.setZipCode2(zip.get("lastFourDigits"));

    if (customerDto.getPhoneNumber().length() == 11) {
      Map<String, String> phone = FormatValue.formatPhoneNumber(customerDto.getPhoneNumber());
      customer.setPhoneNumber1(phone.get("firstThreeDigits"));
      customer.setPhoneNumber2(phone.get("middleFourDigits"));
      customer.setPhoneNumber3(phone.get("lastFourDigits"));
    } else {
      Map<String, String> phone =
          FormatValue.formatPhoneNumberTenDigits(customerDto.getPhoneNumber());
      customer.setPhoneNumber1(phone.get("firstThreeDigits"));
      customer.setPhoneNumber2(phone.get("middleFourDigits"));
      customer.setPhoneNumber3(phone.get("lastFourDigits"));
    }

    if (customerDto.getOptionalPhoneNumber() != null
        && !customerDto.getOptionalPhoneNumber().isEmpty()
        && !customerDto.getOptionalPhoneNumber().equals("")) {
      if (customerDto.getOptionalPhoneNumber().length() == 11) {
        Map<String, String> optionalPhone =
            FormatValue.formatPhoneNumber(customerDto.getOptionalPhoneNumber());
        customer.setOptionalPhoneNumber1(optionalPhone.get("firstThreeDigits"));
        customer.setOptionalPhoneNumber2(optionalPhone.get("middleFourDigits"));
        customer.setOptionalPhoneNumber3(optionalPhone.get("lastFourDigits"));
      } else {
        Map<String, String> optionalPhone =
            FormatValue.formatPhoneNumberTenDigits(customerDto.getOptionalPhoneNumber());
        customer.setOptionalPhoneNumber1(optionalPhone.get("firstThreeDigits"));
        customer.setOptionalPhoneNumber2(optionalPhone.get("middleFourDigits"));
        customer.setOptionalPhoneNumber3(optionalPhone.get("lastFourDigits"));
      }
    }
    logger.info("Updating customer details");

    Customer updatedCustomer = customerRepository.save(customer);
    return updatedCustomer;
  }

  public CustomerResponseDTO saveStepCount(String principleId, String count) {
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Updating Step Count "+ count);
    CustomerResponseDTO customerResponseDTO = null;
    User user = userRepository.findById(Long.valueOf(principleId)).get();
    Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
    customer.setStepCount(Long.valueOf(count));
    customerRepository.save(customer);
    customerResponseDTO = getCustomerResponse(customer);
    AdmissionV2 admission = admissionV2Repository.fetchByUserId(customer.getUser().getId());
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Step Count "+ count);
    if (admission != null && count.equals("5")) {
      OrdersV2 ordersV2 = ordersV2Repository.findByAdmissionId(admission.getId());
      ModelV2 vehicleModel = ordersV2.getModel();
      logger.info("Model name : {}", vehicleModel.getModelName());
      NaviV2 naviV2 = ordersV2.getNavi();
      Boolean sosOption = false;
      if(naviV2 != null) {
        logger.info("Navi sos option : {}", naviV2.getColorOption());
        sosOption = naviV2.getColorOption() == null ? false : naviV2.getColorOption();
      }
      logger.info("Model details for Dealer API {}", vehicleModel);
      if (EV19_TEMPLATES_USING_MODELS.contains(vehicleModel.getModelName()) || sosOption) {
        String visitStatus = mapionService.getDealerVisitStatus(admission.getId());
        logger.info("Dealer API response detail {}", visitStatus);
        customerResponseDTO.setDealerVisitStatus(visitStatus);
      }
    }
    return customerResponseDTO;
  }

  @Override
  @Transactional
  public TempPwdDTO fetchTemporaryPwd(String token, String langCode) throws Exception {
    logger.info("Inside fetch customer temporary password");
    TempPwdDTO tempPwdDTO = new TempPwdDTO();
    User user = userRepository.findByEncodedToken(token);
    AdmissionV2 admission = admissionV2Repository.fetchByUserId(Long.valueOf(user.getId()));
    if (admission == null) {
      return null;
    } else {
      tempPwdDTO.setTempPassword(admission.getNcPassword());
      return tempPwdDTO;
    }
  }

  private CustomerResponseDTO getCustomerResponse(Customer customer) {
    if (customer == null) {
      return null;
    }
    CustomerResponseDTO customerResponse = new CustomerResponseDTO();
    customerResponse.setAddress1(customer.getAddress1());
    customerResponse.setAddress2(customer.getAddress2());
    customerResponse.setCorporateName(customer.getCorporateName());
    customerResponse.setCustomerType(customer.getCustomerType());
    customerResponse.setEmail(customer.getEmail());
    customerResponse.setFamilyName(customer.getFamilyName());
    customerResponse.setFamilyNameKatakana(customer.getFamilyNameKatakana());
    customerResponse.setFirstName(customer.getFirstName());
    customerResponse.setFirstNameKatakana(customer.getFirstNameKatakana());
    customerResponse.setOfficePosition(customer.getOfficePosition());
    customerResponse.setPhoneNumber(
        appendCustomerDetails(customer.getPhoneNumber1())
            + appendCustomerDetails(customer.getPhoneNumber2())
            + appendCustomerDetails(customer.getPhoneNumber3()));
    customerResponse.setOptionalPhoneNumber(
        appendCustomerDetails(customer.getOptionalPhoneNumber1())
            + appendCustomerDetails(customer.getOptionalPhoneNumber2())
            + appendCustomerDetails(customer.getOptionalPhoneNumber3()));
    customerResponse.setRepresentativeName(customer.getRepresentativeName());
    customerResponse.setRepresentativeNameKatakana(customer.getRepresentativeNameKatakana());
    customerResponse.setStepCount(customer.getStepCount());
    customerResponse.setZipCode(
        appendCustomerDetails(customer.getZipCode1())
            + appendCustomerDetails(customer.getZipCode2()));
    return customerResponse;
  }
}
