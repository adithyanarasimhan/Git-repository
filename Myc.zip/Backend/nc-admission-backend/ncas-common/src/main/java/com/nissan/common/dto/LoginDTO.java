package com.nissan.common.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class LoginDTO {
  @NotEmpty private String nissanID;
  @NotEmpty private String temporaryPassword;
}
