package com.nissan.common.repository;

import com.nissan.common.entity.NicosPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface NicosPaymentRepository extends JpaRepository<NicosPayment, Long> {

  @Query(value = "select * from nicos_payment where customer_number=?1", nativeQuery = true)
  NicosPayment fetchByCustomerNumber(String customerNumber);

  @Query(value = "select * from nicos_payment where customer_id=?1 LIMIT 1", nativeQuery = true)
  NicosPayment findByCustomerId(Long id);

  @Query(value = "select max(id) from nicos_payment", nativeQuery = true)
  Long findTopByNicosPayment();

  @Query(value = "select * from nicos_payment order by id desc LIMIT 1", nativeQuery = true)
  NicosPayment findLatestRecord();
}
