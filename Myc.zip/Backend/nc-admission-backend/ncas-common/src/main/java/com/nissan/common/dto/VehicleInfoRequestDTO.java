package com.nissan.common.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class VehicleInfoRequestDTO {
    @NotBlank
    @Size(max = 18, min = 1)
    private String vinNumber;
    private String registrationDate;
    private String firstRegistrationDate;
    private String expiryDate;
    private String naviId;
    @NotBlank
    private String vehicleType;
    private String source;
    private Boolean skipNaviId;
    private String vehicleNumber;
}
