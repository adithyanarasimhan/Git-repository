package com.nissan.common.dto;

import com.nissan.common.entity.Color;
import com.nissan.common.util.Constants;
import com.nissan.common.util.FormatValue;
import lombok.Data;

import java.time.LocalDate;
import java.util.Date;

@Data
public class DownloadCsvOrderV2ListDTO {
  private String createdDate;
  private String status;
  private Long id;
  private String admissionType;
  private String ordersNumber;
  private String companyCode;
  private String companyName;
  private String dealershipName;
  private String phoneNumber;
  private String caName;
  private String caNameKana;
  private String caCode;
  private String email;
  private Long customerType;
  private String modelName;
  private String gradeName;
  private String naviName;
  private String optionsName;
  private String packagePlanName;
  private String vinNumber;
  private String registrationDate;
  private String vinRegisteredDate;
  private String ncId;
  private String cwStatus;
  private String ncJoinedDate;
  private String chargeStartDate;
  private String serviceUpdateDate;
  private String adopterId;
  private String registerNumber;
  private String cwModelName;
  private String planPrice;
  private String emailSendDate;
  private String name;
  private Boolean vehicleTransfer;
  private String oldVinNumber;
  private Boolean active;
  private String source;
  private String vehicleType;
  private String iviFlag;
  private String sosFlag;
  private String paperReason;
  private Long reasonId;
  private String paperReasonFreeComment;

  public DownloadCsvOrderV2ListDTO(
      Date createdDate,
      String status,
      Long id,
      String ordersNumber,
      String companyCode,
      String companyName,
      String dealershipName,
      String phoneNumber,
      String caName,
      String caNameKana,
      String caCode,
      String email,
      Long customerType,
      String modelName,
      String gradeName,
      String naviName,
      String optionsName,
      String packagePlanName,
      String vinNumber,
      String registrationDate,
      Date vinRegisteredDate,
      String ncId,
      String cwStatus,
      Date ncJoinedDate,
      Date chargeStartDate,
      Date serviceUpdateDate,
      String adopterId,
      String registerNumber,
      String cwModelName,
      String planPrice,
      LocalDate emailSendDate,
      String name,
      Boolean vehicleTransfer,
      String oldVinNumber,
      Boolean active,
      String source,
      String vehicleType,
      Boolean iviFlag,
      Boolean colorOption,
      Long reasonId,
      String paperReasonFreeComment) {
    this.createdDate = FormatValue.formatDateMinutes(createdDate);
    this.status = status;
    this.id = id;
    this.ordersNumber = ordersNumber;
    this.companyCode = companyCode;
    this.companyName = companyName;
    this.dealershipName = dealershipName;
    this.phoneNumber = phoneNumber;
    this.caName = caName;
    this.caNameKana = caNameKana;
    this.caCode = caCode;
    this.email = email;
    this.customerType = customerType;
    this.modelName = modelName;
    this.gradeName = gradeName;
    this.naviName = naviName;
    this.optionsName = optionsName;
    this.packagePlanName = packagePlanName;
    this.vinNumber = vinNumber;
    this.registrationDate = registrationDate;
    this.vinRegisteredDate = FormatValue.formatDate(vinRegisteredDate);
    this.ncId = ncId;
    this.cwStatus = cwStatus;
    this.ncJoinedDate = FormatValue.formatDate(ncJoinedDate);
    this.chargeStartDate = FormatValue.formatDate(chargeStartDate);
    this.serviceUpdateDate = FormatValue.formatDate(serviceUpdateDate);
    this.adopterId = adopterId;
    this.registerNumber = registerNumber;
    this.cwModelName = cwModelName;
    this.planPrice = planPrice;
    this.emailSendDate = FormatValue.formatLocalDate(emailSendDate);
    this.name = getPaymentMethod(name);
    this.vehicleTransfer = vehicleTransfer;
    this.oldVinNumber = oldVinNumber;
    this.active = active;
    this.source = Constants.ADMISSION_SOURCE_HOME.equals(source) ? "店舗外" : "店舗";
    this.vehicleType = Constants.VEHICLE_TYPE_NEW_CAR.equals(vehicleType) ? "新車（VINあり）" : "中古車";
    this.iviFlag = (iviFlag != null && iviFlag) ? "1" : "0";
    this.sosFlag = (colorOption != null && colorOption) ? "1" : "0";
    this.reasonId = reasonId;
    this.paperReasonFreeComment = (paperReasonFreeComment != null) ? paperReasonFreeComment : "";
  }

  private String getPaymentMethod(String paymentMethodName) {
    if(paymentMethodName != null) {
      switch (paymentMethodName) {
        case "credit":
          paymentMethodName = "credit 支払い選択済み";
          break;
        case "credit-card":
          paymentMethodName = "credit-card 情報入力済み";
          break;
      }
    }
    return paymentMethodName;
  }
}
