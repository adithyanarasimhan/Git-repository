package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "package_planv2")
@EntityListeners(AuditingEntityListener.class)
public class PackagePlanV2 extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "navi_id", referencedColumnName = "id")
    private NaviV2 navi;

    @Column(name = "package_plan_name")
    private String packagePlanName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "cw_package_plan_name")
    private String cwPackagePlanName;

    @Column(name = "description")
    private String description;

    @Column(name = "price")
    private Long price;

    @Column(name = "admin_fee")
    private Long adminFee;

    @Column(name = "pattern_name")
    private String patternName;

    @Column(name = "terms_name")
    private String termsName;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "category")
    private String category;

    @Column(name = "vehicle_type")
    private String vehicleType;
}
