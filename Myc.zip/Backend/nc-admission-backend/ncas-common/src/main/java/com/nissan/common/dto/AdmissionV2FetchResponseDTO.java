package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class AdmissionV2FetchResponseDTO {
  private ModelV2DTO cwModel;
  private List<ModelV2DTO> models;
  private List<ReasonDTO> reasonTypesPaper;
  private List<PaymentMethodDto> paymentTypes;
  private DealerDTO dealerDetails;
  private String responseCode;
  private String errorMessage;
  private String registrationDate;
  private String firstRegistrationDate;
  private String expiryDate;
  private String vinNumber;
  private String naviId;
  private String colorCode;
  private String color;
  private List<ColorDTO> colors;
  private Boolean dopFlg;
  private String dopValue;
  private String cwVehicleStatus;
  private String oldCwId;
  private String vehicleNumber;
}
