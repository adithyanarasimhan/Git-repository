package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class FetchRecentAdmissionDTO {
    private List<RecentAdmissionResponseDTO> recentAdmissions;
    private String dateRange;
    private Long totalCount;
}
