package com.nissan.common.repository;

import com.nissan.common.entity.Navi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NaviRepository extends JpaRepository<Navi, Long>, QuerydslPredicateExecutor<Navi> {
  @Query(value = "SELECT * FROM navi where grade_id=?1", nativeQuery = true)
  List<Navi> getNaviListByGradeName(long gradeId);
}
