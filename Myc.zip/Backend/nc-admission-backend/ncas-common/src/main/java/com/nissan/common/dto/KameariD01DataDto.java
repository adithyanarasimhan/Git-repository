package com.nissan.common.dto;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import lombok.Data;

@Data
public class KameariD01DataDto {

	private String profitDealerCode;
	private String orderNo;
	private String dealerName;
	private String caShopName = "その他";
	private String caShopTel1;
	private String caShopTel2;
	private String caShopTel3;
	private String caName;
	private String personalOrCorporation = "0";
	private String kanjiName = "日産自動車株式会社";
	private String katakanaName = "ニッサンジドウシャカブシキガイシャ";
	private String birthYear = "";
	private String birthMonth = "";
	private String birthDay = "";
	private String gender = "M";
	private String postalCodePrefix = "220";
	private String postalCodeSuffix = "6217";
	private String address1 = "横浜市西区みなとみらい２−３−５";
	private String address2 = "";
	private String dealerTel;
	private String dmKind = "0";
	private String telemaKind = "0";
	private String cwMobilePhoneNumber = "00000000000";
	private String carrierKind = "2";
	private String changeKind = "0";
	private String registNumber1 = "300";
	private String registNumber2 = "ｱ";
	private String registNumber3 = "1111";
	private String registNumber4 = "東京";
	private String vinChassisModel;
	private String vinChassisNumber;
	private String cwRegistDate;
	private String profitAplicationDate;
	private String profitLastUpdated;
	private String profitCWdataTransmissionDate;
	private String updateKind = "1";
	private String customerNo = "";
	private String mopOrDop = "2";
	private String naviId = "";
	private String shopCode = "ZZZ";
	private String modelCode = "";
	private String basicCode = "";
	private String divisionCode = "";
	private String paintColorCode = "";
	private String linerTrimCode = "";
	private String preTransferVinChassisModel = "";
	private String preTransferVinChassisNo = "";
	private String serviceTypeFlag = "1";
	private String orderDate = "20110731";

	/*
	 * Method to create line content of D01 file with respect to the current Obj
	 * Size 4 9 30 12 5 4 5 20 1 60 40 4 2 2 1 3 4 100 50 12 1 1 13 1 1 3 1
	 * 4 8 12 8 8 8 8 8 1 12 1 10 3 7 3 8 3 1 12 8 1 8 531 29
	 */

	public String convertToD01Content() throws UnsupportedEncodingException {
		StringBuilder d01Content = new StringBuilder();
		d01Content.append(addSpacesRight(profitDealerCode, 4))
				.append(addSpacesRight(orderNo, 9))
				.append(addSpacesRight(dealerName, 30))
				.append(addSpacesRight(caShopName, 12))
				.append(addSpacesRight(caShopTel1, 5))
				.append(addSpacesRight(caShopTel2, 4))
				.append(addSpacesRight(caShopTel3, 5))
				.append(addSpacesRight(caName, 20))
				.append(addSpacesRight(personalOrCorporation, 1))
				.append(addSpacesRight(kanjiName, 60))
				.append(addSpacesRight(katakanaName, 40))
				.append(addSpacesRight(birthYear, 4))
				.append(addSpacesRight(birthMonth, 2))
				.append(addSpacesRight(birthDay, 2))
				.append(addSpacesRight(gender, 1))
				.append(addSpacesRight(postalCodePrefix, 3))
				.append(addSpacesRight(postalCodeSuffix, 4))
				.append(addSpacesRight(address1, 100))
				.append(addSpacesRight(address2, 50))
				.append(addSpacesRight(dealerTel, 12))
				.append(addSpacesRight(dmKind, 1))
				.append(addSpacesRight(telemaKind, 1))
				.append(addSpacesRight(cwMobilePhoneNumber, 13))
				.append(addSpacesRight(carrierKind, 1))
				.append(addSpacesRight(changeKind, 1))
				.append(addSpacesRight(registNumber1, 3))
				.append(addSpacesRight(registNumber2, 1))
				.append(addSpacesRight(registNumber3, 4))
				.append(addSpacesRight(registNumber4, 8))
				.append(addSpacesRight(vinChassisModel, 12))
				.append(addSpacesRight(vinChassisNumber, 8))
				.append(addSpacesRight(cwRegistDate, 8))
				.append(addSpacesRight(profitAplicationDate, 8))
				.append(addSpacesRight(profitLastUpdated, 8))
				.append(addSpacesRight(profitCWdataTransmissionDate, 8))
				.append(addSpacesRight(updateKind, 1))
				.append(addSpacesRight(customerNo, 12))
				.append(addSpacesRight(mopOrDop, 1))
				.append(addSpacesRight(naviId, 10))
				.append(addSpacesRight(shopCode, 3))
				.append(addSpacesRight(modelCode, 7))
				.append(addSpacesRight(basicCode, 3))
				.append(addSpacesRight(divisionCode, 8))
				.append(addSpacesRight(paintColorCode, 3))
				.append(addSpacesRight(linerTrimCode, 1))
				.append(addSpacesRight(preTransferVinChassisModel, 12))
				.append(addSpacesRight(preTransferVinChassisNo, 8))
				.append(addSpacesRight(serviceTypeFlag, 1))
				.append(addSpacesRight(orderDate, 8));
		return d01Content.toString();
	}

	static StringBuilder addSpacesRight(String input, int strLength) throws UnsupportedEncodingException {
		StringBuilder output = new StringBuilder(input);
		int lengthToAppend = strLength - input.getBytes(Charset.forName("SJIS")).length;
		if (lengthToAppend > 0) {
			for (int i = 0; i < lengthToAppend; i++) {
				output.append(" ");
			}
		}
		if (output.toString().getBytes(Charset.forName("SJIS")).length > strLength) {
			if(input.getBytes(Charset.forName("SJIS")).length== (2*input.length()))
				return new StringBuilder(output.substring(0, strLength/2));
			else
				return new StringBuilder(output.substring(0, strLength));

		} else {
			return output;
		}
	}
}