package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "dealer")
@EntityListeners(AuditingEntityListener.class)
public class DealerEntity extends Auditable<String> {

    @Column(name = "company_code")
    private String companyCode;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "dealership_name")
    private String dealershipName;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "ca_name")
    private String caName;

    @Column(name = "ca_name_kana")
    private String caNameKana;

    @Column(name = "ca_code")
    private String caCode;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "email")
    private String email;

    @Column(name = "dealer_type")
    private String dealerType;

    @Id
    @Column(name = "dealer_id")
    private String dealerId;

    @Column(name = "profit_ca_company_code")
    private String profitCaCompanyCode;

    @Column(name = "dealership_code")
    private String dealerShipCode;

    @Column(name = "view_take_action")
    private Boolean viewTakeAction;
}
