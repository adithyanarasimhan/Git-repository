package com.nissan.common.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Component
@Data
public class DealerDTO {

  @Min(value = 1, message = "Please enter a valid company code")
  private String companyCode;

  @NotBlank(message = "Please enter a valid company name")
  private String companyName;

  @NotBlank(message = "Please enter a valid dealership name")
  private String dealershipName;

  @NotBlank(message = "Please enter a valid phone number")
  @Digits(integer = 10, fraction = 0)
  private String phoneNumber;

  @NotBlank(message = "Please enter a valid ca Name")
  private String caName;

  @NotBlank(message = "Please enter a valid ca Name Kana")
  private String caNameKana;

  private Long userId;

  private String dealerId;

  private String dealerType;

  private String email;

  private String profitCaCompanyCode;

  @Min(value = 1, message = "Please enter a valid ca code")
  private String caCode;

  private String dealerShipCode;
}
