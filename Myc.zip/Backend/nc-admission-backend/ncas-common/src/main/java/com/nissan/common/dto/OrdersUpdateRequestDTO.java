package com.nissan.common.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class OrdersUpdateRequestDTO {
  @NotBlank(message = "Please enter a valid order number")
  public String orderNumber;

  public Integer packagePlan;
  public Boolean vehicleTransfer;
  public String vinNumber;
  public Long userId;
  private CustomerDTO customerDetails;
  private DealerDetailsRequestDTO dealerDetails;
}
