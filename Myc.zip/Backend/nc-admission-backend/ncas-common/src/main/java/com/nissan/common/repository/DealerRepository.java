package com.nissan.common.repository;

import com.nissan.common.dto.DownloadCsvOrderListDTO;
import com.nissan.common.entity.DealerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface DealerRepository extends JpaRepository<DealerEntity, Integer> {
    DealerEntity findByUserId(Long id);

    DealerEntity findByCompanyCode(String id);

    DealerEntity findByCompanyCodeAndLangCode(String companyCode, String langCode);

    DealerEntity findByDealerId(String dealerId);

    DealerEntity findByCompanyCodeAndDealerShipCode(String companyCode, String dealerShipCode);

    @Query(
            "SELECT new com.nissan.common.dto.DownloadCsvOrderListDTO (a.createdDate,a.statusJp,o.admissionType,a.id,o.orderNumberPs,d.companyCode,o.companyName,o.dealershipName,o.phoneNumber,o.caName,o.caNameKana,o.caCode,d.email,c.customerType,m.modelName, g.gradeName, n.naviName,op.optionsName,pc.packagePlanName,m.category,o.cwVinNumber,o.firstRegisteredDate,a.vinRegisteredDate,a.ncId,a.cwStatus,o.ncJoinedDate,o.chargeStartDate,o.serviceUpdateDate,o.planPrice,o.adopterId,o.registerNumber,o.modelNameCw,a.emailSendDate,pm.name,o.vehicleTransfer,o.vinNumber,re.displayName,co.comment,o.active) FROM DealerEntity d JOIN Admission a on d.dealerId=a.dealer JOIN Orders o on a.id= o.admission LEFT JOIN Options op on op.id=o.options LEFT JOIN Model m on o.model=m.id LEFT JOIN Grade g on g.id=o.grade LEFT JOIN Navi n on n.id=o.navi LEFT JOIN PackagePlan pc on pc.id=o.packagePlan LEFT JOIN Customer c on c.user=a.user LEFT JOIN PaymentMethod pm on o.paymentMethod=pm.id LEFT JOIN Comment co on co.ordersId=o.id LEFT JOIN Reason re on re.id=co.reasonId WHERE o.createdDate >= :start and o.createdDate <= :end and o.active=:active")
    List<DownloadCsvOrderListDTO> fetchOrdersDetails(Timestamp start, Timestamp end, Boolean active);

    @Query(
            "SELECT new com.nissan.common.dto.DownloadCsvOrderListDTO (a.createdDate,a.statusJp,o.source,o.vehicleType,a.id,d.companyCode,o.companyName,o.dealershipName,o.phoneNumber,o.caName,o.caNameKana,o.caCode,d.email,c.customerType,m.modelName, g.gradeName, n.naviName,op.optionsName,pc.packagePlanName,m.category,o.vinNumber,a.vinRegisteredDate,a.ncId,a.cwStatus,o.chargeStartDate,o.serviceUpdateDate,o.planPrice,o.adopterId,o.registerNumber,a.emailSendDate,pm.name,o.vehicleTransfer,o.vinNumber,re.displayName,co.comment,o.active) FROM DealerEntity d JOIN AdmissionV2 a on d.dealerId=a.dealer JOIN OrdersV2 o on a.id= o.admission LEFT JOIN OptionsV2 op on op.id=o.options LEFT JOIN ModelV2 m on o.model=m.id LEFT JOIN GradeV2 g on g.id=o.grade LEFT JOIN NaviV2 n on n.id=o.navi LEFT JOIN PackagePlanV2 pc on pc.id=o.packagePlan LEFT JOIN Customer c on c.user=a.user LEFT JOIN PaymentMethod pm on o.paymentMethod=pm.id LEFT JOIN Comment co on co.ordersId=o.id LEFT JOIN Reason re on re.id=co.reasonId WHERE o.createdDate >= :start and o.createdDate <= :end and o.active=:active")
    List<DownloadCsvOrderListDTO> fetchOrdersV2Details(
            Timestamp start, Timestamp end, Boolean active);

    DealerEntity findByDealerShipCode(String dealerShipCode);
}
