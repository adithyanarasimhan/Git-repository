package com.nissan.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PaymentResponseDto {
  @JsonProperty("TransactionId")
  private String TransactionId;

  @JsonProperty("TransactionDate")
  private String TransactionDate;

  @JsonProperty("OperateId")
  private String OperateId;

  @JsonProperty("ProcessId")
  private String ProcessId;

  @JsonProperty("ProcessPass")
  private String ProcessPass;

  @JsonProperty("ResponseCd")
  private String ResponseCd;

  @JsonProperty("CompanyCd")
  private String CompanyCd;

  @JsonProperty("ApproveNo")
  private String ApproveNo;

  @JsonProperty("McSecCd")
  private String McSecCd;

  @JsonProperty("McKanaSei")
  private String McKanaSei;

  @JsonProperty("McKanaMei")
  private String McKanaMei;

  @JsonProperty("McBirthDay")
  private String McBirthDay;

  @JsonProperty("McTelNo")
  private String McTelNo;

  @JsonIgnore
  private String kainId;
}
