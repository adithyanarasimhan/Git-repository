package com.nissan.common.config;

import com.amazonaws.services.servicediscovery.AWSServiceDiscovery;
import com.amazonaws.services.servicediscovery.AWSServiceDiscoveryClientBuilder;
import com.amazonaws.services.servicediscovery.model.DiscoverInstancesRequest;
import com.amazonaws.services.servicediscovery.model.DiscoverInstancesResult;
import com.amazonaws.services.servicediscovery.model.HealthStatus;
import com.amazonaws.services.servicediscovery.model.HttpInstanceSummary;
import com.google.common.primitives.Longs;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CloudMapServiceResolver {

  private static final String AWS_INSTANCE_IPV_4_ATTRIBUTE = "AWS_INSTANCE_IPV4";
  private static final String AWS_INSTANCE_PORT_ATTRIBUTE = "AWS_INSTANCE_PORT";

  private static final Random RAND = new SecureRandom(Longs.toByteArray(System.currentTimeMillis()));

  @Value("${aws.cloudmap.namespace}")
  private String cloudMapNamespace;

  public CloudMapServiceResolver() {
    log.info("ServiceLocationResolver: {}", this.getClass().getCanonicalName());
  }

  public String resolve(String serviceName) {

    final AWSServiceDiscovery awsServiceDiscovery =
        AWSServiceDiscoveryClientBuilder.defaultClient();
    final DiscoverInstancesRequest discoverInstancesRequest = new DiscoverInstancesRequest();

    discoverInstancesRequest.setNamespaceName(cloudMapNamespace);
    discoverInstancesRequest.setServiceName(serviceName);
    discoverInstancesRequest.setHealthStatus(HealthStatus.HEALTHY.name());

    final DiscoverInstancesResult discoverInstancesResult =
        awsServiceDiscovery.discoverInstances(discoverInstancesRequest);

    final List<HttpInstanceSummary> allInstances = discoverInstancesResult.getInstances();

    if (true) {
      final List<String> serviceEndpoints =
          allInstances.stream()
              .map(
                  result ->
                      result.getAttributes().get(AWS_INSTANCE_IPV_4_ATTRIBUTE)
                          + ":"
                          + result.getAttributes().get(AWS_INSTANCE_PORT_ATTRIBUTE))
              .collect(Collectors.toList());
      log.info("Found instances: {}", serviceEndpoints);
    }

    final HttpInstanceSummary result = allInstances.get(RAND.nextInt(allInstances.size()));
    final String serviceLocation =
        result.getAttributes().get(AWS_INSTANCE_IPV_4_ATTRIBUTE)
            + ":"
            + result.getAttributes().get(AWS_INSTANCE_PORT_ATTRIBUTE);

    log.info("Given {}, found {}", serviceName + "." + cloudMapNamespace, serviceLocation);

    return serviceLocation;
  }
}
