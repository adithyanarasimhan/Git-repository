package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "tempo_net")
@EntityListeners(AuditingEntityListener.class)
public class TempoDotNet extends Auditable<String> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ca_company_code",unique = true)
    private String caCompanyCode;

    @Column(name = "ca_company_name")
    private String caCompanyName;

    @Column(name = "profit_ca_company_code")
    private String profitCaCompanyCode;

    @Column(name = "dealer_company_phone_number")
    private String dealerCompanyPhoneNumber;

    @Column(name = "jisseki_code")
    private String jissekiCode;

    @Column(name = "kanban_code")
    private String kanbanCode;

    @Column(name = "compass_dealership_code")
    private String compassDealershipCode;

    @Column(name = "profit_dealership_code")
    private String profitDealershipCode;

    @Column(name = "compass_dealer_company_code")
    private String compassDealerCompanyCode;

    @Column(name = "profit_dealer_company_code")
    private String profitDealerCompanyCode;

    @Column(name = "profit_dealer_company_code_block_code")
    private String profitDealerCompanyCodeWithBlockCode;

    @Column(name = "dealer_company_name")
    private String dealerCompanyName;

    @Column(name = "dealership_name")
    private String dealerShipName;

    @Column(name = "regular_closing_day_1")
    private String regularClosingDay1;

    @Column(name = "regular_closing_day_2")
    private String regularClosingDay2;

    @Column(name = "new_vehicle_flag")
    private String newVehicleFlag;

    @Column(name = "used_vehicle_flag")
    private String usedVehicleFlag;
}
