package com.nissan.common.dto;

import lombok.Data;

@Data
public class ResultDto {
    private String responseCd;
    private String errorMessage;
    private String salesCompanyCd;
    private String orderNo;
    private String modelName;
    private String vin;
    private String adaptorId;
    private String firstRegistDate;
    private String vinRegistDate;
    private String regNo;
    private String ncId;
    private String ncPw;
    private String status;
    private String ncJoinDate;
    private String chargeStartDate;
    private String chargeUpdateDate;
    private String planName;
    private String planPrice;
    private String paymentCd;
    private String memKindCd;
    private String name;
    private String nameKana;
    private String corpName;
    private String telNo;
    private String telNo2;
    private String eMail;
    private String userId;
    private String iccId;
    private String serviceEndDate;
}
