package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class NaviV2DTO {
    private long id;
    private long gradeId;
    private String name;
    private String displayName;
    private List<PackagePlanV2DTO> packagePlans;
    private List<OptionsV2DTO> options;
}
