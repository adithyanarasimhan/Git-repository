package com.nissan.common.dto;

import lombok.Data;

@Data
public class ResultInfoSecond {
    private String responseCd;
    private String errorMessage;
    private String salesCompanyCd;
    private String orderNo;
    private String vin;
}
