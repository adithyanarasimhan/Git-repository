package com.nissan.common.dto;

import lombok.Data;

@Data
public class PaymentMethodDto {

  private Long id;

  private String name;

  private String displayName;

  private String type;

}
