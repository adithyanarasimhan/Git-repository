package com.nissan.common.repository;

import com.nissan.common.entity.LocationAddress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocationAddressRepository extends JpaRepository<LocationAddress, Long> {

  @Query(value = "SELECT prefecture_name FROM ( SELECT DISTINCT ON (prefecture_name) * FROM location_address ) p ORDER BY CAST (prefecture_code AS int)", nativeQuery = true)
  List<String> getPrefecture();

  @Query(value = "SELECT city_name1 FROM ( SELECT DISTINCT ON (city_name1) * FROM location_address where prefecture_name=?1) p ORDER BY CAST (city_code AS int)", nativeQuery = true)
  List<String> getCityName1(String prefecture);

  @Query(value = "SELECT distinct(city_name3) FROM location_address where city_name1=?1", nativeQuery = true)
  List<String> getCityName2(String city1);

  @Query(value = "SELECT distinct(city_name3) FROM location_address where prefecture_name=?1 and city_name1=?2", nativeQuery = true)
  List<String> getCityByPrefecture(String prefecture, String city1);

  @Query(value = "SELECT distinct(prefecture_code) FROM location_address where prefecture_name=?1", nativeQuery = true)
  String getPrefCodeByPrefecture(String prefecture);
}
