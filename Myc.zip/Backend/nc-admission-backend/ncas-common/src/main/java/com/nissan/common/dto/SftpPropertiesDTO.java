package com.nissan.common.dto;

import lombok.Data;

@Data
public class SftpPropertiesDTO {
	private String host;
	private Integer port;
	private String username;
	private String root;
	private String privateKey;
	private String passphrase;
	private String fileName;
	private String fileExtension;
	private String source ;
}
