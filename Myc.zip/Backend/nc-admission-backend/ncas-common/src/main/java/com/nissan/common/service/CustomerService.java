package com.nissan.common.service;

import com.nissan.common.dto.*;
import com.nissan.common.entity.Customer;

public interface CustomerService {
  CustomerResponseDTO updateCustomerById(CustomerDTO customerDto, String userName, String langCode)
      throws Exception;

  CustomerSummaryDto fetchCustomerByUserAndLangCode(String userName, String langCode);

  CustomerInfoDTO fetchCustomerNcNameMob(String token, String langCode) throws Exception;

  Customer saveCustomer(OtpDto otpDto, String userName, String langCode);

  CustomerGetResponseDTO fetchCustomerPlanDetails(String userName, String langCode)
      throws Exception;

  ZipCodeResponseDTO fetchPrefecture(String zipCode, String langCode) throws Exception;

  TempPwdDTO fetchTemporaryPwd(String token, String langCode) throws Exception;
}
