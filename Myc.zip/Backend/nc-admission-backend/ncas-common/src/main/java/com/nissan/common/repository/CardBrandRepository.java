package com.nissan.common.repository;

import com.nissan.common.entity.CardBrand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CardBrandRepository
    extends JpaRepository<CardBrand, Long>, QuerydslPredicateExecutor<CardBrand> {
    List<CardBrand> findByLangCode(String langCode);

    @Query(value = "select * from card_brand where id=?", nativeQuery = true)
    CardBrand fetchByLangCodeAndId(Long id);
}
