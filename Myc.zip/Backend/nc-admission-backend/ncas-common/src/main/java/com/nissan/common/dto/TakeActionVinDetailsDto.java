package com.nissan.common.dto;

import com.nissan.common.entity.DemoCarModel;
import com.nissan.common.entity.DemoCarPackagePlan;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class TakeActionVinDetailsDto {
    private LocalDateTime enrollmentDate;
    private String statusDisplayName;
    private String status;
    private DemoCarModel model;
    private String vin;
    private String carPlan;
    private String flagTypeDisplayName;
    private String flagType;
    private String source;
    private String sourceDisplayName;
    private Boolean ivi;
    private Long ncasNumber;
    private String naviId;
    private String companyName;
    private String dealershipName;
    private String dealerShipCode;
    private String caName;
    private String expirationDate;
    private DemoCarPackagePlan packagePlan;
    private boolean icc;

}
