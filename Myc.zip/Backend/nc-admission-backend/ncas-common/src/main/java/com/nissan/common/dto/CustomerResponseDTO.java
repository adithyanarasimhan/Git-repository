package com.nissan.common.dto;

import lombok.Data;

@Data
public class CustomerResponseDTO {
    private String familyName;
    private String familyNameKatakana;
    private String firstName;
    private String firstNameKatakana;
    private String address1;
    private String address2;
    private String phoneNumber;
    private String optionalPhoneNumber;
    private String zipCode;
    private String corporateName;
    private String officePosition;
    private String representativeName;
    private String representativeNameKatakana;
    private String email;
    private Long customerType;
    private Long stepCount;
    private String token;
    private Long userId;
    private String dealerVisitStatus;
}
