package com.nissan.common.dto;

import lombok.Data;

@Data
public class CarwingsVehicleResponseDTO {
    private String responseCd;
    private String errorMessage;
    private String modelName;
    private String vin;
    private String adaptorId;
    private String firstRegDate;
    private String vinRegistDate;
    private String userId;
    private String colorCd;
    private Boolean dopFlg;
    private String status;
    private String colorName;
    private String iviFlag;
}
