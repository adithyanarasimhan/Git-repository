package com.nissan.common.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
public class OtpDto {

  @Email(message = "Email should be valid")
  private String email;

  @Size(min = 6, max = 6, message = "Digits should be 6")
  private String otp;

  private String source;

  public OtpDto setEmail(String email) {
    this.email = email;
    return this;
  }

  public OtpDto setOtp(String otp) {
    this.otp = otp;
    return this;
  }
}
