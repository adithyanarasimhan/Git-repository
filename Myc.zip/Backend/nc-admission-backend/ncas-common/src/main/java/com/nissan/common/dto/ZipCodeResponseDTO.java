package com.nissan.common.dto;

import lombok.Data;

@Data
public class ZipCodeResponseDTO {
    private String address1;
    private String address2;
}
