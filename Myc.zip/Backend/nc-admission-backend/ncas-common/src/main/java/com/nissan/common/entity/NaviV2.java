package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "naviv2")
@EntityListeners(AuditingEntityListener.class)
public class NaviV2 extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "grade_id", referencedColumnName = "id")
    private GradeV2 grade;

    @Column(name = "navi_name")
    private String naviName;

    @Column(name = "cw_navi_name")
    private String cwNaviName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "vehicle_type")
    private String vehicleType;

    @Column(name = "color_option")
    private Boolean colorOption;
}
