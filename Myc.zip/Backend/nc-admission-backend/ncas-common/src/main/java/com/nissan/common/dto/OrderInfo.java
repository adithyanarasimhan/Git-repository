package com.nissan.common.dto;

import lombok.Data;

@Data
public class OrderInfo {
    private String salesCompanyCd;
    private String orderNo;
}
