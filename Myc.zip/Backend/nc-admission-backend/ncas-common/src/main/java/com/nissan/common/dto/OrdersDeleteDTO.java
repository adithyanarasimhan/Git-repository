package com.nissan.common.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class OrdersDeleteDTO {
    @NotBlank private String orderNumber;
}
