package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "dealer_address")
@EntityListeners(AuditingEntityListener.class)
public class DealerAddress extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "company_code")
  private String companyCode;

  @Column(name = "company_name")
  private String companyName;

  @Column(name = "dealership_name")
  private String dealershipName;

  @Column(name = "dealership_code")
  private String dealershipCode;

  @Column(name = "prefecture_name")
  private String prefectureName;

  @Column(name = "dealership_address")
  private String dealershipAddress;

  @Column(name = "total_distance")
  private String totalDistance;

  @Column(name = "zip_code")
  private String zipCode;

  @Column(name = "radius")
  private String radius;

  @Column(name = "phone_number")
  private String phoneNumber;

  @Column(name = "visit_date")
  private Date visitDate;

  @Column(name = "visit_time")
  private String visitTime;

  @Column(name = "visit_status")
  private String visitStatus;

  @Column(name = "regular_closing_day_1")
  private String regularClosingDay1;

  @Column(name = "regular_closing_day_2")
  private String regularClosingDay2;

  @Column(name = "prefecture")
  private String prefecture;

  @Column(name = "city1")
  private String city1;

  @Column(name = "city2")
  private String city2;

  @Column(name = "latitude")
  private Double latitude;

  @Column(name = "longitude")
  private Double longitude;

  @Column(name = "label")
  private String label;

  @OneToOne(cascade = CascadeType.MERGE )
  @JoinColumn(name = "admissionv2_id", referencedColumnName = "id")
  private AdmissionV2 admission;
}
