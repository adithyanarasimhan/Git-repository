package com.nissan.common.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Date;

@Data
public class DealerAddressDTO {

  private String companyCode;
  private String companyName;
  private String dealershipCode;
  private String dealerName;
  private String prefectureName;
  private String address;
  private String dealerPhoneNumber;
  private String regularClosingDay1;
  private String regularClosingDay2;
  private String phoneNumber;
  private String totalDistance;
  private String radius;
  private Double latitude;
  private Double longitude;
  private String label;
  private String vehicleType;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String zipCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String prefecture;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String city1;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String city2;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String regularHoliday;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Date visitDate;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String visitTime;
}
