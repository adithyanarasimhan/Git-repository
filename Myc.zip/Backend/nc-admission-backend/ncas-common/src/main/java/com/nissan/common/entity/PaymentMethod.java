package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "payment_method")
@EntityListeners(AuditingEntityListener.class)
public class PaymentMethod extends Auditable<String> {

  @Id
  @Column(name = "id")
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "display_name")
  private String displayName;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "type")
  private String type;
}
