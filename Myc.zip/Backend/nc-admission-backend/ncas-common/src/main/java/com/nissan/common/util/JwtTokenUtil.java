package com.nissan.common.util;

import com.nissan.common.dto.AuthDto;
import io.jsonwebtoken.*;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class JwtTokenUtil {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenUtil.class);

    public static final long JWT_TOKEN_VALIDITY = 60 * 60;

    public static final long ACCESS_TOKEN_VALIDITY_SECONDS = 5 * 60 * 60;
    public static final long ACCESS_TOKEN_VALIDITY_SECONDS_NISSAN_CONNECT = 24 * 60 * 60;
    public static final String SIGNING_KEY = "devglan123r";
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";
    public static final String AUTHORITIES_KEY = "scopes";

    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    public String getIdFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    public Date getIssuedAtDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getIssuedAt);
    }

    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public String getIdFromRequest(HttpServletRequest httpServletRequest) {
        final String requestTokenHeader = httpServletRequest.getHeader("Authorization");
        String jwtToken = requestTokenHeader.substring(7);
        return getIdFromToken(jwtToken);
    }

    public String getIdFromRequestCustomer(HttpServletRequest httpServletRequest) {
        final String requestTokenHeader = httpServletRequest.getHeader("Authorization");
        return getIdFromToken(requestTokenHeader);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(SIGNING_KEY).parseClaimsJws(token).getBody();
    }

    public Boolean isTokenExpired(String token) {
        try {
            final Date expiration = getExpirationDateFromToken(token);
            logger.info("Expiration date and time in jwt token {}", expiration);
            return expiration.before(new Date());
        } catch (Exception e) {
            return true;
        }
    }

    public Boolean isCustomerTokenExpired(String token) {
        try {
            final Date expiration = getExpirationDateFromToken(token);
            logger.info("Expiration date and time in jwt token {}", expiration);
            return expiration.after(new Date());
        } catch (Exception e) {
            return true;
        }
    }
    private Boolean ignoreTokenExpiration() {
        // here you specify tokens, for that the expiration is ignored
        return false;
    }

    public String generateToken(AuthDto authDto) {
        Map<String, Object> claims = new HashMap<>();
        return doGenerateToken(claims, String.valueOf(authDto.getId()));
    }

    public String generateToken(Authentication authentication) {
        final String authorities =
                authentication.getAuthorities().stream()
                        .map(GrantedAuthority::getAuthority)
                        .collect(Collectors.joining(","));
        return Jwts.builder()
                .setSubject(authentication.getName())
                .claim(AUTHORITIES_KEY, authorities)
                .signWith(SignatureAlgorithm.HS256, SIGNING_KEY)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + ACCESS_TOKEN_VALIDITY_SECONDS * 1000))
                .compact();
    }

    public String generateTokenNissanConnect(Authentication authentication) {
        final String authorities =
                authentication.getAuthorities().stream()
                        .map(GrantedAuthority::getAuthority)
                        .collect(Collectors.joining(","));
        return Jwts.builder()
                .setSubject(authentication.getName())
                .claim(AUTHORITIES_KEY, authorities)
                .signWith(SignatureAlgorithm.HS256, SIGNING_KEY)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(
                        new Date(
                                System.currentTimeMillis() + ACCESS_TOKEN_VALIDITY_SECONDS_NISSAN_CONNECT * 1000))
                .compact();
    }

    private String doGenerateToken(Map<String, Object> claims, String subject) {

        String secret = "secret";
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }

    public Boolean canTokenBeRefreshed(String token) {
        return (!isTokenExpired(token) || ignoreTokenExpiration());
    }

    public Boolean validateToken(String token, AuthDto authDto) {
        final int id = Integer.parseInt(getIdFromToken(token));
        return (id == (authDto.getId()) && !isTokenExpired(token));
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
        final String username = getUsernameFromToken(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }

    public Boolean validateToken(String token) {
        final String username = getUsernameFromToken(token);
        return isCustomerTokenExpired(token);
    }

    public UsernamePasswordAuthenticationToken getAuthentication(
            final String token, final Authentication existingAuth, final UserDetails userDetails) {

        final JwtParser jwtParser = Jwts.parser().setSigningKey(SIGNING_KEY);

        final Jws<Claims> claimsJws = jwtParser.parseClaimsJws(token);

        final Claims claims = claimsJws.getBody();

        final Collection<? extends GrantedAuthority> authorities =
                Arrays.stream(claims.get(AUTHORITIES_KEY).toString().split(","))
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

        return new UsernamePasswordAuthenticationToken(userDetails, "", authorities);
    }
}

