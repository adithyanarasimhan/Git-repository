package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "card_brand")
@EntityListeners(AuditingEntityListener.class)
public class CardBrand extends Auditable<String> {

  @Id
  @Column(name = "id")
  private Long id;

  @Column(name = "card_brand")
  private String name;

  @Column(name = "lang_code")
  private String langCode;
}
