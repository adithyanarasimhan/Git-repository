package com.nissan.common.repository;

import com.nissan.common.entity.ActivityLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface ActivityLogRepository
    extends JpaRepository<ActivityLog, Long>, QuerydslPredicateExecutor<ActivityLog> {

  @Query(
      value = "select * from activity_log where admission_id=? ORDER BY time ASC",
      nativeQuery = true)
  List<ActivityLog> fetchByAdmissionIdAndTime(Long id);
}
