package com.nissan.common.dto;

import com.nissan.common.entity.*;
import com.nissan.common.util.FormatValue;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

@Data
public class OrdersFetchResponseDTO {
  private static final Logger logger = LoggerFactory.getLogger(OrdersFetchResponseDTO.class);
  private String tempOrdersNumber;
  private String status;
  private String statusJp;
  private String admissionDate;
  private String admissionTime;
  private String profitSystemOrderNumber;
  private CustomerResponseDTO customerDetails;
  private Long admissionId;
  private ModelDTO model;
  private GradeDTO grade;
  private NaviDTO navi;
  private PackagePlanDTO planName;
  private OptionDTO option;
  private PaymentMethodDto paymentMethod;
  private String vinNumber;
  private String carwingsVinNumber;
  private Boolean vehicleTransfer;
  private Long price;
  private Integer admissionType;
  private String admissionTypeName;
  private DealerDTO dealerDetails;
  private String token;
  private String userName;
  private NCInfoDTO carwingsDetails;

  public OrdersFetchResponseDTO(Orders orders, Customer customer, User user) {
    setOrderDetails(orders, customer);
    this.userName = (customer == null) ? user.getFirstName() : null;
  }

  public OrdersFetchResponseDTO(Orders orders, Customer customer) {
    setOrderDetails(orders, customer);
  }

  private void setOrderDetails(Orders orders, Customer customer) {
    try {
      this.setTempOrdersNumber(orders.getOrdersNumber());
      this.setProfitSystemOrderNumber(orders.getOrderNumberPs());
      Date orderCreatedDate = orders.getCreatedDate();
      this.setAdmissionDate(new SimpleDateFormat("yyyy-MM-dd").format(orderCreatedDate));
      this.setAdmissionTime(new SimpleDateFormat("hh:mm aaa").format(orderCreatedDate));
      this.setStatus(orders.getAdmission().getStatus());
      this.setStatusJp(orders.getAdmission().getStatusJp());
      this.setCustomerDetails(getCustomerResponse(Optional.ofNullable(customer)));
      this.setAdmissionId(orders.getAdmission().getId());
      this.setModel(convertModelEntityToDTO(orders.getModel()));
      this.setGrade(convertGradeEntityToGradeDTO(orders.getGrade()));
      if (orders.getNavi() != null) this.setNavi(convertNaviEntityToDTO(orders.getNavi()));
      if (orders.getPackagePlan() != null)
        this.setPlanName(convertPackagePlanEntityToDTO(orders.getPackagePlan()));
      if (orders.getOptions() != null)
        this.setOption(convertOptionEntityToDTO(orders.getOptions()));
      if (orders.getPaymentMethod() != null)
        this.setPaymentMethod(convertPaymentMethodEntityToDTO(orders.getPaymentMethod()));
      this.setVinNumber(orders.getVinNumber());
      this.setCarwingsVinNumber(orders.getCwVinNumber());
      this.setVehicleTransfer(orders.getVehicleTransfer());
      if (orders.getPackagePlan() != null) this.setPrice(orders.getPackagePlan().getPrice());
      this.setAdmissionType(orders.getAdmissionType());
      this.setDealerDetails(convertDealerEntityToDTO(orders));
      this.setToken(orders.getAdmission().getUser().getEncodedToken());
      this.setCarwingsDetails(getCarwingsInfo(orders));
    } catch (Exception e) {
      logger.info("Exception in Order Fetch Response Constructor : " + e.getMessage());
      if (orders != null
          && orders.getAdmission() != null
          && orders.getAdmission().getUser() != null)
        logger.info("User id to fetch customer : " + orders.getAdmission().getUser().getId());
    }
  }

  private NCInfoDTO getCarwingsInfo(Orders orders) {
    logger.info("Inside setCarwingsInfo");
    NCInfoDTO ncInfoDTO = new NCInfoDTO();
    try {
      Admission admission = orders.getAdmission();
      ncInfoDTO.setCarwingsVinNumber(orders.getCwVinNumber());
      ncInfoDTO.setVinRegisteredDate(FormatValue.formatDate(admission.getVinRegisteredDate()));
      ncInfoDTO.setFirstRegisteredDate(FormatValue.formatDate(orders.getFirstRegisteredDate()));
      ncInfoDTO.setNcID(admission.getNcId());
      ncInfoDTO.setNcJoinedDate(FormatValue.formatDate(admission.getNcJoinedDate()));
      ncInfoDTO.setNcStatus(admission.getCwStatus());
    } catch (Exception e) {
      logger.error("Exception in setCarwingsInfo : {}", e.getMessage());
      e.printStackTrace();
    }
    return ncInfoDTO;
  }

  private ModelDTO convertModelEntityToDTO(final Model model) {
    final ModelDTO modelDTO = new ModelDTO();
    modelDTO.setId(model.getId());
    modelDTO.setName(model.getModelName());
    modelDTO.setDisplayName(model.getDisplayName());
    modelDTO.setImgUrl(model.getUrl());
    return modelDTO;
  }

  private GradeDTO convertGradeEntityToGradeDTO(final Grade grade) {
    final GradeDTO gradeDTO = new GradeDTO();
    gradeDTO.setId(grade.getId());
    gradeDTO.setModelName(grade.getModel().getModelName());
    gradeDTO.setName(grade.getGradeName());
    gradeDTO.setDisplayName(grade.getDisplayName());
    return gradeDTO;
  }

  private NaviDTO convertNaviEntityToDTO(final Navi navi) {
    final NaviDTO naviDTO = new NaviDTO();
    naviDTO.setId(navi.getId());
    naviDTO.setGradeId(navi.getGrade().getId());
    naviDTO.setName(navi.getNaviName());
    naviDTO.setDisplayName(navi.getDisplayName());
    return naviDTO;
  }

  private OptionDTO convertOptionEntityToDTO(final Options option) {
    final OptionDTO optionDTO = new OptionDTO();
    optionDTO.setId(option.getId());
    optionDTO.setName(option.getOptionsName());
    optionDTO.setDisplayName(option.getDisplayName());
    optionDTO.setNaviId(option.getNavi().getId());
    return optionDTO;
  }

  private PaymentMethodDto convertPaymentMethodEntityToDTO(final PaymentMethod paymentMethod) {
    final PaymentMethodDto paymentMethodDto = new PaymentMethodDto();
    paymentMethodDto.setId(paymentMethod.getId());
    paymentMethodDto.setName(paymentMethod.getName());
    paymentMethodDto.setDisplayName(paymentMethod.getDisplayName());
    return paymentMethodDto;
  }

  private PackagePlanDTO convertPackagePlanEntityToDTO(final PackagePlan packagePlan) {
    final PackagePlanDTO packagePlanDTO = new PackagePlanDTO();
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    return packagePlanDTO;
  }

  private static DealerDTO convertDealerEntityToDTO(Orders orders) {
    logger.info("Inside convertDealerEntityToDTO");
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyName(orders.getCompanyName());
    dealerDTO.setDealershipName(orders.getDealershipName());
    dealerDTO.setPhoneNumber(orders.getPhoneNumber());
    dealerDTO.setCaName(orders.getCaName());
    dealerDTO.setCaNameKana(orders.getCaNameKana());
    dealerDTO.setCaCode(orders.getCaCode());
    return dealerDTO;
  }

  private CustomerResponseDTO getCustomerResponse(Optional<Customer> optionalCustomer) {
    logger.info("Inside get customer response");
    CustomerResponseDTO customerResponse = new CustomerResponseDTO();
    if (!optionalCustomer.isPresent()) {
      return null;
    }
    try {
      Customer customer = optionalCustomer.get();
      customerResponse.setAddress1(customer.getAddress1());
      customerResponse.setAddress2(customer.getAddress2());
      customerResponse.setCorporateName(customer.getCorporateName());
      customerResponse.setEmail(customer.getEmail());
      customerResponse.setFamilyName(customer.getFamilyName());
      customerResponse.setFamilyNameKatakana(customer.getFamilyNameKatakana());
      customerResponse.setFirstName(customer.getFirstName());
      customerResponse.setFirstNameKatakana(customer.getFirstNameKatakana());
      customerResponse.setOfficePosition(customer.getOfficePosition());
      customerResponse.setPhoneNumber(replaceNullFirstParameters(customer.getPhoneNumber1())+""+replaceNullFirstParameters(customer.getPhoneNumber2())+""+replaceNullFirstParameters(customer.getPhoneNumber3()));
      customerResponse.setOptionalPhoneNumber(replaceNullFirstParameters(customer.getOptionalPhoneNumber1())+""+replaceNullFirstParameters(customer.getOptionalPhoneNumber2())+""+replaceNullFirstParameters(customer.getOptionalPhoneNumber3()));
      customerResponse.setRepresentativeName(customer.getRepresentativeName());
      customerResponse.setRepresentativeNameKatakana(customer.getRepresentativeNameKatakana());
      customerResponse.setStepCount(customer.getStepCount());
      customerResponse.setZipCode(customer.getZipCode1()+""+customer.getZipCode2());
      customerResponse.setCustomerType(customer.getCustomerType());
      customerResponse.setUserId(customer.getUser().getId());
      customerResponse.setToken(customer.getUser().getEncodedToken());
    } catch (Exception e) {
      logger.info("Exception in getCustomerResponse : " + e.getMessage());
    }
    return customerResponse;
  }

  private String replaceNullFirstParameters(String value) {
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }
}
