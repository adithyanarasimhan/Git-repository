package com.nissan.common.util;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

@Target({TYPE, METHOD, FIELD, ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {CustomerDTOValidator.class})
@Repeatable(CustomerValidator.List.class)
public @interface CustomerValidator {
  String fieldName();

  String fieldValue();

  String[] dependFieldName();

  String message() default "Not null";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  @Target({ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @interface List {
    CustomerValidator[] value();
  }
}
