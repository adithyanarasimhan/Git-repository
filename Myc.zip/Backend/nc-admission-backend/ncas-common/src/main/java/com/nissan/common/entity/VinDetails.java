package com.nissan.common.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.nissan.common.audit.Auditable;
import com.nissan.common.entity.DemoCarGrade;
import com.nissan.common.entity.DemoCarModel;
import com.nissan.common.entity.DemoCarNavi;
import com.nissan.common.entity.DemoCarPackagePlan;

import lombok.Data;

@Data
@Entity
@Table(name = "vin_details")
@EntityListeners(AuditingEntityListener.class)
public class VinDetails extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vin")
    private String vin;

    @Column(name = "profit_dealer_code")
    private String profitDealerCode;

    @Column(name = "flag_type")
    private String flagType;

    @Column(name = "ivi")
    private Boolean ivi;

    @Column(name = "icc")
    private Boolean icc;

    @Column(name = "car_plan")
    private String carPlan;

    @Column(name = "profit_dealer_shop_code")
    private String profitDealerShopCode;

    @Column(name = "active")
    private boolean active;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "status")
    private String status;

    @Column(name = "source")
    private String source;

    @Column(name = "expiration_date")
    private String expirationDate;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "model_id", referencedColumnName = "id")
    private DemoCarModel model;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "grade_id", referencedColumnName = "id")
    private DemoCarGrade grade;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "navi_id", referencedColumnName = "id")
    private DemoCarNavi navi;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "plan_id", referencedColumnName = "id")
    private DemoCarPackagePlan packagePlan;

    @Column(name = "cw_navi_id")
    private String cwNaviId;

    @Column(name = "enrollment_date")
    private LocalDateTime enrollmentDate;

    @Column(name = "model_name")
    private String modelName;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.REFRESH, CascadeType.MERGE})
    @JoinColumn(name = "dealer_id", referencedColumnName = "dealer_id")
    private DealerEntity dealer;

    @Column(name = "no_of_retry_cw")
    private Integer numberOfRetryWithCw;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "admission_id", referencedColumnName = "id")
    private DemoCarAdmission admission;

    @Column(name = "dealer_name")
    private String dealerName;

    @Column(name = "dealer_shop_name")
    private String dealerShopName;

    @Column(name = "ca_name")
    private String caName;

    @Column(name = "ca_lending_name")
    private String caLendingName;

    @Column(name = "ca_lending_code")
    private String caLendingCode;

}
