package com.nissan.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FOUND)
public class AlreadyExistException extends RuntimeException {

  private static final long serialVersionUID = 266853995330077478L;

  public AlreadyExistException(String exception) {
    super(exception);
  }
}
