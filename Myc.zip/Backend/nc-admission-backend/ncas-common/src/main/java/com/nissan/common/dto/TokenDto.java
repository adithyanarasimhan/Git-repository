package com.nissan.common.dto;

import lombok.Data;

@Data
public class TokenDto {
    private String token;
}
