package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "reason")
@EntityListeners(AuditingEntityListener.class)
public class Reason extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "reason_name")
  private String reasonName;

  @Column(name = "display_name")
  private String displayName;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "type")
  private String type;

  @Column(name = "direct_debit")
  private Boolean directDebit;
}
