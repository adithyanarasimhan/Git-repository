package com.nissan.common.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class OrdersV2UpdateRequestDTO {
    @NotBlank(message = "Please enter a valid order number")
    public String orderNumber;
    public Long packagePlan;
    public Long userId;
    private Boolean vehicleTransfer;
    private String oldVinNumber;
    private CustomerDTO customerDetails;
    private DealerDetailsRequestDTO dealerDetails;
}
