package com.nissan.common.dto;

import com.nissan.common.entity.*;
import com.nissan.common.util.FormatValue;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.Date;

@Data
public class RetryPaymentDTO {
    @CsvBindByName(column = "Admission Type")
    @CsvBindByPosition(position = 0)
    private Integer admissionType;

    @CsvBindByPosition(position = 1)
    @CsvBindByName(column = "Profit Order #")
    private String ordersNumber;

    @CsvBindByPosition(position = 2)
    @CsvBindByName(column = "Status")
    private String status;

    @CsvBindByPosition(position = 3)
    @CsvBindByName(column = "Application date time")
    private Date applicationDatetime;

    @CsvBindByPosition(position = 4)
    @CsvBindByName(column = "Dealer Company Code")
    private String dealerCompanyCode;

    @CsvBindByPosition(position = 5)
    @CsvBindByName(column = "Dealer Company Name")
    private String dealerCompanyName;

    @CsvBindByPosition(position = 6)
    @CsvBindByName(column = "Dealership Name")
    private String dealerShipName;

    @CsvBindByPosition(position = 7)
    @CsvBindByName(column = "Dealer phone #")
    private String dealerPhone;

    @CsvBindByPosition(position = 8)
    @CsvBindByName(column = "C/A Name")
    private String caName;

    @CsvBindByPosition(position = 9)
    @CsvBindByName(column = "C/A Name(Kana)")
    private String caNameKana;

    @CsvBindByName(column = "C/A Code")
    @CsvBindByPosition(position = 10)
    private String caCode;

    @CsvBindByName(column = "C/A Email")
    @CsvBindByPosition(position = 11)
    private String caEmail;

    @CsvBindByPosition(position = 12)
    @CsvBindByName(column = "Customer type")
    private Long customerType;

    @CsvBindByPosition(position = 13)
    @CsvBindByName(column = "E-mail address")
    private String emailAddress;

    @CsvBindByPosition(position = 14)
    @CsvBindByName(column = "Name")
    private String firstName;

    @CsvBindByPosition(position = 15)
    @CsvBindByName(column = "Name(katakana)")
    private String firstNameKatakana;

    @CsvBindByPosition(position = 16)
    @CsvBindByName(column = "Corperate Name")
    private String corporateName;

    @CsvBindByPosition(position = 17)
    @CsvBindByName(column = "Office position")
    private String officePosition;

    @CsvBindByPosition(position = 18)
    @CsvBindByName(column = "Representative's name")
    private String representativeName;

    @CsvBindByPosition(position = 19)
    @CsvBindByName(column = "Representative's name(katakana)")
    private String representativeNameKana;

    @CsvBindByPosition(position = 20)
    @CsvBindByName(column = "Zip Code(first 3digits)")
    private String zipCode1;

    @CsvBindByPosition(position = 21)
    @CsvBindByName(column = "Zip Code(last 4digits)")
    private String zipCode2;
    //
    @CsvBindByPosition(position = 22)
    @CsvBindByName(column = "Address1")
    private String address1;

    @CsvBindByPosition(position = 23)
    @CsvBindByName(column = "Address2")
    private String address2;

    @CsvBindByPosition(position = 24)
    @CsvBindByName(column = "Phone #1(first 3digits)")
    private String phone1;

    @CsvBindByPosition(position = 25)
    @CsvBindByName(column = "Phone #1(second 4digits)")
    private String phone2;

    @CsvBindByPosition(position = 26)
    @CsvBindByName(column = "Phone #1(last 4digits)")
    private String phone3;

    @CsvBindByPosition(position = 27)
    @CsvBindByName(column = "Phone #2(first 3digits)")
    private String optionalPhone1;

    @CsvBindByPosition(position = 28)
    @CsvBindByName(column = "Phone #2(second 4digits)")
    private String optionalPhone2;

    @CsvBindByPosition(position = 29)
    @CsvBindByName(column = "Phone #2(last 4digits)")
    private String optionalPhone3;

    @CsvBindByPosition(position = 30)
    @CsvBindByName(column = "Vehicle Model")
    private String model;

    @CsvBindByPosition(position = 31)
    @CsvBindByName(column = "Vehicle Grade")
    private String grade;

    @CsvBindByPosition(position = 32)
    @CsvBindByName(column = "Vehicle Option 1")
    private String option1;

    @CsvBindByPosition(position = 33)
    @CsvBindByName(column = "Vehicle Option 2")
    private String option2;

    @CsvBindByPosition(position = 34)
    @CsvBindByName(column = "Package plan")
    private String packagePlan;

    @CsvBindByPosition(position = 35)
    @CsvBindByName(column = "VIN")
    private String vin;

    @CsvBindByPosition(position = 36)
    @CsvBindByName(column = "First registered date")
    private String firstRegisteredDate;

    @CsvBindByPosition(position = 37)
    @CsvBindByName(column = "Navi ID")
    private String naviId;

    @CsvBindByPosition(position = 38)
    @CsvBindByName(column = "NCAS #")
    private Long ncasNumber;

    public RetryPaymentDTO(Orders orders, DealerEntity dealerEntity, Customer customer, Payment payment) {
        Admission admission = orders.getAdmission();
        this.admissionType = orders.getAdmissionType();
        this.ordersNumber = orders.getOrderNumberPs();
        this.status = admission.getStatus();
        this.applicationDatetime = admission.getCreatedDate();
        this.dealerCompanyCode = dealerEntity.getCompanyCode();
        this.dealerCompanyName = orders.getCompanyName();
        this.dealerShipName = orders.getDealershipName();
        this.dealerPhone = orders.getPhoneNumber();
        this.caName = orders.getCaName();
        this.caNameKana = orders.getCaNameKana();
        this.caCode = dealerEntity.getCaCode();
        this.caEmail = dealerEntity.getEmail();
        this.customerType = customer.getCustomerType();
        this.emailAddress = customer.getEmail();
        String customerName = FormatValue.replaceNullOptionalPhoneNumber(customer.getFamilyName())
                + FormatValue.replaceNullOptionalPhoneNumber(customer.getFirstName());
        String customerNameKata = FormatValue.replaceNullOptionalPhoneNumber(customer.getFamilyNameKatakana())
                + FormatValue.replaceNullOptionalPhoneNumber(customer.getFirstNameKatakana());
        /**Converting String to double-byte character */
        try {
            this.firstName = FormatValue.convertToShiftJ(customerName.getBytes());
            this.firstNameKatakana = FormatValue.convertToShiftJ(customerNameKata.getBytes());
            this.address1 = (customer.getAddress1() != null) ? FormatValue.convertToShiftJ(customer.getAddress1().getBytes()) : "";
            this.address2 = (customer.getAddress2() != null) ? FormatValue.convertToShiftJ(customer.getAddress2().getBytes()) : "";
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.corporateName = customer.getCorporateName();
        this.officePosition = customer.getOfficePosition();
        this.representativeName = customer.getRepresentativeName();
        this.representativeNameKana = customer.getRepresentativeNameKatakana();
        this.zipCode1 = customer.getZipCode1();
        this.zipCode2 = customer.getZipCode2();
        this.phone1 = customer.getPhoneNumber1();
        this.phone2 = customer.getPhoneNumber2();
        this.phone3 = customer.getPhoneNumber3();
        this.optionalPhone1 = customer.getOptionalPhoneNumber1();
        this.optionalPhone2 = customer.getOptionalPhoneNumber2();
        this.optionalPhone3 = customer.getOptionalPhoneNumber3();
        this.model = orders.getModel().getModelName();
        this.grade = orders.getGrade().getGradeName();
        this.option1 = orders.getNavi().getNaviName();
        this.option2 = (orders.getOptions() != null) ? orders.getOptions().getOptionsName() : "";
        this.packagePlan = orders.getPackagePlan().getPackagePlanName();
        this.vin = orders.getVehicleTransfer() ? orders.getVinNumber() : "";
        this.ncasNumber = admission.getId();
    }
}
