package com.nissan.common.repository;

import com.nissan.common.entity.DemoCarCustomer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface DemoCarCustomerRepository extends JpaRepository<DemoCarCustomer, Long>, QuerydslPredicateExecutor<DemoCarCustomer> {
    
}
