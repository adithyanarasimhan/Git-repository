package com.nissan.common.repository;

import com.nissan.common.entity.NaviV2;
import com.nissan.common.entity.OptionsV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface OptionsV2Repository extends JpaRepository<OptionsV2, Long>, QuerydslPredicateExecutor<OptionsV2> {
    @Query(value = "SELECT * FROM optionsv2 WHERE navi_id =?1", nativeQuery = true)
    List<OptionsV2> getOptionsListByNaviId(long naviId);

    List<OptionsV2> findByNaviAndVehicleTypeIn(NaviV2 naviV2, Set<String> vehicleType);
}
