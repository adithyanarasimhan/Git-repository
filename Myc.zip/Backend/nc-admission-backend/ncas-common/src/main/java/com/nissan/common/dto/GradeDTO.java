package com.nissan.common.dto;

import lombok.Data;

import java.util.List;


@Data
public class GradeDTO {
    private long id;
    private String modelName;
    private String displayName;
    private String name;
    private List<NaviDTO> naviTypes;
}
