package com.nissan.common.entity;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "navi_reference")
@EntityListeners(AuditingEntityListener.class)
public class NaviReference {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "adaptor_kind")
    private String adaptorKind;

    @Column(name = "dop_flag")
    private String dopFlag;
}
