package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "orders")
@EntityListeners(AuditingEntityListener.class)
public class Orders extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "orders_number")
  private String ordersNumber;

  @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "admission_id", referencedColumnName = "id")
  private Admission admission;

  @Column(name = "admission_type")
  private Integer admissionType;

  @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "options_id", referencedColumnName = "id")
  private Options options;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "model_id", referencedColumnName = "id")
  private Model model;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "grade_id", referencedColumnName = "id")
  private Grade grade;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "navi_id", referencedColumnName = "id")
  private Navi navi;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "plan_id", referencedColumnName = "id")
  private PackagePlan packagePlan;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "payment_method", referencedColumnName = "id")
  private PaymentMethod paymentMethod;

  @Column(name = "vehicle_transfer")
  private Boolean vehicleTransfer;

  @Column(name = "vin_number")
  private String vinNumber;

  @Column(name = "new_vin")
  private String newVinNumber;

  @Column(name = "order_number_ps")
  private String orderNumberPs;

  @Column(name = "active")
  private Boolean active;

  @Column(name = "upload_kameri")
  private Boolean uploadKameri;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "terms")
  private Boolean terms;

  @Column(name = "company_name")
  private String companyName;

  @Column(name = "dealership_name")
  private String dealershipName;

  @Column(name = "phone_number")
  private String phoneNumber;

  @Column(name = "ca_name")
  private String caName;

  @Column(name = "ca_name_kana")
  private String caNameKana;

  @Column(name = "ca_code")
  private String caCode;

  @Column(name = "first_registered_date")
  private Date firstRegisteredDate;

  @Column(name = "nc_joined_date")
  private Date ncJoinedDate;

  @Column(name = "charge_start_date")
  private Date chargeStartDate;

  @Column(name = "service_update_date")
  private Date serviceUpdateDate;

  @Column(name = "adopter_id")
  private String adopterId;

  @Column(name = "register_number")
  private String registerNumber;

  @Column(name = "nc_status")
  private String ncStatus;

  @Column(name = "cw_vin_number")
  private String cwVinNumber;

  @Column(name = "plan_price")
  private String planPrice;

  @Column(name = "model_name_cw")
  private String modelNameCw;

}
