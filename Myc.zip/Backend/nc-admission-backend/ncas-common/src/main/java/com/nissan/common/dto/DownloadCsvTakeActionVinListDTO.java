package com.nissan.common.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Data
public class DownloadCsvTakeActionVinListDTO {
    private LocalDateTime enrollmentDate;

    private String status;
    private String model;
    private String vin;
    private String carPlan;
    private String flagType;
    private String source;
    private Boolean icc;
    private Boolean ivi;
    private Long id;
    private String naviId;
    private String caNameLending;
    private String companyName;
    private String dealershipName;
    private String caName;
    private LocalDate expirationDate;

    public DownloadCsvTakeActionVinListDTO(LocalDateTime enrollmentDate, String status, String model, String vin, String carPlan, String flagType, String source, Boolean icc, Boolean ivi, Long id, String naviId, String caNameLending, String companyName, String dealershipName, String caName, LocalDate expirationDate) {
        this.enrollmentDate = enrollmentDate;
        this.status = status;
        this.model = model;
        this.vin = vin;
        this.carPlan = carPlan;
        this.flagType = flagType;
        this.source = source;
        this.icc = icc;
        this.ivi = ivi;
        this.id = id;
        this.naviId = naviId;
        this.caNameLending = caNameLending;
        this.companyName = companyName;
        this.dealershipName = dealershipName;
        this.caName = caName;
        this.expirationDate = expirationDate;
    }
}
