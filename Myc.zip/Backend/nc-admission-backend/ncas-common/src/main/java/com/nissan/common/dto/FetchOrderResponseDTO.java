package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class FetchOrderResponseDTO {
    private OrdersFetchResponseDTO orderDetails;
    private List<PackagePlanDTO> planDetails;
    private DealerDTO dealerDetails;
}
