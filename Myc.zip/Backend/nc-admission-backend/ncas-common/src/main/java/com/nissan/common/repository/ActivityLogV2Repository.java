package com.nissan.common.repository;

import com.nissan.common.entity.ActivityLog;
import com.nissan.common.entity.ActivityLogV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface ActivityLogV2Repository
    extends JpaRepository<ActivityLogV2, Long>, QuerydslPredicateExecutor<ActivityLogV2> {

  @Query(
      value = "select * from activity_logv2 where admission_id=? ORDER BY time ASC",
      nativeQuery = true)
  List<ActivityLogV2> fetchByAdmissionIdAndTime(Long id);
}
