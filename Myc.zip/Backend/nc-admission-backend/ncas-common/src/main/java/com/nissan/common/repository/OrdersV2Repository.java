package com.nissan.common.repository;

import com.nissan.common.dto.DownloadCsvOrderV2ListDTO;
import com.nissan.common.dto.OrdersV2FetchResponseDto;
import com.nissan.common.entity.Orders;
import com.nissan.common.entity.OrdersV2;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import java.sql.Timestamp;
import java.util.List;

public interface OrdersV2Repository extends BaseRepository<OrdersV2> {
  OrdersV2 findByAdmissionId(Long admissionId);

  OrdersV2 findByOrdersNumber(String orderNumber);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersV2FetchResponseDto(o, c, u) FROM OrdersV2 o JOIN AdmissionV2 a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE o.active=true AND a.createdDate >= :admissionCreatedDate  AND d.companyCode=:companyCode")
  List<OrdersV2FetchResponseDto> fetchOrders(
      String companyCode, Pageable pageable, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT count(*) FROM OrdersV2 o JOIN AdmissionV2 a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND d.companyCode=:companyCode")
  Long countOrders(String companyCode, Timestamp admissionCreatedDate);

  @Query(
      "SELECT new com.nissan.common.dto.DownloadCsvOrderV2ListDTO (a.createdDate, a.statusJp, a.id, o.ordersNumber, d.companyCode, o.companyName, o.dealershipName, o.phoneNumber, o.caName, o.caNameKana, o.caCode, d.email, c.customerType, m.modelName, g.gradeName, n.naviName, op.optionsName, pc.packagePlanName, o.vinNumber, o.registrationDate, a.vinRegisteredDate, a.ncId, a.cwStatus, a.ncJoinedDate, o.chargeStartDate, o.serviceUpdateDate, o.adopterId, o.registerNumber, m.cwModelName, o.planPrice, a.emailSendDate, pm.name, o.vehicleTransfer, o.oldVinNumber, o.active, o.source, o.vehicleType, m.category, n.colorOption, com.reasonId, com.comment) FROM DealerEntity d JOIN AdmissionV2 a on d.dealerId=a.dealer JOIN OrdersV2 o on a.id= o.admission LEFT JOIN OptionsV2 op on op.id=o.options LEFT JOIN ModelV2 m on o.model=m.id LEFT JOIN GradeV2 g on g.id=o.grade LEFT JOIN NaviV2 n on n.id=o.navi LEFT JOIN PackagePlanV2 pc on pc.id=o.packagePlan LEFT JOIN Customer c on c.user=a.user LEFT JOIN PaymentMethod pm on o.paymentMethod=pm.id LEFT JOIN CommentV2 com on com.orders=o.id WHERE o.createdDate >= :start and o.createdDate <= :end")
  List<DownloadCsvOrderV2ListDTO> fetchOrdersDetails(Timestamp start, Timestamp end);

  @Query(
      "SELECT o from OrdersV2 o JOIN AdmissionV2 a on a.id=o.admission WHERE o.active=true AND o.uploadKameri=false AND o.lastModifiedDate BETWEEN :startDate AND :endDate AND ((o.source = 'home' and a.status = 'DEALER_COMPLETED') or (o.source = 'dealer' and a.status = 'DEALER_ALL_COMPLETED')) AND o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper')")
  List<OrdersV2> fetchOrdersForKameri(Timestamp startDate, Timestamp endDate);

  @Query(
          "SELECT o from OrdersV2 o JOIN AdmissionV2 a on a.id=o.admission WHERE o.active=true AND o.lastModifiedDate BETWEEN :startDate AND :endDate AND a.status='BANK_ID_RESETTING' AND o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper')")
  List<OrdersV2> fetchResettingOrdersForKameri(Timestamp startDate, Timestamp endDate);

  @Query(
          "SELECT o from OrdersV2 o JOIN AdmissionV2 a on a.id=o.admission WHERE o.active=true AND o.lastModifiedDate BETWEEN :startDate AND :endDate AND a.status='VIN_RESETTING' AND o.withdrawCorrectVin IS NOT NULL AND o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper')")
  List<OrdersV2> fetchVinResettingOrdersForKameri(Timestamp startDate, Timestamp endDate);

  @Query(
          "SELECT o from OrdersV2 o JOIN AdmissionV2 a  on o.admission=a.id where o.active=true and  ((o.source = 'home' and a.status = 'DEALER_COMPLETED') or (o.source = 'dealer' and a.status = 'DEALER_ALL_COMPLETED')) AND o.lastModifiedDate <= :startDate")
  List<OrdersV2> fetchAllTwoDaysBackOrders(Timestamp startDate);

  @Query(
          "SELECT o from OrdersV2 o JOIN AdmissionV2 a  on o.admission=a.id where o.active=true and  a.cwStatus in ('SZ','SS')")
  List<OrdersV2> findByCarWingsStatus();

  OrdersV2 findByOrdersNumberAndVinNumber(String orderNo, String vin);

  @Query("SELECT o FROM OrdersV2 o JOIN AdmissionV2 a on o.admission = a.id WHERE a.createdDate <= :expiryDate AND a.status in ('CUSTOMER_FILLING','CUSTOMER_FILLING_FROM_HOME','DEALER_WORKING','CUSTOMER_COMPLETED','CANCEL','WITHDRAWAL','PERSONAL_INFO_DELETED','BANK_ID_CONFIRMING','BANK_ID_RESETTING','VIN_RESETTING')")
  List<OrdersV2> fetchOrdersCreatedDateBefore(Timestamp expiryDate);;
}
