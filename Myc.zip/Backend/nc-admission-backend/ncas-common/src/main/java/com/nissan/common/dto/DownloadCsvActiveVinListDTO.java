package com.nissan.common.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class DownloadCsvActiveVinListDTO {
    private LocalDateTime enrollmentDate;
    private String ncJoinDate;
    private String status;
    private Long ncasNumber;
    private String profitDealerCode;
    private String companyName;
    private String dealerShopName;
    private String dealerCode;
    private String dealerPhoneNumber;
    private String caName;
    private String caCode;
    private String caNameLending;
    private String caCodeLending;
    private String model;
    private String packagePlan;
    private Long price;
    private String vin;
    private String naviId;
    private String carPlan;
    private String flagType;
    private String source;
    private Boolean ivi;
    private Boolean icc;
    private String ncId;
    private String ncPwd;
    private String expirationDatePwd;

    public DownloadCsvActiveVinListDTO(LocalDateTime enrollmentDate, String ncJoinDate, String status, Long ncasNumber, String profitDealerCode, String companyName, String dealerShopName, String dealerCode, String dealerPhoneNumber, String caName, String caCode, String caNameLending, String caCodeLending, String model, String packagePlan, Long price, String vin, String naviId, String carPlan, String flagType, String source, Boolean ivi, Boolean icc, String ncId, String ncPwd, String expirationDatePwd) {
        this.enrollmentDate = enrollmentDate;
        this.ncJoinDate = ncJoinDate;
        this.status = status;
        this.ncasNumber = ncasNumber;
        this.profitDealerCode = profitDealerCode;
        this.companyName = companyName;
        this.dealerShopName = dealerShopName;
        this.dealerCode = dealerCode;
        this.dealerPhoneNumber = dealerPhoneNumber;
        this.caName = caName;
        this.caCode = caCode;
        this.caNameLending = caNameLending;
        this.caCodeLending = caCodeLending;
        this.model = model;
        this.packagePlan = packagePlan;
        this.price = price;
        this.vin = vin;
        this.naviId = naviId;
        this.carPlan = carPlan;
        this.flagType = flagType;
        this.source = source;
        this.ivi = ivi;
        this.icc = icc;
        this.ncId = ncId;
        this.ncPwd = ncPwd;
        this.expirationDatePwd = expirationDatePwd;
    }
}
