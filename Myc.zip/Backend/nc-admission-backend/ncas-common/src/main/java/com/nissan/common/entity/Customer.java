package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
public class Customer extends Auditable<String> {

  @Id
  @Column(name = "id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_id_seq")
  @SequenceGenerator(name = "customer_id_seq", sequenceName = "customer_id_seq", allocationSize = 1)
  private Long id;

  @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "user_id", referencedColumnName = "id", insertable = true, updatable = true)
  private User user;

  @Column(name = "family_name")
  private String familyName;

  @Column(name = "family_name_katakana")
  private String familyNameKatakana;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "first_name_katakana")
  private String firstNameKatakana;

  @Column(name = "corporate_name")
  private String corporateName;

  @Column(name = "office_position")
  private String officePosition;

  @Column(name = "representative_name")
  private String representativeName;

  @Column(name = "representative_name_katakana")
  private String representativeNameKatakana;

  @Column(name = "address1")
  private String address1;

  @Column(name = "address2")
  private String address2;

  @Column(name = "phone_number1")
  private String phoneNumber1;

  @Column(name = "phone_number2")
  private String phoneNumber2;

  @Column(name = "phone_number3")
  private String phoneNumber3;

  @Column(name = "optional_phone_number1")
  private String optionalPhoneNumber1;

  @Column(name = "optional_phone_number2")
  private String optionalPhoneNumber2;

  @Column(name = "optional_phone_number3")
  private String optionalPhoneNumber3;

  @Column(name = "zip_code1")
  private String zipCode1;

  @Column(name = "zip_code2")
  private String zipCode2;

  @Column(name = "email")
  private String email;

  @Column(name = "step_count")
  private Long stepCount;

  @Column(name = "customer_type")
  private Long customerType;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "active")
  private Boolean active;

  @Column(name = "nc_status")
  private String ncStatus;

  @Column(name = "source")
  private String source;
}
