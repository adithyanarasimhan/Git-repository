package com.nissan.common.dto;

import lombok.Data;

@Data
public class NCInfoDTO {
    private String carwingsVinNumber;
    private String vinRegisteredDate;
    private String firstRegisteredDate;
    private String ncStatus;
    private String ncID;
    private String ncJoinedDate;
}
