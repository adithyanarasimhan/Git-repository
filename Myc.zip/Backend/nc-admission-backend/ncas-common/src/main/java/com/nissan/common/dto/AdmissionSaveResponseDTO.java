package com.nissan.common.dto;

import lombok.Data;

@Data
public class AdmissionSaveResponseDTO {
  private Long admissionId;
  private String orderNumber;
  private Integer admissionType;
  private Integer model;
  private Integer grade;
  private Integer naviType;
  private Integer paymentMethod;
  private String vehicleTransfer;
  private String vinNumber;
  private Integer packagePlan;
  private Long reasonType;
  private String comments;
  private String userName;
  private String signature;
  private Integer userId;
  private String token;
}
