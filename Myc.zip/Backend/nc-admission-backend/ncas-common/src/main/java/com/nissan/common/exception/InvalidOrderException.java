package com.nissan.common.exception;

public class InvalidOrderException extends RuntimeException {
    public InvalidOrderException(String exception) {
        super(exception);
    }
}
