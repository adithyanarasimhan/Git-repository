package com.nissan.common.repository;

import com.nissan.common.entity.GradeV2;
import com.nissan.common.entity.NaviV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface NaviV2Repository extends JpaRepository<NaviV2, Long>, QuerydslPredicateExecutor<NaviV2> {
    @Query(value = "SELECT * FROM naviv2 where grade_id=?1", nativeQuery = true)
    List<NaviV2> getNaviListByGradeId(long gradeId);

    List<NaviV2> findByGradeAndVehicleTypeIn(GradeV2 gradeV2, Set<String> vehicleType);

    NaviV2 findByGradeIdAndCwNaviNameAndLangCode(Long gradeId, String cwNaviName, String langCode);
}
