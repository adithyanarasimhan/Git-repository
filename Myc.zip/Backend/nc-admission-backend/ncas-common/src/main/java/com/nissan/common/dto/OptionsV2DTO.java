package com.nissan.common.dto;

import lombok.Data;

@Data
public class OptionsV2DTO {
    private long id;
    private long naviId;
    private String name;
    private String displayName;
}
