/**
 * 
 */
package com.nissan.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.zip.GZIPInputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.io.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nissan.common.entity.VinDetails;

/**
 * Utility class for Demo car
 *
 */
public class DemoCarUtil {

	private DemoCarUtil() {

	}

	private static final Logger logger = LoggerFactory.getLogger(DemoCarUtil.class);

	/*
	 * Method to convert csv file to xlsx format
	 */
	public static File convertCsvToXLSX(File csvFile, File xlsxFile) {
		try (FileOutputStream fileOutputStream = new FileOutputStream(xlsxFile);
				BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			XSSFWorkbook workBook = new XSSFWorkbook();
			XSSFSheet sheet = workBook.createSheet("sheet1");
			String currentLine = null;
			int rowNum = 0;
			while ((currentLine = br.readLine()) != null) {
				currentLine = currentLine.replace("\"", "");
				String[] str = currentLine.split(",");
				XSSFRow currentRow = sheet.createRow(rowNum);
				rowNum++;
				for (int i = 0; i < str.length; i++) {
					currentRow.createCell(i).setCellValue(str[i]);
				}
			}
			workBook.write(fileOutputStream);
			logger.info("Compass file converted to XLSX format.");
		} catch (Exception ex) {
			logger.error("Failed to convert the Compass csv file.");
		}
		return xlsxFile;
	}

	/*
	 * Method to unzip and untar a '.tar.gz' file
	 */
	public static File unGzipUnTar(File gZipTarFile) {
		File csvFile = null;
		try (TarArchiveInputStream tarInput = new TarArchiveInputStream(
				new GZIPInputStream(new FileInputStream(gZipTarFile)))) {
			tarInput.getNextTarEntry();
			csvFile = File.createTempFile("compasscsv", ".csv");
			FileOutputStream outputFile = new FileOutputStream(csvFile);
			IOUtils.copy(tarInput, outputFile);
			outputFile.close();
			logger.info("UnGzip and UnTar Compass file success.");
		} catch (IOException e) {
			logger.error("Failed to UnGzip/UnTar the Compass file.");
		}
		return csvFile;
	}

	public static File sevenZipSingleFile(String source, String target) {
		File zipFile = new File(target);
		File sourceFile = new File(source);
		try (SevenZOutputFile out = new SevenZOutputFile(zipFile);
				FileInputStream in = new FileInputStream(sourceFile)) {
			SevenZArchiveEntry entry = out.createArchiveEntry(sourceFile, sourceFile.getName());
			out.putArchiveEntry(entry);
			byte[] b = new byte[1024];
			int count = 0;
			while ((count = in.read(b)) > 0) {
				out.write(b, 0, count);
			}
			out.closeArchiveEntry();
			logger.info("File compressed successfully.");
		} catch (IOException e) {
			logger.error("Failed to compress the file : {}", e.getMessage());
		}
		return zipFile;
	}
	
	public static VinDetails findVinDetailsByVin(Collection<VinDetails> vinDetails, String vin) {
        if (CollectionUtils.isEmpty(vinDetails)) {
            return null;
        }
        return vinDetails.stream().filter(vinDetail -> vin.equals(vinDetail.getVin())).findFirst().orElse(null);
    }
}
