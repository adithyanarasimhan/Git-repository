package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@Table(name = "admission")
@EntityListeners(AuditingEntityListener.class)
public class Admission extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.REFRESH, CascadeType.MERGE})
  @JoinColumn(name = "user_id", referencedColumnName = "id")
  private User user;

  @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.REFRESH, CascadeType.MERGE})
  @JoinColumn(name = "dealer_id", referencedColumnName = "dealer_id")
  private DealerEntity dealer;

  @Column(name = "status")
  private String status;

  @Column(name = "status_jp")
  private String statusJp;

  @Column(name = "email_send_date")
  private LocalDate emailSendDate;

  @Column(name = "vin_registered_date")
  private Date vinRegisteredDate;

  @Column(name = "nc_id")
  private String ncId;

  @Column(name = "nc_password")
  private String ncPassword;

  @Column(name = "active")
  private Boolean active;

  @Column(name = "nc_joined_date")
  private Date ncJoinedDate;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "cw_status")
  private String cwStatus;

  @Column(name = "nc_id_generated_date")
  private LocalDate ncIdGeneratedDate;

  @Column(name = "po_mapping")
  private Boolean poMapping;
}
