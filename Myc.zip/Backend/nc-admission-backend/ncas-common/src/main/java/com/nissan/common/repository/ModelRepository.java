package com.nissan.common.repository;

import com.nissan.common.entity.Model;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ModelRepository
    extends JpaRepository<Model, Long>, QuerydslPredicateExecutor<Model> {
  List<Model> findByLangCodeOrderByIdAsc(String lang);

  List<Model> findByLangCodeOrderByModelDisplayOrderAsc(String lang);

  Model findByModelNameAndLangCode(String modelName, String lang);

  @Query(value = "SELECT * FROM model m where m.active = true AND m.lang_code=?1 ORDER BY m.model_display_order ASC", nativeQuery = true)
  List<Model> findByLangCodeActiveTrueOrderByModelDisplayOrderAsc(String lang);

  @Query(value = "SELECT * FROM model m where m.active = true AND m.lang_code=:lang and m.id IN (:ids)", nativeQuery = true)
  Model findByLangCodeAndIds(@Param("lang") String lang, @Param("ids") List<Integer> ids);
}
