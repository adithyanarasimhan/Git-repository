package com.nissan.common.service.impl;

import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.dto.DealerAddressDTO;
import com.nissan.common.dto.DealerAddressResponseDTO;
import com.nissan.common.dto.DealerVisitTimeEnum;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.service.MapionService;
import com.nissan.common.util.Constants;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolException;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultRedirectStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HttpContext;
import org.json.JSONObject;
import org.json.XML;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.util.UriUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Service
public class MapionServiceImp implements MapionService {

  private static final Logger logger = LoggerFactory.getLogger(MapionServiceImp.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(MapionServiceImp.class);

  private static final String EUC_JP = "EUC-JP";

  private static final String FORMAT = "0x%02X";

  private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MM/dd");

  @Value("${ncas.dealer.visit}")
  private String DEALER_VISIT_API;

  @Value("${ncas.dealer.callback}")
  private String CALL_BACK_API;

  @Value("${ncas.dealer.status}")
  private String DEALER_STATUS_API;

  @Value("${nissan.mapion.url}")
  private String mapionURL;

  @Autowired UserRepository userRepository;
  @Autowired AdmissionRepository admissionRepository;
  @Autowired AdmissionV2Repository admissionV2Repository;
  @Autowired OrdersV2Repository ordersV2Repository;
  @Autowired DealerAddressRepository addressRepository;
  @Autowired LocationAddressRepository locationRepository;
  @Autowired TempoDotNetRepository tempoDotNetRepository;
  @Autowired CustomerRepository customerRepository;

  @Override
  public List<DealerAddressDTO> getAddressByZip(String zipCode, int radius) throws Exception {

    long range = radius * (long) 1000;

    logger.info("Inside fetch address for customer");
    List<DealerAddressDTO> dealerAddressDTOS = new ArrayList<>();
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Zip code entered is  "+ zipCode);
    UriComponents targetUrl= UriComponentsBuilder.fromUriString(mapionURL).queryParam("uc","133")
            .queryParam("zip",zipCode).queryParam("pn","10")
            .queryParam("BT1","1").queryParam("radius"+range)
            .build();
    RestTemplate restTemplate = new RestTemplate();
    restTemplate.setRequestFactory(getClientHttpRequestFactory());
    ResponseEntity<String> response = restTemplate.getForEntity(targetUrl.toUri(), String.class);
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Nissan Map response is "+ response);
    ObjectMapper mapper = new ObjectMapper();
    JsonNode array = mapper.readValue(response.getBody(), JsonNode.class);
    if (response.getStatusCode() == HttpStatus.OK) {
      JsonNode object = array.get("tempo");
      if (object == null) {
        throw new ResourceNotFoundException("No Dealer Address found");
      }

      Iterator<JsonNode> iterator = object.iterator();
      logger.info("Response json node iteration");
      while (iterator.hasNext()) {
        JsonNode dealerObject = iterator.next();
        if (StringUtils.isNotEmpty(dealerObject.path("hscd").asText())) {

          DealerAddressDTO dealer = getMapDetails(dealerObject);
          TempoDotNet tempoDotNet =
              tempoDotNetRepository.findByCaCompanyCode(dealer.getCompanyCode());
          if (tempoDotNet != null && !"0".equals(tempoDotNet.getNewVehicleFlag())) {
            dealer.setZipCode(zipCode);
            dealer.setRadius(String.valueOf(radius));
            dealer.setDealerPhoneNumber(tempoDotNet.getDealerCompanyPhoneNumber());
            dealer.setRegularClosingDay1(tempoDotNet.getRegularClosingDay1());
            dealer.setRegularClosingDay2(tempoDotNet.getRegularClosingDay2());
            dealerAddressDTOS.add(dealer);
          }
        }
      }
    } else {
      throw new ResourceNotFoundException("Invalid request");
    }
    return dealerAddressDTOS;
  }

  @Override
  public List<DealerAddressDTO> getAddressByLoc(
      String prefecture, String city1, String city2, int radius) throws Exception {

    long range = radius * (long) 1000;
    logger.info("Inside getAddressByLoc address for customer");
    List<DealerAddressDTO> dealerAddressDTOS = new ArrayList<>();

    String address = prefecture + city1 + city2;
    byte[] bytes = address.getBytes(EUC_JP);
    StringBuilder sb = new StringBuilder();
    for (byte b : bytes) {
      sb.append(String.format(FORMAT, b));
    }
    String encoded = sb.toString().replace("0x", "%");
    logger.info("Encoded prefecture string is {}", encoded);

    String url = mapionURL + "uc=134&add=" + encoded + "&pn=10&BT1=1&radius=" + range;
    StringBuilder response = new StringBuilder();
    URL obj = new URL(url);
    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
    int responseCode = con.getResponseCode();
    logger.info("Address API GET Response Code :: {}", responseCode);
    if (responseCode == HttpURLConnection.HTTP_OK) { // success
      BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
      String inputLine;
      while ((inputLine = in.readLine()) != null) {
        response.append(inputLine);
      }
      in.close();
      mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Address API Map response is "+ response);
    } else {
      logger.info("Address API Map Invalid request");
      throw new ResourceNotFoundException("Invalid request");
    }

    ObjectMapper mapper = new ObjectMapper();
    JsonNode array = mapper.readValue(response.toString(), JsonNode.class);
    JsonNode object = array.get("tempo");
    if (object == null) {
      throw new ResourceNotFoundException("No Dealer Address found");
    } else {
      Iterator<JsonNode> iterator = object.iterator();
      logger.info("Response json node iteration");
      while (iterator.hasNext()) {
        JsonNode dealerObject = iterator.next();
        if (StringUtils.isNotEmpty(dealerObject.path("hscd").asText())) {

          DealerAddressDTO dealer = getMapDetails(dealerObject);
          TempoDotNet tempoDotNet =
              tempoDotNetRepository.findByCaCompanyCode(dealer.getCompanyCode());
          if (tempoDotNet != null && !"0".equals(tempoDotNet.getNewVehicleFlag())) {
            dealer.setPrefecture(prefecture);
            dealer.setCity1(city1);
            dealer.setCity2(city2);
            dealer.setRadius(String.valueOf(radius));
            dealer.setDealerPhoneNumber(tempoDotNet.getDealerCompanyPhoneNumber());
            dealer.setRegularClosingDay1(tempoDotNet.getRegularClosingDay1());
            dealer.setRegularClosingDay2(tempoDotNet.getRegularClosingDay2());
            dealerAddressDTOS.add(dealer);
          }
        }
      }
    }
    return dealerAddressDTOS;
  }

  @Override
  public DealerAddressResponseDTO saveDealer(String userName, DealerAddressDTO addressDTO) {

    DealerAddress dealerAddress = null;
    User user = new User();
    Optional<User> optionalUser = userRepository.findById(Long.valueOf(userName));
    if (optionalUser.isPresent()) {
      user = optionalUser.get();
    }

    AdmissionV2 admission = admissionV2Repository.fetchByUserId(user.getId());
    dealerAddress = addressRepository.findByAdmissionId(admission.getId());
    if (dealerAddress == null) {
      dealerAddress = new DealerAddress();
    }
    dealerAddress.setAdmission(admission);
    dealerAddress.setCompanyCode(addressDTO.getCompanyCode());
    dealerAddress.setCompanyName(addressDTO.getCompanyName());
    dealerAddress.setDealershipCode(addressDTO.getDealershipCode());
    dealerAddress.setDealershipName(addressDTO.getDealerName());
    dealerAddress.setPrefectureName(addressDTO.getPrefectureName());
    dealerAddress.setDealershipAddress(addressDTO.getAddress());
    dealerAddress.setPhoneNumber(addressDTO.getPhoneNumber());
    dealerAddress.setTotalDistance(addressDTO.getTotalDistance());
    dealerAddress.setZipCode(addressDTO.getZipCode());
    dealerAddress.setPrefecture(addressDTO.getPrefecture());
    dealerAddress.setLatitude(addressDTO.getLatitude());
    dealerAddress.setLongitude(addressDTO.getLongitude());
    dealerAddress.setCity1(addressDTO.getCity1());
    dealerAddress.setCity2(addressDTO.getCity2());
    dealerAddress.setVisitDate(addressDTO.getVisitDate());
    dealerAddress.setVisitTime(addressDTO.getVisitTime());
    dealerAddress.setRegularClosingDay1(addressDTO.getRegularClosingDay1());
    dealerAddress.setRegularClosingDay2(addressDTO.getRegularClosingDay2());
    dealerAddress.setRadius(addressDTO.getRadius());
    dealerAddress.setLabel(addressDTO.getLabel());
    return getDealerAddressResponse(addressRepository.save(dealerAddress));
  }

  @Override
  public List<String> getCityDetails(Optional<String> prefecture, Optional<String> city1) {

    if (prefecture.isPresent() && city1.isPresent()) {
      return locationRepository.getCityByPrefecture(prefecture.get(), city1.orElse(" "));
    } else if (prefecture.isPresent()) {
      return locationRepository.getCityName1(prefecture.get());
    } else if (city1.isPresent()) {
      return locationRepository.getCityName2(city1.orElse(" "));
    } else {
      throw new ResourceNotFoundException("Invalid request.");
    }
  }

  @Override
  public String getDealerVisitStatus(Long admissionId) {
    DealerAddress dealerAddress = addressRepository.findByAdmissionId(admissionId);
    OrdersV2 orders = ordersV2Repository.findByAdmissionId(admissionId);
    ModelV2 vehicleModel = orders.getModel();
    String companyCode = dealerAddress.getCompanyCode();
    UriComponentsBuilder apiBuilder = UriComponentsBuilder.fromHttpUrl (DEALER_STATUS_API);
    apiBuilder.queryParam("car_name", getShiftJSValue(vehicleModel.getModelName()));
    apiBuilder = getDealerVisitAPI(admissionId, apiBuilder);
    UriComponentsBuilder apiCallBack = UriComponentsBuilder.fromHttpUrl (DEALER_VISIT_API);
    apiCallBack.queryParam("hansya_cd",companyCode);
    apiCallBack.queryParam("uke_url",CALL_BACK_API);
    HttpHeaders headers = new HttpHeaders();
    headers.set("dealerShipCode", dealerAddress.getDealershipCode());
    headers.set("companyCode", dealerAddress.getCompanyCode());
    MediaType mediaType =
            new MediaType("application", "x-www-form-urlencoded", Charset.forName("SHIFT-JIS"));
    headers.setContentType(mediaType);
    HttpEntity<String> request = new HttpEntity<>(headers);
    RestTemplate restTemplate = getRestTemplate(apiBuilder);
    ResponseEntity<String> response = restTemplate.exchange(apiCallBack.toUriString(), HttpMethod.GET, request, String.class);
    int statusCode = response.getStatusCodeValue();
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Dealer visit API 1 status code : "+ statusCode);
    String result =
        response.getHeaders().get("result") == null ? "" : response.getHeaders().getFirst("result");
    JSONObject xmlJSONObj = XML.toJSONObject(result);
    String visitStatusCode = xmlJSONObj.getJSONObject("receiving_as").get("result").toString();
    String visitStatus =
        Integer.parseInt(visitStatusCode) == 0 ? Constants.SUCCESS : Constants.FAILED;
    dealerAddress.setVisitStatus(visitStatus);
    addressRepository.save(dealerAddress);
    return visitStatus;
  }

  public DealerAddressDTO getMapDetails(JsonNode dealerObject) {

    DealerAddressDTO dealer = new DealerAddressDTO();
    dealer.setCompanyCode(dealerObject.path("hscd").asText());
    dealer.setCompanyName(dealerObject.path("hsnm").asText());
    dealer.setDealershipCode(dealerObject.path("tcd").asText());
    dealer.setDealerName(dealerObject.path("tnm").asText());
    dealer.setPrefectureName(dealerObject.path("fken_nm").asText());
    dealer.setAddress(dealerObject.path("jusho").asText());
    dealer.setPhoneNumber(dealerObject.path("tell").asText());
    dealer.setTotalDistance(dealerObject.path("dist").asText());
    dealer.setRegularHoliday(dealerObject.path("teikyu").asText());
    dealer.setLatitude(dealerObject.path("tnl").asDouble());
    dealer.setLongitude(dealerObject.path("tel").asDouble());
    return dealer;
  }

  private SimpleClientHttpRequestFactory getClientHttpRequestFactory() {
    SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
    /** Connect timeout */
    clientHttpRequestFactory.setConnectTimeout(95000);

    /** Read timeout */
    clientHttpRequestFactory.setReadTimeout(95000);
    return clientHttpRequestFactory;
  }

  private RestTemplate getRestTemplate(UriComponentsBuilder apiBuilder) {
    CloseableHttpClient httpClient =
        HttpClientBuilder.create()
            .setRedirectStrategy(
                new DefaultRedirectStrategy() {

                  @Override
                  public boolean isRedirected(
                      HttpRequest request, HttpResponse response, HttpContext context)
                      throws ProtocolException {

                    System.out.println(response);
                    /** If redirect intercept intermediate response. */
                    if (super.isRedirected(request, response, context)) {
                      int statusCode = response.getStatusLine().getStatusCode();
                      String redirectURL = response.getFirstHeader("Location").getValue();
                      logger.info("redirectURL: {}", redirectURL);
                      URL url = null;
                      try {
                        url = new URL(redirectURL);
                        String sessionKey = url.getQuery().substring(4);
                        apiBuilder.queryParam("session_key",sessionKey);
                        RestTemplate restTemplate = new RestTemplate();
                        ResponseEntity<String> dealerResponse =
                            restTemplate.exchange(
                                apiBuilder.toUriString(), HttpMethod.GET, null, String.class);
                        response.setHeader("result", dealerResponse.getBody());
                      } catch (MalformedURLException e) {
                        e.printStackTrace();
                      }
                      return false;
                    }
                    return false;
                  }
                })
            .build();
    HttpComponentsClientHttpRequestFactory factory =
        new HttpComponentsClientHttpRequestFactory(httpClient);
    return new RestTemplate(factory);
  }

  private UriComponentsBuilder getDealerVisitAPI(Long admissionId, UriComponentsBuilder apiBuilder) {
    AdmissionV2 admission = admissionV2Repository.findById(admissionId).get();
    Optional<Customer> optionalCustomer =
        customerRepository.findByUserId(admission.getUser().getId());
    DealerAddress dealerAddress = addressRepository.findByAdmissionId(admission.getId());
    apiBuilder.queryParam("hansya_cd",dealerAddress.getCompanyCode());
    apiBuilder.queryParam("store_cd", dealerAddress.getDealershipCode());
    apiBuilder.queryParam("visit_time", DealerVisitTimeEnum.getValue(dealerAddress.getVisitTime()));
    if (optionalCustomer.isPresent()) {
      Customer customer = optionalCustomer.get();
      if (customer.getFamilyName() != null) {
        apiBuilder.queryParam("name1", getShiftJSValue(customer.getFamilyName()));
      }
      if (customer.getFirstName() != null) {
        apiBuilder.queryParam("name2", getShiftJSValue(customer.getFirstName()));
      }
      if (customer.getFamilyNameKatakana() != null) {
        apiBuilder.queryParam("kana1", getShiftJSValue(customer.getFamilyNameKatakana()));
      }
      if (customer.getFirstNameKatakana() != null) {
        apiBuilder.queryParam("kana2", getShiftJSValue(customer.getFirstNameKatakana()));
      }
      if (customer.getZipCode1() != null) {
        apiBuilder.queryParam("zip_t3",customer.getZipCode1());
        apiBuilder.queryParam("zip_l4", customer.getZipCode2());
      }
      if (dealerAddress != null) {
        String prefName = dealerAddress.getPrefectureName();
        apiBuilder.queryParam("pref_cd", locationRepository.getPrefCodeByPrefecture(prefName));
      }

      if (customer.getAddress1() != null) {
        apiBuilder.queryParam("add_city", getShiftJSValue(customer.getAddress1()));
      }
      if (customer.getAddress2() != null) {
        apiBuilder.queryParam("add_other", getShiftJSValue(customer.getAddress2()));
      }
      if (customer.getEmail() != null) {
        apiBuilder.queryParam("mail_add", customer.getEmail());
      }
      if (customer.getPhoneNumber1() != null) {
        apiBuilder.queryParam("tel_num_up", customer.getPhoneNumber1());
        apiBuilder.queryParam("tel_num_mid", customer.getPhoneNumber2());
        apiBuilder.queryParam("tel_num_low", customer.getPhoneNumber3());
      }
      if (customer.getOptionalPhoneNumber1() != null) {
        apiBuilder.queryParam("tel_other_up", customer.getOptionalPhoneNumber1());
        apiBuilder.queryParam("tel_other_mid", customer.getOptionalPhoneNumber2());
        apiBuilder.queryParam("tel_other_low", customer.getOptionalPhoneNumber3());
      }
      apiBuilder.queryParam("visit_day", FORMATTER.format(dealerAddress.getVisitDate()));
      apiBuilder.queryParam(
          "free_comment",
          getShiftJSValue(
              "■■お客さまに、来店のご用件について確認のご連絡をお願いします■■\nそれに伴い、来店希望日が設定されております。\n"
                  + "お客さまにご連絡の上、ご用件と来店日時をご確認ください。\n＜お客さまのご来店が必要となるケースは以下の二つです＞\n"
                  + "　●SOSコール初期設定の実施\n"
                  + "　　　SOSコールをお申込いただいた場合、販売店での初期設定が必要となります。\n"
                  + "　　　お客さまにご連絡の上、ご案内をお願い致します。\n"
                  + "\n"
                  + "　●TCU-ON作業の実施\n"
                  + "　　　2020年1月以前発売のEV車については、TCU-ONの作業を実施する必要があります。\n"
                  + "　　　お客さまにご連絡の上、ご案内をお願い致します。\n"
                  + "　　　但し、ZESP・ZESP2満期に伴い、改めてNissanConnectにお申込いただいた場合は、\n"
                  + "　　　すでにTCU-ONの状態である可能性があり(※)ご来店の必要はありません。\n"
                  + "　　　ご連絡の際にお客さまにご確認ください。\n"
                  + "　　　　(※)ZESP・ZESP2満期による退会から1ヶ月間は、TCU-ONの状態が維持されます"));
    }

    return apiBuilder;
  }

  private DealerAddressResponseDTO getDealerAddressResponse(DealerAddress address) {
    if (address == null) {
      return null;
    }
    DealerAddressResponseDTO dealerAddress = new DealerAddressResponseDTO();
    dealerAddress.setCompanyCode(address.getCompanyCode());
    dealerAddress.setCompanyName(address.getCompanyName());
    dealerAddress.setDealershipCode(address.getDealershipCode());
    dealerAddress.setDealerName(address.getDealershipName());
    dealerAddress.setPrefectureName(address.getPrefectureName());
    dealerAddress.setAddress(address.getDealershipAddress());
    dealerAddress.setPhoneNumber(address.getPhoneNumber());
    dealerAddress.setTotalDistance(address.getTotalDistance());
    dealerAddress.setZipCode(address.getZipCode());
    dealerAddress.setPrefecture(address.getPrefecture());
    dealerAddress.setLatitude(address.getLatitude());
    dealerAddress.setLongitude(address.getLongitude());
    dealerAddress.setCity1(address.getCity1());
    dealerAddress.setCity2(address.getCity2());
    dealerAddress.setVisitDate(address.getVisitDate());
    dealerAddress.setVisitTime(address.getVisitTime());
    dealerAddress.setRadius(address.getRadius());
    return dealerAddress;
  }

  private String getShiftJSValue(String data) {
    if (!isEnglish(data)) {
      return UriUtils.encodePath(data, Constants.SHIFT_JIS);
    }
    return data;
  }

  private boolean isEnglish(CharSequence charSequence) {
    boolean isEnglish = true;
    for (char c : charSequence.toString().toCharArray()) {
      if (Character.UnicodeBlock.of(c) != Character.UnicodeBlock.BASIC_LATIN) {
        isEnglish = false;
        break;
      }
    }

    return isEnglish;
  }
}
