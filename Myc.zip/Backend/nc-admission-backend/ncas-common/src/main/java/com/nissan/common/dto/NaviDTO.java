package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class NaviDTO {
    private long id;
    private long gradeId;
    private String name;
    private String displayName;
    private List<PackagePlanDTO> packagePlans;
    private List<OptionDTO> options;
}
