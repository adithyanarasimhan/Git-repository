package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "notification")
@EntityListeners(AuditingEntityListener.class)
public class Notification extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "notification_name")
  private String notificationName;

  @Column(name = "display_name")
  private String displayName;

  @Column(name = "lang_code")
  private String langCode;
}
