package com.nissan.common.exception;

public class IncompleteOrderException extends RuntimeException {
    public IncompleteOrderException(String exception) {
        super(exception);
    }
}
