package com.nissan.common.dto;

import lombok.Data;

@Data
public class AvailableColorDTO {
    private Long id;
    private String colorCode;
    private String name;
    private String displayName;
    private String image;
}
