package com.nissan.common.service;

import com.nissan.common.dto.UserDto;
import com.nissan.common.entity.User;

public interface UserService {
  User saveUser(UserDto userDto);
}
