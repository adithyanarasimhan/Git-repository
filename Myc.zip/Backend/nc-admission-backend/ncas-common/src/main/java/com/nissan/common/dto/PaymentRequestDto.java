package com.nissan.common.dto;

import lombok.Data;

@Data
public class PaymentRequestDto {
  private String MerchantId;
  private String Card;
  private String MerchantPass;
  private String TransactionDate;
  private String OperateId;
  private String Token;
  private String TenantId;
  private String PayType;
  private String Amount;
}
