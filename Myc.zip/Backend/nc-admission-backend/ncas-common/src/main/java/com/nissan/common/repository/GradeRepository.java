package com.nissan.common.repository;

import com.nissan.common.entity.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GradeRepository
    extends JpaRepository<Grade, Long>, QuerydslPredicateExecutor<Grade> {
    @Query(value = "SELECT * FROM grade WHERE model_name =?1", nativeQuery = true)
    List<Grade> getGradesByModelName(String modelName);
}
