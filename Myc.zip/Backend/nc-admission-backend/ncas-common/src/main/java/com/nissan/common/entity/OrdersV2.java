package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "ordersv2")
@EntityListeners(AuditingEntityListener.class)
public class OrdersV2 extends Auditable<String> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "orders_number")
    private String ordersNumber;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "admissionv2_id", referencedColumnName = "id")
    private AdmissionV2 admission;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "optionsv2_id", referencedColumnName = "id")
    private OptionsV2 options;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "modelv2_id", referencedColumnName = "id")
    private ModelV2 model;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "gradev2_id", referencedColumnName = "id")
    private GradeV2 grade;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "naviv2_id", referencedColumnName = "id")
    private NaviV2 navi;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "planv2_id", referencedColumnName = "id")
    private PackagePlanV2 packagePlan;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "payment_method", referencedColumnName = "id")
    private PaymentMethod paymentMethod;

    @Column(name = "old_vin")
    private String oldVinNumber;

    @Column(name = "vehicle_transfer")
    private Boolean vehicleTransfer;

    @Column(name = "vin_number")
    private String vinNumber;

    @Column(name = "order_number_ps")
    private String orderNumberPs;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "upload_kameri")
    private Boolean uploadKameri;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "registration_date")
    private String registrationDate;

    @Column(name = "first_registration_date")
    private String firstRegistrationDate;

    @Column(name = "expiry_date")
    private String expiryDate;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "color_id", referencedColumnName = "id")
    private Color color;

    @Column(name = "adopter_id")
    private String adopterId;

    @Column(name = "register_number")
    private String registerNumber;

    @Column(name = "charge_start_date")
    private Date chargeStartDate;

    @Column(name = "service_update_date")
    private Date serviceUpdateDate;

    @Column(name = "source")
    private String source;

    @Column(name = "cw_navi_id")
    private String cwNaviId;

    @Column(name = "color")
    private String colorName;

    @Column(name = "color_code")
    private String colorCode;

    @Column(name = "plan_price")
    private String planPrice;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "dealership_name")
    private String dealershipName;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "ca_name")
    private String caName;

    @Column(name = "ca_name_kana")
    private String caNameKana;

    @Column(name = "ca_code")
    private String caCode;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "customer_name_kana")
    private String customerNameKana;

    @Column(name = "customer_phone_number")
    private String customerPhoneNumber;

    @Column(name = "customer_zipcode")
    private String customerZipCode;

    @Column(name = "vehicle_type")
    private String vehicleType;

    @Column(name = "vin_search_status")
    private String vinSearchStatus;

    @Column(name = "vin_search_color_code")
    private String vinSearchColorCode;

    @Column(name = "old_cw_id")
    private String oldCarwingsId;

    @Column(name = "nc_joined_date")
    private Date ncJoinedDate;

    @Column(name = "withdraw_correct_vin")
    private String withdrawCorrectVin;

    @Column(name = "vehicle_number")
    private String vehicleNumber;

}
