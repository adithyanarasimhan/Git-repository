package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class VehicleInfoResponseDTO {
    private String responseCode;
    private String errorMessage;
    private String modelName;
    private String vinNumber;
    private String naviType;
    private String registeredDate;
    private String color;
    private String colorCode;
    private String vehicleImage;
    private String variant;
    private String naviId;
    private List<PaymentMethodDto> paymentTypes;
    private List<PackagePlansDTO> packagePlans;
}
