package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comment")
@EntityListeners(AuditingEntityListener.class)
public class Comment extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "reason_id")
  private Long reasonId;

  @Column(name = "orders_id")
  private Long ordersId;

  @Column(name = "comment")
  private String comment;

  @Column(name = "active")
  private Boolean active;

  @Column(name = "lang_code")
  private String langCode;
}
