package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class GradeV2DTO {
    private long id;
    private String modelName;
    private String displayName;
    private String name;
    private List<NaviV2DTO> naviTypes;
    private NaviV2DTO naviType;
}
