package com.nissan.common.dto;

import lombok.Data;

@Data
public class ReasonDTO {
    private long id;
    private String name;
    private String displayName;
    private Boolean showInDirectDebitPaper;
}
