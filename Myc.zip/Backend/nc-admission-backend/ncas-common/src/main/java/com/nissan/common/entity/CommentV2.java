package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "commentv2")
@EntityListeners(AuditingEntityListener.class)
public class CommentV2 extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "reason_id")
    private Long reasonId;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.REFRESH, CascadeType.MERGE})
    @JoinColumn(name = "ordersv2_id", referencedColumnName = "id")
    private OrdersV2 orders;

    @Column(name = "comment")
    private String comment;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "lang_code")
    private String langCode;
}
