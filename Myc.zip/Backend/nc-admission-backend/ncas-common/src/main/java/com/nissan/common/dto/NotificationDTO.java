package com.nissan.common.dto;

import lombok.Data;

@Data
public class NotificationDTO {
    private long id;
    private String name;
    private String displayName;
}
