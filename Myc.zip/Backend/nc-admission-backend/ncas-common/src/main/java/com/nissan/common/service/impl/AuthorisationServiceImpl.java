package com.nissan.common.service.impl;

import com.nissan.common.config.JwtAuthenticationProvider;
import com.nissan.common.entity.User;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.util.JwtTokenUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
public class AuthorisationServiceImpl implements AuthorisationService {

  private static final Logger logger = LoggerFactory.getLogger(AuthorisationServiceImpl.class);

  @Autowired UserRepository userRepository;

  @Autowired private DealerRepository dealerRepositoryRepository;

  @Autowired private JwtAuthenticationProvider authenticationManager;

  @Autowired DealerRepository dealerRepository;

  @Autowired private JwtTokenUtil jwtTokenUtil;

  @Override
  public String generateTokenOnUser(Long userId) {
    logger.info("Inside generateTokenOnUser");
    Optional<User> userOptional = userRepository.findById(userId);
    String token = null;
    if (userOptional.isPresent()) {
      User user = userOptional.get();
      Set<GrantedAuthority> authorities = new HashSet<>();
      user.getRoles()
          .forEach(
              role -> {
                authorities.add(new SimpleGrantedAuthority(role.getName()));
              });
      final Authentication authentication =
          authenticationManager.authenticate(
              new UsernamePasswordAuthenticationToken(user, null, authorities));
      // SecurityContextHolder.getContext().setAuthentication(authentication);
      token = jwtTokenUtil.generateToken(authentication);
    }
    return token;
  }

  @Override
  public String generateTokenOnUserNissanConnect(Long userId) {
    Optional<User> userOptional = userRepository.findById(userId);
    String token = null;
    if (userOptional.isPresent()) {
      User user = userOptional.get();
      Set<GrantedAuthority> authorities = new HashSet<>();
      user.getRoles()
          .forEach(
              role -> {
                authorities.add(new SimpleGrantedAuthority(role.getName()));
              });
      final Authentication authentication =
          authenticationManager.authenticate(
              new UsernamePasswordAuthenticationToken(user, null, authorities));
      // SecurityContextHolder.getContext().setAuthentication(authentication);
      token = jwtTokenUtil.generateTokenNissanConnect(authentication);
    }
    return token;
  }
}
