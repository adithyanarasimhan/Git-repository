package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "grade")
@EntityListeners(AuditingEntityListener.class)
public class Grade extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "model_name", referencedColumnName = "model_name")
  private Model model;

  @Column(name = "display_name")
  private String displayName;

  @Column(name = "grade_name")
  private String gradeName;

  @Column(name = "lang_code")
  private String langCode;
}
