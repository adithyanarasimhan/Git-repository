package com.nissan.common.dto;

public enum DealerVisitTimeEnum {

  K1("Any Time", 1),
  K2("9:00-12:00", 2),
  K3("12:00-15:00", 3),
  K4("15:00-18:00", 4);

  private final String key;
  private final Integer value;

  DealerVisitTimeEnum(String key, Integer value) {
    this.key = key;
    this.value = value;
  }

  public String getKey() {
    return key;
  }

  public Integer getValue() {
    return value;
  }

  public static Integer getValue(String value) {
    if (value.equalsIgnoreCase(K1.getKey())) return K1.getValue();
    else if (value.equalsIgnoreCase(K2.getKey())) return K2.getValue();
    else if (value.equalsIgnoreCase(K3.getKey())) return K3.getValue();
    else if (value.equalsIgnoreCase(K4.getKey())) return K4.getValue();
    else return null;
  }
}
