package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class FetchOrdersDTO {
    private List<OrdersFetchResponseDTO> orders;
    private Long totalCount;
}
