package com.nissan.common.dto;

import lombok.Data;

@Data
public class ValidateTokenResponseDTO {
    private Long userId;
    private String userType;
}
