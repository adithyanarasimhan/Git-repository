package com.nissan.common.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.nissan.common.config.SecretsManager;
import com.nissan.common.dto.SftpPropertiesDTO;

@Component
public class SftpOperationsUtil {

	private static final Logger logger = LoggerFactory.getLogger(SftpOperationsUtil.class);

	// Set the prompt when logging in for the first time. Optional value: (ask | yes
	// | no)
	private static final String SESSION_CONFIG_STRICT_HOST_KEY_CHECKING = "StrictHostKeyChecking";

	private String protocol = "sftp";
	private String sessionStrictHostKeyChecking = "no";
	private Integer sessionConnectTimeout = 15000;
	private Integer channelConnectedTimeout = 15000;
	/**
	 * Encrypted key mode login
	 * @param sftpProperties 
	 * 
	 * @return
	 */
	private ChannelSftp connectByKey(SftpPropertiesDTO sftpProperties) throws Exception {
		String host = sftpProperties.getHost();	    
	    SecretsManager secretsManager = new SecretsManager();
	    ByteBuffer byteBuffer = secretsManager.getCertificate(sftpProperties.getPrivateKey());
	    InputStream inputStream = new ByteArrayInputStream(byteBuffer.array());
	    File compassKeyFile = File.createTempFile("compass", ".pem");
	    try {
	      FileUtils.copyInputStreamToFile(inputStream, compassKeyFile);
	    } finally {
	      IOUtils.closeQuietly(inputStream);
	    }
	    JSch jsch = new JSch();
		// Set the key and password, support the key way to login
		if (!StringUtils.isEmpty(compassKeyFile.getPath())) {
			if (!StringUtils.isEmpty(sftpProperties.getPassphrase())) {
				// Set the key with a password
				jsch.addIdentity(compassKeyFile.getPath(), sftpProperties.getPassphrase());
			} else {
				// Set the key without a password
				jsch.addIdentity(compassKeyFile.getPath());
			}
		}
		logger.info("Try to connect sftp[{}@{}], use private key[{}] with passphrase[{}] on port [{}]",
				sftpProperties.getUsername(), host, sftpProperties.getPrivateKey(), sftpProperties.getPassphrase(),
				sftpProperties.getPort());

		Session session = createSession(jsch, sftpProperties);
		// Set the login timeout time
		session.connect(sessionConnectTimeout);
		logger.info("Session connected to {} .", host);
		// Create sftp communication channel
		Channel channel = session.openChannel(protocol);
		channel.connect(channelConnectedTimeout);
		logger.info("Channel created to {} .", host);
	    return (ChannelSftp) channel;
	}

	/**
	 * Create session
	 * 
	 * @param jsch
	 * @param host
	 * @param username
	 * @param port
	 * @return
	 * @throws Exception
	 */
	private Session createSession(JSch jsch, SftpPropertiesDTO sftpProperties) throws Exception {
		Session session = null;

		if (sftpProperties.getPort() <= 0) {
			session = jsch.getSession(sftpProperties.getUsername(), sftpProperties.getHost());
		} else {
			session = jsch.getSession(sftpProperties.getUsername(), sftpProperties.getHost(), sftpProperties.getPort());
		}

		if (session == null) {
			throw new Exception(sftpProperties.getHost() + " session is null");
		}
		logger.info("Jsch Session created.");
		session.setConfig(SESSION_CONFIG_STRICT_HOST_KEY_CHECKING, sessionStrictHostKeyChecking);
		return session;
	}

	/**
	 * Close the connection
	 * 
	 * @param sftp
	 */
	private void disconnect(ChannelSftp sftp) {
		try {
			if (sftp != null) {
				if (sftp.isConnected()) {
					sftp.disconnect();
				} else if (sftp.isClosed()) {
					logger.info("sftp is closed already");
				}
				if (null != sftp.getSession()) {
					sftp.getSession().disconnect();
				}
			}
		} catch (JSchException e) {
			logger.error(e.getMessage());
		}
	}

	/*
	 * Download latest file from SFTP server
	 */
	@SuppressWarnings("unchecked")
	public File downloadLatestFile(SftpPropertiesDTO sftpProperties){
		ChannelSftp sftpChannel = null;
		File file = null;
		try {
			sftpChannel = connectByKey(sftpProperties);
			sftpChannel.cd(sftpProperties.getRoot());
			Vector<LsEntry> zipFileList = sftpChannel.ls('*' + sftpProperties.getFileExtension());
			if (!zipFileList.isEmpty()) {
				LsEntry latestFile = getLatestFile(zipFileList);
				file = File.createTempFile("tempsftp", sftpProperties.getFileExtension());
				try (OutputStream outputStream = new FileOutputStream(file)) {
					sftpChannel.get(latestFile.getFilename(), outputStream);
					sftpChannel.exit();
					logger.info("Download file success. Target file: {}", latestFile.getFilename());
				} catch (Exception e) {
					logger.error("Failed to download file. {} ", e.getMessage());
				}
			}else {
				logger.info("No file present in : {}", sftpProperties.getRoot());
			}
		} catch (Exception e) {
			logger.error("Failed to download file : {}", e.getMessage());
		} finally {
			if(null != sftpChannel) {
				this.disconnect(sftpChannel);
			}
		}
		return file;
	}
	
	/*
	 * Download file from SFTP server
	 */
	@SuppressWarnings("unchecked")
	public File downloadFile(SftpPropertiesDTO sftpProperties){
		ChannelSftp sftpChannel = null;
		File file = null;
		try {
			sftpChannel = connectByKey(sftpProperties);
			sftpChannel.cd(sftpProperties.getRoot());
			file = File.createTempFile("tempsftp", sftpProperties.getFileExtension());
			try(OutputStream outputStream = new FileOutputStream(file)){
				if(!StringUtils.isEmpty(sftpProperties.getFileName())) {
					sftpChannel.get(sftpProperties.getFileName(), outputStream);
					sftpChannel.exit();
					logger.info("Download file success. Target file: {}", sftpProperties.getFileName());
				}else {
					logger.info("File name cannot be empty");
				}
			}catch (Exception e) {
				logger.error("Failed to download file: {}", e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Failed to download file: {}", e.getMessage());
		} finally {
			if(null != sftpChannel) {
				this.disconnect(sftpChannel);
			}
		}
		return file;
	}
	
	public void upload(SftpPropertiesDTO sftpProperties) {
		try {
			ChannelSftp sftpChannel = connectByKey(sftpProperties);
			sftpChannel.put(sftpProperties.getSource(), sftpProperties.getRoot());
			sftpChannel.exit();
			logger.info("Upload file success. Target path: {}", sftpProperties.getRoot());
		} catch (Exception e) {
			logger.error("Failed to upload the file: {}", e.getMessage());
		}
	}
	
	/*
	 * Delete expired files from SFTP server
	 */
	@SuppressWarnings("unchecked")
	public void deleteExpiredFiles(SftpPropertiesDTO sftpProperties, int expiryInDays){
		ChannelSftp sftpChannel = null;
		try {
			sftpChannel = connectByKey(sftpProperties);
			sftpChannel.cd(sftpProperties.getRoot());
			Vector<LsEntry> zipFileList = sftpChannel.ls('*' + sftpProperties.getFileExtension());
			if (!zipFileList.isEmpty()) {
				List<LsEntry> expiredFiles = getExpiredFiles(zipFileList, expiryInDays);
				for(LsEntry expiredFile : expiredFiles) {
					try{
						sftpChannel.rm(expiredFile.getFilename());
						logger.info("Expired File removed: {}", expiredFile.getFilename());
					} catch (Exception e) {
						logger.error("Failed to remove expired file. {} ", e.getMessage());
					}
				}
			}else {
				logger.info("No file present in : {}", sftpProperties.getRoot());
			}
		} catch (Exception e) {
			logger.error("Failed to delete expired files : {}", e.getMessage());
		} finally {
			if(null != sftpChannel) {
				this.disconnect(sftpChannel);
			}
		}
	}

	private List<LsEntry> getExpiredFiles(Vector<LsEntry> zipFileList, int expiryInDays) {
		return zipFileList.stream()
				.filter(f -> LocalDateTime
						.ofInstant(Instant.ofEpochMilli(f.getAttrs().getMTime() * 1000L), ZoneId.systemDefault())
						.isBefore(LocalDateTime.now().minusDays(expiryInDays)))
				.collect(Collectors.toList());
	}

	private LsEntry getLatestFile(Vector<LsEntry> list) {
		if (list.size() == 1) {
			return list.get(0);
		} else {
			return Collections.max(list, Comparator.comparing(f -> f.getAttrs().getMTime()));
		}
	}

}
