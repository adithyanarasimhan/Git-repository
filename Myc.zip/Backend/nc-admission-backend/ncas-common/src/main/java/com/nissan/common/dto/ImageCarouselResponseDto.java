package com.nissan.common.dto;

import lombok.Data;

@Data
public class ImageCarouselResponseDto {
  private String name;
  private String url;
}
