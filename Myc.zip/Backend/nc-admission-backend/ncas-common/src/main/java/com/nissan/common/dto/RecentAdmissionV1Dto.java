package com.nissan.common.dto;

import lombok.Data;

import java.text.SimpleDateFormat;
import java.util.Date;

@Data
public class RecentAdmissionV1Dto {
  private String version;
  private Long admissionId;
  private String admissionDate;
  private String dealerName;
  private String modelName;
  private String gradeName;
  private String naviName;
  private String naviDisplayName;
  private Boolean vehicleTransfer;
  private String vinNumber;
  private String planName;
  private Long planAmount;
  private String paymentTypeName;
  private String paymentTypeDisplayName;
  private Long userId;
  private String optionName;
  private String customerName;
  private String customerFamilyName;
  private String userName;
  private String reasonType;
  private String reasonName;
  private String reasonDisplayName;
  private String comment;
  private String orderNumber;
  private Long reasonId;
  private String corporateName;
  private Long customerType;
  private Integer admissionType;
  private String address1;
  private String address2;
  private String zipCode;
  private String encodedToken;

  public RecentAdmissionV1Dto() {}

  public RecentAdmissionV1Dto(
      String version,
      Long admissionId,
      Date createdDate,
      String dealerName,
      String modelName,
      String gradeName,
      String naviName,
      String naviDisplayName,
      Boolean vehicleTransfer,
      String vinNumber,
      String planName,
      Long planAmount,
      String paymentTypeName,
      String paymentTypeDisplayName,
      Long userId,
      String optionName,
      String customerName,
      String customerFamilyName,
      String userName,
      String orderNumber,
      String corporateName,
      Long customerType,
      String address1,
      String address2,
      String zipCode1,
      String zipCode2,
      Integer admissionType,
      String encodedToken,
      String comment,
      Long reasonId) {
    this.version = version;
    this.admissionId = admissionId;
    this.admissionDate = (new SimpleDateFormat("yyyy-MM-dd, h:mm a").format(createdDate));
    this.dealerName = dealerName;
    this.modelName = modelName;
    this.gradeName = gradeName;
    this.naviName = naviName;
    this.naviDisplayName = naviDisplayName;
    this.vehicleTransfer = vehicleTransfer;
    this.vinNumber = vinNumber;
    this.planName = planName;
    this.planAmount = planAmount;
    this.paymentTypeName = paymentTypeName;
    this.paymentTypeDisplayName = paymentTypeDisplayName;
    this.userId = userId;
    this.optionName = optionName;
    this.customerName = customerName;
    this.customerFamilyName = customerFamilyName;
    this.userName = userName;
    this.comment = comment;
    this.orderNumber = orderNumber;
    this.reasonId = reasonId;
    this.corporateName = corporateName;
    this.customerType = customerType;
    this.address1 = replaceNullFirstParameters(address1);
    this.address2 = replaceNullFirstParameters(address2);
    this.zipCode =
        (replaceNullFirstParameters(zipCode1) + "" + replaceNullFirstParameters(zipCode2));
    this.admissionType = admissionType;
    this.encodedToken = encodedToken;
  }

  private String replaceNullFirstParameters(String value) {
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }
}
