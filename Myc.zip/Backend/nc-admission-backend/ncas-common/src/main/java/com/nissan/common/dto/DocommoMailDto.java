package com.nissan.common.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

@Data
public class DocommoMailDto {
    @CsvBindByName(column = "NCID")
    @CsvBindByPosition(position = 0)
    private String NCID;
    @CsvBindByName(column = "Applicability")
    @CsvBindByPosition(position = 1)
    private String applicability;
    @CsvBindByName(column = "ICCID")
    @CsvBindByPosition(position = 2)
    private String ICCID;
}
