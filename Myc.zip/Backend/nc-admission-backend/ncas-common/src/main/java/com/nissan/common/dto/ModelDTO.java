package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class ModelDTO {
  private long id;
  private String name;
  private String displayName;
  private String imgUrl;
  private List<GradeDTO> grades;
  private Boolean category;
}
