package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "nicos_payment")
@EntityListeners(AuditingEntityListener.class)
public class NicosPayment extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nicos_payment_id_seq")
  @SequenceGenerator(name = "nicos_payment_id_seq", sequenceName = "nicos_payment_id_seq", allocationSize = 1)
  private Long id;

  @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.REFRESH, CascadeType.MERGE})
  @JoinColumn(name = "customer_id", referencedColumnName = "id")
  private Customer customer;

  @Column(name = "company_code")
  private String companyCode;

  @Column(name = "customer_number")
  private String customerNumber;

  /*@Generated(GenerationTime.INSERT)
  @Column(name = "handling_number", insertable = false)*/
  @Column(name = "handling_number")
  private Long handlingNumber;

  @Column(name = "bank_code")
  private Long bankCode;

  @Column(name = "bank_name")
  private String bankName;

  @Column(name = "branch_shop_code")
  private Long branchShopCode;

  @Column(name = "branch_shop_name")
  private String branchShopName;

  @Column(name = "deposit_item")
  private String depositItem;

  @Column(name = "account_type")
  private Integer accountType;

  @Column(name = "account_id")
  private Long accountId;

  @Column(name = "account_name")
  private String accountName;

  @Column(name = "account_number")
  private Long accountNumber;

  @Column(name = "account_holder_katakana")
  private String accountHolderKatakana;

  @Column(name = "status")
  private Integer status;

  @Column(name = "result_code")
  private Integer resultCode;

  @Column(name = "payment_status")
  private String paymentStatus;

  @Column(name = "version")
  private String version;
}