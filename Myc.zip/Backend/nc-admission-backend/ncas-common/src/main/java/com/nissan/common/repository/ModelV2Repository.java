package com.nissan.common.repository;

import com.nissan.common.entity.ModelV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface ModelV2Repository extends JpaRepository<ModelV2, Long>, QuerydslPredicateExecutor<ModelV2> {
    ModelV2 findByCwModelNameAndLangCodeAndVehicleTypeIn(String cwModelName, String langCode, Set<String> vehicleType);

    List<ModelV2> findByLangCodeAndVehicleTypeInOrderByModelDisplayOrderAsc(String lang, Set<String> vehicleType);

    List<ModelV2> findByLangCodeOrderByModelDisplayOrderAsc(String lang);

    ModelV2 findByModelNameAndLangCodeAndVehicleTypeIn(String modelName, String langCode, Set<String> vehicleType);
}
