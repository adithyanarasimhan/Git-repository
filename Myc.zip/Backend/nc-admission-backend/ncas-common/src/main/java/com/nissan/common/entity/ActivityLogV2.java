package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "activity_logv2")
@EntityListeners(AuditingEntityListener.class)
public class ActivityLogV2 extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "admission_id")
  private Long admissionId;

  @Column(name = "message")
  private String message;

  @Column(name = "type")
  private String type;

  @Column(name = "time")
  @CreationTimestamp
  private LocalDateTime time;

  @Column(name = "message_jp")
  private String messageJp;
}
