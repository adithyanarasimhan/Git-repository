package com.nissan.common.service.impl;

import com.nissan.common.dto.UserDto;
import com.nissan.common.entity.Role;
import com.nissan.common.entity.User;
import com.nissan.common.repository.RoleRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.service.UserService;
import com.nissan.common.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {

  @Autowired private UserRepository userRepository;
  @Autowired private BCryptPasswordEncoder bcryptEncoder;
  @Autowired private RoleRepository roleRepository;
  public static final String DEALER = "dealer";

  @Override
  @Transactional
  public User saveUser(UserDto userDto) {
    User user = null;
    if (userDto.getId() == null) {
      user = new User();
      if (userDto.getFirstName() != null) user.setFirstName(userDto.getFirstName());
    } else {
      user = userRepository.findById(userDto.getId()).get();
    }
    user.setUsername(userDto.getUsername());
    user.setPassword(bcryptEncoder.encode(userDto.getPassword()));
    user.setEnabled(true);
    user.setIsValidToken(userDto.isValidToken());
    Role role;
    Set<Role> roleSet = new HashSet<>();
    if (DEALER.equals(userDto.getType())) {
      role = roleRepository.findRoleByName(Constants.ROLE_CA);
    } else {
      role = roleRepository.findRoleByName(Constants.ROLE_CUSTOMER);
    }
    roleSet.add(role);
    user.setRoles(roleSet);
    return userRepository.save(user);
  }
}
