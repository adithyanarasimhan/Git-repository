package com.nissan.common.repository;

import com.nissan.common.entity.Color;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ColorRepository
    extends JpaRepository<Color, Long>, QuerydslPredicateExecutor<Color> {

  @Query(value = "SELECT * FROM color WHERE model_name =?1 and lang_code=?2", nativeQuery = true)
  List<Color> getColorListByModelName(String modelName, String langCode);

  @Query(value = "SELECT * FROM color WHERE model_name =?1 and cw_color=?2 LIMIT 1", nativeQuery = true)
  Optional<Color> getColorByModelCWColorName(String modelName, String sosColor);
}
