package com.nissan.common.repository;

import com.nissan.common.dto.*;
import com.nissan.common.entity.Admission;
import com.nissan.common.entity.DealerEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;

public interface AdmissionRepository
    extends JpaRepository<Admission, Long>, QuerydslPredicateExecutor<Admission> {
  @Query(value = "select * from admission where user_id=?1", nativeQuery = true)
  Admission fetchByUserId(Long userId);

  @Query(value = "select * from admission where user_id=? and lang_code=?", nativeQuery = true)
  Admission fetchByUserIdAndLang(Long userId, String lang);

  @Query(value = "select * from admission where nc_id=?1", nativeQuery = true)
  Admission fetchByNcId(String nissanID);

  List<Admission> findByDealer(DealerEntity dealerEntity, Pageable pageable);

  @Query(
      "SELECT new com.nissan.common.dto.VehicleTransferRecordDto(o,d,c,pm) FROM Admission a JOIN Orders o on a.id=o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  VehicleTransferRecordDto fetchVehicleTransferRecord(Admission admission);

  @Query(
          "SELECT new com.nissan.common.dto.DigitalNotificationDTO(o,d,c,pm) FROM Admission a JOIN Orders o on a.id=o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  DigitalNotificationDTO fetchDigitalNotificationRecord(Admission admission);

  @Query(
          "SELECT new com.nissan.common.dto.RetryPaymentDTO(o,d,c,pm) FROM Admission a JOIN Orders o on a.id= o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  RetryPaymentDTO fetchBankIdResettingRecord(Admission admission);

  @Query(
          "SELECT new com.nissan.common.dto.MopOperatorDTO(o,d,c,pm) FROM Admission a JOIN Orders o on a.id= o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  MopOperatorDTO fetchMopOperatorRecord(Admission admission);

  @Query(
      "SELECT new com.nissan.common.dto.NfsPaymentRecordDto(o,d,c,pm) FROM Admission a JOIN Orders o on a.id= o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id WHERE a=:admission")
  NfsPaymentRecordDto fetchNfsPaymentRecord(Admission admission);

  @Query(
      "SELECT new com.nissan.common.dto.DigitalAdmissionRecordDto(o,d,c,pm,npm) FROM Admission a JOIN Orders o on a.id= o.admission LEFT JOIN DealerEntity d on a.dealer=d.dealerId LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id LEFT JOIN NicosPayment npm on npm.customer=c.id WHERE a=:admission")
  DigitalAdmissionRecordDto fetchDigitalAdmissionRecord(Admission admission);

  @Query(
      "SELECT distinct new com.nissan.common.dto.RecentAdmissionV1Dto('new',a.id, a.createdDate, o.caName, m.displayName, g.displayName, n.naviName,n.displayName, o.vehicleTransfer, o.vinNumber, pc.packagePlanName, pc.price, py.name, py.displayName, u.id, op.optionsName, c.firstName, c.familyName, u.firstName, o.ordersNumber, c.corporateName, c.customerType, c.address1, c.address2, c.zipCode1, c.zipCode2, o.admissionType, u.encodedToken,CASE WHEN com.id>0 THEN com.comment ELSE NULL END as comment, CASE WHEN com.id>0 THEN com.reasonId ELSE NULL END as reasonId)  FROM Admission a JOIN Orders o on a.id=o.admission LEFT JOIN Model m on o.model=m.id LEFT JOIN Grade g on g.id=o.grade LEFT JOIN Navi n on n.id=o.navi LEFT JOIN PackagePlan pc on pc.id=o.packagePlan LEFT JOIN PaymentMethod py on py.id=o.paymentMethod LEFT JOIN User u on u.id=a.user LEFT JOIN Options op on op.id=o.options LEFT JOIN Customer c on c.user=u.id LEFT JOIN Comment com on com.ordersId=o.id WHERE a.active=true AND a.createdDate BETWEEN :startDate AND :endDate AND a.dealer=:dealer ORDER BY a.id DESC")
  List<RecentAdmissionV1Dto> fetchRecentAdmissions(
      DealerEntity dealer, Timestamp startDate, Timestamp endDate);

  List<Admission> findByNcIdNotNullAndStatusNot(String status);

  @Query(value = "select * from admission where dealer_id=? and po_mapping=false and active=true", nativeQuery = true)
  List<Admission> fetchByOrderIdAndPoStatus(String dealerId);
}
