package com.nissan.common.repository;

import com.nissan.common.entity.DealerAddress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DealerAddressRepository extends JpaRepository<DealerAddress, Long> {

  DealerAddress findByAdmissionId(Long id);

}
