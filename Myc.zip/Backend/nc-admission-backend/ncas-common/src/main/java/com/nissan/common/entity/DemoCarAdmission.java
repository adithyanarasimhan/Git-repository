package com.nissan.common.entity;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@Table(name = "democar_admission")
@EntityListeners(AuditingEntityListener.class)
public class DemoCarAdmission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nc_id")
    private String ncId;

    @Column(name = "nc_password")
    private String ncPassword;

    @Column(name = "vin")
    private String vin;

    @Column(name = "status")
    private String status;

    @Column(name = "nc_joined_date")
    private String ncJoinDate;

    @Column(name = "cw_id")
    private String cwId;

    @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.ALL})
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    private DemoCarCustomer customer;

    @Column(name = "send_to_nlo")
    private Boolean sendToNlo;

    @Column(name = "vin_reg_date")
    private String vinRegDate;

    @Column(name = "iccid")
    private String iccId;

    @Column(name = "nc_pw_expiration_date")
    private String ncPasswordExpirationDate;

}
