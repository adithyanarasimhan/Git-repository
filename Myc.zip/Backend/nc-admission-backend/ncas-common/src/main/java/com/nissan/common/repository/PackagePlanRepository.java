package com.nissan.common.repository;

import com.nissan.common.entity.Navi;
import com.nissan.common.entity.PackagePlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PackagePlanRepository
    extends JpaRepository<PackagePlan, Long>, QuerydslPredicateExecutor<PackagePlan> {
  @Query(
      value =
          "select * from package_plan P inner join orders O on P.id=O.plan_id"
              + " inner join admission A on O.admission_id=A.id inner join customer C on A.user_id=C.user_id where C.id=?1",
      nativeQuery = true)
  PackagePlan getPackagePlanByCustomerId(long id);

  List<PackagePlan> findByLangCode(String lang);

  @Query(value = "SELECT * FROM package_plan WHERE navi_id =?1", nativeQuery = true)
  List<PackagePlan> getPackageListByNaviId(long naviId);

  @Query(value = "SELECT * FROM package_plan WHERE navi_id =?1 limit 1", nativeQuery = true)
  PackagePlan getPackageByPlanName(long naviId);
}
