package com.nissan.common.dto;

import com.nissan.common.entity.OrdersV2;
import lombok.Data;

import java.util.List;

@Data
public class FetchOrdersV2Dto {
  private List<OrdersV2FetchResponseDto> orders;
  private Long totalCount;
}
