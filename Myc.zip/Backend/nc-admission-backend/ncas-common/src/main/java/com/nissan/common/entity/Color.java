package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Set;

@Entity
@Data
@Table(name = "color")
@EntityListeners(AuditingEntityListener.class)
public class Color extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "color_name")
    private String colorName;

    @Column(name = "color_code")
    private String colorCode;

    @Column(name = "cw_color")
    private String cwColor;

    @Column(name = "sos_color")
    private String sosColor;

    @Column(name = "image_url")
    private String imageURL;

    @Column(name = "model_name")
    private String modelName;

    @Column(name = "cw_model_name")
    private String cwModelName;

    @Column(name = "sos_display_color")
    private String sosDisplayColor;

    @Column(name = "lang_code")
    private String langCode;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumns({@JoinColumn(name = "model_name", referencedColumnName = "cw_model_name")})
    private Set<ModelV2> models;
}
