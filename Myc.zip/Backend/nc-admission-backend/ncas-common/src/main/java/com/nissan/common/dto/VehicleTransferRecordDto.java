package com.nissan.common.dto;

import com.nissan.common.entity.*;
import com.nissan.common.util.FormatValue;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.Date;

@Data
public class VehicleTransferRecordDto {
  @CsvBindByName(column = "Admission Type")
  @CsvBindByPosition(position = 0)
  private Integer admissionType;

  @CsvBindByPosition(position = 1)
  @CsvBindByName(column = "Profit Order #")
  private String ordersNumber;

  @CsvBindByPosition(position = 2)
  @CsvBindByName(column = "Status")
  private String status;

  @CsvBindByPosition(position = 3)
  @CsvBindByName(column = "Application date time")
  private Date applicationDatetime;

  @CsvBindByPosition(position = 4)
  @CsvBindByName(column = "Dealer Company Code")
  private String dealerCompanyCode;

  @CsvBindByPosition(position = 5)
  @CsvBindByName(column = "Dealer Company Name")
  private String dealerCompanyName;

  @CsvBindByPosition(position = 6)
  @CsvBindByName(column = "Dealership Name")
  private String dealerShipName;

  @CsvBindByPosition(position = 7)
  @CsvBindByName(column = "Dealer phone #")
  private String dealerPhone;

  @CsvBindByPosition(position = 8)
  @CsvBindByName(column = "C/A Name")
  private String caName;

  @CsvBindByPosition(position = 9)
  @CsvBindByName(column = "C/A Name(Kana)")
  private String caNameKana;

  @CsvBindByName(column = "C/A Code")
  @CsvBindByPosition(position = 10)
  private String caCode;

  @CsvBindByName(column = "C/A Email")
  @CsvBindByPosition(position = 11)
  private String caEmail;

  @CsvBindByPosition(position = 12)
  @CsvBindByName(column = "Customer type")
  private Long customerType;

  @CsvBindByPosition(position = 13)
  @CsvBindByName(column = "E-mail address")
  private String emailAddress;

    @CsvBindByPosition(position = 14)
  @CsvBindByName(column = "Name")
  private String firstName;

  @CsvBindByPosition(position = 15)
  @CsvBindByName(column = "Name(katakana)")
  private String firstNameKatakana;

  @CsvBindByPosition(position = 16)
  @CsvBindByName(column = "Corperate Name")
  private String corporateName;

  @CsvBindByPosition(position = 17)
  @CsvBindByName(column = "Office position")
  private String officePosition;

  @CsvBindByPosition(position = 18)
  @CsvBindByName(column = "Representative's name")
  private String representativeName;

  @CsvBindByPosition(position = 19)
  @CsvBindByName(column = "Representative's name(katakana)")
  private String representativeNameKana;

  @CsvBindByPosition(position = 20)
  @CsvBindByName(column = "Zip Code(first 3digits)")
  private String zipCode1;

  @CsvBindByPosition(position = 21)
  @CsvBindByName(column = "Zip Code(last 4digits)")
  private String zipCode2;
  //
  @CsvBindByPosition(position = 22)
  @CsvBindByName(column = "Address1")
  private String address1;

  @CsvBindByPosition(position = 23)
  @CsvBindByName(column = "Address2")
  private String address2;

  @CsvBindByPosition(position = 24)
  @CsvBindByName(column = "Phone #1(first 3digits)")
  private String phone1;

  @CsvBindByPosition(position = 25)
  @CsvBindByName(column = "Phone #1(second 4digits)")
  private String phone2;
  //
  @CsvBindByPosition(position = 26)
  @CsvBindByName(column = "Phone #1(last 4digits)")
  private String phone3;

  @CsvBindByPosition(position = 27)
  @CsvBindByName(column = "Phone #2(first 3digits)")
  private String optionalPhone1;

  @CsvBindByPosition(position = 28)
  @CsvBindByName(column = "Phone #2(second 4digits)")
  private String optionalPhone2;

  @CsvBindByPosition(position = 29)
  @CsvBindByName(column = "Phone #2(last 4digits)")
  private String optionalPhone3;

  @CsvBindByPosition(position = 30)
  @CsvBindByName(column = "Vehicle Model")
  private String model;

  @CsvBindByPosition(position = 31)
  @CsvBindByName(column = "Vehicle Grade")
  private String grade;

  @CsvBindByPosition(position = 32)
  @CsvBindByName(column = "Vehicle Option 1")
  private String option1;

  @CsvBindByPosition(position = 33)
  @CsvBindByName(column = "Vehicle Option 2")
  private String option2;

  @CsvBindByPosition(position = 34)
  @CsvBindByName(column = "Package plan")
  private String packagePlan;

  @CsvBindByPosition(position = 35)
  @CsvBindByName(column = "VIN")
  private String vin;

  @CsvBindByPosition(position = 36)
  @CsvBindByName(column = "First registered date")
  private String firstRegisteredDate;

  @CsvBindByPosition(position = 37)
  @CsvBindByName(column = "Navi ID")
  private String naviId;

  @CsvBindByPosition(position = 38)
  @CsvBindByName(column = "Payment method")
  private String paymentMethod;

  @CsvBindByPosition(position = 39)
  @CsvBindByName(column = "Card #(first 4digits)")
  private String card1;

  @CsvBindByPosition(position = 40)
  @CsvBindByName(column = "Card #(second 4digits)")
  private String card2;

  @CsvBindByPosition(position = 41)
  @CsvBindByName(column = "Card #(third 4digits)")
  private String card3;

  @CsvBindByPosition(position = 42)
  @CsvBindByName(column = "Card #(last 4digits)")
  private String card4;

  @CsvBindByPosition(position = 43)
  @CsvBindByName(column = "Expiry date(month)")
  private Long expiryMonth;

  @CsvBindByPosition(position = 44)
  @CsvBindByName(column = "Expiry date(year)")
  private Long expiryYear;

  @CsvBindByPosition(position = 45)
  @CsvBindByName(column = "Card brand")
  private String cardBrand;

  @CsvBindByPosition(position = 46)
  @CsvBindByName(column = "Card Name")
  private String cardName;

  @CsvBindByPosition(position = 47)
  @CsvBindByName(column = "Transfer")
  private Boolean transfer;

  @CsvBindByPosition(position = 48)
  @CsvBindByName(column = "Old vehicle VIN")
  private String oldVehicleVin;

  @CsvBindByPosition(position = 49)
  @CsvBindByName(column = "NCAS #")
  private Long ncasNumber;

  public VehicleTransferRecordDto(Orders orders, DealerEntity dealerEntity, Customer customer, Payment payment) {
    Admission admission = orders.getAdmission();
    this.admissionType = orders.getAdmissionType();
    this.ordersNumber = orders.getOrderNumberPs();
    this.status = admission.getStatus();
    this.applicationDatetime = admission.getCreatedDate();
    this.dealerCompanyCode = dealerEntity.getCompanyCode();
    this.dealerCompanyName = orders.getCompanyName();
    this.dealerShipName = orders.getDealershipName();
    this.dealerPhone = orders.getPhoneNumber();
    this.caName = orders.getCaName();
    this.caNameKana = orders.getCaNameKana();
    this.caCode = dealerEntity.getCaCode();
    this.caEmail = dealerEntity.getEmail();
    this.customerType = customer.getCustomerType();
    this.emailAddress = customer.getEmail();
    String customerName = FormatValue.replaceNullOptionalPhoneNumber(customer.getFamilyName())
            + FormatValue.replaceNullOptionalPhoneNumber(customer.getFirstName());
    String customerNameKata = FormatValue.replaceNullOptionalPhoneNumber(customer.getFamilyNameKatakana())
            + FormatValue.replaceNullOptionalPhoneNumber(customer.getFirstNameKatakana());
    /**Converting String to double-byte character */
    try {
      this.firstName = FormatValue.convertToShiftJ(customerName.getBytes());
      this.firstNameKatakana = FormatValue.convertToShiftJ(customerNameKata.getBytes());
      this.address1 = (customer.getAddress1() != null) ? FormatValue.convertToShiftJ(customer.getAddress1().getBytes()) : "";
      this.address2 = (customer.getAddress2() != null) ? FormatValue.convertToShiftJ(customer.getAddress2().getBytes()) : "";
    } catch (Exception e) {
      e.printStackTrace();
    }
    this.corporateName = customer.getCorporateName();
    this.officePosition = customer.getOfficePosition();
    this.representativeName = customer.getRepresentativeName();
    this.representativeNameKana = customer.getRepresentativeNameKatakana();
    this.zipCode1 = customer.getZipCode1();
    this.zipCode2 = customer.getZipCode2();
    this.address1 = customer.getAddress1();
    this.address2 = customer.getAddress2();
    this.phone1 = customer.getPhoneNumber1();
    this.phone2 = customer.getPhoneNumber2();
    this.phone3 = customer.getPhoneNumber3();
    this.optionalPhone1 = customer.getOptionalPhoneNumber1();
    this.optionalPhone2 = customer.getOptionalPhoneNumber2();
    this.optionalPhone3 = customer.getOptionalPhoneNumber3();
    this.model = orders.getModel().getModelName();
    this.grade = orders.getGrade().getGradeName();
    this.option1 = orders.getNavi().getNaviName();
    this.option2 = (orders.getOptions() != null) ? orders.getOptions().getOptionsName() : "";
    this.packagePlan = orders.getPackagePlan().getPackagePlanName();
    this.paymentMethod = orders.getPaymentMethod().getName();
    this.card1 = payment.getCardNumber1();
    this.card2 = payment.getCardNumber2();
    this.card3 = payment.getCardNumber3();
    this.card4 = payment.getCardNumber4();
    this.expiryMonth = payment.getExpiryMonth();
    this.expiryYear = payment.getExpiryYear();
    this.cardBrand = payment.getCardType();
    this.cardName = payment.getCardName();
    this.transfer = orders.getVehicleTransfer();
    this.oldVehicleVin = orders.getVinNumber();
    this.ncasNumber = admission.getId();
  }

  public VehicleTransferRecordDto(
      Integer admissionType,
      String ordersNumber,
      String status,
      Date applicationDatetime,
      String dealerCompanyCode,
      String dealerCompanyName,
      String dealerShipName,
      String dealerPhone,
      String caName,
      String caNameKana,
      String caCode,
      String email,
      Long customerType,
      String emailAddress,
      String name,
      String nameKatakana,
      String corporateName,
      String officePosition,
      String representativeName,
      String representativeNameKana,
      String zipCode1,
      String zipCode2,
      String address1,
      String address2,
      String phone1,
      String phone2,
      String phone3,
      String optionalPhone1,
      String optionalPhone2,
      String optionalPhone3,
      String model,
      String grade,
      String packagePlan,
      String paymentMethod,
      String card1,
      String card2,
      String card3,
      String card4,
      Long expiryMonth,
      Long expiryYear,
      Long cardBrand,
      String cardName,
      Boolean transfer,
      String oldVehicleVin) {
    this.admissionType = admissionType;
    this.ordersNumber = ordersNumber;
    this.status = status;
    this.applicationDatetime = applicationDatetime;
    this.dealerCompanyCode = dealerCompanyCode;
    this.dealerCompanyName = dealerCompanyName;
    this.dealerShipName = dealerShipName;
    this.dealerPhone = dealerPhone;
    this.caName = caName;
    this.caNameKana = caNameKana;
    this.caCode = caCode;
    //this.email = email;
    this.customerType = customerType;
    this.emailAddress = emailAddress;
    //this.name = name;
    //this.nameKatakana = nameKatakana;
    this.corporateName = corporateName;
    this.officePosition = officePosition;
    this.representativeName = representativeName;
    this.representativeNameKana = representativeNameKana;
    this.zipCode1 = zipCode1;
    this.zipCode2 = zipCode2;
    this.address1 = address1;
    this.address2 = address2;
    this.phone1 = phone1;
    this.phone2 = phone2;
    this.phone3 = phone3;
    this.optionalPhone1 = optionalPhone1;
    this.optionalPhone2 = optionalPhone2;
    this.optionalPhone3 = optionalPhone3;
    this.model = model;
    this.grade = grade;
    this.packagePlan = packagePlan;
    this.paymentMethod = paymentMethod;
    this.card1 = card1;
    this.card2 = card2;
    this.card3 = card3;
    this.card4 = card4;
    this.expiryMonth = expiryMonth;
    this.expiryYear = expiryYear;
    //this.cardBrand = cardBrand;
    this.cardName = cardName;
    this.transfer = transfer;
    this.oldVehicleVin = oldVehicleVin;
  }
}
