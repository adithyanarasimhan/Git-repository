package com.nissan.common.dto;



import javax.validation.constraints.Size;

public class VerifyNcIdSendTempPwdDto {


    private String ncId;

    public String getNcId() {
        return ncId;
    }

    public void setNcId(String ncId) {
        this.ncId = ncId;
    }

    @Size(max = 11)
    private String phoneNumber;

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
