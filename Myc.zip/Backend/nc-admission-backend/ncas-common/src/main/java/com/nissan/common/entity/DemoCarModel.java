package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "democar_model")
@EntityListeners(AuditingEntityListener.class)
public class DemoCarModel extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "model_name")
    private String modelName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "cw_model_name")
    private String cwModelName;

    @Column(name = "lang_code")
    private String langCode;
    
    @Column(name = "url")
    private String url;

    @Column(name = "model_display_order")
    private Long modelDisplayOrder;
}
