package com.nissan.common.dto;

import lombok.Data;

@Data
public class CustomerSummaryDTOV2 {

  private String familyName;

  private String familyNameKatakana;

  private String firstName;

  private String firstNameKatakana;

  private String address1;

  private String address2;

  private Long phoneNumber1;

  private Long phoneNumber2;

  private Long zipCode1;
  private Long zipCode2;

  private String corporateName;

  private String officePosition;

  private String representativeName;

  private String representativeNameKatakana;

  private String email;

  private Long customerType;

  private String model;

  private String packagePlan;

  private Long amount;

  private String naviType;

  private String grade;

  private String vinNumber;

  private Integer admissionType;

  private Boolean vehicleTransfer;

  private String notificationMethod;

  private String cardType;

  private String nameOnCard;

  private String cardNumber;

  private String ExpiryDate;

  private String zipCode;

  private String phoneNumber;

  private String optionalPhoneNumber;

  private String imgUrl;

  private String optionsName;

  private DealerAddressDTO dealerAddressDTO;

  private String fileName;

  private Long adminFee;

  private String oldVinNumber;
}
