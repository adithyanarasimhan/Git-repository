package com.nissan.common.dto;

import lombok.Data;

@Data
public class ColorDTO {
  private Long id;
  private String color;
  private String cwColor;
  private String colorCode;
  private String url;
}
