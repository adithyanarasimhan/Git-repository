package com.nissan.common.service;

import com.nissan.common.dto.*;

public interface CustomerServiceV2 {
    CustomerGetResponseDTO fetchCustomerPlanDetailsV2(String userName, String langCode)
            throws Exception;

    CustomerSummaryDTOV2 fetchCustomerByUserAndLangCodeV2(String userName, String langCode);

    CustomerResponseDTO updateCustomerById(CustomerDTO customerDto, String userName, String langCode)
            throws Exception;

    CustomerResponseDTO saveStepCount(String principleId, String count);

    TempPwdDTO fetchTemporaryPwd(String token, String langCode) throws Exception;
}
