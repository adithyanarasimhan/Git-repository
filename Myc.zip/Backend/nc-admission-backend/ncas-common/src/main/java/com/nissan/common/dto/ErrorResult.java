package com.nissan.common.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ErrorResult {
    private List<FieldValidationError> result=new ArrayList<>();
}
