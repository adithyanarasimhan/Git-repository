package com.nissan.common.repository;

import com.nissan.common.dto.OrdersFetchResponseDTO;
import com.nissan.common.entity.Orders;
import com.nissan.common.entity.OrdersV2;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface OrdersRepository
    extends JpaRepository<Orders, Long>,
        QuerydslPredicateExecutor<Orders>,
        PagingAndSortingRepository<Orders, Long> {

  Orders findByAdmissionId(Long admissionId);

  Orders findByOrdersNumber(String orderNumber);

  Orders findByOrderNumberPs(String profitSystemOrderNumber);

  @Query(
      "SELECT o from Orders o JOIN Admission a  on o.admission=a.id where o.active=true and o.admissionType=1 and  a.status =:dealerCompleted AND o.lastModifiedDate <= :startDate")
  List<Orders> fetchAllTwoDaysBackOrders(String dealerCompleted, Timestamp startDate);

  @Query(
          "SELECT o from Orders o JOIN Admission a  on o.admission=a.id LEFT JOIN PackagePlan pl on o.packagePlan=pl.id LEFT JOIN Customer c on c.user=a.user LEFT JOIN Payment pm on pm.customer=c.id where o.active=true and o.admissionType=1 and o.uploadKameri=false and a.status =:dealerCompleted AND o.lastModifiedDate <= :startDate AND o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') AND o.packagePlan IN (SELECT id FROM PackagePlan plan WHERE plan.packagePlanName!='m-op')")
  List<Orders> fetchDOPEnhancementOrders(String dealerCompleted, Timestamp startDate);

  @Query(
      "SELECT o from Orders o JOIN Admission a  on o.admission=a.id where o.active=true and o.admissionType=1 and  a.cwStatus in ('SZ','SS')")
  List<Orders> findByCarWingsStatus();

  @Query(
      "SELECT o from Orders o JOIN Admission a  on o.admission=a.id where o.active=true and o.admissionType=1 and  a.status =:dealerCompleted")
  List<Orders> fetchAllOrders(String dealerCompleted);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI')) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  List<OrdersFetchResponseDTO> fetchMappedOrders(
      String companyCode, String dealerShipCode, Pageable pageable, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI'))")
  List<OrdersFetchResponseDTO> fetchMappedOrdersForBusiness(
      Pageable pageable, Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI')) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  List<OrdersFetchResponseDTO> fetchUnMappedOrders(
      String companyCode, String dealerShipCode, Pageable pageable, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI'))")
  List<OrdersFetchResponseDTO> fetchUnMappedOrdersForBusiness(
      Pageable pageable, Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE  o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  List<OrdersFetchResponseDTO> fetchOtherMappedOrders(
      String companyCode, String dealerShipCode, Pageable pageable, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE  o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL)")
  List<OrdersFetchResponseDTO> fetchOtherMappedOrdersForBusiness(
      Pageable pageable, Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE  o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  List<OrdersFetchResponseDTO> fetchOtherUnMappedOrders(
      String companyCode, String dealerShipCode, Pageable pageable, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE  o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL)")
  List<OrdersFetchResponseDTO> fetchOtherUnMappedOrdersForBusiness(
      Pageable pageable, Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE  o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=2 AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  List<OrdersFetchResponseDTO> fetchNotInterestedOrders(
      String companyCode, String dealerShipCode, Pageable pageable, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT new com.nissan.common.dto.OrdersFetchResponseDTO(o, c, u) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN User u on u.id=a.user LEFT JOIN Customer c on c.user=u.id WHERE  o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=2")
  List<OrdersFetchResponseDTO> fetchNotInterestedOrdersForBusiness(
      Pageable pageable, Timestamp admissionCreatedDate,  Boolean active);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI')) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  Long countMappedOrders(String companyCode, String dealerShipCode, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI'))")
  Long countMappedOrdersForBusiness(Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI')) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  Long countUnMappedOrders(String companyCode, String dealerShipCode, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND o.navi IN (SELECT id FROM Navi n WHERE n.naviName='m-op') AND (o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') OR o.model IN (SELECT id FROM Model mo WHERE mo.category='IVI'))")
  Long countUnMappedOrdersForBusiness(Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  Long countOtherMappedOrders(String companyCode, String dealerShipCode, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL)")
  Long countOtherMappedOrdersForBusiness(Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL) AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  Long countOtherUnMappedOrders(String companyCode, String dealerShipCode, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='paper') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL)")
  Long countOtherUnMappedOrdersForBusiness(Timestamp admissionCreatedDate, Boolean active);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.active=true AND a.createdDate >= :admissionCreatedDate AND o.admissionType=2  AND d.companyCode=:companyCode AND d.dealerShipCode=:dealerShipCode")
  Long countNotInterestedOrders(String companyCode, String dealerShipCode, Timestamp admissionCreatedDate);

  @Query(
      value =
          "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission WHERE o.active=:active AND a.createdDate >= :admissionCreatedDate AND o.admissionType=2")
  Long countNotInterestedOrdersForBusiness(Timestamp admissionCreatedDate, Boolean active);

  @Query(
      "SELECT o from Orders o JOIN Admission a on a.id=o.admission LEFT JOIN PackagePlan pl on o.packagePlan=pl.id WHERE o.active=true AND o.uploadKameri=false AND o.lastModifiedDate BETWEEN :startDate AND :endDate AND o.admissionType=1 AND o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') AND (a.status='DEALER_COMPLETED') AND o.packagePlan IN (SELECT id FROM PackagePlan plan WHERE plan.packagePlanName='m-op')")
  List<Orders> findLast24HrsOrders(Timestamp startDate, Timestamp endDate);

  @Query(
          "SELECT o from Orders o JOIN Admission a on a.id=o.admission WHERE o.active=true AND o.lastModifiedDate BETWEEN :startDate AND :endDate AND o.admissionType=1 AND o.paymentMethod IN (SELECT id FROM PaymentMethod pm WHERE pm.name!='paper') AND (a.status='BANK_ID_RESETTING')")
  List<Orders> fetchResettingOrdersForKameri(Timestamp startDate, Timestamp endDate);

  @Query("SELECT o From Orders o JOIN Admission a on a.id=o.admission LEFT JOIN DealerEntity d on d.dealerId=a.dealer WHERE o.orderNumberPs=:profitNumber AND d.companyCode=:companyCode AND o.active=true")
  Orders findByOrderNumberPsAndCompanyCode(String profitNumber, String companyCode);

  @Query("SELECT o FROM Orders o JOIN Admission a ON o.admission = a.id WHERE a.status in ('DEALER_WORKING','CUSTOMER_COMPLETED') AND o.active = true AND o.orderNumberPs IS NULL")
  List<Orders> fetchActiveOrdersForSendingAlert();

  @Query("SELECT o FROM Orders o JOIN Admission a ON o.admission = a.id WHERE a.createdDate <= :expiryDate AND a.status in ('CUSTOMER_FILLING','CUSTOMER_FILLING_FROM_HOME','DEALER_WORKING','CUSTOMER_COMPLETED','CANCEL','WITHDRAWAL','PERSONAL_INFO_DELETED','BANK_ID_CONFIRMING','BANK_ID_RESETTING','VIN_RESETTING')")
  List<Orders> fetchOrdersCreatedDateBefore(Timestamp expiryDate);

  @Query(value = "SELECT count(*) FROM Orders o JOIN Admission a on a.id=o.admission WHERE o.active=false AND a.createdDate >= :admissionCreatedDate AND o.admissionType=1 AND o.orderNumberPs IS NOT null AND (o.paymentMethod in (SELECT id FROM PaymentMethod pm WHERE pm.name='bank') OR o.paymentMethod IS null) AND o.model IN (SELECT id FROM Model mo WHERE mo.category!='IVI' OR mo.category IS NULL)")
  Long countOtherMappedDeletedOrdersForBusiness(Timestamp admissionCreatedDate);
}
