package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class FetchOrderV2ResponseDTO {
    private OrdersV2FetchResponseDto orderDetails;
    private List<PackagePlanV2DTO> planDetails;
    private DealerDTO dealerDetails;
}
