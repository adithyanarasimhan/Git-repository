package com.nissan.common.dto;

import com.nissan.common.entity.*;
import com.nissan.common.util.Constants;
import com.nissan.common.util.FormatValue;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;
import org.apache.tomcat.util.bcel.Const;

import java.util.Date;

@Data
public class DigitalAdmissionRecordDto {

  @CsvBindByName(column = "RPA status")
  @CsvBindByPosition(position = 0)
  private Integer rpaStatus;

  @CsvBindByName(column = "RPA First run date")
  @CsvBindByPosition(position = 1)
  private Date rpaFirstRunDate;

  @CsvBindByName(column = "Admission Type")
  @CsvBindByPosition(position = 2)
  private Integer admissionType;

  @CsvBindByName(column = "Profit Order #")
  @CsvBindByPosition(position = 3)
  private String profitOrder;

  @CsvBindByPosition(position = 4)
  @CsvBindByName(column = "Status")
  private String status;

  @CsvBindByPosition(position = 5)
  @CsvBindByName(column = "Application date time")
  private Date applicationDatetime;

  @CsvBindByPosition(position = 6)
  @CsvBindByName(column = "Dealer Company Code")
  private String dealerCompanyCode;

  @CsvBindByPosition(position = 7)
  @CsvBindByName(column = "Dealer Company Name")
  private String dealerCompanyName;

  @CsvBindByPosition(position = 8)
  @CsvBindByName(column = "Dealership Name")
  private String dealerShipName;

  @CsvBindByPosition(position = 9)
  @CsvBindByName(column = "Dealer phone #")
  private String dealerPhone;

  @CsvBindByPosition(position = 10)
  @CsvBindByName(column = "C/A Name")
  private String caName;

  @CsvBindByPosition(position = 11)
  @CsvBindByName(column = "C/A Name(Kana)")
  private String caNameKana;

  @CsvBindByName(column = "C/A Code")
  @CsvBindByPosition(position = 12)
  private String caCode;

  @CsvBindByName(column = "C/A Email")
  @CsvBindByPosition(position = 13)
  private String caEmail;

  @CsvBindByPosition(position = 14)
  @CsvBindByName(column = "Customer type")
  private Long customerType;

  @CsvBindByPosition(position = 15)
  @CsvBindByName(column = "E-mail address")
  private String emailAddress;

  @CsvBindByPosition(position = 16)
  @CsvBindByName(column = "Name")
  private String firstName;

  @CsvBindByPosition(position = 17)
  @CsvBindByName(column = "Name(katakana)")
  private String firstNameKatakana;

  @CsvBindByPosition(position = 18)
  @CsvBindByName(column = "Corperate Name")
  private String corporateName;

  @CsvBindByPosition(position = 19)
  @CsvBindByName(column = "Office position")
  private String officePosition;

  @CsvBindByPosition(position = 20)
  @CsvBindByName(column = "Representative's name")
  private String representativeName;

  @CsvBindByPosition(position = 21)
  @CsvBindByName(column = "Representative's name(katakana)")
  private String representativeNameKana;

  @CsvBindByPosition(position = 22)
  @CsvBindByName(column = "Zip Code(first 3digits)")
  private String zipCode1;

  @CsvBindByPosition(position = 23)
  @CsvBindByName(column = "Zip Code(last 4digits)")
  private String zipCode2;

  @CsvBindByPosition(position = 24)
  @CsvBindByName(column = "Address1")
  private String address1;

  @CsvBindByPosition(position = 25)
  @CsvBindByName(column = "Address2")
  private String address2;

  @CsvBindByPosition(position = 26)
  @CsvBindByName(column = "Phone #1(first 3digits)")
  private String phone1;

  @CsvBindByPosition(position = 27)
  @CsvBindByName(column = "Phone #1(second 4digits)")
  private String phone2;

  @CsvBindByPosition(position = 28)
  @CsvBindByName(column = "Phone #1(last 4digits)")
  private String phone3;

  @CsvBindByPosition(position = 29)
  @CsvBindByName(column = "Phone #2(first 3digits)")
  private String optionalPhone1;

  @CsvBindByPosition(position = 30)
  @CsvBindByName(column = "Phone #2(second 4digits)")
  private String optionalPhone2;

  @CsvBindByPosition(position = 31)
  @CsvBindByName(column = "Phone #2(last 4digits)")
  private String optionalPhone3;

  @CsvBindByPosition(position = 32)
  @CsvBindByName(column = "Vehicle Model")
  private String model;

  @CsvBindByPosition(position = 33)
  @CsvBindByName(column = "Vehicle Grade")
  private String grade;

  @CsvBindByPosition(position = 34)
  @CsvBindByName(column = "Vehicle Option 1")
  private String option1;

  @CsvBindByPosition(position = 35)
  @CsvBindByName(column = "Vehicle Option 2")
  private String option2;

  @CsvBindByPosition(position = 36)
  @CsvBindByName(column = "Package plan")
  private String packagePlan;

  @CsvBindByPosition(position = 37)
  @CsvBindByName(column = "VIN")
  private String vin;

  @CsvBindByPosition(position = 38)
  @CsvBindByName(column = "First registered date")
  private String firstRegisteredDate;

  @CsvBindByPosition(position = 39)
  @CsvBindByName(column = "VIN registered date")
  private String vinRegisteredDate;

  @CsvBindByPosition(position = 40)
  @CsvBindByName(column = "Navi ID")
  private String naviId;

  @CsvBindByPosition(position = 41)
  @CsvBindByName(column = "Payment method")
  private String paymentMethod;

  @CsvBindByPosition(position = 42)
  @CsvBindByName(column = "Card brand")
  private String cardBrand;

  @CsvBindByPosition(position = 43)
  @CsvBindByName(column = "Card Name")
  private String cardName;

  @CsvBindByPosition(position = 44)
  @CsvBindByName(column = "Credit ID")
  private String creditId;

  @CsvBindByPosition(position = 45)
  @CsvBindByName(column = "Transfer")
  private Boolean transfer;

  @CsvBindByPosition(position = 46)
  @CsvBindByName(column = "Old vehicle VIN")
  private String oldVehicleVin;

  @CsvBindByPosition(position = 47)
  @CsvBindByName(column = "Bank code")
  private Long bankCode;

  @CsvBindByPosition(position = 48)
  @CsvBindByName(column = "Bank name")
  private String bankName;

  @CsvBindByPosition(position = 49)
  @CsvBindByName(column = "Branch shop code")
  private Long branchShopCode;

  @CsvBindByPosition(position = 50)
  @CsvBindByName(column = "Branch shop name")
  private String branchShopName;

  @CsvBindByPosition(position = 51)
  @CsvBindByName(column = "Account type")
  private Integer accountType;

  @CsvBindByPosition(position = 52)
  @CsvBindByName(column = "Account ID")
  private Long accountId;

  @CsvBindByPosition(position = 53)
  @CsvBindByName(column = "Account name")
  private String accountName;

  @CsvBindByPosition(position = 54)
  @CsvBindByName(column = "SOS color")
  private String sosColor;

  @CsvBindByPosition(position = 55)
  @CsvBindByName(column = "IVI flag")
  private String iviFlag;

  @CsvBindByPosition(position = 56)
  @CsvBindByName(column = "Vehicle number plate 1")
  private String vehicleNumberPlate1;

  @CsvBindByPosition(position = 57)
  @CsvBindByName(column = "Vehicle number plate 2")
  private String vehicleNumberPlate2;

  @CsvBindByPosition(position = 58)
  @CsvBindByName(column = "Vehicle number plate 3")
  private String vehicleNumberPlate3;

  @CsvBindByPosition(position = 59)
  @CsvBindByName(column = "Vehicle number plate 4")
  private String vehicleNumberPlate4;

  @CsvBindByPosition(position = 60)
  @CsvBindByName(column = "NCAS #")
  private Long ncasNumber;

  public DigitalAdmissionRecordDto(Orders orders, DealerEntity dealerEntity, Customer customer, Payment payment, NicosPayment nicosPayment) {
    Admission admission = orders.getAdmission();
    this.rpaStatus = 0;
    this.admissionType = orders.getAdmissionType();
    this.profitOrder = orders.getOrderNumberPs();
    this.status = admission.getStatus();
    this.applicationDatetime = admission.getCreatedDate();
    this.dealerCompanyCode = dealerEntity.getCompanyCode();
    this.dealerCompanyName = orders.getCompanyName();
    this.dealerShipName = orders.getDealershipName();
    this.dealerPhone = orders.getPhoneNumber();
    this.caName = orders.getCaName();
    this.caNameKana = orders.getCaNameKana();
    this.caCode = dealerEntity.getCaCode();
    this.caEmail = dealerEntity.getEmail();
    this.customerType = customer.getCustomerType();
    this.emailAddress = customer.getEmail();
    String customerName = FormatValue.replaceNullOptionalPhoneNumber(customer.getFamilyName())
            + FormatValue.replaceNullOptionalPhoneNumber(customer.getFirstName());
    String customerNameKata = FormatValue.replaceNullOptionalPhoneNumber(customer.getFamilyNameKatakana())
            + FormatValue.replaceNullOptionalPhoneNumber(customer.getFirstNameKatakana());
    /**Converting String to double-byte character */
    try {
      this.firstName = FormatValue.convertToShiftJ(customerName.getBytes());
      this.firstNameKatakana = FormatValue.convertToShiftJ(customerNameKata.getBytes());
      this.address1 = (customer.getAddress1() != null) ? FormatValue.convertToShiftJ(customer.getAddress1().getBytes()) : "";
      this.address2 = (customer.getAddress2() != null) ? FormatValue.convertToShiftJ(customer.getAddress2().getBytes()) : "";
    } catch (Exception e) {
      e.printStackTrace();
    }
    this.corporateName = customer.getCorporateName();
    this.officePosition = customer.getOfficePosition();
    this.representativeName = customer.getRepresentativeName();
    this.representativeNameKana = customer.getRepresentativeNameKatakana();
    this.zipCode1 = customer.getZipCode1();
    this.zipCode2 = customer.getZipCode2();
    this.phone1 = customer.getPhoneNumber1();
    this.phone2 = customer.getPhoneNumber2();
    this.phone3 = customer.getPhoneNumber3();
    this.optionalPhone1 = customer.getOptionalPhoneNumber1();
    this.optionalPhone2 = customer.getOptionalPhoneNumber2();
    this.optionalPhone3 = customer.getOptionalPhoneNumber3();
    this.model = orders.getModel().getModelName();
    this.grade = orders.getGrade().getGradeName();
    this.option1 = orders.getNavi().getNaviName();
    this.option2 = (orders.getOptions() != null) ? orders.getOptions().getOptionsName() : "";
    this.packagePlan = orders.getPackagePlan().getPackagePlanName();
    this.vin = orders.getCwVinNumber();
    this.paymentMethod = orders.getPaymentMethod().getName();
    this.cardBrand = payment.getCardType();
    this.cardName = payment.getCardName();
    this.creditId = payment.getCreditId();
    this.transfer = orders.getVehicleTransfer();
    this.oldVehicleVin = orders.getVehicleTransfer() ? orders.getVinNumber() : "";
    if (orders.getPaymentMethod() != null
        && Constants.PAYMENT_METHOD_BANK.equals(orders.getPaymentMethod().getName())) {
      if(nicosPayment != null) {
        this.bankCode = nicosPayment.getBankCode();
        this.bankName = nicosPayment.getBankName();
        this.branchShopCode = nicosPayment.getBranchShopCode();
        this.branchShopName = nicosPayment.getBranchShopName();
        this.accountType = nicosPayment.getAccountType();
        this.accountId = nicosPayment.getAccountId();
        this.accountName = nicosPayment.getAccountName();
      }
    }
    this.iviFlag = Constants.CATEGORY_IVI.equals(orders.getModel().getCategory()) ? "1" : "0";
    this.ncasNumber = admission.getId();
  }
}
