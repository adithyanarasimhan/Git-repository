package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
public class OptionsV2 extends Auditable<String> {

    @Id
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "navi_id", referencedColumnName = "id")
    private NaviV2 navi;

    @Column(name = "options_name")
    private String optionsName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "cw_options_name")
    private String cwOptionsName;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "vehicle_type")
    private String vehicleType;
}
