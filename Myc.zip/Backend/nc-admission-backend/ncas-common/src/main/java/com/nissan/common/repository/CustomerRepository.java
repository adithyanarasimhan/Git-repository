package com.nissan.common.repository;

import com.nissan.common.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository
    extends JpaRepository<Customer, Long>, QuerydslPredicateExecutor<Customer> {
  Optional<Customer> findByUserIdAndLangCode(Long userId, String langCode);

  Optional<Customer> findByUserId(Long userId);

  @Query(value = "select * from customer where user_id=?", nativeQuery = true)
  Customer findCustomerByUserId(Long userId);

  Customer findByEmail(String email);

  @Query(value = "select * from customer where nc_status=?", nativeQuery = true)
  List<Customer> findByNcStatus(String status);
}
