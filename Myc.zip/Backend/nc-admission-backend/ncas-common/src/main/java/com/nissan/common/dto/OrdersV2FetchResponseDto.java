package com.nissan.common.dto;

import com.nissan.common.entity.*;
import com.nissan.common.util.Constants;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

@Data
public class OrdersV2FetchResponseDto {

  public static final String USED_CARS = "UsedCars";
  private static final Logger logger = LoggerFactory.getLogger(OrdersFetchResponseDTO.class);
  private String tempOrdersNumber;
  private String status;
  private String statusJp;
  private String admissionDate;
  private String admissionTime;
  private CustomerResponseDTO customerDetails;
  private Long admissionId;
  private ModelV2DTO model;
  private GradeV2DTO grade;
  private NaviV2DTO navi;
  private String cwNaviId;
  private PackagePlanV2DTO planName;
  private OptionsV2DTO option;
  private PaymentMethodDto paymentMethod;
  private String vinNumber;
  private String carwingsVinNumber;
  private Boolean vehicleTransfer;
  private Long price;
  private String admissionType;
  private String admissionTypeName;
  private DealerDTO dealerDetails;
  private String token;
  private String userName;
  private String oldVinNumber;
  private String paymentStatus;
  private String source;
  private String vehicleType;
  private String iviFlag;
  private String sosFlag;
  private String paperReason;
  private String paperReasonFreeComment;
  private String fileName;
  private String registrationDate;
  private String firstRegistrationDate;
  private String expiryDate;
  private String vehicleNumber;

  public OrdersV2FetchResponseDto(OrdersV2 orders, Customer customer, User user) {
    setOrderDetails(orders, customer);
    this.userName = (customer == null) ? user.getFirstName() : null;
  }

  public OrdersV2FetchResponseDto(OrdersV2 orders, Customer customer) {
    setOrderDetails(orders, customer);
  }

  private void setOrderDetails(OrdersV2 orders, Customer customer) {
    try {
      Date orderCreatedDate = orders.getCreatedDate();
      this.setTempOrdersNumber(orders.getOrdersNumber());
      this.setAdmissionDate(new SimpleDateFormat("yyyy-MM-dd").format(orderCreatedDate));
      this.setAdmissionTime(new SimpleDateFormat("hh:mm aaa").format(orderCreatedDate));
      this.setStatus(orders.getAdmission().getStatus());
      this.setStatusJp(orders.getAdmission().getStatusJp());
      this.setCustomerDetails(getCustomerResponse(Optional.ofNullable(customer)));
      this.setAdmissionId(orders.getAdmission().getId());
      this.setModel(convertModelEntityToDTO(orders.getModel()));
      this.setGrade(convertGradeEntityToGradeDTO(orders.getGrade()));
      if (orders.getNavi() != null) this.setNavi(convertNaviEntityToDTO(orders.getNavi()));
      if (orders.getCwNaviId() != null) this.setCwNaviId(orders.getCwNaviId());
      if (orders.getPackagePlan() != null)
        this.setPlanName(convertPackagePlanEntityToDTO(orders.getPackagePlan()));
      if (orders.getOptions() != null)
        this.setOption(convertOptionEntityToDTO(orders.getOptions()));
      if (orders.getPaymentMethod() != null)
        this.setPaymentMethod(convertPaymentMethodEntityToDTO(orders.getPaymentMethod()));
      this.setVinNumber(orders.getVinNumber());
      this.setVehicleTransfer(orders.getVehicleTransfer());
      this.setOldVinNumber(orders.getOldVinNumber());
      if (orders.getPackagePlan() != null) this.setPrice(orders.getPackagePlan().getPrice());
      this.setAdmissionType(USED_CARS);
      this.setDealerDetails(convertDealerEntityToDTO(orders));
      this.setToken(orders.getAdmission().getUser().getEncodedToken());
      this.source = Constants.ADMISSION_SOURCE_HOME.equals(orders.getSource()) ? "店舗外" : "店舗";
      this.vehicleType =
          Constants.VEHICLE_TYPE_NEW_CAR.equals(orders.getVehicleType()) ? "新車（VINあり）" : "中古車";
      if (orders.getModel().getCategory() != null)
        this.iviFlag = orders.getModel().getCategory() ? "1" : "0";
      this.sosFlag = (orders.getNavi() != null && orders.getNavi().getColorOption()) ? "1" : "0";
      // TODO NICOS payment retry logic
      this.setPaymentStatus(Constants.FAILED);
      // this.setCarwingsDetails(getCarwingsInfo(orders));
      this.setVehicleNumber(orders.getVehicleNumber());
      this.setRegistrationDate(orders.getRegistrationDate());
      this.setFirstRegistrationDate(orders.getFirstRegistrationDate());
      this.setExpiryDate(orders.getExpiryDate());
    } catch (Exception e) {
      e.printStackTrace();
      logger.info("Exception in OrderV2 Fetch Response Constructor : " + e.getMessage());
      if (orders != null
          && orders.getAdmission() != null
          && orders.getAdmission().getUser() != null)
        logger.info("User id to fetch customer : " + orders.getAdmission().getUser().getId());
    }
  }

  private CustomerResponseDTO getCustomerResponse(Optional<Customer> optionalCustomer) {
    logger.info("Inside get customer response");
    CustomerResponseDTO customerResponse = new CustomerResponseDTO();
    if (!optionalCustomer.isPresent()) {
      return null;
    }
    try {
      Customer customer = optionalCustomer.get();
      customerResponse.setAddress1(customer.getAddress1());
      customerResponse.setAddress2(customer.getAddress2());
      customerResponse.setCorporateName(customer.getCorporateName());
      customerResponse.setEmail(customer.getEmail());
      customerResponse.setFamilyName(customer.getFamilyName());
      customerResponse.setFamilyNameKatakana(customer.getFamilyNameKatakana());
      customerResponse.setFirstName(customer.getFirstName());
      customerResponse.setFirstNameKatakana(customer.getFirstNameKatakana());
      customerResponse.setOfficePosition(customer.getOfficePosition());
      customerResponse.setPhoneNumber(
          replaceNullFirstParameters(customer.getPhoneNumber1())
              + ""
              + replaceNullFirstParameters(customer.getPhoneNumber2())
              + ""
              + replaceNullFirstParameters(customer.getPhoneNumber3()));
      customerResponse.setOptionalPhoneNumber(
          replaceNullFirstParameters(customer.getOptionalPhoneNumber1())
              + ""
              + replaceNullFirstParameters(customer.getOptionalPhoneNumber2())
              + ""
              + replaceNullFirstParameters(customer.getOptionalPhoneNumber3()));
      customerResponse.setRepresentativeName(customer.getRepresentativeName());
      customerResponse.setRepresentativeNameKatakana(customer.getRepresentativeNameKatakana());
      customerResponse.setStepCount(customer.getStepCount());
      customerResponse.setZipCode(customer.getZipCode1() + "" + customer.getZipCode2());
      customerResponse.setCustomerType(customer.getCustomerType());
      customerResponse.setUserId(customer.getUser().getId());
      customerResponse.setToken(customer.getUser().getEncodedToken());
    } catch (Exception e) {
      logger.info("Exception in getCustomerResponse : " + e.getMessage());
    }
    return customerResponse;
  }

  private ModelV2DTO convertModelEntityToDTO(final ModelV2 model) {
    final ModelV2DTO modelDTO = new ModelV2DTO();
    modelDTO.setId(model.getId());
    modelDTO.setName(model.getModelName());
    modelDTO.setDisplayName(model.getDisplayName());
    modelDTO.setImgUrl(model.getUrl());
    return modelDTO;
  }

  private GradeV2DTO convertGradeEntityToGradeDTO(final GradeV2 grade) {
    final GradeV2DTO gradeDTO = new GradeV2DTO();
    gradeDTO.setId(grade.getId());
    gradeDTO.setModelName(grade.getModel().getModelName());
    gradeDTO.setName(grade.getGradeName());
    gradeDTO.setDisplayName(grade.getDisplayName());
    return gradeDTO;
  }

  private NaviV2DTO convertNaviEntityToDTO(final NaviV2 navi) {
    final NaviV2DTO naviDTO = new NaviV2DTO();
    naviDTO.setId(navi.getId());
    naviDTO.setGradeId(navi.getGrade().getId());
    naviDTO.setName(navi.getNaviName());
    naviDTO.setDisplayName(navi.getDisplayName());
    return naviDTO;
  }

  private OptionsV2DTO convertOptionEntityToDTO(final OptionsV2 option) {
    final OptionsV2DTO optionDTO = new OptionsV2DTO();
    optionDTO.setId(option.getId());
    optionDTO.setName(option.getOptionsName());
    optionDTO.setDisplayName(option.getDisplayName());
    optionDTO.setNaviId(option.getNavi().getId());
    return optionDTO;
  }

  private PaymentMethodDto convertPaymentMethodEntityToDTO(final PaymentMethod paymentMethod) {
    final PaymentMethodDto paymentMethodDto = new PaymentMethodDto();
    paymentMethodDto.setId(paymentMethod.getId());
    paymentMethodDto.setName(paymentMethod.getName());
    paymentMethodDto.setDisplayName(paymentMethod.getDisplayName());
    return paymentMethodDto;
  }

  private PackagePlanV2DTO convertPackagePlanEntityToDTO(final PackagePlanV2 packagePlan) {
    final PackagePlanV2DTO packagePlanDTO = new PackagePlanV2DTO();
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    packagePlanDTO.setAdminFee(packagePlan.getAdminFee());
    packagePlanDTO.setDescription(packagePlan.getDescription());
    return packagePlanDTO;
  }

  private static DealerDTO convertDealerEntityToDTO(OrdersV2 orders) {
    logger.info("Inside convertDealerEntityToDTO");
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyName(orders.getCompanyName());
    dealerDTO.setDealershipName(orders.getDealershipName());
    dealerDTO.setPhoneNumber(orders.getPhoneNumber());
    dealerDTO.setCaName(orders.getCaName());
    dealerDTO.setCaNameKana(orders.getCaNameKana());
    dealerDTO.setCaCode(orders.getCaCode());
    return dealerDTO;
  }

  private String replaceNullFirstParameters(String value) {
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }
}
