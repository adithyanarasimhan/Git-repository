package com.nissan.common.util;

import com.google.common.collect.ImmutableList;

import java.util.*;

public final class Constants {

  private Constants() {
    super();
  }

  public static final String EN = "en";
  public static final String JP = "jp";
  public static final String ROLE_CUSTOMER = "ROLE_CUSTOMER";
  public static final String ROLE_CA = "ROLE_CA";
  public static final String ROLE_KAMEARI = "ROLE_KAMEARI";
  public static final String ROLE_FPN = "ROLE_FPN";
  public static final String ROLE_BUSINESS = "ROLE_BUSINESS";
  public static final String ROLE_JF0 = "ROLE_JF0";
  public static final String ROLE_IB4 = "ROLE_IB4";
  public static final String FPC = "FPC";
  public static final String FPN = "FPN";
  public static final String HOUSE_CARD = "HOUSE CARD";
  public static final String SUCCESS = "SUCCESS";
  public static final String FAILED = "FAILED";
  public static final String ERROR = "ERROR";
  public static final String CORRUPT_DOWNLOAD = "File contains corrupt data";
  public static final String AUTH_OPERATE_ID = "1Auth";
  public static final String PAY_TYPE = "01";
  public static final String TENANT_ID = "0001";
  public static final String PAYMENT_METHOD_DIGITAL = "digital";
  public static final String PAYMENT_METHOD_PAPER = "paper";
  public static final String PAYMENT_METHOD_BANK = "bank";
  public static final String BANK_EN ="BANK";
  public static final String BANK_JP ="口座振替";
  public static final String VISA = "VISA";
  public static final String JCB = "JCB";
  public static final String AMEX = "AMEX";
  public static final String NICOS = "NICOS";
  public static final String NFS = "NFS";
  public static final String NFS_JP = "日産ハウスカード";
  public static final String NOT_SEND = "NOT_SEND";
  public static final String SEND = "SEND";
  public static final String SUBSCRIBED_NC = "SUBSCRIBED NC";
  public static final String SORT_ASCENDING = "asc";
  public static final String SORT_DESCENDING = "desc";
  public static final String STATUS_EMAIL = "email";
  public static final String STATUS = "status";
  public static final String DEALER_TYPE_CA = "CA";
  public static final String DEALER_TYPE_BUSINESS = "Business";
  public static final String DEALER_TYPE_KAMEARI = "Kameari";
  public static final String DEALER_TYPE_IB4 = "IB4";
  public static final String DEALER_TYPE_JF0 = "JF0";
  public static final String SHIFT_JIS = "Shift_JIS";
  public static final String AWS_SECRET = "nissan-connect-aws-keys";
  public static final String RDS_SECRET = "/rds/nissan-admission";
  public static final String GOOGLE_SECRET = "/nissan-connect/google-key";
  public static final String SFTP_SECRET = "/nissan-connect/sftp";
  public static final String CAR_WINGS_SECRET = "/nissan-connect/car_wings";
  public static final String VPM_SECRET = "/nissan-connect/vpm";
  public static final String SAML_SECRET = "/nissan-connect/saml_key_store";
  public static final String SONY_SECRET = "/nissan-connect/sony_merchant_pass";
  public static final String MAPION_SECRET = "/nissan-connect/mapion_key";
  public static final String DEALER_API_SECRET = "/nissan-connect/dealer_visit_api";
  public static final String NICOS_SECRET = "/nissan-connect/nicos_hashcode_key";
  public static final String NICOS_KEYSTORE = "/nissan-connect/nicos_key_store_password";
  public static final String ADMISSION_SOURCE_DEALER = "dealer";
  public static final String ADMISSION_SOURCE_HOME = "home";
  public static final String NFS_PAYMENT = "nfs";
  public static final String CREDIT_PAYMENT = "credit-card";
  public static final String PACKAGE_BASIC = "basic";
  public static final String PACKAGE_SOS = "sos";
  public static final String PACKAGE_BASIC_SOS = "basic-sos";
  public static final String PACKAGE_BASIC_OPERATOR_SERVICE = "basic-operator-service";
  public static final String HTTP = "http://";
  public static final String PRINCIPAL_ID = "principalId";
  public static final String COMPANY_CODE = "28707";
  public static final String PAYMENT_INITIATED =  "PAYMENT_INITIATED";
  public static final String PAYMENT_COMPLETE =  "PAYMENT_COMPLETE";
  public static final String PAYMENT_FAILED =  "PAYMENT_FAILED";
  /** Error Codes*/
  public static final String STATUS_200 = "200";
  public static final String STATUS_204 = "204";
  public static final String STATUS_206 = "206";
  public static final String STATUS_500 = "500";
  public static final String SYSTEM_ERROR = "10099";
  public static final String VEHICLE_NOT_FOUND = "20000";
  public static final String VIN_NAVIID_NOT_MATCH = "20001";
  public static final String MEMBER_MORE_EXIST = "20002";

  public static final Map<String, String> SORTING_KEYS =
      new HashMap<String, String>() {
        {
          put("tempOrdersNumber", "ordersNumber");
          put("status", "a.status");
          put("statusJp", "a.statusJp");
          put("admissionDate", "a.createdDate");
          put("admissionTime", "a.createdDate");
          put("customerType", "c.customerType");
          put("familyName", "c.familyName");
          put("familyNameKatakana", "c.familyNameKatakana");
          put("firstName", "c.firstName");
        }
      };
  public static final String STATUS_CUSTOMER_FILLING = "CUSTOMER_FILLING";
  public static final String STATUS_CUSTOMER_FILLING_JP = "お客さま入力中";
  public static final String STATUS_CUSTOMER_COMPLETED = "CUSTOMER_COMPLETED";
  public static final String STATUS_CUSTOMER_COMPLETED_JP = "PROFIT注文書No.未登録";
  public static final String STATUS_DEALER_WORKING = "DEALER_WORKING";
  public static final String STATUS_DEALER_WORKING_JP = "PROFIT注文書No.未登録";
  public static final String STATUS_DEALER_COMPLETED = "DEALER_COMPLETED";
  public static final String STATUS_DEALER_COMPLETED_JP = "PROFIT注文書No.登録済み";
  public static final String STATUS_DEALER_ALL_COMPLETED = "DEALER_ALL_COMPLETED";
  public static final String STATUS_DEALER_ALL_COMPLETED_JP = "C/A申込作業完了";
  public static final String STATUS_DEALER_COMPLETED_VIN_JP = "お客さま申込完了";
  public static final String STATUS_DEALER_COMPLETED_SS = "DEALER_ALL_COMPLETED";
  public static final String STATUS_DEALER_COMPLETED_SS_JP = "C/A申込作業完了";
  public static final String STATUS_DEALER_COMPLETED_SZ = "REGISTERED(in_preparation)";
  public static final String STATUS_DEALER_COMPLETED_SZ_JP = "登録完了（ID通知準備中）";
  public static final String STATUS_DEALER_COMPLETED_SA = "REGISTERED(in_preparation)";
  public static final String STATUS_DEALER_COMPLETED_SA_JP = "登録完了（ID通知準備中）";
  public static final String PAPER_STATUS_MAIL_POSTED = "REGISTERED(id_posted)";
  public static final String PAPER_STATUS_MAIL_POSTED_JP = "登録完了（ID通知発送済み）";
  public static final String STATUS_EMAIL_SENT = "REGISTERED(id_sent)";
  public static final String STATUS_EMAIL_SENT_JP = "登録完了（ID通知送信済み）";
  public static final String STATUS_CANCEL = "CANCEL";
  public static final String STATUS_CANCEL_JP = "申込キャンセル";
  public static final String STATUS_WITHDRAWAL_ZZ = "WITHDRAWAL";
  public static final String STATUS_WITHDRAWAL_ZZ_JP = "退会済み";
  public static final String STATUS_PERSONAL_INFO_DELETED_DW = "PERSONAL_INFO_DELETED";
  public static final String STATUS_PERSONAL_INFO_DELETED_DW_JP = "個人情報削除済";
  public static final String STATUS_BANK_ID_CONFIRMING = "BANK_ID_CONFIRMING";
  public static final String STATUS_BANK_ID_CONFIRMING_JP = "口座情報確認中";
  public static final String STATUS_BANK_ID_RESETTING = "BANK_ID_RESETTING";
  public static final String STATUS_BANK_ID_RESETTING_JP = "口座情報再設定中";
  public static final String STATUS_VIN_RESETTING = "VIN_RESETTING";
  public static final String STATUS_VIN_RESETTING_JP = "車台番号再設定中";
  public static final String STATUS_RESENT_EMAIL_JP = "お客様にNC-IDを通知するメールが再送信されました";
  public static final String STATUS_SENT_EMAIL_NC_JP = "お客様にNC-IDを通知するメールが送信されました";
  public static final String NO_THANKS_DEALER_COMPLETED_JP = "C/A作業完了";
  public static final String AUTH_SERVICE = "ncas-auth-service";
  public static final String ADMISSION_SERVICE = "ncas-admission-service";
  public static final String CARWINGS_SERVICE = "ncas-carwings-service";
  public static final String PAYMENT_SERVICE = "ncas-payment-service";
  public static final String NOTIFICATION_SERVICE = "ncas-notification-service";
  public static final String DEMOCAR_SERVICE = "ncas-democar-service";
  public static final long SIXTY_MINUTES = 60;
  public static Set<String> VEHICLE_CATEGORY_NEW_CAR = new HashSet<>(Arrays.asList("common", "newcar"));
  public static Set<String> VEHICLE_CATEGORY_USED_CAR = new HashSet<>(Arrays.asList("common", "usedcar"));
  public static final String VEHICLE_TYPE_NEW_CAR = "newcar";
  public static final String VEHICLE_TYPE_USED_CAR = "usedcar";
  public static final String SOURCE_FPN = "fpn";
  public static final String SOURCE_COMPASS = "compass";
  public static final String NAVI_TYPE_SOS = "s-os";
  public static final String NC_ID_GENERATED = "NC ID生成された";
  public static final String CARWINGS_STATUS_SA = "SA";
  public static final String CARWINGS_STATUS_SZ = "SZ";
  public static final String CARWINGS_STATUS_SS = "SS";
  public static final String CARWINGS_STATUS_SC = "SC";
  public static final String CARWINGS_STATUS_CODE_ZERO = "0";
  public static final ImmutableList<String> DAYZ_MODEL = ImmutableList.of( "Dayz","デイズ");
  public static final ImmutableList<String> NOTE_MODEL = ImmutableList.of( "Note","ノート（2020年12月発売）");
  public static final ImmutableList<String> ARIYA_MODEL = ImmutableList.of( "Ariya","アリア");
  public static final ImmutableList<String> EV_TEMPLATES_USING_MODELS =
          ImmutableList.of( "LEAF (January 2020 ~)","リーフ（2020年2月～）");
  public static final ImmutableList<String> EV19_TEMPLATES_USING_MODELS =
          ImmutableList.of( "Leaf (before January 2020)","リーフ（2020年1月以前）", "e-NV200");
  public static final ImmutableList<String> EV20_TEMPLATES_USING_MODELS =
          ImmutableList.of( "Leaf (from February 2020)","リーフ（2020年2月～）");
  public static final ImmutableList<String> B13B_TEMPLATES_USING_MODELS =
          ImmutableList.of("Note","SKYLINE (September 2019 ~)","ノート","スカイライン（2019年9月～）");
  public static final ImmutableList<String> IVI_TEMPLATES_USING_MODELS =
          ImmutableList.of("Note","Skyline (From September 2019)","ノート（2020年12月発売）","スカイライン（2019年9月～）");
  public static final ImmutableList<String> PDF_USING_MODELS =
          ImmutableList.of( "Leaf (from February 2020)","リーフ（2020年2月～）","ノート（2020年12月発売）","Skyline (From September 2019)","Note","スカイライン（2019年9月～）");
  public static final String BUSINESS = "Business";
  public static final String CATEGORY_IVI = "IVI";

  /** Database Model Name */
  public static final String DB_SKYLINE = "スカイライン（2019年9月～）";
  public static final String DB_LEAF = "リーフ";
  public static final String DB_LEAF_2019_JP = "リーフ（2020年1月以前）";
  public static final String DB_LEAF_2020_JP = "リーフ（2020年2月～）";
  public static final String DB_LEAF_2019_EN = "Leaf (before January 2020)";
  public static final String DB_LEAF_2020_EN = "Leaf (from February 2020)";
  public static final String DB_E_NV200 = "e-NV200";
  public static final String DB_NOTE = "ノート（2020年12月～）";
  public static final String DB_DAYZ = "デイズ";
  public static final String DB_ROOX = "ルークス";
  public static final String DB_KICKS = "キックス";
  public static final String DB_X_TRAIL = "エクストレイル";
  public static final String DB_ELGRAND = "エルグランド";
  public static final String DB_TEANA = "ティアナ";
  public static final String DB_FUGA = "フーガ";
  public static final String DB_CIMA = "シーマ";
  public static final String DB_OTHERS = "その他";

  /** Carwings Model Name */
  public static final String CW_SKYLINE = "スカイライン";
  public static final String CW_LEAF = "リーフ";
  public static final String CW_E_NV200 = "e-NV200";
  public static final String CW_NOTE = "ノート";
  /** CW return both the values DAYZ or デイズ */
  public static final String CW_DAYZ = "DAYZ";
  public static final String CW_DAYZ_DB = "デイズ";
  public static final String CW_ROOX = "ルークス";
  public static final String CW_KICKS = "キックス";
  public static final String CW_X_TRAIL = "エクストレイル";
  public static final String CW_ELGRAND = "エルグランド";
  public static final String CW_TEANA = "ティアナ";
  /** CW return both the values フーガ or フーガハイブリッド */
  public static final String CW_FUGA = "フーガハイブリッド";
  public static final String CW_FUGA_DB = "フーガ";
  /** CW return both the values シーマ or シーマハイブリッド */
  public static final String CW_CIMA = "シーマハイブリッド";
  public static final String CW_CIMA_DB = "シーマ";

  /** Color Table Model Name */
  public static final String C_NOTE = "ノート（2020年12月発売）";

  public static final String REASON_NAME_A = "reasona";
  public static final String REASON_NAME_B = "reasonb";
  public static final String REASON_NAME_C = "reasonc";

  public static final String CW_VIN_RESPONSE_DOP_TRUE = "1";
  public static final String CW_VIN_RESPONSE_IVI_TRUE = "1";

  public static final String DC_NOTIFICATION_STATUS_NO_INFO = "NoInfoCompass";
  public static final String DC_NOTIFICATION_STATUS_PRVATE_FLAG = "PrivateFlagCompass";
  public static final String DC_NOTIFICATION_STATUS_CW_IMPORT_SUCCESS = "CwImportSuccess";
  public static final String DC_NOTIFICATION_STATUS_CW_IMPORT_FAILED = "CwImportFailed";
  public static final String DC_NOTIFICATION_STATUS_RETURN_MANUALLY = "ReturnManually";
  public static final String DC_NOTIFICATION_STATUS_RETURN_AUTOMATICALLY = "ReturnAutomatically";

  public static final HashMap<String, String> NAVI_REFERENCE_FLAG = new HashMap<String, String>(){{
    put("1", "m-op-free-plan");
    put("2", "d-op");
  }};

  public static final String VIN_SEARCH_ERROR_DATA = "Error Data : Inconsistency";
  public static final String VIN_SEARCH_SYSTEM_ERROR = "System Error";

  public static final String DEALER_NOT_FOUND = "Dealer not found";

  public static final String STATUS_DEALER_WRONG = "DEALER_WRONG";
  public static final String STATUS_DEALER_WRONG_JP = "Profit注文書No.登録誤り に変更されました。";

  public static final String STATUS_RESTORED_ORDER = "Restored the record";
  public static final String STATUS_RESTORED_ORDER_JP = "レコードを復元しました。";

  public static final String EMAIL_SENT_SUCCESS_MESSAGE = "Email has been sent. Please check your mail!";
  public static final String EMAIL_SENT_SUCCESS_MESSAGE_JP = "担当者様へメールを送りました。ご確認お願いいたします";

  public static final String EMAIL_SENT_FAILURE_MESSAGE = "Could not send email. Please retry";

  public static final String CA_EMAIL_SENT = "Registration mail to CA has been triggered successfully";
  public static final String CA_EMAIL_FAILURE = "Couldn't trigger Registration mail to CA";

  public static final String NCID_EMAIL_SENT = "NC ID Mail has been sent.Please check your mail!";
  public static final String NCID_EMAIL_FAILURE = "Could not send email. Please retry";

  public static final String VERIFICATION_EMAIL_SENT = "Verification email has been sent.Please check your mail!";
  public static final String VERIFICATION_EMAIL_FAILURE = "Could not send email. Please retry";

  public static final String REGISTRATION_EMAIL_SENT = "Registration mail has been triggered successfully";
  public static final String REGISTRATION_EMAIL_FAILURE = "Couldn't trigger Registration mail";

  public static final String PO_EMAIL_SENT = "PO Mail to CA has been triggered successfully";
  public static final String PO_EMAIL_FAILURE = "Couldn't trigger PO mail to CA";

  public static final String FILE_UPLOAD = "Inspection Document Uploaded";
  public static final String FILE_UPLOAD_JP = "車検証を登録しました。";
  public static final String FILE_UPLOAD_ERROR = "Inspection Document Upload Failed";

}
