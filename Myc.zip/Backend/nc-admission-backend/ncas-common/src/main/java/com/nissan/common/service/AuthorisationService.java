package com.nissan.common.service;

public interface AuthorisationService {
  String generateTokenOnUser(Long userId);

  String generateTokenOnUserNissanConnect(Long userId);
}
