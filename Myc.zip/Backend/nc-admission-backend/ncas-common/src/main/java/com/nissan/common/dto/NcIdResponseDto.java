package com.nissan.common.dto;

import lombok.Data;

@Data
public class NcIdResponseDto {
    private String email;
}
