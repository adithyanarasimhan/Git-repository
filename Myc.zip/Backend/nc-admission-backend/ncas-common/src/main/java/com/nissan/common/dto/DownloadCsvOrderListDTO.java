package com.nissan.common.dto;

import com.nissan.common.util.FormatValue;
import lombok.Data;

import java.time.LocalDate;
import java.util.Date;

@Data
public class DownloadCsvOrderListDTO {
    private String createdDate;
    private String status;
    private Integer admissionType;
    private String admissionTypeName;
    private String admissionSource;
    private String vehicleType;
    private Long id;
    private String ordersNumber;
    private String companyCode;
    private String companyName;
    private String dealershipName;
    private String phoneNumber;
    private String caName;
    private String caNameKana;
    private String caCode;
    private String email;
    private Long customerType;
    private String modelName;
    private String gradeName;
    private String naviName;
    private String optionsName;
    private String packagePlanName;
    private String iviFlag;
    private String sosFlag;
    private String cwVinNumber;
    private String firstRegisteredDate;
    private String vinRegisteredDate;
    private String ncId;
    private String ncStatus;
    private String ncJoinedDate;
    private String chargeStartDate;
    private String serviceUpdateDate;
    private String planPrice;
    private String adopterId;
    private String registerNumber;
    private String modelNameCw;
    private String emailSendDate;
    private String name;
    private Boolean vehicleTransfer;
    private String vinNumber;
    private String paperReason;
    private String paperComment;
    private Boolean active;

    public DownloadCsvOrderListDTO( Date createdDate,String status,Integer admissionType,Long id,String ordersNumber, String companyCode, String companyName, String dealershipName, String phoneNumber, String caName, String caNameKana, String caCode, String email, Long customerType, String modelName, String gradeName, String naviName, String optionsName, String packagePlanName, String category, String cwVinNumber, Date firstRegisteredDate, Date vinRegisteredDate, String ncId,String ncStatus, Date ncJoinedDate, Date chargeStartDate, Date serviceUpdateDate,String planPrice ,String adopterId, String registerNumber,String modelNameCw,LocalDate emailSendDate, String name, Boolean vehicleTransfer, String vinNumber,String paperReason, String paperComment, Boolean active) {
        this.createdDate = FormatValue.formatDateMinutes(createdDate);
        this.status = status;
        this.admissionType = admissionType;
        this.admissionSource = "店舗";
        this.vehicleType = "新車（VINなし）";
        this.id = id;
        this.ordersNumber = ordersNumber;
        this.companyCode = companyCode;
        this.companyName = companyName;
        this.dealershipName = dealershipName;
        this.phoneNumber = phoneNumber;
        this.caName = caName;
        this.caNameKana = caNameKana;
        this.caCode = caCode;
        this.email = email;
        this.customerType = customerType;
        this.modelName = modelName;
        this.gradeName = gradeName;
        this.naviName = naviName;
        this.optionsName = optionsName;
        this.packagePlanName = packagePlanName;
        if ("IVI".equals(category)) {
            this.iviFlag = "1";
        } else {
            this.iviFlag = "0";
        }
        if (packagePlanName.contains("sos")) {
            this.sosFlag = "1";
        } else {
            this.sosFlag = "0";
        }
        this.cwVinNumber = cwVinNumber;
        this.firstRegisteredDate = FormatValue.formatYearMonth(firstRegisteredDate);
        this.vinRegisteredDate = FormatValue.formatDate(vinRegisteredDate);
        this.ncId = ncId;
        this.ncStatus = ncStatus;
        this.ncJoinedDate = FormatValue.formatDate(ncJoinedDate);
        this.chargeStartDate = FormatValue.formatDate(chargeStartDate);
        this.serviceUpdateDate = FormatValue.formatDate(serviceUpdateDate);
        this.planPrice = planPrice;
        this.adopterId = adopterId;
        this.registerNumber = registerNumber;
        this.modelNameCw=modelNameCw;
        this.emailSendDate = FormatValue.formatLocalDate(emailSendDate);
        this.name = name;
        this.vehicleTransfer = vehicleTransfer;
        this.vinNumber = vinNumber;
        this.paperReason = paperReason;
        this.paperComment = paperComment;
        this.active = active;
    }

    public DownloadCsvOrderListDTO( Date createdDate, String status, String source, String vehicleType, Long id, String companyCode, String companyName, String dealershipName, String phoneNumber, String caName, String caNameKana, String caCode, String email, Long customerType, String modelName, String gradeName, String naviName, String optionsName, String packagePlanName, Boolean category, String cwVinNumber, Date vinRegisteredDate, String ncId,String ncStatus, Date chargeStartDate, Date serviceUpdateDate,String planPrice ,String adopterId, String registerNumber,LocalDate emailSendDate, String name, Boolean vehicleTransfer, String vinNumber,String paperReason, String paperComment, Boolean active) {
        this.createdDate = FormatValue.formatDateMinutes(createdDate);
        this.status = status;
        this.admissionType = null;
        this.admissionSource = source;
        this.vehicleType = vehicleType;
        this.id=id;
        this.ordersNumber = "";
        this.companyCode = companyCode;
        this.companyName = companyName;
        this.dealershipName = dealershipName;
        this.phoneNumber = phoneNumber;
        this.caName = caName;
        this.caNameKana = caNameKana;
        this.caCode = caCode;
        this.email = email;
        this.customerType = customerType;
        this.modelName = modelName;
        this.gradeName = gradeName;
        this.naviName = naviName;
        this.optionsName = optionsName;
        this.packagePlanName = packagePlanName;
        if (category) {
            this.iviFlag = "1";
        } else {
            this.iviFlag = "0";
        }
        if (packagePlanName.contains("sos")) {
            this.sosFlag = "1";
        } else {
            this.sosFlag = "0";
        }
        this.cwVinNumber = cwVinNumber;
        this.firstRegisteredDate = "";
        this.vinRegisteredDate = FormatValue.formatDate(vinRegisteredDate);
        this.ncId = ncId;
        this.ncStatus = ncStatus;
        this.ncJoinedDate = "";
        this.chargeStartDate = FormatValue.formatDate(chargeStartDate);
        this.serviceUpdateDate = FormatValue.formatDate(serviceUpdateDate);
        this.planPrice = planPrice;
        this.adopterId = adopterId;
        this.registerNumber = registerNumber;
        this.modelNameCw = "";
        this.emailSendDate = FormatValue.formatLocalDate(emailSendDate);
        this.name = name;
        this.vehicleTransfer = vehicleTransfer;
        this.vinNumber = vinNumber;
        this.paperReason = paperReason;
        this.paperComment = paperComment;
        this.active = active;
    }
}