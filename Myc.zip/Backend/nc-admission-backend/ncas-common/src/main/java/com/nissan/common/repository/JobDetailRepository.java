package com.nissan.common.repository;

import com.nissan.common.entity.JobDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobDetailRepository extends JpaRepository<JobDetails, Long> {}
