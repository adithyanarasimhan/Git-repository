package com.nissan.common.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class AuthDto {
 private Long id;
}
