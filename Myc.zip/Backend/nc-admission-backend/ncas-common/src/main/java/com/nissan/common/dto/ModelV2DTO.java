package com.nissan.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class ModelV2DTO {
  private long id;
  private String name;
  private String cwModelName;
  private String displayName;
  private String imgUrl;
  private List<GradeV2DTO> grades;
  private GradeV2DTO grade;
  private Boolean iviCategory;
  private Boolean colorOption;
}
