package com.nissan.common.service;

import com.nissan.common.dto.DealerAddressDTO;
import com.nissan.common.dto.DealerAddressResponseDTO;

import java.util.List;
import java.util.Optional;

public interface MapionService {

  List<DealerAddressDTO> getAddressByZip(String zipCode, int radius) throws Exception;

  List<DealerAddressDTO> getAddressByLoc(String prefecture, String city1, String city2, int radius)
      throws Exception;

  DealerAddressResponseDTO saveDealer(String userName, DealerAddressDTO addressDTO) throws Exception;

  List<String> getCityDetails(Optional<String> city1, Optional<String> city2);

  String getDealerVisitStatus(Long admissionId);
}
