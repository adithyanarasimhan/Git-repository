package com.nissan.common.dto;

import lombok.Data;

@Data
public class PackagePlanV2DTO {
    private long id;
    private long naviId;
    private String name;
    private String displayName;
    private long price;
    private long adminFee;
    private String checkSheetPattern;
    private String tcPattern;
    private String description;
}
