package com.nissan.common.dto;

import lombok.Data;

@Data
public class DealerDetailsRequestDTO {
    private String companyName;
    private String dealershipName;
    private String phoneNumber;
    private String caName;
    private String caNameKana;
    private String caCode;
}
