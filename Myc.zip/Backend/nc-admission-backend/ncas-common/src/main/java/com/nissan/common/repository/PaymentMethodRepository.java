package com.nissan.common.repository;

import com.nissan.common.entity.PaymentMethod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PaymentMethodRepository
    extends JpaRepository<PaymentMethod, Long>, QuerydslPredicateExecutor<PaymentMethod> {
  List<PaymentMethod> findByLangCode(String lang);

  @Query(
      "SELECT pm from PaymentMethod pm where pm.langCode=:lang AND pm.name IN (:names) ORDER BY pm.name DESC")
  List<PaymentMethod> findByLangCodeAndNameIn(String lang, Set<String> names);

  @Query(value = "select * from payment_method where name=? AND lang_code=?", nativeQuery = true)
  PaymentMethod findByNameAndLangCode(String name, String lang_code);

  @Query(value = "select * from payment_method where display_name=? AND lang_code=?", nativeQuery = true)
  PaymentMethod findByDisplayNameAndLangCode(String displayName, String lang_code);
}
