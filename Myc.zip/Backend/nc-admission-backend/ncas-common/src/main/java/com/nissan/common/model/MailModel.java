package com.nissan.common.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class MailModel {

  private String from;
  private String sentTo;
  private String subject;
  private List<Object> attachments;
  private Map<String, Object> model;
  private String templateName;
}
