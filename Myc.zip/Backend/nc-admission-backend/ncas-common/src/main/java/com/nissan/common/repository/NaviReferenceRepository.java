package com.nissan.common.repository;

import com.nissan.common.entity.NaviReference;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface NaviReferenceRepository extends JpaRepository<NaviReference, Long>, QuerydslPredicateExecutor<NaviReference> {
    NaviReference findByAdaptorKind(String adaptorKind);
}
