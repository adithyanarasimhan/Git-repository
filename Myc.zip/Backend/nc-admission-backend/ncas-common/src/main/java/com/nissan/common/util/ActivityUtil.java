package com.nissan.common.util;

import com.nissan.common.entity.ActivityLog;
import com.nissan.common.entity.ActivityLogV2;
import com.nissan.common.entity.Admission;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.repository.ActivityLogRepository;
import com.nissan.common.repository.ActivityLogV2Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class ActivityUtil {
  @Autowired public ActivityLogRepository activityLogRepository;
  @Autowired public ActivityLogV2Repository activityLogV2Repository;

    public void createActivityLog(Admission admission) {

        ActivityLog activityLog = new ActivityLog();
        activityLog.setAdmissionId(admission.getId());
        activityLog.setTime(LocalDateTime.now());
        activityLog.setType(Constants.STATUS);
        activityLog.setMessage(admission.getStatus());
        activityLog.setMessageJp(admission.getStatusJp() + " " + "に変更されました");
        activityLogRepository.save(activityLog);
    }

    public void createActivityLogV2(AdmissionV2 admission) {

        ActivityLogV2 activityLog = new ActivityLogV2();
        activityLog.setAdmissionId(admission.getId());
        activityLog.setTime(LocalDateTime.now());
        activityLog.setType(Constants.STATUS);
        activityLog.setMessage(admission.getStatus());
        activityLog.setMessageJp(admission.getStatusJp() + " " + "に変更されました");
        activityLogV2Repository.save(activityLog);
    }
}
