package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "package_plan")
@EntityListeners(AuditingEntityListener.class)
public class PackagePlan extends Auditable<String> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "navi_id", referencedColumnName = "id")
  private Navi navi;

  @Column(name = "package_plan_name")
  private String packagePlanName;

  @Column(name = "display_name")
  private String displayName;

  @Column(name = "price")
  private Long price;

  @Column(name = "pattern_name")
  private String patternName;

  @Column(name = "terms_name")
  private String termsName;

  @Column(name = "lang_code")
  private String langCode;

  @Column(name = "category")
  private String category;
}
