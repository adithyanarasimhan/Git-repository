package com.nissan.common.dto;

import lombok.Data;

@Data
public class UserDto {
  private Long id;
  private String firstName;
  private String lastName;
  private String username;
  private String type;
  private String password;
  private boolean enabled;
  private boolean tokenExpired;
  private boolean isValidToken;
}
