package com.nissan.common.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class PaymentDTO {

  @NotEmpty private String cardName;

  @Size(min = 12, max = 16)
  private String cardNumber;

  @NotNull private Long cardBrand;
  
  @NotNull private Long stepCount;

  @NotNull
  @Range(min = 01, max = 12)
  private String expiryMonth;

  @NotNull(message = "token should be entered")
  @NotNull
  @Range(min = 00, max = 99)
  private String expiryYear;

  private String token1;

  private String token2;

  @NotNull(message = "amount should be entered")
  private String amount;
}
