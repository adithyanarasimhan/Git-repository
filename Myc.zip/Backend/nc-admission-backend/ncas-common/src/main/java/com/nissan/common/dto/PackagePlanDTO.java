package com.nissan.common.dto;

import lombok.Data;

@Data
public class PackagePlanDTO {
  private long id;
  private long naviId;
  private String name;
  private String displayName;
  private long price;
  private String checkSheetPattern;
  private String tcPattern;
  private String category;
  private String carPlan;
  private String iccFee;
}
