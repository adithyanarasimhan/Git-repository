package com.nissan.common.config;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.Properties;

public class SecretsManager implements ApplicationListener<ApplicationPreparedEvent> {

  private static final Logger LOGGER = LoggerFactory.getLogger(SecretsManager.class);

  private static final String REGION = "ap-northeast-1";
  private static final String ACTIVE_PROFILE = "SPRING_PROFILES_ACTIVE";
  private static final String DATA_SOURCE_URL = "spring.datasource.url";
  private static final String DATA_SOURCE_USERNAME = "spring.datasource.username";
  private static final String GOOGLE_KEY = "googleKey";
  private static final String AWS_ACCESS_KEY = "awsAccessKey";
  private static final String AWS_SECRET_KEY = "awsSecretKey";
  private static final String SPRING_GOOGLE_KEY = "spring.google.key";
  private static final String SFTP_KEY_PASS_PHRASE = "sftp.keyPassphrase";
  private static final String KEY_STORE_HEADER = "keyStoreHeader";
  private static final String KEY_STORE_PASSWORD = "keyStorePassWord";
  private static final String CAR_WINGS_PASSWORD = "car.wings.password";
  private static final String CAR_WINGS_SECRET_KEY = "car.wings.secret.key";
  private static final String ASP_USER_PASSWORD = "asp.user.password";
  private static final String SONY_MERCHANT_ID = "sony.merchant.id";
  private static final String SONY_MERCHANT_PASS = "sony.merchant.password";
  private static final String SONY_KAIIN_PASS = "sony.kaiin.password";
  private static final String NISSAN_MAPION_URL = "nissan.mapion.url";
  private static final String DEALER_VISIT_API = "ncas.dealer.visit";
  private static final String DEALER_VISIT_CALLBACK = "ncas.dealer.callback";
  private static final String DEALER_VISIT_STATUS = "ncas.dealer.status";
  private static final String NICOS_HASHCODE_KEY = "nicos.hashcode.key";
  private static final String NICOS_KEYSTORE_PASS= "nicos.keystore.pass";
  private static final String VPM_PASSWORD = "vpm.password";

  private ObjectMapper mapper = new ObjectMapper();

  @Override
  public void onApplicationEvent(ApplicationPreparedEvent event) {
    String profile = System.getenv(ACTIVE_PROFILE);
    LOGGER.info("profile {} ", profile);
    if (!"local".equals(profile)) {

      /** Get passwords from AWS Secret Manager using secret name */
      String awsSecret = getSecret(Constants.AWS_SECRET);
      String googleKey = getSecret(profile + Constants.GOOGLE_SECRET);
      String sftpData = getSecret(profile + Constants.SFTP_SECRET);
      String carWingsData = getSecret(profile + Constants.CAR_WINGS_SECRET);
      String vpmData = getSecret(profile + Constants.VPM_SECRET);
      String samlData = getSecret(profile + Constants.SAML_SECRET);
      String sonyData = getSecret(profile + Constants.SONY_SECRET);
      String mapionURL= getSecret(profile + Constants.MAPION_SECRET);
      String dealerAPIKey = getSecret(profile + Constants.DEALER_API_SECRET);
      String nicosAPIKey = getSecret(profile + Constants.NICOS_SECRET);
      String nicoKeyStore = getSecret(profile + Constants.NICOS_KEYSTORE);
      LOGGER.info("Got the secret values");

      ConfigurableEnvironment environment = event.getApplicationContext().getEnvironment();
      Properties props = new Properties();
      props.put(AWS_ACCESS_KEY, getString(awsSecret, AWS_ACCESS_KEY));
      props.put(AWS_SECRET_KEY, getString(awsSecret, AWS_SECRET_KEY));
      props.put(SPRING_GOOGLE_KEY, getString(googleKey, GOOGLE_KEY));
      props.put(SFTP_KEY_PASS_PHRASE, getString(sftpData, SFTP_KEY_PASS_PHRASE));
      props.put(KEY_STORE_HEADER, getString(samlData, KEY_STORE_HEADER));
      props.put(KEY_STORE_PASSWORD, getString(samlData, KEY_STORE_PASSWORD));
      props.put(CAR_WINGS_PASSWORD, getString(carWingsData, CAR_WINGS_PASSWORD));
      props.put(VPM_PASSWORD, getString(vpmData, VPM_PASSWORD));
      props.put(CAR_WINGS_SECRET_KEY, getString(carWingsData, CAR_WINGS_SECRET_KEY));
      props.put(ASP_USER_PASSWORD, getString(carWingsData, ASP_USER_PASSWORD));
      props.put(SONY_MERCHANT_ID, getString(sonyData, SONY_MERCHANT_ID));
      props.put(SONY_MERCHANT_PASS, getString(sonyData, SONY_MERCHANT_PASS));
      props.put(SONY_KAIIN_PASS, getString(sonyData, SONY_KAIIN_PASS));
      props.put(NISSAN_MAPION_URL, getString(mapionURL, NISSAN_MAPION_URL));
      props.put(DEALER_VISIT_API, getString(dealerAPIKey, DEALER_VISIT_API));
      props.put(DEALER_VISIT_CALLBACK, getString(dealerAPIKey, DEALER_VISIT_CALLBACK));
      props.put(DEALER_VISIT_STATUS, getString(dealerAPIKey, DEALER_VISIT_STATUS));
      props.put(NICOS_HASHCODE_KEY, getString(nicosAPIKey, NICOS_HASHCODE_KEY));
      props.put(NICOS_KEYSTORE_PASS, getString(nicoKeyStore, NICOS_KEYSTORE_PASS));
      /** Get data source url and username from AWS ECS properties */
      props.put(DATA_SOURCE_URL, System.getenv(DATA_SOURCE_URL));
      props.put(DATA_SOURCE_USERNAME, System.getenv(DATA_SOURCE_USERNAME));

      environment
          .getPropertySources()
          .addFirst(new PropertiesPropertySource("aws.secret.manager", props));
    }
  }

  public static String getSecret(String secretName) {
    AWSSecretsManager client = AWSSecretsManagerClientBuilder.standard().withRegion(REGION).build();
    LOGGER.info("built the client {}", secretName);
    String secret = null, decodedBinarySecret = null;
    GetSecretValueRequest getSecretValueRequest =
        new GetSecretValueRequest().withSecretId(secretName);
    GetSecretValueResult getSecretValueResult = null;

    try {
      getSecretValueResult = client.getSecretValue(getSecretValueRequest);
    } catch (DecryptionFailureException
        | InternalServiceErrorException
        | InvalidParameterException
        | InvalidRequestException
        | ResourceNotFoundException e) {
      LOGGER.error("error {}", e);
      throw e;
    } catch (Throwable t) {
      LOGGER.error("generic error {}", t);
      throw t;
    }

    /**
     * Decrypts secret using the associated KMS CMK. Depending on whether the secret is a string or
     * binary, one of these fields will be populated.
     */
    if (getSecretValueResult.getSecretString() != null) {
      secret = getSecretValueResult.getSecretString();
    } else {
      decodedBinarySecret =
          new String(Base64.getDecoder().decode(getSecretValueResult.getSecretBinary()).array());
    }
    return secret != null ? secret : decodedBinarySecret;
  }

  /**
   * Getting binary certificates from the Secrets Manger
   *
   * @param secretName
   * @return ByteBuffer
   */
  public ByteBuffer getCertificate(String secretName) {
    AWSSecretsManager client = AWSSecretsManagerClientBuilder.standard().withRegion(REGION).build();
    ByteBuffer binarySecretData = null;
    GetSecretValueRequest getSecretValueRequest =
        new GetSecretValueRequest().withSecretId(secretName);
    GetSecretValueResult getSecretValueResult = null;
    try {
      getSecretValueResult = client.getSecretValue(getSecretValueRequest);

    } catch (ResourceNotFoundException e) {
      LOGGER.error("The requested secret " + secretName + " was not found {}", e);
    } catch (InvalidRequestException e) {
      LOGGER.error("The request was invalid {}", e);
    } catch (java.security.InvalidParameterException e) {
      LOGGER.error("The request had invalid params: {}", e);
    }

    if (null != getSecretValueResult && null != getSecretValueResult.getSecretBinary()) {
      binarySecretData = getSecretValueResult.getSecretBinary();
    }
    return binarySecretData;
  }

  private String getString(String json, String path) {
    try {
      JsonNode root = mapper.readTree(json);
      return root.path(path).asText();
    } catch (IOException e) {
      return null;
    }
  }
}
