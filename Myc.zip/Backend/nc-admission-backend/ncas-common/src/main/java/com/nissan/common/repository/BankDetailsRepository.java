package com.nissan.common.repository;

import com.nissan.common.entity.BankDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BankDetailsRepository extends JpaRepository<BankDetails, Long> {

  @Query(value = "select * from bank_details where bank_code=?1 LIMIT 1", nativeQuery = true)
  BankDetails findByBankCode(Long bankCode);

  @Query(value = "select * from bank_details where branch_shop_code=?1 LIMIT 1", nativeQuery = true)
  BankDetails findByBranchCode(Long branchCode);
}
