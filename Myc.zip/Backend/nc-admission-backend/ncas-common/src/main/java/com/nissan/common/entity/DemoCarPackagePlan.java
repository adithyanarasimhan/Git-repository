package com.nissan.common.entity;


import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "democar_package_plan")
@EntityListeners(AuditingEntityListener.class)
public class DemoCarPackagePlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "navi_id", referencedColumnName = "id")
    private DemoCarNavi navi;

    @Column(name = "package_plan_name")
    private String packagePlanName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "cw_package_plan_name")
    private String cwPackagePlanName;

    @Column(name = "description")
    private String description;

    @Column(name = "price")
    private Long price;

    @Column(name = "icc_fee")
    private Long iccFee;


    @Column(name = "terms_name")
    private String termsName;

    @Column(name = "lang_code")
    private String langCode;

    @Column(name = "car_plan")
    private String carPlan;

}
