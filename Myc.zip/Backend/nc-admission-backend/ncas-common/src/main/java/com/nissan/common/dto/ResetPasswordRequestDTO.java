package com.nissan.common.dto;

import lombok.Data;

@Data
public class ResetPasswordRequestDTO {
	private String aspUser;
	private String aspPassword;
	private String vin;
	private String cwId;
}
