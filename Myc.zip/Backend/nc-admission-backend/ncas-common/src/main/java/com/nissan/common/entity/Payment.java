package com.nissan.common.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "payment")
@EntityListeners(AuditingEntityListener.class)
public class Payment extends Auditable<String> {

  @Id
  @Column(name = "id")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payment_id_seq")
  @SequenceGenerator(name = "payment_id_seq", sequenceName = "payment_id_seq", allocationSize = 1)
  private Long id;

  @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "customer_id", referencedColumnName = "id")
  private Customer customer;

  @Column(name = "amount")
  private Long amount;

  @Column(name = "card_type")
  private String cardType;

  @Column(name = "credit_id")
  private String creditId;

  @Column(name = "card_name")
  private String cardName;

  @Column(name = "card_brand")
  private Long cardBrand;

  @Column(name = "status")
  private String status;

  @Column(name = "card_number_1")
  private String cardNumber1;

  @Column(name = "card_number_2")
  private String cardNumber2;

  @Column(name = "card_number_3")
  private String cardNumber3;

  @Column(name = "card_number_4")
  private String cardNumber4;

  @Column(name = "expiry_month")
  private Long expiryMonth;

  @Column(name = "expiry_year")
  private Long expiryYear;

  @Column(name = "step_count")
  private Long stepCount;

  @Column(name = "active")
  private Boolean active;

  @Column(name = "lang_code")
  private String langCode;
}
