package com.nissan.common.dto;

import lombok.Data;

@Data
public class ResetPasswordResponseDTO {
	private String responseCd;
	private String errorMessage;
	private String vin;
	private String cwId;
	private String ncId;
	private String ncPw;
}
