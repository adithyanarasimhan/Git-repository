package com.nissan.auth.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.dto.AuthDto;
import com.nissan.common.dto.AuthToken;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.dto.ValidateTokenResponseDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.User;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.util.Constants;
import com.nissan.common.util.JwtTokenUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("api/v1")
public class AuthenticationController {

  private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

  @Autowired DealerRepository dealerRepository;
  @Autowired UserRepository userRepository;

  @Autowired AuthorisationService authorisationService;

  @Autowired JwtTokenUtil jwtTokenUtil;
  @Autowired private UserDetailsService userDetailsService;

  @PostMapping(value = "/token", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> createAuthenticationToken(
      @RequestBody AuthDto authenticationRequest) {

    logger.info("Inside create token api");
    String token = authorisationService.generateTokenOnUser(authenticationRequest.getId());
    if (token == null) {
      return new ResponseEntity<>(
          new ResponseDTO("error", "404", "the user with provided id does not exist in the system")
              .setData(null),
          HttpStatus.NOT_FOUND);
    }

    return new ResponseEntity<>(
        new ResponseDTO("success", "200", "token generated successfully")
            .setData(new AuthToken().setToken(token)),
        HttpStatus.OK);
  }

  @PostMapping(value = "/encodedtoken", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> createEncodedAuthenticationToken(
      @RequestBody AuthDto authenticationRequest) {

    String token = authorisationService.generateTokenOnUser(authenticationRequest.getId());
    String encodedTokenToken = token.substring(token.length() - 8);
    if (token == null) {
      return new ResponseEntity<>(
          new ResponseDTO("error", "404", "the user with provided id does not exist in the system")
              .setData(null),
          HttpStatus.NOT_FOUND);
    }

    return new ResponseEntity<>(
        new ResponseDTO("success", "200", "token generated successfully")
            .setData(new AuthToken().setToken(encodedTokenToken)),
        HttpStatus.OK);
  }

  @GetMapping(value = "/user", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> decodeJWTToken(
      HttpServletRequest httpServletRequest, @RequestParam(name = "token") String requestToken)
      throws JsonProcessingException {
    logger.info("Inside get user details by token");
    try {
      String username = "";
      if (requestToken != null) {
        User user = userRepository.findByEncodedToken(requestToken);
        if (user != null) {
          logger.info("Encoded token is available");
          requestToken = user.getToken();
          logger.info("jwt token : " + requestToken);
          username = user.getUsername();

          /** Home admission token validation */
          if (user.getSource() != null && user.getSource().equals(Constants.ADMISSION_SOURCE_HOME)) {
            logger.info("Token validation for Home Admission : {}", jwtTokenUtil.validateToken(requestToken));
            if (!jwtTokenUtil.validateToken(requestToken)) {
              return new ResponseEntity<>(
                      new ResponseDTO(Constants.FAILED, "401", "JWT Token expired"),
                      HttpStatus.UNAUTHORIZED);
            }
          }
        } else {
          try {
            username = jwtTokenUtil.getUsernameFromToken(requestToken);
          } catch (Exception e) {
            return new ResponseEntity<>(
                new ResponseDTO(Constants.FAILED, "400", e.getMessage()), HttpStatus.BAD_REQUEST);
          }
        }
        logger.info("username : " + username);
        if (username != null) {
          logger.info("username is available");
          UserDetails userDetails = userDetailsService.loadUserByUsername(username);
          logger.info("User details loaded");

          if (user != null || jwtTokenUtil.validateToken(requestToken, userDetails)) {
            user = user == null ? userRepository.findByUsername(username) : user;
            logger.info("Token validated");
            ValidateTokenResponseDTO response = new ValidateTokenResponseDTO();
            response.setUserId(user.getId());
            logger.info("User Id is : " + user.getId());

            logger.info(
                "FPC Simple granted authority : "
                    + new ObjectMapper()
                        .writeValueAsString(new SimpleGrantedAuthority(Constants.ROLE_FPN)));
            logger.info(
                "is dealer role FPC present : "
                    + userDetails
                        .getAuthorities()
                        .contains(new SimpleGrantedAuthority(Constants.ROLE_FPN)));

            if (userDetails.getAuthorities().contains(new SimpleGrantedAuthority(Constants.ROLE_CA))
                || userDetails
                    .getAuthorities()
                    .contains(new SimpleGrantedAuthority(Constants.ROLE_FPN))) {
              DealerEntity dealerEntity = dealerRepository.findByUserId(user.getId());
              if (dealerEntity == null) {
                logger.info("Dealer not found");
                return new ResponseEntity<>(
                    new ResponseDTO(Constants.FAILED, "204", "Dealer not found"),
                    HttpStatus.BAD_REQUEST);
              }
              response.setUserType(Constants.ROLE_CA);
              logger.info("User is a dealer");
            } else if (userDetails
                .getAuthorities()
                .contains(new SimpleGrantedAuthority(Constants.ROLE_CUSTOMER))) {
              response.setUserType(Constants.ROLE_CUSTOMER);
              logger.info("User is a customer");
            }

            return new ResponseEntity<>(
                new ResponseDTO(Constants.SUCCESS, "200", "JWT Token validated successfully")
                    .setData(response),
                HttpStatus.OK);
          }
        }
      }
    } catch (Throwable e) {
      logger.error("Exception in get user details : " + e.getStackTrace());
      logger.info("Exception in get user details : " + e.getMessage());
    }
    logger.info("JWT Token expired");
    return new ResponseEntity<>(
            new ResponseDTO(Constants.FAILED, "401", "JWT Token expired"),
            HttpStatus.UNAUTHORIZED);
  }
}
