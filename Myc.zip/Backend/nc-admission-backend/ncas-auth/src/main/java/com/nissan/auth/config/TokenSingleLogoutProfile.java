package com.nissan.auth.config;

import org.opensaml.common.SAMLException;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.ws.message.encoder.MessageEncodingException;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.websso.SingleLogoutProfile;

public interface TokenSingleLogoutProfile extends SingleLogoutProfile {

  void sendLogoutRequest(SAMLMessageContext context, String userToken)
      throws SAMLException, MetadataProviderException, MessageEncodingException;
}
