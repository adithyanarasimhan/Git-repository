/*
 * Copyright 2019 Vincenzo De Notaris
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nissan.auth.config;

import com.nissan.auth.service.impl.SAMLUserDetailsServiceImpl;
import com.nissan.auth.util.CustomLogoutSuccessHandler;
import com.nissan.common.config.SecretsManager;
import com.nissan.common.repository.UserRepository;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.io.IOUtils;
import org.apache.velocity.app.VelocityEngine;
import org.opensaml.saml2.metadata.provider.HTTPMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.parse.ParserPool;
import org.opensaml.xml.parse.StaticBasicParserPool;
import org.opensaml.xml.security.BasicSecurityConfiguration;
import org.opensaml.xml.signature.SignatureConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLBootstrap;
import org.springframework.security.saml.SAMLEntryPoint;
import org.springframework.security.saml.SAMLLogoutFilter;
import org.springframework.security.saml.context.SAMLContextProviderLB;
import org.springframework.security.saml.key.JKSKeyManager;
import org.springframework.security.saml.key.KeyManager;
import org.springframework.security.saml.log.SAMLDefaultLogger;
import org.springframework.security.saml.metadata.*;
import org.springframework.security.saml.parser.ParserPoolHolder;
import org.springframework.security.saml.processor.*;
import org.springframework.security.saml.trust.httpclient.TLSProtocolConfigurer;
import org.springframework.security.saml.util.VelocityFactory;
import org.springframework.security.saml.websso.*;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.KeyStore;
import java.util.*;

@Configuration
@EnableWebSecurity
@Order(1)
@EnableGlobalMethodSecurity(securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter
    implements InitializingBean, DisposableBean {

  private static final Logger LOGGER = LoggerFactory.getLogger(WebSecurityConfig.class);

  private Timer backgroundTaskTimer;

  private MultiThreadedHttpConnectionManager multiThreadedHttpConnectionManager;

  @Autowired private SAMLUserDetailsServiceImpl samlUserDetailsServiceImpl;

  @Autowired private UserRepository userRepository;
  @Autowired private BCryptPasswordEncoder bcryptEncoder;

  @Resource(name = "userService")
  private UserDetailsService userDetailsService;

  @Value("${idpKeycloakMetadataURL}")
  private String idpKeycloakMetadataURL;

  @Value("${entityBasedURL}")
  private String entityBasedURL;

  @Value("${entityId}")
  private String entityId;

  @Value("${key.store.saml}")
  private String samlKeystore;

  @Value("${keyStoreHeader}")
  private String keyStoreHeader;

  @Value("${keyStorePassWord}")
  private String keyStorePassWord;

  @Value("${serverName}")
  private String serverName;

  @Value("${samlWebSSOUrl}")
  private String samlWebSSOUrl;

  @Value("${logOutRedirect}")
  private String logOutRedirect;

  /**
   * Initialization of the velocity engine
   *
   * @return
   */
  @Bean
  public VelocityEngine velocityEngine() {
    return VelocityFactory.getEngine();
  }

  /**
   * XML parser pool needed for OpenSAML parsing
   *
   * @return
   */
  @Bean(initMethod = "initialize")
  public StaticBasicParserPool parserPool() {
    return new StaticBasicParserPool();
  }

  @Bean(name = "parserPoolHolder")
  public ParserPoolHolder parserPoolHolder() {
    return new ParserPoolHolder();
  }

  private List<String> allowedMethods =
      new ArrayList<String>() {
        {
          add(HttpMethod.GET.name());
          add(HttpMethod.POST.name());
          add(HttpMethod.PUT.name());
          add(HttpMethod.PATCH.name());
          add(HttpMethod.DELETE.name());
        }
      };

  /**
   * Bindings, encoders and decoders used for creating and parsing messages
   *
   * @return
   */
  @Bean
  public HttpClient httpClient() {
    return new HttpClient(this.multiThreadedHttpConnectionManager);
  }

  /**
   * SAML Authentication Provider responsible for validating of received SAML messages
   *
   * @return
   */
  @Bean
  public SAMLAuthenticationProvider samlAuthenticationProvider() {
    SAMLAuthenticationProvider samlAuthenticationProvider = new SAMLAuthenticationProvider();
    samlAuthenticationProvider.setUserDetails(samlUserDetailsServiceImpl);
    samlAuthenticationProvider.setForcePrincipalAsString(false);
    return samlAuthenticationProvider;
  }

  /**
   * Provider of default SAML Context
   *
   * @return
   */
  @Bean
  public SAMLContextProviderLB contextProvider() {
    SAMLContextProviderLB samlContextProviderLB = new SAMLContextProviderLB();
    samlContextProviderLB.setScheme("https");
    samlContextProviderLB.setServerName(serverName);
    samlContextProviderLB.setContextPath("/");
    return samlContextProviderLB;
  }

  /**
   * Initialization of OpenSAML library
   *
   * @return
   */
  @Bean
  public static SAMLBootstrap sAMLBootstrap() {
    return new SAMLBootstrap() {
      @Override
      public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
          throws BeansException {
        super.postProcessBeanFactory(beanFactory);

        BasicSecurityConfiguration config =
            (BasicSecurityConfiguration)
                org.opensaml.Configuration.getGlobalSecurityConfiguration();
        config.registerSignatureAlgorithmURI(
            "RSA", SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
        config.setSignatureReferenceDigestMethod(SignatureConstants.ALGO_ID_DIGEST_SHA256);
      }
    };
  }

  /**
   * Logger for SAML messages and events
   *
   * @return
   */
  @Bean
  public SAMLDefaultLogger samlLogger() {
    return new SAMLDefaultLogger();
  }

  /**
   * SAML 2.0 WebSSO Assertion Consumer
   *
   * @return
   */
  @Bean
  public WebSSOProfileConsumer webSSOprofileConsumer() {
    return new WebSSOProfileConsumerImpl();
  }

  /**
   * SAML 2.0 Holder-of-Key WebSSO Assertion Consumer
   *
   * @return
   */
  @Bean
  public WebSSOProfileConsumerHoKImpl hokWebSSOprofileConsumer() {
    return new WebSSOProfileConsumerHoKImpl();
  }

  /**
   * SAML 2.0 Web SSO profile
   *
   * @return
   */
  @Bean
  public WebSSOProfile webSSOprofile() {
    return new WebSSOProfileImpl();
  }

  /**
   * SAML 2.0 Holder-of-Key Web SSO profile
   *
   * @return
   */
  @Bean
  public WebSSOProfileConsumerHoKImpl hokWebSSOProfile() {
    return new WebSSOProfileConsumerHoKImpl();
  }

  /**
   * SAML 2.0 ECP profile
   *
   * @return
   */
  @Bean
  public WebSSOProfileECPImpl ecpprofile() {
    return new WebSSOProfileECPImpl();
  }

  @Bean
  public SingleLogoutProfile logoutprofile() {
    return new SingleLogoutProfileImpl();
  }

  @Bean
  public KeyManager keyManager() {
    SecretsManager secretsManager = new SecretsManager();
    ByteBuffer byteBuffer = secretsManager.getCertificate(samlKeystore);
    InputStream inputStream = new ByteArrayInputStream(byteBuffer.array());
    KeyStore keyStore = null;
    try {
      keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(inputStream, keyStorePassWord.toCharArray());
    } catch (Exception e) {
      LOGGER.error("Exception while loading saml Keystore {}", e.getMessage());
      e.printStackTrace();
    } finally {
      IOUtils.closeQuietly(inputStream);
    }
    Map<String, String> passwords = new HashMap<String, String>();
    passwords.put(keyStoreHeader, keyStorePassWord);
    return new JKSKeyManager(keyStore, passwords, keyStoreHeader);
  }

  /**
   * Setup TLS Socket Factory
   *
   * @return
   */
  @Bean
  public TLSProtocolConfigurer tlsProtocolConfigurer() {
    return new TLSProtocolConfigurer();
  }

  @Bean
  public WebSSOProfileOptions defaultWebSSOProfileOptions() {
    WebSSOProfileOptions webSSOProfileOptions = new WebSSOProfileOptions();
    webSSOProfileOptions.setIncludeScoping(false);
    webSSOProfileOptions.setNameID("urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified");
    return webSSOProfileOptions;
  }

  /**
   * Entry point to initialize authentication, default values taken from properties file
   *
   * @return
   */
  @Bean
  public SAMLEntryPoint samlEntryPoint() {
    SAMLEntryPoint samlEntryPoint = new SAMLEntryPoint();
    samlEntryPoint.setDefaultProfileOptions(defaultWebSSOProfileOptions());
    return samlEntryPoint;
  }

  /**
   * Setup advanced info about metadata
   *
   * @return
   */
  @Bean
  public ExtendedMetadata extendedMetadata() {
    ExtendedMetadata extendedMetadata = new ExtendedMetadata();
    extendedMetadata.setIdpDiscoveryEnabled(false);
    extendedMetadata.setSignMetadata(false);
    extendedMetadata.setEcpEnabled(true);
    return extendedMetadata;
  }

  @Bean
  @Qualifier("idp-keycloak")
  public ExtendedMetadataDelegate keycloakExtendedMetadataProvider()
      throws MetadataProviderException {
    HTTPMetadataProvider httpMetadataProvider =
        new HTTPMetadataProvider(this.backgroundTaskTimer, httpClient(), idpKeycloakMetadataURL);
    httpMetadataProvider.setParserPool(parserPool());
    ExtendedMetadataDelegate extendedMetadataDelegate =
        new ExtendedMetadataDelegate(httpMetadataProvider, extendedMetadata());
    extendedMetadataDelegate.setMetadataTrustCheck(false);
    extendedMetadataDelegate.setMetadataRequireSignature(false);
    backgroundTaskTimer.purge();
    return extendedMetadataDelegate;
  }

  /**
   * IDP Metadata configuration - paths to metadata of IDPs in circle of trust Do no forget to call
   * iniitalize method on providers
   *
   * @param providers
   * @return
   * @throws MetadataProviderException
   */
  @Bean
  @Qualifier("metadata")
  public CachingMetadataManager metadata(List<MetadataProvider> providers)
      throws MetadataProviderException {
    return new CachingMetadataManager(providers);
  }

  /**
   * Filter automatically generates default SP metadata
   *
   * @return
   */
  @Bean
  public MetadataGenerator metadataGenerator() {
    MetadataGenerator metadataGenerator = new MetadataGenerator();
    metadataGenerator.setEntityId(entityId);
    metadataGenerator.setEntityBaseURL(entityBasedURL);
    metadataGenerator.setExtendedMetadata(extendedMetadata());
    metadataGenerator.setIncludeDiscoveryExtension(false);
    metadataGenerator.setKeyManager(keyManager());
    return metadataGenerator;
  }

  /**
   * The filter is waiting for connections on URL suffixed with filter Suffix and presents SP
   * metadata there
   *
   * @return
   */
  @Bean
  public MetadataDisplayFilter metadataDisplayFilter() {
    return new MetadataDisplayFilter();
  }

  /**
   * Handler deciding where to redirect user after failed login
   *
   * @return
   */
  @Bean
  public SimpleUrlAuthenticationFailureHandler authenticationFailureHandler() {
    SimpleUrlAuthenticationFailureHandler failureHandler =
        new SimpleUrlAuthenticationFailureHandler();
    failureHandler.setUseForward(true);
    failureHandler.setDefaultFailureUrl("/error");
    return failureHandler;
  }

  /**
   * Processing filter for WebSSO profile messages
   *
   * @return
   * @throws Exception
   */
  @Bean
  public CustomSAMLProcessingFilter samlWebSSOProcessingFilter() throws Exception {
    CustomSAMLProcessingFilter samlWebSSOProcessingFilter = new CustomSAMLProcessingFilter();
    samlWebSSOProcessingFilter.setAuthenticationManager(authenticationManager());
    samlWebSSOProcessingFilter.setAuthenticationSuccessHandler(
        new AuthenticationSuccessHandler() {
          @Override
          public void onAuthenticationSuccess(
              HttpServletRequest request,
              HttpServletResponse response,
              Authentication authentication)
              throws IOException, ServletException {
            String jwtToken = response.getHeader("Authorization");
            String url = response.getHeader("url");
            if (url == null) {
              response.sendRedirect(samlWebSSOUrl + jwtToken);
            } else {
              response.sendRedirect(url);
            }
          }
        });
    samlWebSSOProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
    return samlWebSSOProcessingFilter;
  }

  @Bean
  public MetadataGeneratorFilter metadataGeneratorFilter() {
    return new MetadataGeneratorFilter(metadataGenerator());
  }

  /**
   * Handler for successful logout
   *
   * @return
   */
  @Bean
  public LogoutSuccessHandler successLogoutHandler() {
    return new CustomLogoutSuccessHandler();
  }

  /**
   * Logout handler terminating local session
   *
   * @return
   */
  @Bean
  public SecurityContextLogoutHandler logoutHandler() {
    SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
    logoutHandler.setInvalidateHttpSession(true);
    logoutHandler.setClearAuthentication(true);
    return logoutHandler;
  }

  /**
   * Bindings
   *
   * @return
   */
  private ArtifactResolutionProfile artifactResolutionProfile() {
    final ArtifactResolutionProfileImpl artifactResolutionProfile =
        new ArtifactResolutionProfileImpl(httpClient());
    artifactResolutionProfile.setProcessor(new SAMLProcessorImpl(soapBinding()));
    return artifactResolutionProfile;
  }

  @Bean
  public HTTPArtifactBinding artifactBinding(ParserPool parserPool, VelocityEngine velocityEngine) {
    return new HTTPArtifactBinding(parserPool, velocityEngine, artifactResolutionProfile());
  }

  @Bean
  public HTTPSOAP11Binding soapBinding() {
    return new HTTPSOAP11Binding(parserPool());
  }

  @Bean
  public HTTPPostBinding httpPostBinding() {
    return new HTTPPostBinding(parserPool(), velocityEngine());
  }

  @Bean
  public HTTPRedirectDeflateBinding httpRedirectDeflateBinding() {
    return new HTTPRedirectDeflateBinding(parserPool());
  }

  @Bean
  public HTTPSOAP11Binding httpSOAP11Binding() {
    return new HTTPSOAP11Binding(parserPool());
  }

  @Bean
  public HTTPPAOS11Binding httpPAOS11Binding() {
    return new HTTPPAOS11Binding(parserPool());
  }

  /**
   * SAMLProcessorImpl
   *
   * @return
   */
  @Bean
  public SAMLProcessorImpl processor() {
    Collection<SAMLBinding> bindings = new ArrayList<SAMLBinding>();
    bindings.add(httpRedirectDeflateBinding());
    bindings.add(httpPostBinding());
    bindings.add(artifactBinding(parserPool(), velocityEngine()));
    bindings.add(httpSOAP11Binding());
    bindings.add(httpPAOS11Binding());
    return new SAMLProcessorImpl(bindings);
  }

  public CustomSAMLLogoutProfile logoutProfile() {
    CustomSAMLLogoutProfile logoutProfile = new CustomSAMLLogoutProfile();
    logoutProfile.setIdpKeycloakMetadataURL(this.idpKeycloakMetadataURL);
    logoutProfile.setEntityId(this.entityId);
    logoutProfile.setUserRepository(this.userRepository);
    logoutProfile.setProcessor(processor());
    return logoutProfile;
  }

  /**
   * Filter processing incoming logout messages First argument determines URL user will be
   * redirected to after successful global logout
   *
   * @return
   */
  @Bean
  public LogoutFilter samlLogoutProcessingFilter() {
    CustomSAMLLogoutProcessingFilter samlLogoutProcessingFilter =
        new CustomSAMLLogoutProcessingFilter(successLogoutHandler(), logoutHandler());
    samlLogoutProcessingFilter.setProcessor(processor());
    samlLogoutProcessingFilter.setContextProvider(contextProvider());
    samlLogoutProcessingFilter.setSamlLogger(samlLogger());
    samlLogoutProcessingFilter.setProfile(logoutProfile());
    return samlLogoutProcessingFilter;
  }

  /**
   * Overrides default logout processing filter with the one processing SAML messages
   *
   * @return
   */
  @Bean
  public SAMLLogoutFilter samlLogoutFilter() {
    CustomSAMLLogoutFilter customSAMLLogoutFilter =
        new CustomSAMLLogoutFilter(
            successLogoutHandler(),
            new LogoutHandler[] {logoutHandler()},
            new LogoutHandler[] {logoutHandler()});
    customSAMLLogoutFilter.setProfile(logoutProfile());
    customSAMLLogoutFilter.setApiHomePageURL(this.logOutRedirect);
    return customSAMLLogoutFilter;
  }

  /**
   * Define the security filter chain in order to support SSO Auth by using SAML 2.0
   *
   * @return Filter chain proxy
   * @throws Exception
   */
  @Bean
  public FilterChainProxy samlFilter() throws Exception {
    List<SecurityFilterChain> chains = new ArrayList<SecurityFilterChain>();
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml2/login/**"), samlEntryPoint()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml2/logout/**"), samlLogoutFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml2/metadata/**"), metadataDisplayFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml2/SSO/**"), samlWebSSOProcessingFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml2/SingleLogout/**"), samlLogoutProcessingFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml/login/**"), samlEntryPoint()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml/logout/**"), samlLogoutFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml/metadata/**"), metadataDisplayFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml/SSO/**"), samlWebSSOProcessingFilter()));
    chains.add(
        new DefaultSecurityFilterChain(
            new AntPathRequestMatcher("/saml/SingleLogout/**"), samlLogoutProcessingFilter()));
    return new FilterChainProxy(chains);
  }

  /**
   * Returns the authentication manager currently used by Spring. It represents a bean definition
   * with the aim allow wiring from other classes performing the Inversion of Control (IoC).
   *
   * @throws Exception
   */
  @Bean
  @Override
  public AuthenticationManager authenticationManagerBean() throws Exception {
    return super.authenticationManagerBean();
  }

  /**
   * configure AuthenticationManager so that it knows from where to load
   *
   * @param auth
   */
  @Autowired
  public void configureGlobal(AuthenticationManagerBuilder auth) {}

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Autowired
  public void globalUserDetails(AuthenticationManagerBuilder auth) throws Exception {
    auth.userDetailsService(userDetailsService).passwordEncoder(bcryptEncoder);
  }

  /**
   * Defines the web based security configuration.
   *
   * @param http It allows configuring web based security for specific http requests.
   * @throws Exception
   */
  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.httpBasic().authenticationEntryPoint(samlEntryPoint());
    http.addFilterBefore(metadataGeneratorFilter(), ChannelProcessingFilter.class)
        .addFilterAfter(samlFilter(), BasicAuthenticationFilter.class)
        .addFilterBefore(samlFilter(), CsrfFilter.class);
    RequestHeaderRequestMatcher principalIdHeaderMatcher =
        new RequestHeaderRequestMatcher("principalId");
    http.authorizeRequests().requestMatchers(principalIdHeaderMatcher).permitAll();
    http.csrf()
        .disable()
        .authorizeRequests()
        .antMatchers("/saml2/**", "/saml/**")
        .permitAll()
        .antMatchers("/css/**")
        .permitAll()
        .antMatchers("/img/**")
        .permitAll()
        .antMatchers("/js/**")
        .permitAll()
        .antMatchers(HttpMethod.POST, "/api/v1/token", "/api/v1/encodedtoken", "/api/v1/dealers")
        .permitAll()
        .antMatchers(
            HttpMethod.GET, "/api/v1/user", "/api/v1/ping", "/api/v1/gdlogin", "/api/v1/logout")
        .permitAll()
        .antMatchers(HttpMethod.GET, "/actuator/health")
        .permitAll()
        .antMatchers(HttpMethod.GET, "/swagger**", "/swagger-resources/**", "/configuration")
        .permitAll()
        .anyRequest()
        .authenticated();
    http.logout().disable();
  }

  /**
   * Sets a custom authentication provider.
   *
   * @param auth SecurityBuilder used to create an AuthenticationManager.
   * @throws Exception
   */
  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.authenticationProvider(samlAuthenticationProvider());
  }

  public void init() {
    this.backgroundTaskTimer = new Timer(true);
    this.multiThreadedHttpConnectionManager = new MultiThreadedHttpConnectionManager();
  }

  public void shutdown() {
    this.backgroundTaskTimer.purge();
    this.backgroundTaskTimer.cancel();
    this.multiThreadedHttpConnectionManager.shutdown();
  }

  @Override
  public void afterPropertiesSet() throws Exception {
    init();
  }

  @Override
  public void destroy() throws Exception {
    shutdown();
  }
}
