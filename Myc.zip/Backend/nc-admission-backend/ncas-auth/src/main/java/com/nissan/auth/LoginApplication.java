package com.nissan.auth;

import com.nissan.common.audit.SpringSecurityAuditorAware;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = {"com.nissan.auth","com.nissan.common"})
@EnableJpaRepositories(basePackages={"com.nissan.common.repository","com.nissan.auth.repository"})
@EntityScan(basePackages = {"com.nissan.common.entity","com.nissan.auth.entity"})
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@EnableScheduling
public class LoginApplication {

  @Bean
  public AuditorAware<String> auditorAware() {
    return new SpringSecurityAuditorAware();
  }

  public static void main(String[] args) {
    SpringApplication.run(LoginApplication.class, args);
  }
}
