package com.nissan.auth.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.entity.User;
import com.nissan.common.repository.RoleRepository;
import com.nissan.common.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService {

  private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

  public static final String DEALER = "dealer";
  @Autowired private UserRepository userRepository;

  @Autowired private RoleRepository roleRepository;
  @Autowired private BCryptPasswordEncoder bcryptEncoder;

  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    logger.info("Inside load user by user name");
    User user = userRepository.findByUsername(username);
    logger.info("is user present : " + (user != null));
    if (user == null) {
      throw new UsernameNotFoundException("Invalid username or password.");
    }
    logger.info("userName : " + user.getUsername());
    logger.info("password : " + user.getPassword());
    return new org.springframework.security.core.userdetails.User(
        user.getUsername(), user.getPassword(), getAuthority(user));
  }

  private Set<SimpleGrantedAuthority> getAuthority(User user) {
    Set<SimpleGrantedAuthority> authorities = new HashSet<>();
    user.getRoles()
        .forEach(
            role -> {
              // authorities.add(new SimpleGrantedAuthority(role.getName()));
              authorities.add(new SimpleGrantedAuthority(role.getName()));
            });
    try {
      logger.info("authorities : " + (new ObjectMapper().writeValueAsString(authorities)));
    } catch (JsonProcessingException e) {
      logger.info("Couldn't print authorities value");
    }
    return authorities;
    // return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
  }
}
