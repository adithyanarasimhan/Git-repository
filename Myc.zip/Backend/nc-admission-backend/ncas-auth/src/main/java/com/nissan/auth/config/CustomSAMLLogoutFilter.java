package com.nissan.auth.config;

import com.nissan.common.util.JwtTokenUtil;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.ws.message.encoder.MessageEncodingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.saml.SAMLConstants;
import org.springframework.security.saml.SAMLLogoutFilter;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.util.Assert;
import org.springframework.web.bind.ServletRequestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomSAMLLogoutFilter extends SAMLLogoutFilter {

  protected TokenSingleLogoutProfile tokenBasedProfile;

  private String apiHomePageURL;

  private String getLogoutRedirectHtml() {
    return "<html><head><script type=\"text/javascript\">window.onload=function(){document.forms[\"myform\"].submit();}"
        + "</script></head><body><form id=\"myform\" action=\""
        + getApiHomePageURL()
        + "\" method=\"get\"></form></body></html>";
  }

  @Autowired JwtTokenUtil jwtTokenUtil;

  public CustomSAMLLogoutFilter(
      LogoutSuccessHandler logoutSuccessHandler,
      LogoutHandler[] localHandler,
      LogoutHandler[] globalHandlers) {
    super(logoutSuccessHandler, localHandler, globalHandlers);
  }

  @Override
  public void processLogout(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws IOException, ServletException {

    if (requiresLogout(request, response)) {
      try {
        String userToken = ServletRequestUtils.getStringParameter(request, "token", "");

        if (userToken.equals(null)
            || userToken.equals("")
            || userToken.equals("null")
            || jwtTokenUtil.isTokenExpired(userToken)) {
          response.setStatus(HttpStatus.OK.value());
          response.getWriter().write(getLogoutRedirectHtml());
          response.getWriter().flush();
        } else if (!userToken.equals(null) && !userToken.equals("") && isGlobalLogout(request)) {
          logger.info("IS a global logout");
          SAMLMessageContext context = contextProvider.getLocalAndPeerEntity(request, response);
          logger.info("Going to send logout request to GD");
          tokenBasedProfile.sendLogoutRequest(context, userToken);
          logger.info("Finished sending logout request to GD");
          samlLogger.log(SAMLConstants.LOGOUT_REQUEST, SAMLConstants.SUCCESS, context);
        } else {
          super.doFilter(request, response, chain);
        }

      } catch (SAMLException e) {
        logger.error("Error initializing global logout", e);
        throw new ServletException("Error initializing global logout", e);
      } catch (MetadataProviderException e) {
        logger.error("Error processing metadata", e);
        throw new ServletException("Error processing metadata", e);
      } catch (MessageEncodingException e) {
        logger.error("Error encoding outgoing message", e);
        throw new ServletException("Error encoding outgoing message", e);
      }

    } else {

      chain.doFilter(request, response);
    }
  }

  protected boolean isGlobalLogout(HttpServletRequest request) {
    String localLogout = request.getParameter(LOGOUT_PARAMETER);
    return (localLogout == null || !"true".equals(localLogout.toLowerCase().trim()));
  }

  public void setProfile(TokenSingleLogoutProfile tokenBasedProfile) {
    Assert.notNull(tokenBasedProfile, "TokenBasedProfile can't be null");
    this.tokenBasedProfile = tokenBasedProfile;
  }

  public String getApiHomePageURL() {
    return apiHomePageURL;
  }

  public void setApiHomePageURL(String apiHomePageURL) {
    this.apiHomePageURL = apiHomePageURL;
  }
}
