package com.nissan.auth.config;

import com.amazonaws.util.StringUtils;
import com.nimbusds.jose.JOSEException;
import com.nissan.common.entity.TempoDotNet;
import com.nissan.common.repository.TempoDotNetRepository;
import com.nissan.common.dto.DealerDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.Role;
import com.nissan.common.entity.User;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.RoleRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.util.Constants;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.SneakyThrows;
import org.opensaml.Configuration;
import org.opensaml.saml2.core.*;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.saml.SAMLAuthenticationToken;
import org.springframework.security.saml.SAMLProcessingFilter;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.*;

public class CustomSAMLProcessingFilter extends SAMLProcessingFilter {

    private static final Logger logger = LoggerFactory.getLogger(CustomSAMLProcessingFilter.class);

    public static final String BUSINESS = "Business";
    public static final String KAMEARI = "Kameari";
    public static final String CA = "CA";
    public static final String FPC = "FPC";
    public static final String RoleID = "RoleID";
    public static final String CN = "CN";

    public static final String JNCS01 = "JNCS01";
    public static final String IB4 = "IB4";
    public static final String JF0 = "JF0";

    private String jwtToken;

    @Value("${logOutRedirect}")
    private String logOutRedirect;

    @Autowired
    AuthorisationService authorisationService;
    @Autowired
    DealerRepository dealerRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    TempoDotNetRepository tempoDotNetRepository;

    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;

    @SneakyThrows
    @Override
    public Authentication attemptAuthentication(
            HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            try {
                String samlResponse = request.getParameter("SAMLResponse");
                byte[] base64DecodedResponse = Base64.getDecoder().decode(samlResponse);
                ByteArrayInputStream is = new ByteArrayInputStream(base64DecodedResponse);
                DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
                documentBuilderFactory.setNamespaceAware(true);
                DocumentBuilder docBuilder = documentBuilderFactory.newDocumentBuilder();

                Document document = docBuilder.parse(is);
                Element element = document.getDocumentElement();
                UnmarshallerFactory unmarshallerFactory = Configuration.getUnmarshallerFactory();
                Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(element);
                XMLObject responseXmlObj = unmarshaller.unmarshall(element);
                Response response1 = (Response) responseXmlObj;
                Assertion assertion = response1.getAssertions().get(0);
                final List<AuthnStatement> authnStatements = assertion.getAuthnStatements();
                String sessionIndex = null;
                if (!CollectionUtils.isEmpty(authnStatements)) {
                    final AuthnStatement authnStatement = authnStatements.get(0);
                    sessionIndex = authnStatement.getSessionIndex();
                }
                List<AttributeStatement> attributeStatements = assertion.getAttributeStatements();
                Map<String, String> results = new HashMap<String, String>();
                List<String> roleList = new ArrayList();
                logger.info("entering into saml attributes");
                attributeStatements.forEach(
                        a -> {
                            List<Attribute> attributes = a.getAttributes();
                            attributes.forEach(
                                    att -> {
                                        att.getAttributeValues()
                                                .forEach(
                                                        v -> {
                                                            if (att.getName().equals(RoleID)) {
                                                                Map<String, String> roleMap =
                                                                        splitToMap(v.getDOM().getTextContent());
                                                                roleList.add(roleMap.get(CN));
                                                                results.put(att.getName(), roleMap.get(CN));
                                                            } else {
                                                                results.put(att.getName(), v.getDOM().getTextContent());
                                                            }
                                                        });
                                    });
                        });
                String roleName = results.get("nissanLocalOuCode");
                logger.info("GD Role name {}", roleName);
                logger.info("GD Role list size {}", roleList.size());
                roleList.forEach(role -> logger.info("Value of Role {}", role));
                String roleId = results.get("RoleID");
                if (!StringUtils.isNullOrEmpty(roleId) && roleList.contains(JNCS01)) {
                    roleName = Constants.ROLE_KAMEARI;
                } else if (!StringUtils.isNullOrEmpty(roleName) && (Constants.FPC.equals(roleName) || Constants.FPN.equals(roleName))) {
                    roleName = Constants.ROLE_FPN;
                } else if (!StringUtils.isNullOrEmpty(roleName) && IB4.equals(roleName)) {
                    roleName = Constants.ROLE_BUSINESS;
                } else if (!StringUtils.isNullOrEmpty(roleName) && JF0.equals(roleName)) {
                    roleName = Constants.ROLE_FPN;
                } else {
                    roleName = Constants.ROLE_CA;
                }
                String caCode = results.get("userID");
                String companyCode = results.get("nissanCompanyCode").substring(3);
                String mobilNumber = results.get("telephoneNumber");
                String mailAddress = results.get("mailAddress");
                String caName = results.get("nissanLocalSn") + results.get("nissanLocalGivenName");
                String caNameKana = results.get("nissanJpYomiSn") + results.get("nissanJpYomiGivenName");
                String dealerShipName = results.get("nissanLocalOu");
                String dealerShipCode = results.get("nissanLocalOuCode");
                User user = userRepository.findByUsername(caCode);
                if (user == null) {
                    user = createUser(roleName, caCode);
                }
                logger.info("user name is : {}", user.getUsername());
                DealerEntity dealer = dealerRepository.findByDealerId(caCode);
                TempoDotNet tempoDotNet = tempoDotNetRepository.findByCaCompanyCode(companyCode);
                DealerDTO dealerDTO = new DealerDTO();
                dealerDTO.setUserId(user.getId());
                if (roleName != null && Constants.ROLE_FPN.equals(roleName)) {
                    logger.info("FPN or FPC user");
                    dealerDTO.setCompanyCode(companyCode);
                    dealerDTO.setDealerType(JF0);
                } else if (roleName != null && Constants.ROLE_KAMEARI.equals(roleName)) {
                    logger.info("Kameari user");
                    dealerDTO.setCompanyCode(companyCode);
                    dealerDTO.setDealerType(KAMEARI);
                } else if (roleName != null && Constants.ROLE_BUSINESS.equals(roleName)) {
                    logger.info("IB4 user");
                    dealerDTO.setCompanyCode(companyCode);
                    dealerDTO.setDealerType(IB4);
                } else if (tempoDotNet != null) {
                    dealerDTO.setCompanyCode(tempoDotNet.getProfitCaCompanyCode());
                    dealerDTO.setCompanyName(tempoDotNet.getCaCompanyName());
                    dealerDTO.setProfitCaCompanyCode(tempoDotNet.getProfitCaCompanyCode());
                    dealerDTO.setDealerType(CA);
                } else {
                    String jwtToken = authorisationService.generateTokenOnUser(user.getId());
                    user.setToken(jwtToken);
                    user.setIsValidToken(true);
                    user.setSamlSessionIndex(sessionIndex);
                    userRepository.save(user);
                    response.setHeader("url", (this.logOutRedirect + "api/v1/logout?token=" + jwtToken));
                    return returnAuthenticationToken(request, response);
                }
                dealerDTO.setDealershipName(dealerShipName);
                dealerDTO.setDealerShipCode(dealerShipCode);
                dealerDTO.setCaCode(caCode);
                dealerDTO.setCaName(caName);
                dealerDTO.setCaNameKana(caNameKana);
                dealerDTO.setPhoneNumber(mobilNumber);
                dealerDTO.setDealerId(caCode);
                dealerDTO.setEmail(mailAddress);
                logger.info("dealer dto is : {}", dealerDTO.getDealershipName());
                if (dealer == null) {
                    dealer = createDealer(dealerDTO);
                } else {
                    dealer = updateDealer(dealerDTO, dealer);
                }
                String jwtToken = authorisationService.generateTokenOnUser(dealer.getUserId());
                user.setToken(jwtToken);
                user.setIsValidToken(true);
                user.setSamlSessionIndex(sessionIndex);
                userRepository.save(user);
                response.setHeader("Authorization", jwtToken);
                String decryptedSamlResponse =
                        new String(Base64.getDecoder().decode(samlResponse), StandardCharsets.UTF_8);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return returnAuthenticationToken(request, response);
    }

    private Authentication returnAuthenticationToken(
            HttpServletRequest request, HttpServletResponse response) {
        try {
            SAMLMessageContext context = contextProvider.getLocalEntity(request, response);
            SAMLAuthenticationToken token = new SAMLAuthenticationToken(context);
            return token;
        } catch (MetadataProviderException me) {
            me.printStackTrace();
            return null;
        }
    }

    public DealerEntity createDealer(DealerDTO dealerDTO) {
        logger.info("entering into create dealer");
        DealerEntity dealerEntity = new DealerEntity();
        dealerEntity.setUserId(dealerDTO.getUserId());
        dealerEntity.setCompanyName(dealerDTO.getCompanyName());
        dealerEntity.setCompanyCode(dealerDTO.getCompanyCode());
        dealerEntity.setDealerId(dealerDTO.getDealerId());
        dealerEntity.setDealerType(dealerDTO.getDealerType());
        dealerEntity.setProfitCaCompanyCode(dealerDTO.getProfitCaCompanyCode());
        dealerEntity.setEmail(dealerDTO.getEmail());
        dealerEntity.setPhoneNumber(dealerDTO.getPhoneNumber());
        dealerEntity.setCaCode(dealerDTO.getCaCode());
        dealerEntity.setCaName(dealerDTO.getCaName());
        dealerEntity.setCaNameKana(dealerDTO.getCaNameKana());
        dealerEntity.setDealershipName(dealerDTO.getDealershipName());
        dealerEntity.setDealerShipCode(dealerDTO.getDealerShipCode());
        dealerEntity = dealerRepository.save(dealerEntity);
        logger.info("dealerShipName  dealerEntity : {}", dealerEntity.getDealershipName());
        return dealerEntity;
    }

    public User createUser(String roleName, String dealerId) {
        User user;
        user = new User();
        user.setUsername(dealerId);
        user.setIsValidToken(true);
        user.setPassword(bcryptEncoder.encode(dealerId));
        user = userRepository.save(user);
        logger.info("User id {} created for dealer {}", user.getId(), dealerId);
        Set<Role> roleSet = new HashSet<>();
        Role role = roleRepository.findRoleByName(roleName);
        logger.info("Role name : {} for GD role : {}", roleName, role);
        roleSet.add(role);
        user.setRoles(roleSet);
        user = userRepository.save(user);
        return user;
    }

    public String getJwtToken() {
        return jwtToken;
    }

    public String createJWT(String id, String issuer, String subject, long ttlMillis)
            throws JOSEException {
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        final String JWT_SECRET = "yeWAgVDfb$!MFn@MCJVN7uqkznHbDLR#";
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);

        // We will sign our JWT with our ApiKey secret
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(JWT_SECRET);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

        // Let's set the JWT Claims
        JwtBuilder builder =
                Jwts.builder()
                        .setId(id)
                        .setIssuedAt(now)
                        .setSubject(subject)
                        .setIssuer(issuer)
                        .signWith(signatureAlgorithm, signingKey);

        // if it has been specified, let's add the expiration
        if (ttlMillis >= 0) {
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }

        // Builds the JWT and serializes it to a compact, URL-safe string
        return builder.compact();
    }

    private DealerEntity updateDealer(DealerDTO dealerDTO, DealerEntity dealerEntity) {
        logger.info("entering into update dealer");
        dealerEntity.setUserId(dealerDTO.getUserId());
        dealerEntity.setCompanyName(dealerDTO.getCompanyName());
        dealerEntity.setCompanyCode(dealerDTO.getCompanyCode());
        dealerEntity.setDealerId(dealerDTO.getDealerId());
        dealerEntity.setDealerType(dealerDTO.getDealerType());
        dealerEntity.setProfitCaCompanyCode(dealerDTO.getProfitCaCompanyCode());
        dealerEntity.setEmail(dealerDTO.getEmail());
        dealerEntity.setPhoneNumber(dealerDTO.getPhoneNumber());
        dealerEntity.setCaCode(dealerDTO.getCaCode());
        dealerEntity.setCaName(dealerDTO.getCaName());
        dealerEntity.setCaNameKana(dealerDTO.getCaNameKana());
        dealerEntity.setDealershipName(dealerDTO.getDealershipName());
        dealerEntity.setDealerShipCode(dealerDTO.getDealerShipCode());
        dealerEntity = dealerRepository.save(dealerEntity);
        logger.info("Dealer details updated successfully");
        return dealerEntity;
    }

    public static Map<String, String> splitToMap(String str) {
        String[] tokens = str.split(",|=");
        Map<String, String> map = new HashMap<>();
        for (int i = 0; i < tokens.length - 1; ) map.put(tokens[i++], tokens[i++]);
        return map;
    }
}
