package com.nissan.auth.config;

import com.nissan.common.entity.User;
import com.nissan.common.repository.UserRepository;
import org.joda.time.DateTime;
import org.opensaml.common.SAMLException;
import org.opensaml.common.SAMLObject;
import org.opensaml.common.SAMLObjectBuilder;
import org.opensaml.saml2.core.*;
import org.opensaml.saml2.metadata.Endpoint;
import org.opensaml.saml2.metadata.IDPSSODescriptor;
import org.opensaml.saml2.metadata.SPSSODescriptor;
import org.opensaml.saml2.metadata.SingleLogoutService;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.ws.message.encoder.MessageEncodingException;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.storage.SAMLMessageStorage;
import org.springframework.security.saml.util.SAMLUtil;
import org.springframework.security.saml.websso.SingleLogoutProfileImpl;

import static org.springframework.security.saml.util.SAMLUtil.isDateTimeSkewValid;

public class CustomSAMLLogoutProfile extends SingleLogoutProfileImpl
    implements TokenSingleLogoutProfile {

  private static final Logger logger = LoggerFactory.getLogger(CustomSAMLLogoutProfile.class);
  private UserRepository userRepository;
  private String idpKeycloakMetadataURL;
  private String entityId;

  public void sendLogoutRequest(SAMLMessageContext context, String userToken)
      throws SAMLException, MetadataProviderException, MessageEncodingException {

    // If no user is logged in we do not initialize the protocol.
    if (userToken == null) {
      return;
    }

    // First invalidate the local session
    User userByToken = userRepository.findByEncodedToken(userToken);
    if (userByToken == null) {
      logger.info("Could not find user with encoded token:" + userToken);
      userByToken = userRepository.findByToken(userToken);
      if (userByToken == null) {
        logger.info("Could not find user with token:" + userToken);
        return;
      }
    }
    userByToken.setIsValidToken(false);
    userRepository.save(userByToken);

    IDPSSODescriptor idpDescriptor = (IDPSSODescriptor) context.getPeerEntityRoleMetadata();
    SPSSODescriptor spDescriptor = (SPSSODescriptor) context.getLocalEntityRoleMetadata();
    String binding = SAMLUtil.getLogoutBinding(idpDescriptor, spDescriptor);

    SingleLogoutService logoutServiceIDP =
        SAMLUtil.getLogoutServiceForBinding(idpDescriptor, binding);
    LogoutRequest logoutRequest = getLogoutRequest(context, userByToken, logoutServiceIDP);

    context.setCommunicationProfileId(getProfileIdentifier());
    context.setOutboundMessage(logoutRequest);
    context.setOutboundSAMLMessage(logoutRequest);
    context.setPeerEntityEndpoint(logoutServiceIDP);

    boolean signMessage = context.getPeerExtendedMetadata().isRequireLogoutRequestSigned();
    sendMessage(context, signMessage);

    SAMLMessageStorage messageStorage = context.getMessageStorage();
    if (messageStorage != null) {
      messageStorage.storeMessage(logoutRequest.getID(), logoutRequest);
    }
  }

  protected LogoutRequest getLogoutRequest(
      SAMLMessageContext context, User userByToken, Endpoint bindingService)
      throws SAMLException, MetadataProviderException {

    SAMLObjectBuilder<LogoutRequest> builder =
        (SAMLObjectBuilder<LogoutRequest>)
            builderFactory.getBuilder(LogoutRequest.DEFAULT_ELEMENT_NAME);
    LogoutRequest request = builder.buildObject();
    buildCommonAttributes(context.getLocalEntityId(), request, bindingService);

    // Add session indexes
    SAMLObjectBuilder<SessionIndex> sessionIndexBuilder =
        (SAMLObjectBuilder<SessionIndex>)
            builderFactory.getBuilder(SessionIndex.DEFAULT_ELEMENT_NAME);

    SessionIndex index = sessionIndexBuilder.buildObject();
    index.setSessionIndex(userByToken.getSamlSessionIndex());
    request.getSessionIndexes().add(index);

    if (request.getSessionIndexes().size() == 0) {
      throw new SAMLException("No session indexes to logout user for were found");
    }

    SAMLObjectBuilder<NameID> nameIDBuilder =
        (SAMLObjectBuilder<NameID>) builderFactory.getBuilder(NameID.DEFAULT_ELEMENT_NAME);
    NameID nameID = nameIDBuilder.buildObject();
    nameID.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified");
    nameID.setNameQualifier(idpKeycloakMetadataURL);
    nameID.setSPNameQualifier(entityId);
    //    nameID.setSPProvidedID(credential.getNameID().getSPProvidedID());
    nameID.setValue(userByToken.getUsername());
    request.setNameID(nameID);

    return request;
  }

  public void processLogoutResponse(SAMLMessageContext context)
      throws SAMLException, org.opensaml.xml.security.SecurityException, ValidationException {

    SAMLObject message = context.getInboundSAMLMessage();

    // Verify type
    if (!(message instanceof LogoutResponse)) {
      throw new SAMLException("Message is not of a LogoutResponse object type");
    }
    LogoutResponse response = (LogoutResponse) message;

    // Make sure request was authenticated if required, authentication is done as part of the
    // binding processing
    if (!context.isInboundSAMLMessageAuthenticated()
        && context.getLocalExtendedMetadata().isRequireLogoutResponseSigned()) {
      throw new SAMLException(
          "Logout Response object is required to be signed by the entity policy: "
              + context.getInboundSAMLMessageId());
    }

    // Verify issue time
    DateTime time = response.getIssueInstant();
    if (!isDateTimeSkewValid(getResponseSkew(), time)) {
      throw new SAMLException(
          "Response issue time in LogoutResponse is either too old or with date in the future");
    }

    // Verify issuer
    if (response.getIssuer() != null) {
      Issuer issuer = response.getIssuer();
      verifyIssuer(issuer, context);
    }

    // Verify status
    String statusCode = response.getStatus().getStatusCode().getValue();
    if (StatusCode.SUCCESS_URI.equals(statusCode)) {
      logger.info("Single Logout was successful");
    } else if (StatusCode.PARTIAL_LOGOUT_URI.equals(statusCode)) {
      logger.info("Single Logout was partially successful");
    } else {
      String[] logMessage = new String[2];
      logMessage[0] = response.getStatus().getStatusCode().getValue();
      StatusMessage message1 = response.getStatus().getStatusMessage();
      if (message1 != null) {
        logMessage[1] = message1.getMessage();
      }
      logger.warn("Received LogoutResponse has invalid status code {}", logMessage);
    }
  }

  public void setUserRepository(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  public void setIdpKeycloakMetadataURL(String idpKeycloakMetadataURL) {
    this.idpKeycloakMetadataURL = idpKeycloakMetadataURL;
  }

  public void setEntityId(String entityId) {
    this.entityId = entityId;
  }
}
