package com.nissan.auth.config;

import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.LogoutResponse;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.ws.message.decoder.MessageDecodingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.saml.SAMLConstants;
import org.springframework.security.saml.SAMLLogoutProcessingFilter;
import org.springframework.security.saml.context.SAMLContextProvider;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.log.SAMLLogger;
import org.springframework.security.saml.processor.SAMLProcessor;
import org.springframework.security.saml.util.SAMLUtil;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.util.Assert;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class CustomSAMLLogoutProcessingFilter extends LogoutFilter {

    protected SAMLProcessor processor;
    protected TokenSingleLogoutProfile tokenBasedProfile;
    protected SAMLLogger samlLogger;
    protected SAMLContextProvider contextProvider;

    /**
     * Class logger.
     */
    protected static final Logger logger = LoggerFactory.getLogger(SAMLLogoutProcessingFilter.class);

    /**
     * Default processing URL.
     */
    public static final String FILTER_URL = "/saml/SingleLogout";

    /**
     * Logout handlers.
     */
    private final List<LogoutHandler> handlers;
    private String filterProcessesUrl;

    public CustomSAMLLogoutProcessingFilter(LogoutSuccessHandler logoutSuccessHandler, LogoutHandler... handlers) {
        super(logoutSuccessHandler, handlers);
        this.handlers = Arrays.asList(handlers);
        this.setFilterProcessesUrl(FILTER_URL);
    }

    public CustomSAMLLogoutProcessingFilter(String logoutSuccessUrl, LogoutHandler... handlers) {
        super(logoutSuccessUrl, handlers);
        this.setFilterProcessesUrl(FILTER_URL);
        this.handlers = Arrays.asList(handlers);
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        processLogout((HttpServletRequest) req, (HttpServletResponse) res, chain);
    }

    public void processLogout(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {

        if (requiresLogout(request, response)) {

            SAMLMessageContext context;

            try {

                logger.debug("Processing SAML logout message");
                context = contextProvider.getLocalEntity(request, response);
                context.setCommunicationProfileId(getProfileName());
                processor.retrieveMessage(context);
                context.setLocalEntityEndpoint(SAMLUtil.getEndpoint(context.getLocalEntityRoleMetadata().getEndpoints(), context.getInboundSAMLBinding(), context.getInboundMessageTransport()));

            } catch (SAMLException e) {
                logger.debug("Incoming SAML message is invalid", e);
                throw new ServletException("Incoming SAML message is invalid", e);
            } catch (MetadataProviderException e) {
                logger.debug("Error determining metadata contracts", e);
                throw new ServletException("Error determining metadata contracts", e);
            } catch (MessageDecodingException e) {
                throw new ServletException("Error decoding incoming SAML message", e);
            } catch (org.opensaml.xml.security.SecurityException e) {
                logger.debug("Incoming SAML message failed security validation", e);
                throw new ServletException("Incoming SAML message failed security validation", e);
            }

            if (context.getInboundSAMLMessage() instanceof LogoutResponse) {

                try {

                    tokenBasedProfile.processLogoutResponse(context);

                    logger.debug("Performing local logout after receiving logout response from {}", context.getPeerEntityId());
                    super.doFilter(request, response, chain);

                    samlLogger.log(SAMLConstants.LOGOUT_RESPONSE, SAMLConstants.SUCCESS, context);

                } catch (Exception e) {
                    logger.debug("Received logout response is invalid", e);
                    samlLogger.log(SAMLConstants.LOGOUT_RESPONSE, SAMLConstants.FAILURE, context, e);
                }

            }

        } else {
            chain.doFilter(request, response);
        }

    }

    protected String getProfileName() {
        return SAMLConstants.SAML2_SLO_PROFILE_URI;
    }

    @Override
    public void setFilterProcessesUrl(String filterProcessesUrl) {
        this.filterProcessesUrl = filterProcessesUrl;
        super.setFilterProcessesUrl(filterProcessesUrl);
    }

    public void setProcessor(SAMLProcessor processor) {
        Assert.notNull(processor, "SAML Processor can't be null");
        this.processor = processor;
    }

    /**
     * Gets the URL used to determine if this Filter is invoked
     * @return the URL used to determine if this Fitler is invoked
     */
    public String getFilterProcessesUrl() {
        return filterProcessesUrl;
    }

    protected boolean requiresLogout(HttpServletRequest request, HttpServletResponse response) {
        return SAMLUtil.processFilter(getFilterProcessesUrl(), request);
    }

    public void setProfile(TokenSingleLogoutProfile tokenBasedProfile) {
        Assert.notNull(tokenBasedProfile, "TokenBasedProfile can't be null");
        this.tokenBasedProfile = tokenBasedProfile;
    }

    public void setContextProvider(SAMLContextProvider contextProvider) {
        Assert.notNull(contextProvider, "Context provider can't be null");
        this.contextProvider = contextProvider;
    }

    public void setSamlLogger(SAMLLogger samlLogger) {
        Assert.notNull(samlLogger, "SAML logger can't be null");
        this.samlLogger = samlLogger;
    }

}

