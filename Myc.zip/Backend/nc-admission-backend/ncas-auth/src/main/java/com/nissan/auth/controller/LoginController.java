package com.nissan.auth.controller;

import com.nissan.auth.dto.LoginDTO;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.entity.User;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.util.Constants;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

@RestController
@RequestMapping("api")
public class LoginController {

  private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

  @Value("${loginURL}")
  private String loginURL;

  @Value("${logOutRedirect}")
  private String logOutRedirect;

  @Value("${logOutURL}")
  private String logOutURL;

  @Autowired UserRepository userRepository;

  @PostMapping(value = "/v1/login", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> login(@Valid @RequestBody LoginDTO loginDTO) throws Exception {
    String status = null;

    if (Constants.SUCCESS.equals(status)) {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Successful login").setData(status), HttpStatus.OK);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Login failed").setData(status),
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @GetMapping(value = "/v1/gdlogin", produces = MediaType.APPLICATION_JSON_VALUE)
  public void gdLogin(HttpServletRequest httpServletRequest, HttpServletResponse response)
      throws Exception {
    User user = null;
    String token = httpServletRequest.getParameter("token");
    logger.info("inside Login Controller gdLogin method");
    if (token != null) {
      logger.info("inside Login Controller gdLogin method token is not null");
      user = userRepository.findByToken(token);
    }
    if (user == null || !user.getIsValidToken()) {
      logger.info("inside Login Controller gdLogin method user is null");
      response.sendRedirect(logOutRedirect);
    } else {
      logger.info("inside Login Controller gdLogin method user is not null");
      response.sendRedirect(loginURL);
    }
  }

  @GetMapping(value = "/v1/logout", produces = MediaType.APPLICATION_JSON_VALUE)
  public void logout(HttpServletRequest httpServletRequest, HttpServletResponse response)
      throws Exception {
    String status = null;
    String token = httpServletRequest.getParameter("token");
    URIBuilder url = new URIBuilder(logOutURL);
    url.addParameter("token",token);
    response.sendRedirect(url.build().toString());
  }
}
