INSERT INTO nissan_admin."role"
(role_id, "name", created_by, created_date, last_modified_by, last_modified_date)
VALUES(1, 'ROLE_CA', 'Admin', current_timestamp, 'Admin', current_timestamp);

INSERT INTO nissan_admin."role"
(role_id, "name", created_by, created_date, last_modified_by, last_modified_date)
VALUES(2, 'ROLE_KAMEARI','Admin', current_timestamp, 'Admin', current_timestamp);
INSERT INTO nissan_admin."role"
(role_id, "name", created_by, created_date, last_modified_by, last_modified_date)
VALUES(3, 'ROLE_FPN', 'Admin', current_timestamp, 'Admin', current_timestamp);
INSERT INTO nissan_admin."role"
(role_id, "name", created_by, created_date, last_modified_by, last_modified_date)
VALUES(4, 'ROLE_BUSINESS','Admin', current_timestamp, 'Admin', current_timestamp);
