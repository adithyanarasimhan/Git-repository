package com.nissan.carwings.service.impl;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.carwings.service.TempoNetService;
import com.nissan.common.entity.TempoDotNet;
import com.nissan.common.repository.TempoDotNetRepository;
import org.apache.commons.mail.util.MimeMessageParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

@Service
public class TempoDotNetServiceImpl implements TempoNetService {

  private static final Logger logger = LoggerFactory.getLogger(TempoNetService.class);

  @Autowired TempoDotNetRepository tempoDotNetRepository;
  ObjectMapper objectMapper = new ObjectMapper();

  public List<S3ObjectInputStream> readEmails(
      String accessKeyId, String secretAccessKey, String incommingBucket, String prefix) throws Exception {
    logger.info("Inside read tempo dot net file");
    List<S3ObjectInputStream> s3ObjectInputStreamList = new ArrayList<S3ObjectInputStream>();
    AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
    AmazonS3 s3 =
        AmazonS3Client.builder()
            .withRegion(Regions.AP_NORTHEAST_1)
            .withCredentials(new AWSStaticCredentialsProvider(credentials))
            .build();
    logger.info("Fetching s3 object");
    logger.info("incommingBucket: {}, prefix : {}", incommingBucket, prefix);
    ObjectListing listing = s3.listObjects(incommingBucket);
    List<S3ObjectSummary> summaries = listing.getObjectSummaries();

    while (listing.isTruncated()) {
      listing = s3.listNextBatchOfObjects(listing);
      summaries.addAll(listing.getObjectSummaries());
    }
    logger.info("Fetching s3 object successful");
    for (S3ObjectSummary s3ObjectSummary : summaries) {
      String key = s3ObjectSummary.getKey(); // getting the key of the item
      logger.info("key: {}", key);
      S3Object object = s3.getObject(new GetObjectRequest(incommingBucket, key));
      InputStream mailFileInputStream = object.getObjectContent();
      MimeMessage message =
              getMimeMessageForRawEmailString(
                      mailFileInputStream); // converting input stream to mime message
      object.close();
      logger.info("Deleting current s3 object from ds3 bucket");
      s3.deleteObject(incommingBucket, key);
      logger.info("Deleting current s3 object from ds3 bucket successful");
      try {
        mailFileInputStream.close();
      } catch (IOException e) {
      }
    }
    return s3ObjectInputStreamList;
  }

  public MimeMessage getMimeMessageForRawEmailString(InputStream mailFileInputStream)
      throws Exception {
    logger.info("Iterating mail input to mime");
    Properties props = new Properties();
    Session session = Session.getDefaultInstance(props, null);
    MimeMessage message = new MimeMessage(session, mailFileInputStream);
    MimeMessageParser parser = new MimeMessageParser(message);
    Object content = message.getContent();
    logger.info("Content : {}", content);
    Multipart multiPart = (Multipart) content;

    logger.info("multi part count : {}", multiPart.getCount());
    for (int i = 0; i < multiPart.getCount(); i++) {
      MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(i);
      if (Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition())) {
        logger.info("Attachment fetched from mime part");
        String fileName = part.getFileName();
        logger.info("filename : {}", fileName);
        part.saveFile(fileName);
        BufferedReader bufReader =
            new BufferedReader(
                new InputStreamReader(new FileInputStream(fileName), "Shift_JIS"));
        bufReader.readLine().getBytes("Shift_JIS");
        if(fileName.toLowerCase().contains("hansya")) {
          readHanshaFile(bufReader);
        } else if(fileName.toLowerCase().contains("jisseki")) {
          readJissekiFile(bufReader);
        } else if(fileName.toLowerCase().contains("kanban")) {
          readKanbanFile(bufReader);
        }
        bufReader.close();
      }
    }
    return message;
  }

  @Transactional
  private void readHanshaFile(BufferedReader bufReader) throws IOException {
    logger.info("Inside readHanshaFile");
    String line = null;
    while ((line = bufReader.readLine()) != null) {
      logger.info("*****Saving data to tempo dot net table");
      ArrayList<String> stringArrayList = new ArrayList<>(Arrays.asList(line.split(",")));
      String caCompanyCode = stringArrayList.get(2).replaceAll("^\"|\"$", "");
      logger.info("caCompanyCode : {}", caCompanyCode);
      TempoDotNet tempoDotNetEntity = tempoDotNetRepository.findByCaCompanyCode(caCompanyCode);
      if (tempoDotNetEntity == null) {
        logger.info("****Saving data to tempo dot net table new object");
        TempoDotNet tempoDotNet = new TempoDotNet();
        tempoDotNet.setCaCompanyCode(caCompanyCode);
        tempoDotNet.setCaCompanyName(stringArrayList.get(6).replaceAll("^\"|\"$", ""));
        tempoDotNet.setProfitCaCompanyCode(stringArrayList.get(3).replaceAll("^\"|\"$", ""));
        tempoDotNet.setDealerCompanyPhoneNumber(stringArrayList.get(9).replaceAll("^\"|\"$", ""));
        tempoDotNetRepository.save(tempoDotNet);
      } else {
        logger.info("****Updating data to tempo dot net table");
        tempoDotNetEntity.setCaCompanyName(stringArrayList.get(6).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setProfitCaCompanyCode(
            stringArrayList.get(3).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setDealerCompanyPhoneNumber(stringArrayList.get(9).replaceAll("^\"|\"$", ""));
        tempoDotNetRepository.save(tempoDotNetEntity);
      }
      logger.info("*****Saving data to tempo dot net table successful");
    }
  }

  @Transactional
  private void readJissekiFile(BufferedReader bufReader) throws IOException {
    logger.info("Inside readJissekiFile");
    String line = null;
    while ((line = bufReader.readLine()) != null) {
      logger.info("*****Saving data to tempo dot net table");
      ArrayList<String> stringArrayList = new ArrayList<>(Arrays.asList(line.split(",")));
      String caCompanyCode = stringArrayList.get(3).replaceAll("^\"|\"$", "");
      logger.info("caCompanyCode : {}", caCompanyCode);
      TempoDotNet tempoDotNetEntity = tempoDotNetRepository.findByCaCompanyCode(caCompanyCode);
      if (tempoDotNetEntity == null) {
        logger.info("****Saving data to tempo dot net table new object");
        TempoDotNet tempoDotNet = new TempoDotNet();
        tempoDotNet.setCaCompanyCode(caCompanyCode);
        tempoDotNet.setJissekiCode(stringArrayList.get(1).replaceAll("^\"|\"$", ""));
        tempoDotNet.setCompassDealershipCode(stringArrayList.get(7).replaceAll("^\"|\"$", ""));
        tempoDotNet.setProfitDealershipCode(stringArrayList.get(9).replaceAll("^\"|\"$", ""));
        tempoDotNetRepository.save(tempoDotNet);
      } else {
        logger.info("****Updating data to tempo dot net table");
        tempoDotNetEntity.setJissekiCode(stringArrayList.get(1).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setCompassDealershipCode(stringArrayList.get(7).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setProfitDealershipCode(stringArrayList.get(9).replaceAll("^\"|\"$", ""));
        tempoDotNetRepository.save(tempoDotNetEntity);
      }
      logger.info("*****Saving data to tempo dot net table successful");
    }
  }

  @Transactional
  private void readKanbanFile(BufferedReader bufReader) throws IOException {
    logger.info("Inside readKanbanFile");
    String line = null;
    while ((line = bufReader.readLine()) != null) {
      logger.info("*****Saving data to tempo dot net table");
      ArrayList<String> stringArrayList = new ArrayList<>(Arrays.asList(line.split(",")));
      String caCompanyCode = stringArrayList.get(2).replaceAll("^\"|\"$", "");
      logger.info("caCompanyCode : {}", caCompanyCode);
      TempoDotNet tempoDotNetEntity = tempoDotNetRepository.findByCaCompanyCode(caCompanyCode);
      if (tempoDotNetEntity == null) {
        logger.info("****Saving data to tempo dot net table new object");
        TempoDotNet tempoDotNet = new TempoDotNet();
        tempoDotNet.setCaCompanyCode(caCompanyCode);
        tempoDotNet.setKanbanCode(stringArrayList.get(1).replaceAll("^\"|\"$", ""));
        tempoDotNet.setProfitDealerCompanyCode(stringArrayList.get(3).replaceAll("^\"|\"$", ""));
        tempoDotNet.setProfitDealerCompanyCodeWithBlockCode(stringArrayList.get(4).replaceAll("^\"|\"$", ""));
        tempoDotNet.setDealerCompanyName(stringArrayList.get(5).replaceAll("^\"|\"$", ""));
        tempoDotNet.setDealerShipName(stringArrayList.get(9).replaceAll("^\"|\"$", ""));
        tempoDotNet.setRegularClosingDay1(stringArrayList.get(21).replaceAll("^\"|\"$", ""));
        tempoDotNet.setRegularClosingDay2(stringArrayList.get(22).replaceAll("^\"|\"$", ""));
        tempoDotNet.setNewVehicleFlag(stringArrayList.get(36).replaceAll("^\"|\"$", ""));
        tempoDotNet.setUsedVehicleFlag(stringArrayList.get(38).replaceAll("^\"|\"$", ""));
        tempoDotNetRepository.save(tempoDotNet);
      } else {
        logger.info("****Updating data to tempo dot net table");
        tempoDotNetEntity.setKanbanCode(stringArrayList.get(1).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setProfitDealerCompanyCode(stringArrayList.get(3).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setProfitDealerCompanyCodeWithBlockCode(stringArrayList.get(4).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setDealerCompanyName(stringArrayList.get(5).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setDealerShipName(stringArrayList.get(9).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setRegularClosingDay1(stringArrayList.get(21).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setRegularClosingDay2(stringArrayList.get(22).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setNewVehicleFlag(stringArrayList.get(36).replaceAll("^\"|\"$", ""));
        tempoDotNetEntity.setUsedVehicleFlag(stringArrayList.get(38).replaceAll("^\"|\"$", ""));
        tempoDotNetRepository.save(tempoDotNetEntity);
      }
      logger.info("*****Saving data to tempo dot net table successful");
    }
  }


}
