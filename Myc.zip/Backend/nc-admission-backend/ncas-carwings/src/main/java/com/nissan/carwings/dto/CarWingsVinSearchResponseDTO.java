package com.nissan.carwings.dto;

import lombok.Data;

@Data
public class CarWingsVinSearchResponseDTO {
    private String responseCd;
    private String errorMessage;
    private String modelName;
    private String vin;
    private String adaptorId;
    private String firstRegDate;
    private String vinRegistDate;
    private String status;
    private String userId;
    private String colorName;
    private String dopFlg;
    private String iviFlg;
}
