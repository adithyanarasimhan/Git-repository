package com.nissan.carwings.controller;

import com.nissan.carwings.CarwingsConfig;
import com.nissan.carwings.service.CommunicationService;
import com.nissan.carwings.service.TempoNetService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

@RestController
@RequestMapping("secured/api/v1")
public class HomeController {

    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    CommunicationService communicationService;
    @Autowired
    TempoNetService tempoNetService;
    private CarwingsConfig carwingsConfig;

    public HomeController(final CarwingsConfig carwingsConfig) {
        this.carwingsConfig = carwingsConfig;
    }

    @GetMapping(value = "{langCode}/carwings", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 */2 * * *", zone = "Asia/Tokyo")
    public void getOrderDetails()
            throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, NoSuchPaddingException, InvalidAlgorithmParameterException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        communicationService.getOrderDetails();
    }

    @GetMapping(value = "{langCode}/kameri", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 2 * * *", zone = "Asia/Tokyo")
    public void sendFiles()
            throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, NoSuchPaddingException, InvalidAlgorithmParameterException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        communicationService.sendFiles();
        communicationService.sendV2FilesToKameri();
    }

    @Scheduled(cron = "0 0 2 * * *", zone = "Asia/Tokyo")
    @GetMapping(value = "{langCode}/tempo", produces = MediaType.APPLICATION_JSON_VALUE)
    public void tempoNet() throws Exception {
        tempoNetService.readEmails(
                carwingsConfig.awsAccessKey,
                carwingsConfig.awsSecretKey,
                carwingsConfig.tempoDotNetBucket,
                carwingsConfig.tempoDotNetPrefix);
    }

    @GetMapping(value = "{langCode}/ncIdToEmail", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 15 * * *", zone = "Asia/Tokyo")
    public void sendNcIdToCustomerEmail() throws Exception {
        logger.info("Start Phase 1 NC-ID Mails to Customer and CA");
        communicationService.sendNcIdToNewCarCus();
        logger.info("End Phase 1 NC-ID Mails");
        logger.info("Start Phase 2 NC-ID Mails to Customer and CA");
        communicationService.sendNcIdToUsedCarCus();
        logger.info("End Phase 2 NC-ID Mails");
    }

    @GetMapping(value = "{langCode}/democarkameari", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 4 * * *", zone = "Asia/Tokyo")
    public void sendD01ToKameari() {
        communicationService.sendD01fileToKameari();
    }

    @GetMapping(value = "{langCode}/dop/ncid", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 2 * * *", zone = "Asia/Tokyo")
    public void sendDOPEnhancementFiles()
            throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, NoSuchPaddingException, InvalidAlgorithmParameterException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        communicationService.sendDOPEnhancementFilesToKameri();
    }

}
