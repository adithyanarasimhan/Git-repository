package com.nissan.carwings;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CarwingsConfig {

    @Value("${awsAccessKey}")
    public String awsAccessKey;

    @Value("${awsSecretKey}")
    public String awsSecretKey;

    @Value("${tempoDotNetBucket}")
    public String tempoDotNetBucket;

    @Value("${tempoDotNetPrefix}")
    public String tempoDotNetPrefix;
}
