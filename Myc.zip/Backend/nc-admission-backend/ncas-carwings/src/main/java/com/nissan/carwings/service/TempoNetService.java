package com.nissan.carwings.service;

import com.amazonaws.services.s3.model.S3ObjectInputStream;

import java.util.List;

public interface TempoNetService {
    List<S3ObjectInputStream> readEmails(
            String accessKeyId, String secretAccessKey, String incommingBucket, String prefix) throws Exception;
}
