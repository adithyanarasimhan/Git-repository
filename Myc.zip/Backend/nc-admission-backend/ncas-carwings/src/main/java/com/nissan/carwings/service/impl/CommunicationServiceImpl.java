package com.nissan.carwings.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.carwings.dto.*;
import com.nissan.carwings.service.CommunicationService;
import com.nissan.common.util.CustomMappingStrategy;
import com.nissan.carwings.util.SftpUpload;
import com.nissan.common.config.CloudMapServiceResolver;
import com.nissan.common.config.SecretsManager;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import com.nissan.common.util.DemoCarUtil;
import com.nissan.common.util.SftpOperationsUtil;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLContext;
import javax.validation.Valid;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.*;
import java.security.cert.CertificateException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.nissan.common.util.Constants.*;

@Service
public class CommunicationServiceImpl implements CommunicationService {

    private static final Logger logger = LoggerFactory.getLogger(CommunicationServiceImpl.class);
    private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(CommunicationServiceImpl.class);
    public static final String PO_MAIL_CA = "/notification/secured/api/v1/en/invalidPOMailCA";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Value("${key.store.carwings}")
    private String carwingsKeyStore;

    @Value("${spring.carwings.url}")
    private String carWingsUrl;

    @Value("${spring.carwings.vinsearchurl}")
    private String carWingsVinSearchUrl;

    @Value("${spring.carwings.resetpasswordurl}")
    private String cwResetPasswordUrl;

    @Value("${car.wings.password}")
    private String carWingsPassword;

    @Value("${asp.user.password}")
    private String userPassword;

    @Value("${car.wings.secret.key}")
    private String secretKey;

    @Value("${file.characterformat}")
    private String fileCharacterFormat;

    @Value("${spring.sftp.remotedir}")
    private String remoteDir;

    @Value("${kameri.democar.folder}")
    private String democarKameriFolder;

    public static final String ASP_USER = "NCAS";
    public static final String CARWINGS_STATUS_SA = "SA";
    public static final String CARWINGS_STATUS_SZ = "SZ";
    public static final String CARWINGS_STATUS_SS = "SS";
    public static final String CARWINGS_STATUS_SC = "SC";
    public static final String CARWINGS_STATUS_ZZ = "ZZ";
    public static final String CARWINGS_STATUS_DW = "DW";
    public static final String CARWINGS_STATUS_XX = "XX";
    public static final String CARWINGS_STATUS_DP = "DP";
    public static final String APPLICANT_LIST_NFS = "applicant_list_NFS";
    public static final String APPLICANT_LIST_MOP_OPERATOR = "applicant_list_MopOperator";
    public static final String APPLICANT_LIST_RETRY_PAYMENT = "applicant_list_ResetPayment";
    public static final String APPLICANT_LIST_WITHDRAW_VIN_RESET = "applicant_list_Withdraw_VIN_RESET";
    public static final String APPLICANT_LIST_RPA = "applicant_list_RPA";
    public static final String APPLICANT_LIST_TRANSFER_CONFIRMATION =
            "applicant_list_TransferConfirmation";
    public static final String APPLICANT_LIST_DIGITAL_NOTIFICATON = "applicant_list_DigitalNotification";
    public static final String NEW_CAR_NC_ID = "/notification/secured/api/v1/en/ncIdMail";
    public static final String USED_CAR_NC_ID = "/notification/secured/api/v2/en/ncIdMail";
    public static final String NEW_CAR_CANCEL = "/notification/secured/api/v1/en/cancelAdmission";
    public static final String USED_CAR_CANCEL = "/notification/secured/api/v2/en/cancelAdmission";

    public static final String VEHICLE = "Vehicle";
    public static final String DIGITAL_ADMISSION = "Admission";
    public static final String NFS_PAYMENT = "NfsPayment";

    public static final long MIN_LEAF_RANGE = 000000;
    public static final long MAX_LEAF_RANGE = 90000L;

    public static final Pattern SKYLINE_2019 = Pattern.compile("^HV37-\\d+|^HNV37-\\d+|^RV37-\\d+");
    public static final Pattern LEAF = Pattern.compile("^ZE1-\\d+");
    public static final Pattern E_NV200 = Pattern.compile("^VME0-\\d+|^ME0-\\d+");
    public static final Pattern NOTE =
            Pattern.compile("^E13-\\d+|^FE13-\\d+|^SNE13-\\d+|^FSNE13-\\d+");
    public static final Pattern DAYZ =
            Pattern.compile("^B43W-\\d+|^B44W-\\d+|^B45W-\\d+|^B46W-\\d+|^B47W-\\d+|^B48W-\\d+");
    public static final Pattern ROOX = Pattern.compile("^B44A-\\d+|^B45A-\\d+|^B47A-\\d+|^B48A-\\d+");
    public static final Pattern KICKS = Pattern.compile("^P15-\\d+");
    public static final Pattern X_TRAIL =
            Pattern.compile("^T32-\\d+|^NT32-\\d+|^HT32-\\d+|^HNT32-\\d+");
    public static final Pattern ELGRAND =
            Pattern.compile("^PE52-\\d+|^PNE52-\\d+|^TE52-\\d+|^TNE52-\\d+");
    public static final Pattern TEANA = Pattern.compile("^L33-\\d+");
    public static final Pattern FUGA = Pattern.compile("^Y51-\\d+|^KY51-\\d+|^KNY51-\\d+|^HY51-\\d+");
    public static final Pattern CIMA = Pattern.compile("^HGY51-\\d+");
    public static final Pattern OLD_DAYZ = Pattern.compile("^B[0-9]{2}W-[0-9]{1}0\\d+");

    private static final String D01_DATE_FORMAT = "yyyyMMdd";

    private Long processedOrders = 0L;

    @Autowired
    AdmissionRepository admissionRepository;
    @Autowired
    OrdersRepository ordersRepository;
    @Autowired
    AdmissionV2Repository admissionV2Repository;
    @Autowired
    OrdersV2Repository ordersV2Repository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    DealerAddressRepository dealerAddressRepository;
    @Autowired
    ActivityUtil activityUtil;
    @Autowired
    SftpUpload sftpUpload;
    @Autowired
    CloudMapServiceResolver serviceResolver;
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    PaymentMethodRepository paymentMethodRepository;

    @Autowired
    ModelV2Repository modelV2Repository;
    @Autowired
    GradeV2Repository gradeV2Repository;
    @Autowired
    NaviV2Repository naviV2Repository;
    @Autowired
    PackagePlanV2Repository packagePlanV2Repository;
    @Autowired
    OptionsV2Repository optionsV2Repository;
    @Autowired
    ReasonRepository reasonRepository;
    @Autowired
    ColorRepository colorRepository;
    @Autowired
    NaviReferenceRepository naviReferenceRepository;

    @Autowired
    ModelRepository modelRepository;
    @Autowired
    GradeRepository gradeRepository;
    @Autowired
    NaviRepository naviRepository;
    @Autowired
    PackagePlanRepository packagePlanRepository;
    @Autowired
    OptionsRepository optionsRepository;
    @Autowired
    TempoDotNetRepository tempoDotNetRepository;
    @Autowired
    DealerRepository dealerRepository;
    @Autowired
    Environment env;
    @Autowired
    SftpOperationsUtil sftpOperationsUtil;
    @Autowired
    VinDetailsRepository vinDetailsRepository;

    @Override
    public void getOrderDetails()
            throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, NoSuchPaddingException, InvalidAlgorithmParameterException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        RestTemplate restTemplate = cwInitialSetUp();
        HashMap<String, String> vinOrderMapForUsedCar = new HashMap<>();
        LocalDateTime currentDateTime = LocalDateTime.now();
        LocalDateTime localdateTime = currentDateTime.minusHours(48);
        java.sql.Timestamp startDate = Timestamp.valueOf(localdateTime);
        List<Object> orderInfo = new ArrayList<>();
        fetchNewCarOrdersForNCID(startDate, orderInfo);
        fetchUsedCarOrdersForNCID(orderInfo, vinOrderMapForUsedCar);
        logger.info("orders count : {}", orderInfo.size());
        /**Ticket - APX0281-46-carwings-scheduler-set-limit-500 */
        int dataLimit = 500;
        logger.info(" Carwings dataLimit : {}", dataLimit);
        AtomicInteger ai = new AtomicInteger();
        Collection<List<Object>> chunkedOrders = orderInfo.stream()
                .collect(Collectors.groupingBy(item -> ai.getAndIncrement() / dataLimit)).values();
        chunkedOrders.forEach(chunk -> {
            List<Object> subList = new ArrayList<Object>(chunk);
            logger.info("sending order data, orders count : {}", subList.size());
            try {
                List<ResultDto> resultDtos = getResponseListDto(restTemplate, orderInfo);
                resultDtos.forEach(
                        result -> {
                            logger.info(
                                    "carwings orderno : {} companycode : {} vin : {} ",
                                    result.getOrderNo(),
                                    result.getSalesCompanyCd(),
                                    result.getVin());
                            if (result.getOrderNo() != null
                                    && !result.getOrderNo().isEmpty()
                                    && result.getSalesCompanyCd() != null
                                    && !result.getSalesCompanyCd().isEmpty()) {
                                Orders order =
                                        ordersRepository.findByOrderNumberPsAndCompanyCode(
                                                result.getOrderNo(), result.getSalesCompanyCd());
                                saveCarwingsInfoForNewCar(order, result);
                            } else if (result.getVin() != null && !result.getVin().isEmpty()) {
                                String orderNo = vinOrderMapForUsedCar.get(result.getVin());
                                logger.info("Carwings response orderNo {} vin {}", orderNo, result.getVin());
                                OrdersV2 ordersV2 =
                                        ordersV2Repository.findByOrdersNumberAndVinNumber(orderNo, result.getVin());
                                saveCarwingsInfoForUsedCar(ordersV2, result);
                            }
                        });
            } catch (Exception e) {
                logger.error("carwings job failed", e);
            }
            logger.info("Successfully sent, orders count={}", subList.size());
        });

    }

    private RestTemplate cwInitialSetUp()
            throws IOException, NoSuchAlgorithmException, KeyManagementException, KeyStoreException,
            CertificateException {
        SecretsManager secretsManager = new SecretsManager();
        ByteBuffer byteBuffer = secretsManager.getCertificate(carwingsKeyStore);
        InputStream inputStream = new ByteArrayInputStream(byteBuffer.array());
        File somethingFile = File.createTempFile("keystore", ".jks");
        try {
            FileUtils.copyInputStreamToFile(inputStream, somethingFile);
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        SSLContext sslContext =
                SSLContextBuilder.create()
                        .loadTrustMaterial(
                                ResourceUtils.getFile(somethingFile.getPath()), carWingsPassword.toCharArray())
                        .build();
        CloseableHttpClient client = HttpClients.custom().setSslcontext(sslContext).build();
        HttpComponentsClientHttpRequestFactory requestFactory =
                new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(client);
        return new RestTemplate(requestFactory);
    }

    private void saveCarwingsInfoForUsedCar(OrdersV2 ordersV2, ResultDto result) {
        logger.error("Inside saveCarwingsInfoForUsedCar {} {}", result.getNcJoinDate(), result.getVinRegistDate());
        if (ordersV2 != null) {
            AdmissionV2 admissionV2 = ordersV2.getAdmission();
            admissionV2.setNcId(result.getNcId());
            admissionV2.setNcPassword(result.getNcPw());
            admissionV2.setCwStatus(result.getStatus());
            if (CARWINGS_STATUS_SC.equals(result.getStatus())) {
                admissionV2.setStatus(Constants.STATUS_CANCEL);
                admissionV2.setStatusJp(Constants.STATUS_CANCEL_JP);
                activityUtil.createActivityLogV2(admissionV2);
            } else {
                switch (result.getStatus()) {
                    case CARWINGS_STATUS_SA:
                        admissionV2.setStatus(Constants.STATUS_DEALER_COMPLETED_SA);
                        admissionV2.setStatusJp(Constants.STATUS_DEALER_COMPLETED_SA_JP);
                        activityUtil.createActivityLogV2(admissionV2);
                        break;
                    case CARWINGS_STATUS_ZZ:
                        admissionV2.setStatus(STATUS_WITHDRAWAL_ZZ);
                        admissionV2.setStatusJp(STATUS_WITHDRAWAL_ZZ_JP);
                        activityUtil.createActivityLogV2(admissionV2);
                        break;
                    case CARWINGS_STATUS_DW:
                    case CARWINGS_STATUS_XX:
                    case CARWINGS_STATUS_DP:
                        admissionV2.setStatus(STATUS_PERSONAL_INFO_DELETED_DW);
                        admissionV2.setStatusJp(STATUS_PERSONAL_INFO_DELETED_DW_JP);
                        activityUtil.createActivityLogV2(admissionV2);
                        break;
                }
            }
            String ncJoinedDate = result.getNcJoinDate();
            String vinRegisteredDate = result.getVinRegistDate();
            Date formattedNcJoinedDate = null;
            Date formattedVinRegisteredDate = null;
            try {
                if (StringUtils.isNotEmpty(ncJoinedDate)) {
                    formattedNcJoinedDate = new SimpleDateFormat("yyyyMMdd").parse(ncJoinedDate);
                }
                if (StringUtils.isNotEmpty(vinRegisteredDate)) {
                    formattedVinRegisteredDate = new SimpleDateFormat("yyyyMMdd").parse(vinRegisteredDate);
                }
            } catch (ParseException e) {
                logger.error("Exception while formatting ncJoined or vinRegistered date" + e.getMessage());
            }
            admissionV2.setNcJoinedDate(formattedNcJoinedDate);
            admissionV2.setVinRegisteredDate(formattedVinRegisteredDate);
            admissionV2.setNcIdGeneratedDate(LocalDate.now());
            admissionV2Repository.save(admissionV2);
            saveCarwingsDataToOrderV2(result, ordersV2, formattedNcJoinedDate);
        }
    }

    private void saveCarwingsDataToOrderV2(
            ResultDto result, OrdersV2 order, Date formattedNcJoinedDate) {
        order.setNcJoinedDate(formattedNcJoinedDate);
        logger.error("Inside saveCarwingsDataToOrderV2 {} {}", result.getChargeStartDate(), result.getChargeUpdateDate());
        Date formattedChargeStartDate = null;
        Date formattedServiceUpdateDate = null;
        try {
            if (StringUtils.isNotEmpty(result.getChargeStartDate())) {
                formattedChargeStartDate =
                        new SimpleDateFormat("yyyyMMdd").parse(result.getChargeStartDate());
            }
            if (StringUtils.isNotEmpty(result.getChargeUpdateDate())) {
                formattedServiceUpdateDate =
                        new SimpleDateFormat("yyyyMMdd").parse(result.getChargeUpdateDate());
            }
        } catch (ParseException e) {
            logger.error("Exception while formatting ChargeStart or ChargeUpdate Date" + e.getMessage());
        }

        order.setChargeStartDate(formattedChargeStartDate);
        order.setServiceUpdateDate(formattedServiceUpdateDate);
        order.setAdopterId(result.getAdaptorId());
        order.setRegisterNumber(result.getRegNo());
        order.setPlanPrice(result.getPlanPrice());
        ordersV2Repository.save(order);
    }

    private void saveCarwingsInfoForNewCar(Orders order, ResultDto result) {
        if (order != null) {
            Admission admission = order.getAdmission();
            boolean continueExecution = true;
            if (result.getStatus().equals(CARWINGS_STATUS_SA)) {
                if (null != order.getPackagePlan() && null != order.getPackagePlan().getPrice() && (order.getPackagePlan().getPrice().toString().equals(result.getPlanPrice()))) {
                    /** do nothing **/
                } else {
                    logger.info("inside Error Notify mail flow order={}", order);
                    sendInvalidPOMailCA(order.getId());

                    if ((null != order.getPaymentMethod()) && (order.getPaymentMethod().getId() == 1 || order.getPaymentMethod().getId() == 5
                            || order.getPaymentMethod().getId() == 2 || order.getPaymentMethod().getId() == 4
                            || order.getPaymentMethod().getId() == 11 || order.getPaymentMethod().getId() == 12)) {
                        admission.setStatus(Constants.STATUS_CUSTOMER_COMPLETED);
                        admission.setStatusJp(Constants.STATUS_CUSTOMER_COMPLETED_JP);
                    } else {
                        admission.setStatus(Constants.STATUS_DEALER_WORKING);
                        admission.setStatusJp(Constants.STATUS_DEALER_WORKING_JP);
                    }
                    admission.setPoMapping(false);
                    logger.info("deleted order number {}", order.getOrderNumberPs());
                    admissionRepository.save(admission);
                    order.setOrderNumberPs(null);
                    ordersRepository.save(order);
                    activityUtil.createActivityLog(admission);
                    continueExecution = false;
                }
            }
            if (continueExecution) {
                logger.info("Inside normal flow order {}", order);
                admission.setNcId(result.getNcId());
                admission.setNcPassword(result.getNcPw());
                admission.setCwStatus(result.getStatus());
                if (CARWINGS_STATUS_SC.equals(result.getStatus())) {
                    admission.setStatus(Constants.STATUS_CANCEL);
                    admission.setStatusJp(Constants.STATUS_CANCEL_JP);
                    activityUtil.createActivityLog(admission);
                } else {
                    switch (result.getStatus()) {
                        case CARWINGS_STATUS_SA:
                            admission.setStatus(Constants.STATUS_DEALER_COMPLETED_SA);
                            admission.setStatusJp(Constants.STATUS_DEALER_COMPLETED_SA_JP);
                            activityUtil.createActivityLog(admission);
                            break;
                        case CARWINGS_STATUS_SS:
                            admission.setStatus(Constants.STATUS_DEALER_COMPLETED_SS);
                            admission.setStatusJp(Constants.STATUS_DEALER_COMPLETED_SS_JP);
                            activityUtil.createActivityLog(admission);
                            break;
                        case CARWINGS_STATUS_SZ:
                            admission.setStatus(Constants.STATUS_DEALER_COMPLETED_SZ);
                            admission.setStatusJp(Constants.STATUS_DEALER_COMPLETED_SZ_JP);
                            activityUtil.createActivityLog(admission);
                            break;
                        case CARWINGS_STATUS_ZZ:
                            admission.setStatus(STATUS_WITHDRAWAL_ZZ);
                            admission.setStatusJp(STATUS_WITHDRAWAL_ZZ_JP);
                            activityUtil.createActivityLog(admission);
                            break;
                        case CARWINGS_STATUS_DW:
                        case CARWINGS_STATUS_XX:
                        case CARWINGS_STATUS_DP:
                            admission.setStatus(STATUS_PERSONAL_INFO_DELETED_DW);
                            admission.setStatusJp(STATUS_PERSONAL_INFO_DELETED_DW_JP);
                            activityUtil.createActivityLog(admission);
                            break;
                    }
                }
                String ncJoinedDate = result.getNcJoinDate();
                String vinRegisteredDate = result.getVinRegistDate();
                Date formattedNcJoinedDate = null;
                Date formattedVinRegisteredDate = null;
                try {
                    formattedNcJoinedDate = new SimpleDateFormat("yyyyMMdd").parse(ncJoinedDate);
                } catch (ParseException e) {
                    logger.error("exception occurred while formatting nc joined date" + e.getMessage());
                }
                try {
                    formattedVinRegisteredDate = new SimpleDateFormat("yyyyMMdd").parse(vinRegisteredDate);
                } catch (ParseException e) {
                    logger.error("exception occurred while formatting vin registered date" + e.getMessage());
                }
                admission.setNcJoinedDate(formattedNcJoinedDate);
                admission.setVinRegisteredDate(formattedVinRegisteredDate);
                admission.setNcIdGeneratedDate(LocalDate.now());
                admissionRepository.save(admission);
                saveCarwingsDataToOrder(result, order, formattedNcJoinedDate);
            }
        }
    }

    private void fetchNewCarOrdersForNCID(Timestamp startDate, List<Object> orderInfo) {
        List<Orders> orders =
                ordersRepository.fetchAllTwoDaysBackOrders(Constants.STATUS_DEALER_COMPLETED, startDate);
        /** Retry for carwings status SZ and SS */
        orders.addAll(ordersRepository.findByCarWingsStatus());
        logger.info("orders count={}", orders.size());
    orders.stream()
        .forEach(
            order -> {
              Admission admission = order.getAdmission();
              if (StringUtils.isEmpty(admission.getCwStatus())
                  || (!CARWINGS_STATUS_SA.equals(admission.getCwStatus())
                      && !CARWINGS_STATUS_SC.equals(admission.getCwStatus()))) {
                DealerEntity dealer = admission.getDealer();
                logger.info("the order number is ={}", order.getOrderNumberPs());
                if (StringUtils.isNotEmpty(order.getOrderNumberPs())) {
                  Map<String, Object> infoMap = new HashMap<>();
                  infoMap.put(
                      "salesCompanyCd", String.valueOf(dealer.getCompanyCode()).toUpperCase());
                  infoMap.put("orderNo", order.getOrderNumberPs().toUpperCase());
                  infoMap.put("vin", "");
                  orderInfo.add(infoMap);
                }
              }
            });
    }

    private void fetchUsedCarOrdersForNCID(
            List<Object> orderInfo, HashMap<String, String> vinOrderMapForUsedCar) {
        logger.info("Inside fetchUsedCarOrdersForNCID");
        LocalDateTime currentDateTime = LocalDateTime.now();
        LocalDateTime localdateTime = currentDateTime.minusHours(24);
        java.sql.Timestamp startDate = Timestamp.valueOf(localdateTime);
        List<OrdersV2> orders =
                ordersV2Repository.fetchAllTwoDaysBackOrders(startDate);
        /** Retry for carwings status SZ and SS */
        orders.addAll(ordersV2Repository.findByCarWingsStatus());
        logger.info("orders count={}", orders.size());
        orders.stream()
                .forEach(
                        order -> {
                            AdmissionV2 admission = order.getAdmission();
                            if (StringUtils.isEmpty(admission.getCwStatus())
                                    || (!CARWINGS_STATUS_SA.equals(admission.getCwStatus())
                                    && !CARWINGS_STATUS_SC.equals(admission.getCwStatus()))) {
                                DealerEntity dealer = admission.getDealer();
                                logger.info("the order number is {} {}", order.getOrdersNumber(), order.getVinNumber());
                                if (StringUtils.isNotEmpty(order.getVinNumber())) {
                                    Map<String, Object> infoMap = new HashMap<>();
                                    vinOrderMapForUsedCar.put(order.getVinNumber(), order.getOrdersNumber());
                                    infoMap.put("vin", order.getVinNumber());
                                    infoMap.put("salesCompanyCd", "");
                                    infoMap.put("orderNo", "");
                                    orderInfo.add(infoMap);
                                }
                            }
                        });
    }

    @Override
    public void sendDOPEnhancementFilesToKameri() throws KeyManagementException, CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, InvalidAlgorithmParameterException, NoSuchPaddingException {
        RestTemplate restTemplate = cwInitialSetUp();
        HashMap<String, String> vinOrderMapForUsedCar = new HashMap<>();
        LocalDateTime currentDateTime = LocalDateTime.now();
        LocalDateTime localdateTime = currentDateTime.minusHours(24);
        java.sql.Timestamp startDate = Timestamp.valueOf(localdateTime);
        List<Object> orderInfo = new ArrayList<>();
        List<Orders> orders = ordersRepository.fetchDOPEnhancementOrders(STATUS_DEALER_COMPLETED, startDate);
        orders.stream().forEach(order -> {
            Admission admission = order.getAdmission();
            DealerEntity dealer = admission.getDealer();
            logger.info("the order number is ={}", order.getOrderNumberPs());
            Map<String, Object> infoMap = new HashMap<>();
            infoMap.put(
                    "salesCompanyCd", String.valueOf(dealer.getCompanyCode()).toUpperCase());
            infoMap.put("orderNo", order.getOrderNumberPs().toUpperCase());
            orderInfo.add(infoMap);
        });
        List<ResultDto> resultDtos = getResponseListDto(restTemplate, orderInfo);
        resultDtos.forEach(
                result -> {
                    logger.info(
                            "carwings orderno={} companycode={} vin={} ",
                            result.getOrderNo(),
                            result.getSalesCompanyCd(),
                            result.getVin());
                    if (result.getOrderNo() != null
                            && !result.getOrderNo().isEmpty()
                            && result.getSalesCompanyCd() != null
                            && !result.getSalesCompanyCd().isEmpty()) {
                        Orders order =
                                ordersRepository.findByOrderNumberPsAndCompanyCode(
                                        result.getOrderNo(), result.getSalesCompanyCd());
                        if (CARWINGS_STATUS_SA.equals(result.getStatus())) {
                            generateDOPEnhancementFiles(order, result);
                        }
                    }
                });
    }

    private void generateDOPEnhancementFiles(Orders order, ResultDto resultDto) {
        Path myPath = null;
        BufferedWriter writer = null;
        Charset charset = null;
        ObjectMapper objectMapper = new ObjectMapper();
        if (fileCharacterFormat.equals("UTF_8")) {
            charset = StandardCharsets.UTF_8;
        } else {
            charset = Charset.forName("Shift_JIS");
        }

        try {

            logger.info(
                    "Inside generateDOPEnhancementFiles order no : {} admission status : {}",
                    order.getOrdersNumber(),
                    order.getAdmission().getStatus());
            logger.info("NCID : {}", resultDto.getNcId());
            String companyCode = order.getAdmission().getDealer().getCompanyCode();
            logger.info("generate digital notification file");
            DigitalNotificationDTO digitalNotificationDTO =
                    admissionRepository.fetchDigitalNotificationRecord(order.getAdmission());
            myPath =
                    getfilePath(
                            APPLICANT_LIST_DIGITAL_NOTIFICATON, resultDto.getNcId(), "");
            writer =
                    Files.newBufferedWriter(
                            myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            StatefulBeanToCsv<DigitalNotificationDTO> beanToCsv =
                    getDigitalNotificationWriter(writer);
            beanToCsv.write(digitalNotificationDTO);
            writer.flush();
            writer.close();
            sftpUpload.upload(myPath.toString(), remoteDir);
            logger.info(
                    "Digital notification content : {}",
                    objectMapper.writeValueAsString(digitalNotificationDTO));

            Admission admission = order.getAdmission();
            admission.setNcId(resultDto.getNcId());
            Admission updatedAdmission = admissionRepository.save(admission);

            order.setUploadKameri(true);
            Orders updatedOrder = ordersRepository.save(order);

            logger.info(
                    "Admission no: {} kameri flag is set to {}",
                    updatedAdmission.getId(),
                    updatedOrder.getUploadKameri());

        } catch (IOException e) {
            logger.error(
                    "IOException in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(
                    "Exception in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    @Override
    public void sendV2FilesToKameri() {
        logger.info("Inside send V2 files to kameri");
        LocalDateTime currentDateTime = LocalDateTime.now();
        Timestamp endDate = Timestamp.valueOf(currentDateTime);
        LocalDateTime localdateTime = currentDateTime.minusHours(24);
        Timestamp startDate = Timestamp.valueOf(localdateTime);
        logger.info("startDate : {} endDate : {}", startDate, endDate);
        List<OrdersV2> last24HrsOrders = ordersV2Repository.fetchOrdersForKameri(startDate, endDate);
        logger.info("size of last 24 hrs orders V2 is : {}", last24HrsOrders.size());
        processedOrders = 0L;
        last24HrsOrders.forEach(
                order -> {
                    uploadOrderV2ToKameri(order);
                });
        logger.info("size of last 24 hrs orders successfully processed is {}", processedOrders);

        logger.info("load bank id resetting for kamaeri");
        List<OrdersV2> resettingOrders = ordersV2Repository.fetchResettingOrdersForKameri(startDate, endDate);
        logger.info("size of resetting orders V2 is : {}", resettingOrders.size());
        processedOrders = 0L;
        resettingOrders.forEach(
                order -> {
                    uploadResettingOrderV2ToKameri(order);
                });
        logger.info("size of resetting orders successfully processed is {}", processedOrders);

        logger.info("load vin reset orders for kamaeri");
        List<OrdersV2> vinResettingOrders = ordersV2Repository.fetchVinResettingOrdersForKameri(startDate, endDate);
        logger.info("size of vin resetting orders V2 is : {}", vinResettingOrders.size());
        processedOrders = 0L;
        vinResettingOrders.forEach(
                order -> {
                    uploadResettingOrderV2ToKameri(order);
                });
        logger.info("size of vin resetting orders successfully processed is {}", processedOrders);
    }

    @Override
    public List<ResultDto> fetchMemberInfoByVinNumber(List<String> vin)
            throws KeyManagementException, CertificateException, NoSuchAlgorithmException,
            KeyStoreException, IOException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException,
            IllegalBlockSizeException {
        RestTemplate restTemplate = cwInitialSetUp();
        CarWingsRequestDto carWingsRequestDto = new CarWingsRequestDto();
        List<Object> orderInfo = new ArrayList<>();
        vin.forEach(
                v -> {
                    Map<String, Object> infoMap = new HashMap<>();
                    infoMap.put("vin", v);
                    infoMap.put("salesCompanyCd", "");
                    infoMap.put("orderNo", "");
                    orderInfo.add(infoMap);
                });
        carWingsRequestDto.setAspUser(ASP_USER);
        carWingsRequestDto.setAspPassword(userPassword);
        carWingsRequestDto.setRecordCount(orderInfo.size());
        OrderList orderList = new OrderList();
        orderList.setOrderInfo(orderInfo);
        return getResponseListDto(restTemplate, orderInfo);
    }

    @Transactional
    private void uploadVinResettingOrderV2ToKamaeri(OrdersV2 order) {
        Path myPath = null;
        BufferedWriter writer = null;
        Charset charset = null;
        ObjectMapper objectMapper = new ObjectMapper();
        if (fileCharacterFormat.equals("UTF_8")) {
            charset = StandardCharsets.UTF_8;
        } else {
            charset = Charset.forName("Shift_JIS");
        }

        try {

            logger.info(
                    "Inside uploadVinResettingOrderV2ToKamaeri order no : {} admission status : {}",
                    order.getOrdersNumber(),
                    order.getAdmission().getStatus());
            String companyCode = order.getAdmission().getDealer().getCompanyCode();
            if (STATUS_VIN_RESETTING.equals(order.getAdmission().getStatus())) {
                logger.info("generate Vin Reset file");
                VinResetDTO vinResetDTO =
                        admissionV2Repository.fetchVinResettingRecord(order.getAdmission());
                myPath =
                        getfilePath(
                                APPLICANT_LIST_WITHDRAW_VIN_RESET, order.getVinNumber(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<VinResetDTO> beanToCsv =
                        getVinResetWriter(writer);
                beanToCsv.write(vinResetDTO);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info(
                        "vin reset content : {}",
                        objectMapper.writeValueAsString(vinResetDTO));
            }
        } catch (IOException e) {
            logger.error(
                    "IOException in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(
                    "Exception in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    @Transactional
    private void uploadResettingOrderV2ToKameri(OrdersV2 order) {
        Path myPath = null;
        BufferedWriter writer = null;
        Charset charset = null;
        ObjectMapper objectMapper = new ObjectMapper();
        if (fileCharacterFormat.equals("UTF_8")) {
            charset = StandardCharsets.UTF_8;
        } else {
            charset = Charset.forName("Shift_JIS");
        }

        try {

            logger.info(
                    "Inside uploadOrderToKameri order no : {} admission status : {}",
                    order.getOrdersNumber(),
                    order.getAdmission().getStatus());
            String companyCode = order.getAdmission().getDealer().getCompanyCode();
            if (STATUS_BANK_ID_RESETTING.equals(order.getAdmission().getStatus())) {
                logger.info("generate Retry payment file");
                RetryPaymentV2DTO retryPaymentV2DTO =
                        admissionV2Repository.fetchBankIdResettingRecord(order.getAdmission());
                myPath =
                        getfilePath(
                                APPLICANT_LIST_RETRY_PAYMENT, order.getVinNumber(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<RetryPaymentV2DTO> beanToCsv =
                        getRetryPaymentV2Writer(writer);
                beanToCsv.write(retryPaymentV2DTO);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info(
                        "retry payment content : {}",
                        objectMapper.writeValueAsString(retryPaymentV2DTO));
                processedOrders++;
            }
        } catch (IOException e) {
            logger.error(
                    "IOException in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(
                    "Exception in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    @Transactional
    private void uploadOrderV2ToKameri(OrdersV2 order) {
        Path myPath = null;
        BufferedWriter writer = null;
        Charset charset = null;
        ObjectMapper objectMapper = new ObjectMapper();
        if (fileCharacterFormat.equals("UTF_8")) {
            charset = StandardCharsets.UTF_8;
        } else {
            charset = Charset.forName("Shift_JIS");
        }
        try {

            logger.info(
                    "Inside uploadOrderToKameri order no : {} admission status : {}",
                    order.getOrdersNumber(),
                    order.getAdmission().getStatus());
            String companyCode = "";
            if (Constants.ADMISSION_SOURCE_HOME.equals(order.getSource())) {
                DealerAddress dealerAddress = dealerAddressRepository.findByAdmissionId(order.getAdmission().getId());
                companyCode = dealerAddress.getCompanyCode();
            } else if (ADMISSION_SOURCE_DEALER.equals(order.getSource())) {
                companyCode = order.getAdmission().getDealer().getCompanyCode();
            }
            if (order.getVehicleTransfer() != null && order.getVehicleTransfer()) {
                logger.info("vehicle transfer is available");
                VehicleTransferRecordV2Dto vehicleTransferRecordDto =
                        admissionV2Repository.fetchVehicleTransferRecord(order.getAdmission());
                myPath =
                        getfilePath(
                                APPLICANT_LIST_TRANSFER_CONFIRMATION, order.getVinNumber(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<VehicleTransferRecordV2Dto> beanToCsv =
                        getVehicleTransferV2Writer(writer);
                beanToCsv.write(vehicleTransferRecordDto);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info(
                        "vehicle transfer content : {}",
                        objectMapper.writeValueAsString(vehicleTransferRecordDto));
            }

            if ("SA".equals(order.getVinSearchStatus())) {
                logger.info("with draw file generation started");
                WithDrawDTO withDrawDTO =
                        admissionV2Repository.fetchWithDrawRecord(order.getAdmission());
                myPath =
                        getfilePath(
                                APPLICANT_LIST_TRANSFER_CONFIRMATION, order.getVinNumber(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<WithDrawDTO> beanToCsv = getWithDrawWriter(writer);
                beanToCsv.write(withDrawDTO);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info(
                        "vehicle transfer content : {}",
                        objectMapper.writeValueAsString(withDrawDTO));
            }

            if ("nfs".equals(order.getPaymentMethod().getName())) {
                logger.info("payment type is nfs");
                NfsPaymentRecordV2Dto nfsPaymentRecordDto =
                        admissionV2Repository.fetchNfsPaymentRecord(order.getAdmission());
                myPath = getfilePath(APPLICANT_LIST_NFS, order.getVinNumber(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<NfsPaymentRecordV2Dto> beanToCsv = getNfsV2Writer(writer);
                beanToCsv.write(nfsPaymentRecordDto);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info("nfs content : {}", objectMapper.writeValueAsString(nfsPaymentRecordDto));
            } else if ("credit-card".equals(order.getPaymentMethod().getName()) || PAYMENT_METHOD_BANK.equals(order.getPaymentMethod().getName())) {
                logger.info("payment type is credit-card");
                DigitalAdmissionRecordV2Dto digitalAdmissionRecordDto =
                        admissionV2Repository.fetchDigitalAdmissionRecord(order.getAdmission());
                myPath = getfilePath(APPLICANT_LIST_RPA, order.getVinNumber(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<DigitalAdmissionRecordV2Dto> beanToCsv =
                        getDigitalAdmissionV2Writer(writer);
                beanToCsv.write(digitalAdmissionRecordDto);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info("RPA content : {}", objectMapper.writeValueAsString(digitalAdmissionRecordDto));
            }
            logger.info("file {} uploaded successfully", myPath.getFileName());

            order.setUploadKameri(true);
            OrdersV2 updatedOrder = ordersV2Repository.save(order);

            logger.info(
                    "Admission no: {} status is set to {}",
                    updatedOrder.getAdmission().getId(),
                    updatedOrder.getUploadKameri());

            processedOrders++;
        } catch (IOException e) {
            logger.error(
                    "IOException in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(
                    "Exception in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    public void sendFiles() {
        logger.info("Inside send files to kameri");
        LocalDateTime currentDateTime = LocalDateTime.now();
        Timestamp endDate = Timestamp.valueOf(currentDateTime);
        LocalDateTime localdateTime = currentDateTime.minusHours(24);
        Timestamp startDate = Timestamp.valueOf(localdateTime);
        logger.info("startDate : {} endDate : {}", startDate, endDate);
        List<Orders> last24HrsOrders = ordersRepository.findLast24HrsOrders(startDate, endDate);
        logger.info("size of last 24 hrs orders is : {}", last24HrsOrders.size());
        processedOrders = 0L;
        if (!last24HrsOrders.isEmpty()) {
            createDirectoryForKameriFiles();
        }
        last24HrsOrders.forEach(
                order -> {
                    uploadOrderToKameri(order);
                });
        logger.info("size of last 24 hrs orders successfully processed is {}", processedOrders);

        logger.info("load bank id resetting for kamaeri");
        List<Orders> resettingOrders = ordersRepository.fetchResettingOrdersForKameri(startDate, endDate);
        logger.info("size of resetting orders V2 is : {}", resettingOrders.size());
        processedOrders = 0L;
        resettingOrders.forEach(
                order -> {
                    uploadResettingOrderToKameri(order);
                });
        logger.info("size of resetting orders successfully processed is {}", processedOrders);
    }

    private void createDirectoryForKameriFiles() {
        logger.info("Inside createDirectoryForKameriFiles");
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateTimeInfo = dateFormat.format(new Date());
        File file = new File(System.getProperty("user.home") + File.separator + dateTimeInfo);
        if (file.exists()) {
            logger.info("Directory {} already exists", dateTimeInfo);
        } else {
            if (file.mkdir()) {
                logger.info("Directory {} created successfully", dateTimeInfo);
            }
        }
    }

    @Transactional
    private void uploadResettingOrderToKameri(Orders order) {
        Path myPath = null;
        BufferedWriter writer = null;
        Charset charset = null;
        ObjectMapper objectMapper = new ObjectMapper();
        if (fileCharacterFormat.equals("UTF_8")) {
            charset = StandardCharsets.UTF_8;
        } else {
            charset = Charset.forName("Shift_JIS");
        }

        try {

            logger.info(
                    "Inside uploadOrderToKameri order no : {} admission status : {}",
                    order.getOrdersNumber(),
                    order.getAdmission().getStatus());
            String companyCode = order.getAdmission().getDealer().getCompanyCode();
            if (STATUS_BANK_ID_RESETTING.equals(order.getAdmission().getStatus())) {
                logger.info("generate Retry payment file");
                RetryPaymentDTO retryPaymentDTO =
                        admissionRepository.fetchBankIdResettingRecord(order.getAdmission());
                myPath =
                        getfilePath(
                                APPLICANT_LIST_RETRY_PAYMENT, order.getOrderNumberPs(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<RetryPaymentDTO> beanToCsv =
                        getRetryPaymentWriter(writer);
                beanToCsv.write(retryPaymentDTO);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info(
                        "retry payment content : {}",
                        objectMapper.writeValueAsString(retryPaymentDTO));
                processedOrders++;
            }
        } catch (IOException e) {
            logger.error(
                    "IOException in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(
                    "Exception in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    @Transactional
    private void uploadOrderToKameri(Orders order) {
        Path myPath = null;
        BufferedWriter writer = null;
        Charset charset = null;
        ObjectMapper objectMapper = new ObjectMapper();
        if (fileCharacterFormat.equals("UTF_8")) {
            charset = StandardCharsets.UTF_8;
        } else {
            charset = Charset.forName("Shift_JIS");
        }

        try {
            logger.info(
                    "Inside uploadOrderToKameri order no : {} admission status : {}",
                    order.getOrdersNumber(),
                    order.getAdmission().getStatus());
            String companyCode = order.getAdmission().getDealer().getCompanyCode();
            if (order.getVehicleTransfer()) {
                logger.info("vehicle transfer is available");
                VehicleTransferRecordDto vehicleTransferRecordDto =
                        admissionRepository.fetchVehicleTransferRecord(order.getAdmission());
                myPath =
                        getfilePath(
                                APPLICANT_LIST_TRANSFER_CONFIRMATION, order.getOrderNumberPs(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<VehicleTransferRecordDto> beanToCsv = getVehicleTransferWriter(writer);
                beanToCsv.write(vehicleTransferRecordDto);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info(
                        "vehicle transfer content : {}",
                        objectMapper.writeValueAsString(vehicleTransferRecordDto));
            }

            if (PAYMENT_METHOD_DIGITAL.equals(order.getPaymentMethod().getName()) && PACKAGE_BASIC_OPERATOR_SERVICE.equals(order.getPackagePlan().getPackagePlanName())) {
                logger.info("generate mop operator file");
                MopOperatorDTO mopOperatorDTO = admissionRepository.fetchMopOperatorRecord(order.getAdmission());
                myPath = getfilePath(APPLICANT_LIST_MOP_OPERATOR, order.getOrderNumberPs(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<MopOperatorDTO> beanToCsv = getMopOperatorWriter(writer);
                beanToCsv.write(mopOperatorDTO);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info("mop operator : {}", objectMapper.writeValueAsString(mopOperatorDTO));
            } else if ("nfs".equals(order.getPaymentMethod().getName())) {
                logger.info("payment type is nfs");
                NfsPaymentRecordDto nfsPaymentRecordDto = admissionRepository.fetchNfsPaymentRecord(order.getAdmission());
                myPath = getfilePath(APPLICANT_LIST_NFS, order.getOrderNumberPs(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<NfsPaymentRecordDto> beanToCsv = getNfsWriter(writer);
                beanToCsv.write(nfsPaymentRecordDto);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info("nfs content : {}", objectMapper.writeValueAsString(nfsPaymentRecordDto));
            } else if ("credit-card".equals(order.getPaymentMethod().getName()) || PAYMENT_METHOD_BANK.equals(order.getPaymentMethod().getName())) {
                logger.info("payment type is credit-card");
                DigitalAdmissionRecordDto digitalAdmissionRecordDto =
                        admissionRepository.fetchDigitalAdmissionRecord(order.getAdmission());
                myPath = getfilePath(APPLICANT_LIST_RPA, order.getOrderNumberPs(), companyCode);
                writer =
                        Files.newBufferedWriter(
                                myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                StatefulBeanToCsv<DigitalAdmissionRecordDto> beanToCsv = getDigitalAdmissionWriter(writer);
                beanToCsv.write(digitalAdmissionRecordDto);
                writer.flush();
                writer.close();
                sftpUpload.upload(myPath.toString(), remoteDir);
                logger.info("RPA content : {}", objectMapper.writeValueAsString(digitalAdmissionRecordDto));
            }
            logger.info("file {} uploaded successfully", myPath.getFileName());

            order.setUploadKameri(true);
            Orders updatedOrder = ordersRepository.save(order);

            logger.info(
                    "Admission no: {} status is set to {}",
                    updatedOrder.getAdmission().getId(),
                    updatedOrder.getUploadKameri());
            processedOrders++;
        } catch (IOException e) {
            logger.error(
                    "IOException in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(
                    "Exception in uploadOrderToKameri orderno={} with exception={} : ",
                    order.getOrdersNumber(),
                    e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    @Override
    public void sendNcIdToNewCarCus() {
        logger.info("Inside sendNcIdToNewCarCus");
        List<Admission> admissions =
                admissionRepository.findByNcIdNotNullAndStatusNot(Constants.STATUS_EMAIL_SENT);
        logger.info("FindByNcIdNotNullAndStatusNot admission count {}", admissions.size());

        admissions.forEach(
                admission -> {
                    logger.info("Sending NC-ID to customer {}", admission.getUser().getId());
                    String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
                    logger.info("API service URL {}", serviceLocation);
                    HttpHeaders headers = new HttpHeaders();
                    headers.set("principalId", admission.getUser().getId().toString());
                    HttpEntity<String> request = new HttpEntity<>(headers);
                    try {
                        if (CARWINGS_STATUS_SA.equals(admission.getCwStatus())) {
                            Orders orders = ordersRepository.findByAdmissionId(admission.getId());
                            if (orders.getPaymentMethod() != null
                                    && (Constants.CREDIT_PAYMENT.equals(orders.getPaymentMethod().getName())
                                    || Constants.NFS_PAYMENT.equals(orders.getPaymentMethod().getName()))) {
                                String url = HTTP + serviceLocation + NEW_CAR_NC_ID;
                                ResponseEntity<Customer> response =
                                        restTemplate.postForEntity(url, request, Customer.class);
                                logger.info("NC-ID Mail sent for user {}", response.getBody());
                            }
                        } else if (CARWINGS_STATUS_SC.equals(admission.getCwStatus())) {
                            String url = HTTP + serviceLocation + NEW_CAR_CANCEL;
                            ResponseEntity<Customer> response =
                                    restTemplate.exchange(url, HttpMethod.GET, request, Customer.class);
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"cancel Admission Mail sent for user"+ response.getBody());
                        }
                    } catch (Exception ex) {
                        logger.info("Exception in sendNcIdToNewCarCus {} {}", admission.getId(), ex.getMessage());
                    }
                });
    }

    @Override
    public void sendNcIdToUsedCarCus() {
        logger.info("Inside sendNcIdToUsedCarCus");
        List<AdmissionV2> admissions =
                admissionV2Repository.findByNcIdNotNullAndStatusNot(Constants.STATUS_EMAIL_SENT);
        logger.info("FindByNcIdNotNullAndStatusNot admission count {}", admissions.size());

        admissions.forEach(
                admission -> {
                    logger.info("SendSending NC-ID to customer {}", admission.getUser().getId());
                    String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
                    logger.info("API service URL {}", serviceLocation);
                    HttpHeaders headers = new HttpHeaders();
                    headers.set(PRINCIPAL_ID, admission.getUser().getId().toString());
                    HttpEntity<String> request = new HttpEntity<>(headers);

                    try {
                        if (CARWINGS_STATUS_SA.equals(admission.getCwStatus())) {
                            OrdersV2 orders = ordersV2Repository.findByAdmissionId(admission.getId());
                            if (orders.getPaymentMethod() != null
                                    && (Constants.CREDIT_PAYMENT.equals(orders.getPaymentMethod().getName())
                                    || Constants.NFS_PAYMENT.equals(orders.getPaymentMethod().getName()))) {
                                String url = HTTP + serviceLocation + USED_CAR_NC_ID;
                                ResponseEntity<Customer> response =
                                        restTemplate.postForEntity(url, request, Customer.class);
                                logger.info("NC-ID Mail sent for user {}", response.getBody());
                            }
                        } else if (CARWINGS_STATUS_SC.equals(admission.getCwStatus())) {
                            String url = HTTP + serviceLocation + USED_CAR_CANCEL;
                            ResponseEntity<Customer> response =
                                    restTemplate.exchange(url, HttpMethod.GET, request, Customer.class);
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"cancel Admission Mail sent for user  :"+response.getBody() );
                        }
                    } catch (Exception ex) {
                        logger.info("Exception in sendNcIdToUsedCarCus {} {}", admission.getId(), ex.getMessage());
                    }
                });
    }

    private StatefulBeanToCsv<RetryPaymentDTO> getRetryPaymentWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<RetryPaymentDTO> beanToCsv = null;
        try {
            final CustomMappingStrategy<RetryPaymentDTO> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(RetryPaymentDTO.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<RetryPaymentDTO>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<VinResetDTO> getVinResetWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<VinResetDTO> beanToCsv = null;
        try {
            final CustomMappingStrategy<VinResetDTO> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(VinResetDTO.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<VinResetDTO>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }


    private StatefulBeanToCsv<RetryPaymentV2DTO> getRetryPaymentV2Writer(
            BufferedWriter writer) {
        StatefulBeanToCsv<RetryPaymentV2DTO> beanToCsv = null;
        try {
            final CustomMappingStrategy<RetryPaymentV2DTO> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(RetryPaymentV2DTO.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<RetryPaymentV2DTO>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<VehicleTransferRecordV2Dto> getVehicleTransferV2Writer(
            BufferedWriter writer) {
        StatefulBeanToCsv<VehicleTransferRecordV2Dto> beanToCsv = null;
        try {
            final CustomMappingStrategy<VehicleTransferRecordV2Dto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(VehicleTransferRecordV2Dto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<VehicleTransferRecordV2Dto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<VehicleTransferRecordDto> getVehicleTransferWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<VehicleTransferRecordDto> beanToCsv = null;
        try {
            final CustomMappingStrategy<VehicleTransferRecordDto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(VehicleTransferRecordDto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<VehicleTransferRecordDto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<WithDrawDTO> getWithDrawWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<WithDrawDTO> beanToCsv = null;
        try {
            final CustomMappingStrategy<WithDrawDTO> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(WithDrawDTO.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<WithDrawDTO>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<DigitalNotificationDTO> getDigitalNotificationWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<DigitalNotificationDTO> beanToCsv = null;
        try {
            final CustomMappingStrategy<DigitalNotificationDTO> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(DigitalNotificationDTO.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<DigitalNotificationDTO>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<NfsPaymentRecordV2Dto> getNfsV2Writer(BufferedWriter writer) {
        StatefulBeanToCsv<NfsPaymentRecordV2Dto> beanToCsv = null;
        try {
            final CustomMappingStrategy<NfsPaymentRecordV2Dto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(NfsPaymentRecordV2Dto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<NfsPaymentRecordV2Dto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<MopOperatorDTO> getMopOperatorWriter(BufferedWriter writer) {
        StatefulBeanToCsv<MopOperatorDTO> beanToCsv = null;
        try {
            final CustomMappingStrategy<MopOperatorDTO> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(MopOperatorDTO.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<MopOperatorDTO>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<NfsPaymentRecordDto> getNfsWriter(BufferedWriter writer) {
        StatefulBeanToCsv<NfsPaymentRecordDto> beanToCsv = null;
        try {
            final CustomMappingStrategy<NfsPaymentRecordDto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(NfsPaymentRecordDto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<NfsPaymentRecordDto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<DigitalAdmissionRecordV2Dto> getDigitalAdmissionV2Writer(
            BufferedWriter writer) {
        StatefulBeanToCsv<DigitalAdmissionRecordV2Dto> beanToCsv = null;
        try {
            final CustomMappingStrategy<DigitalAdmissionRecordV2Dto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(DigitalAdmissionRecordV2Dto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<DigitalAdmissionRecordV2Dto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private StatefulBeanToCsv<DigitalAdmissionRecordDto> getDigitalAdmissionWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<DigitalAdmissionRecordDto> beanToCsv = null;
        try {
            final CustomMappingStrategy<DigitalAdmissionRecordDto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(DigitalAdmissionRecordDto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<DigitalAdmissionRecordDto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return beanToCsv;
    }

    private Path getfilePath(String fileName, String profitSystemOrderNumber, String companyCode) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateTimeInfo = dateFormat.format(new Date());
        final String CSV_LOCATION = getFileName(fileName, profitSystemOrderNumber, companyCode);
        Path myPath =
                Paths.get(
                        System.getProperty("user.home")
                                + File.separator
                                + CSV_LOCATION);
        logger.info(
                "filename for profitSystemOrderNumber : {} is {} ",
                profitSystemOrderNumber,
                myPath.getFileName());
        logger.info("File path is : {} ", myPath.toAbsolutePath());
        return myPath;
    }

    private void createAndUploadToKameri(String fileName, String fileType) {
        logger.info("createAndUploadToKameri");
        final String CSV_LOCATION = getFileName(fileName);
        Path myPath = Paths.get(System.getProperty("user.home") + File.separator + CSV_LOCATION);
        BufferedWriter writer = null;
        try {
            writer = Files.newBufferedWriter(myPath, StandardCharsets.UTF_8);
            LocalDateTime currentDateTime = LocalDateTime.now();
            Timestamp endDate = Timestamp.valueOf(currentDateTime);
            LocalDateTime localdateTime = currentDateTime.minusHours(24);
            Timestamp startDate = Timestamp.valueOf(localdateTime);

            if (VEHICLE.equals(fileType)) {
                final CustomMappingStrategy<VehicleTransferRecordDto> mappingStrategy =
                        new CustomMappingStrategy<>();
                mappingStrategy.setType(VehicleTransferRecordDto.class);
                StatefulBeanToCsv<VehicleTransferRecordDto> beanToCsv =
                        new StatefulBeanToCsvBuilder<VehicleTransferRecordDto>(writer)
                                .withMappingStrategy(mappingStrategy)
                                .build();
                logger.info("inside kameri startdate={},enddate={}", startDate, endDate);
            }
            if (DIGITAL_ADMISSION.equals(fileType)) {
                final CustomMappingStrategy<DigitalAdmissionRecordDto> mappingStrategy =
                        new CustomMappingStrategy<>();
                mappingStrategy.setType(DigitalAdmissionRecordDto.class);
                StatefulBeanToCsv<DigitalAdmissionRecordDto> beanToCsv =
                        new StatefulBeanToCsvBuilder(writer).withMappingStrategy(mappingStrategy).build();
                logger.info("inside kameri startdate={},enddate={}", startDate, endDate);
            }
            if (NFS_PAYMENT.equals(fileType)) {
                {
                    final CustomMappingStrategy<NfsPaymentRecordDto> mappingStrategy =
                            new CustomMappingStrategy<>();
                    mappingStrategy.setType(NfsPaymentRecordDto.class);
                    StatefulBeanToCsv<NfsPaymentRecordDto> beanToCsv =
                            new StatefulBeanToCsvBuilder(writer).withMappingStrategy(mappingStrategy).build();
                    logger.info("inside kameri startdate={},enddate={}", startDate, endDate);
                }
            }

            writer.flush();
            writer.close();
            logger.info("contents of the file in scheduler");
            logger.info("size of the file in scheduler={}", FileUtils.sizeOf(myPath.toFile()));
            try (BufferedReader br = Files.newBufferedReader(myPath)) {

                /** CSV file delimiter */
                String DELIMITER = ",";

                /** read the file line by line */
                String line;
                while ((line = br.readLine()) != null) {
                    logger.info("contents columns in scheduler");
                    /** convert line into columns */
                    String[] columns = line.split(DELIMITER);

                    /** print all columns */
                    System.out.println("User[" + String.join(", ", columns) + "]");
                }

            } catch (IOException ex) {
                ex.printStackTrace();
            }
            sftpUpload.upload(myPath.toString());
        } catch (IOException ex) {
            logger.error(
                    "error occurred while writing contents to csv file={} with exception={}",
                    fileName,
                    ex.getMessage());
        } catch (Exception ex) {
            logger.error(
                    "error occurred while writing contents to csv file={} with exception={}",
                    fileName,
                    ex.getMessage());
        } finally {
            if (writer != null) {
                try {
                    writer.flush();
                    writer.close();
                } catch (IOException e) {
                    /** ignore */
                }
            }
        }
    }

    private String getFileName(String name) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateTimeInfo = dateFormat.format(new Date());
        return dateTimeInfo.concat(String.format("_%s.csv", name));
    }

    private String getFileName(String name, String profitSystemOrderNumber, String companyCode) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateTimeInfo = dateFormat.format(new Date());
        return dateTimeInfo
                .concat(String.format("_%s", name))
                .concat(String.format("_%s.csv", profitSystemOrderNumber + "_" + companyCode));
    }

    private void saveCarwingsDataToOrder(ResultDto result, Orders order, Date formattedNcJoinedDate) {
        order.setNcJoinedDate(formattedNcJoinedDate);
        Date firstRegistrationDateFormated = null;
        try {
            firstRegistrationDateFormated =
                    new SimpleDateFormat("yyyyMM").parse(result.getFirstRegistDate());
        } catch (ParseException e) {
            logger.error("exception occurred while formatting Registration date" + e.getMessage());
        }
        order.setFirstRegisteredDate(firstRegistrationDateFormated);
        Date chargeStartDateFormated = null;
        try {
            chargeStartDateFormated = new SimpleDateFormat("yyyyMMdd").parse(result.getChargeStartDate());
        } catch (ParseException e) {
            logger.error("exception occurred while formatting Registration date" + e.getMessage());
        }
        order.setChargeStartDate(chargeStartDateFormated);
        Date serviceUpdateDateFormated = null;
        try {
            serviceUpdateDateFormated =
                    new SimpleDateFormat("yyyyMMdd").parse(result.getChargeUpdateDate());
        } catch (ParseException e) {
            logger.error("exception occurred while formatting Service update date" + e.getMessage());
        }
        order.setServiceUpdateDate(serviceUpdateDateFormated);
        order.setAdopterId(result.getAdaptorId());
        order.setRegisterNumber(result.getRegNo());
        order.setCwVinNumber(result.getVin());
        order.setPlanPrice(result.getPlanPrice());
        order.setModelNameCw(result.getModelName());
        ordersRepository.save(order);
    }

    private CarWingsVinSearchResponseDTO fetchVinDetailsFromCarwings(
            VehicleInfoRequestDTO vehicleInfoRequest, String lang) throws KeyManagementException, CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException {
        CarWingsVinSearchResponseDTO response = null;
        try {
            RestTemplate restTemplate = cwInitialSetUp();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            CarWingsVinSearchRequestDTO carwingsVinSearchRequestDTO = new CarWingsVinSearchRequestDTO();
            carwingsVinSearchRequestDTO.setAspUser(ASP_USER);
            carwingsVinSearchRequestDTO.setAspPassword(userPassword);
            carwingsVinSearchRequestDTO.setVin(vehicleInfoRequest.getVinNumber());
            if (vehicleInfoRequest.getNaviId() != null && !vehicleInfoRequest.getNaviId().isEmpty()) {
                carwingsVinSearchRequestDTO.setNaviId(vehicleInfoRequest.getNaviId());
            } else {
                carwingsVinSearchRequestDTO.setNaviId("");
            }
            String resultString = objectMapper.writeValueAsString(carwingsVinSearchRequestDTO);
            logger.info("car wings vin search dto={}", resultString);
            HttpEntity<String> entity = new HttpEntity<>(resultString, headers);
            try {
                ResponseEntity<CarWingsVinSearchResponseDTO> responseEntity =
                        restTemplate.postForEntity(
                                carWingsVinSearchUrl, entity, CarWingsVinSearchResponseDTO.class);
                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    logger.info("response success");
                    response = responseEntity.getBody();
                } else if (responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
                    logger.info("bad request");
                    List<CarWingsVinSearchResponseDTO> listResponse =
                            (List<CarWingsVinSearchResponseDTO>) responseEntity.getBody();
                    response = listResponse.get(0);
                } else {
                    logger.info("error response");
                    response = responseEntity.getBody();
                }
            } catch (HttpClientErrorException ex) {
                logger.info("error status code : {}, text : {}", ex.getStatusCode(), ex.getStatusText());
                ResponseEntity<String> res = new ResponseEntity<String>(ex.getResponseBodyAsString(), ex.getResponseHeaders(), ex.getStatusCode());
                response = objectMapper.readValue(res.getBody(), CarWingsVinSearchResponseDTO.class);
            }
            logger.info("car wings response={}", objectMapper.writeValueAsString(response));
        } catch (Exception e) {
            logger.info("Error in fetchVinDetailsFromCarwings : {}", e.getMessage());
            e.printStackTrace();
        }
        return response;
    }

    @Override
    public AdmissionV2FetchResponseDTO fetchVehicleInfo(
            VehicleInfoRequestDTO vehicleInfoRequest, String lang) {
        AdmissionV2FetchResponseDTO response = null;
        if (Constants.VEHICLE_TYPE_NEW_CAR.equals(vehicleInfoRequest.getVehicleType())) {
            response = fetchNewCarVehicleInfo(vehicleInfoRequest, lang);
        } else if (Constants.VEHICLE_TYPE_USED_CAR.equals(vehicleInfoRequest.getVehicleType())) {
            response = fetchUsedCarVehicleInfo(vehicleInfoRequest, lang);
        }
        return response;
    }

    private AdmissionV2FetchResponseDTO checkVinAndFirstRegisteredDate(
            String firstRegDate, String expiryDate) {
        AdmissionV2FetchResponseDTO response = null;
        logger.info("Inside checkVinAndFirstRegisteredDate");
        String errorVehicleTypeUsedCar = "Your vehicle is an Used vehicle.";
        try {
             if (firstRegDate != null && !firstRegDate.isEmpty()
                    && expiryDate != null && !expiryDate.isEmpty()) {
                String firstRegFormat = firstRegDate.contains("-") ? "yyyy-MM" : "yyyyMM";
                String expDateFormat = expiryDate.contains("-") ? "yyyy-MM" : "yyyyMM";
                DateTimeFormatter firstRegFormatter = DateTimeFormatter.ofPattern(firstRegFormat);
                DateTimeFormatter expDateFormatter = DateTimeFormatter.ofPattern(expDateFormat);
                YearMonth firstRegMonth = YearMonth.parse(firstRegDate, firstRegFormatter);
                YearMonth expDateMonth = YearMonth.parse(expiryDate, expDateFormatter);
                if (firstRegMonth.getMonth() != expDateMonth.getMonth()) {
                    response = new AdmissionV2FetchResponseDTO();
                    response.setResponseCode(STATUS_206);
                    response.setErrorMessage(errorVehicleTypeUsedCar);
                }
            }
        } catch (Exception e) {
            logger.info("exception in checkVinAndFirstRegisteredDate");
            e.printStackTrace();
        }
        return response;
    }

    private AdmissionV2FetchResponseDTO fetchUsedCarVehicleInfo(
            VehicleInfoRequestDTO vehicleInfoRequest, String lang) {
        logger.info("Inside fetchUsedCarVehicleInfo");
        AdmissionV2FetchResponseDTO vehicleInfoResponse = new AdmissionV2FetchResponseDTO();
        vehicleInfoResponse.setVehicleNumber(vehicleInfoRequest.getVehicleNumber());
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"fetchUsedCarVehicleInfo VehicleNumber  :"+ vehicleInfoRequest.getVehicleNumber() );
        vehicleInfoResponse.setRegistrationDate(vehicleInfoRequest.getRegistrationDate());
        vehicleInfoResponse.setFirstRegistrationDate(vehicleInfoRequest.getFirstRegistrationDate());
        vehicleInfoResponse.setExpiryDate(vehicleInfoRequest.getExpiryDate());
        vehicleInfoResponse.setVinNumber(vehicleInfoRequest.getVinNumber());
        try {
            if (!StringUtils.isEmpty(vehicleInfoRequest.getVinNumber())) {
                vehicleInfoRequest.setVinNumber(vehicleInfoRequest.getVinNumber().toUpperCase());
            }

            if (!StringUtils.isEmpty(vehicleInfoRequest.getNaviId())) {
                vehicleInfoRequest.setNaviId(vehicleInfoRequest.getNaviId().toUpperCase());
            }

            if (vehicleInfoRequest.getSkipNaviId() == null) {
                vehicleInfoRequest.setSkipNaviId(false);
            }

            logger.info("make request for vin search");
            CarWingsVinSearchResponseDTO carwingsVehicleResponse = null;
            carwingsVehicleResponse = fetchVinDetailsFromCarwings(vehicleInfoRequest, lang);

            if ("0".equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("Carwings response success code {}", carwingsVehicleResponse.getStatus());
                if (!CW_VIN_RESPONSE_IVI_TRUE.equals(carwingsVehicleResponse.getIviFlg())
                        && !vehicleInfoRequest.getSkipNaviId()
                        && (vehicleInfoRequest.getNaviId() == null
                        || vehicleInfoRequest.getNaviId().isEmpty())) {
                    logger.info("DOP falg is true");
                    vehicleInfoResponse.setResponseCode("204"); String errorVehicleTypeNewCar = "Your vehicle is a New vehicle.";
                    vehicleInfoResponse.setErrorMessage("Navi ID is mandatory for DOP");
                    return vehicleInfoResponse;
                } else if (!vehicleInfoRequest.getSkipNaviId()
                        && vehicleInfoRequest.getNaviId() != null
                        && vehicleInfoRequest.getNaviId().length() > 12) {
                    vehicleInfoResponse.setResponseCode("204");
                    vehicleInfoResponse.setErrorMessage("Navi ID length should be between 1 and 12");
                    return vehicleInfoResponse;
                }

                String vin = carwingsVehicleResponse.getVin();
                if (carwingsVehicleResponse.getModelName() != null) {
                    carwingsVehicleResponse =
                            vinSearchPatternForModel(vehicleInfoRequest, lang, carwingsVehicleResponse);
                    logger.info("set model");
                    String modelName = carwingsVehicleResponse.getModelName();
                    if (CW_LEAF.equals(modelName)) {
                        vehicleInfoResponse.setCwModel(
                                getLeafModelV2(vin, lang, VEHICLE_CATEGORY_USED_CAR));
                    } else {
                        vehicleInfoResponse.setCwModel(
                                getModelV2(modelName, lang, VEHICLE_CATEGORY_USED_CAR));
                    }
                } else {
                    vehicleInfoResponse.setCwModel(null);
                }
                vehicleInfoResponse.setModels(getModelV2Info(lang, VEHICLE_CATEGORY_USED_CAR));
                vehicleInfoResponse.setPaymentTypes(getPaymentMethod(lang));
                vehicleInfoResponse.setRegistrationDate(vehicleInfoRequest.getRegistrationDate());
                vehicleInfoResponse.setFirstRegistrationDate(vehicleInfoRequest.getFirstRegistrationDate());
                vehicleInfoResponse.setDopFlg(!CW_VIN_RESPONSE_IVI_TRUE.equals(carwingsVehicleResponse.getIviFlg()));
                vehicleInfoResponse.setOldCwId(carwingsVehicleResponse.getUserId());
                if (!vehicleInfoRequest.getSkipNaviId()
                        && vehicleInfoRequest.getNaviId() != null
                        && !vehicleInfoRequest.getNaviId().isEmpty()
                        && vehicleInfoResponse.getDopFlg()) {
                    vehicleInfoResponse.setNaviId(carwingsVehicleResponse.getAdaptorId());
                    if (vehicleInfoResponse.getNaviId() != null && vehicleInfoResponse.getNaviId().length() > 1) {
                        logger.info("check navi reference repo");
                        String adaptorKind = vehicleInfoResponse.getNaviId().substring(0, 1);
                        NaviReference naviReference = naviReferenceRepository.findByAdaptorKind(adaptorKind);
                        if (naviReference != null && NAVI_REFERENCE_FLAG.containsKey(naviReference.getDopFlag())) {
                            vehicleInfoResponse.setDopValue(NAVI_REFERENCE_FLAG.get(naviReference.getDopFlag()));
                            logger.info("navi reference flag : {}", naviReference.getDopFlag());
                        }
                    }
                }
                vehicleInfoResponse.setColors(
                        fetchColor(
                                vehicleInfoRequest.getVinNumber(), carwingsVehicleResponse.getModelName(), lang));
                if (carwingsVehicleResponse.getColorName() != null) {
                    Optional<Color> color =
                            colorRepository.getColorByModelCWColorName(
                                    carwingsVehicleResponse.getModelName(), carwingsVehicleResponse.getColorName());
                    vehicleInfoResponse.setColor(color.isPresent() ? color.get().getSosColor() : null);
                    vehicleInfoResponse.setColorCode(color.isPresent() ? color.get().getColorName() : null);
                }
                getReasonInfo(lang, vehicleInfoResponse);
                vehicleInfoResponse =
                        validateCarwingsResponse(vehicleInfoResponse, carwingsVehicleResponse, VEHICLE_TYPE_USED_CAR);
            } else if (VEHICLE_NOT_FOUND.equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("Carwings response error code {}", carwingsVehicleResponse.getStatus());
                vehicleInfoResponse = vinSearchPattern(vehicleInfoResponse, lang, VEHICLE_CATEGORY_USED_CAR);
                vehicleInfoResponse =
                        validateCarwingsResponse(vehicleInfoResponse, carwingsVehicleResponse, VEHICLE_TYPE_USED_CAR);
            } else if (VIN_NAVIID_NOT_MATCH.equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("Carwings response error Data code {}", carwingsVehicleResponse.getStatus());
                if (vehicleInfoRequest.getNaviId() != null) {
                    vehicleInfoResponse = vinSearchPattern(vehicleInfoResponse, lang, VEHICLE_CATEGORY_USED_CAR);
                    vehicleInfoResponse =
                            validateCarwingsResponse(vehicleInfoResponse, carwingsVehicleResponse, VEHICLE_TYPE_USED_CAR);
                } else {
                    vehicleInfoResponse.setResponseCode(STATUS_206);
                    vehicleInfoResponse.setErrorMessage(VIN_SEARCH_ERROR_DATA);
                }
            } else if (MEMBER_MORE_EXIST.equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("Carwings response error Data code {}", carwingsVehicleResponse.getStatus());
                vehicleInfoResponse.setResponseCode(STATUS_206);
                vehicleInfoResponse.setErrorMessage(VIN_SEARCH_ERROR_DATA);
            } else {
                logger.info("Carwings response System error code {}", carwingsVehicleResponse.getStatus());
                vehicleInfoResponse.setResponseCode(STATUS_206);
                vehicleInfoResponse.setErrorMessage(VIN_SEARCH_SYSTEM_ERROR);
            }
        } catch (Exception e) {
            logger.info("Error in fetchUsedCarVehicleInfo");
            e.printStackTrace();
        }
        return vehicleInfoResponse;
    }

    @Transactional
    private ModelV2DTO getModelV2(String cwModelName, String lang, Set<String> vehicleType) {
        logger.info("Inside getModelV2");
        ModelV2DTO res = null;
        try {
            mylogger.info(
                    org.owasp.esapi.Logger.SECURITY_SUCCESS,
                    "cwModelName :"+ cwModelName
                    +"lang :"+lang
                    + "vechicleType :"+objectMapper.writeValueAsString(vehicleType));
            res =
                    convertModelV2EntityToDTO(
                            modelV2Repository.findByCwModelNameAndLangCodeAndVehicleTypeIn(
                                    cwModelName, lang, vehicleType),
                            vehicleType);
        } catch (Exception e) {
            logger.error("Error in getModelV2");
            e.printStackTrace();
        }
        return res;
    }

    private ModelV2DTO convertModelV2EntityToDTO(final ModelV2 model, Set<String> vehicleType)
            throws JsonProcessingException {
        // logger.info("model : {}", objectMapper.writeValueAsString(model));
        final ModelV2DTO modelDTO = new ModelV2DTO();
        modelDTO.setId(model.getId());
        modelDTO.setName(model.getModelName());
        modelDTO.setCwModelName(model.getCwModelName());
        modelDTO.setDisplayName(model.getDisplayName());
        modelDTO.setImgUrl(model.getUrl());
        modelDTO.setGrades(getGradeListByModelId(model, vehicleType));
        modelDTO.setIviCategory(model.getCategory());
        return modelDTO;
    }

    @Transactional
    private List<GradeV2DTO> getGradeListByModelId(final ModelV2 model, Set<String> vehicleType) {
        return gradeV2Repository.findByModelAndVehicleTypeIn(model, vehicleType).stream()
                .map(gradeV2 -> convertGradeEntityToGradeDTO(gradeV2, vehicleType))
                .collect(Collectors.toList());
    }

    private GradeV2DTO convertGradeEntityToGradeDTO(final GradeV2 grade, Set<String> vehicleType) {
        final GradeV2DTO gradeDTO = new GradeV2DTO();
        gradeDTO.setId(grade.getId());
        gradeDTO.setModelName(grade.getModel().getModelName());
        gradeDTO.setName(grade.getGradeName());
        gradeDTO.setDisplayName(grade.getDisplayName());
        gradeDTO.setNaviTypes(getNaviV2ListByGradeName(grade, vehicleType));
        return gradeDTO;
    }

    @Transactional
    private List<NaviV2DTO> getNaviV2ListByGradeName(final GradeV2 grade, Set<String> vehicleType) {
        return naviV2Repository.findByGradeAndVehicleTypeIn(grade, vehicleType).stream()
                .map(naviV2 -> convertNaviEntityToDTO(naviV2, vehicleType))
                .collect(Collectors.toList());
    }

    private NaviV2DTO convertNaviEntityToDTO(final NaviV2 navi, Set<String> vehicleType) {
        final NaviV2DTO naviDTO = new NaviV2DTO();
        naviDTO.setId(navi.getId());
        naviDTO.setGradeId(navi.getGrade().getId());
        naviDTO.setName(navi.getNaviName());
        naviDTO.setDisplayName(navi.getDisplayName());
        naviDTO.setPackagePlans(getPlanListByNaviName(navi, vehicleType));
        naviDTO.setOptions(getOptionsV2ByNavi(navi, vehicleType));
        return naviDTO;
    }

    @Transactional
    private List<OptionsV2DTO> getOptionsV2ByNavi(final NaviV2 navi, Set<String> vehicleType) {
        return optionsV2Repository.findByNaviAndVehicleTypeIn(navi, vehicleType).stream()
                .map(this::convertOptionEntityToDTO)
                .collect(Collectors.toList());
    }

    private OptionsV2DTO convertOptionEntityToDTO(final OptionsV2 option) {
        final OptionsV2DTO optionDTO = new OptionsV2DTO();
        optionDTO.setId(option.getId());
        optionDTO.setName(option.getOptionsName());
        optionDTO.setDisplayName(option.getDisplayName());
        optionDTO.setNaviId(option.getNavi().getId());
        return optionDTO;
    }

    @Transactional
    private List<PackagePlanV2DTO> getPlanListByNaviName(final NaviV2 navi, Set<String> vehicleType) {
        return packagePlanV2Repository.findByNaviAndVehicleTypeIn(navi, vehicleType).stream()
                .map(this::convertPackagePlanEntityToDTO)
                .collect(Collectors.toList());
    }

    private PackagePlanV2DTO convertPackagePlanEntityToDTO(final PackagePlanV2 packagePlan) {
        final PackagePlanV2DTO packagePlanDTO = new PackagePlanV2DTO();
        packagePlanDTO.setId(packagePlan.getId());
        packagePlanDTO.setName(packagePlan.getPackagePlanName());
        packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
        packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
        packagePlanDTO.setPrice(packagePlan.getPrice());
        packagePlanDTO.setAdminFee(packagePlan.getAdminFee());
        packagePlanDTO.setCheckSheetPattern(packagePlan.getPatternName());
        packagePlanDTO.setTcPattern(packagePlan.getTermsName());
        packagePlanDTO.setDescription(packagePlan.getDescription());
        return packagePlanDTO;
    }

    private ColorDTO convertColorEntityToDTO(Color color) {
        ColorDTO colorDTO = new ColorDTO();
        colorDTO.setId(color.getId());
        colorDTO.setColor(color.getSosColor());
        colorDTO.setCwColor(color.getCwColor());
        colorDTO.setColorCode(color.getColorName());
        colorDTO.setUrl(color.getImageURL());
        return colorDTO;
    }

    @Transactional
    private void getReasonInfo(String lang, AdmissionV2FetchResponseDTO admissionFetchResponse) {
        admissionFetchResponse.setReasonTypesPaper(new ArrayList<>());
        reasonRepository.findByLangCode(lang).stream()
                .map(
                        reason -> {
                            if ("reasonTypesPaper".equals(reason.getType())) {
                                if (!(Constants.REASON_NAME_A.equals(reason.getReasonName())
                                        || Constants.REASON_NAME_B.equals(reason.getReasonName())
                                        || Constants.REASON_NAME_C.equals(reason.getReasonName()))) {
                                    admissionFetchResponse
                                            .getReasonTypesPaper()
                                            .add(convertReasonEntityToDTO(reason));
                                }
                            }
                            return reason;
                        })
                .collect(Collectors.toList());
    }

    private ReasonDTO convertReasonEntityToDTO(final Reason reason) {
        final ReasonDTO reasonDTO = new ReasonDTO();
        reasonDTO.setId(reason.getId());
        reasonDTO.setName(reason.getReasonName());
        reasonDTO.setDisplayName(reason.getDisplayName());
        reasonDTO.setShowInDirectDebitPaper(reason.getDirectDebit());
        return reasonDTO;
    }

    @Transactional
    private List<PaymentMethodDto> getPaymentMethod(String lang) {
        Set<String> paymentMethodNames = new HashSet<>();
        paymentMethodNames.add("digital");
        paymentMethodNames.add("paper");
        return paymentMethodRepository.findByLangCodeAndNameIn(lang, paymentMethodNames).stream()
                .map(this::convertpaymentMethodEntityToDTO)
                .collect(Collectors.toList());
    }

    private PaymentMethodDto convertpaymentMethodEntityToDTO(final PaymentMethod paymentMethod) {
        final PaymentMethodDto paymentMethodDto = new PaymentMethodDto();
        paymentMethodDto.setId(paymentMethod.getId());
        paymentMethodDto.setName(paymentMethod.getName());
        paymentMethodDto.setDisplayName(paymentMethod.getDisplayName());
        paymentMethodDto.setType(paymentMethod.getType());
        return paymentMethodDto;
    }

    @Transactional
    private List<ModelV2DTO> getModelV2Info(String lang, Set<String> vehicleType) {
        List<ModelV2DTO> res = new ArrayList<>();
        try {
            res =
                    modelV2Repository
                            .findByLangCodeAndVehicleTypeInOrderByModelDisplayOrderAsc(lang, vehicleType).stream()
                            .map(
                                    modelV2 -> {
                                        try {
                                            return convertModelV2EntityToDTO(modelV2, vehicleType);
                                        } catch (JsonProcessingException e) {
                                            logger.error("Error in Convert model v2 entity to dto");
                                            e.printStackTrace();
                                        }
                                        return null;
                                    })
                            .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Error in get models");
            e.printStackTrace();
        }
        return res;
    }

    public AdmissionV2FetchResponseDTO fetchNewCarVehicleInfo(
            VehicleInfoRequestDTO vehicleInfoRequest, String lang) {
        logger.info("Inside fetchNewCarVehicleInfo");
        AdmissionV2FetchResponseDTO vehicleInfoResponse = new AdmissionV2FetchResponseDTO();
        /** Setting user details */
        vehicleInfoResponse.setVehicleNumber(vehicleInfoRequest.getVehicleNumber());
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"fetchUsedCarVehicleInfo VehicleNumber  :"+vehicleInfoRequest.getVehicleNumber() );
        vehicleInfoResponse.setRegistrationDate(vehicleInfoRequest.getRegistrationDate());
        vehicleInfoResponse.setFirstRegistrationDate(vehicleInfoRequest.getFirstRegistrationDate());
        vehicleInfoResponse.setExpiryDate(vehicleInfoRequest.getExpiryDate());
        vehicleInfoResponse.setVinNumber(vehicleInfoRequest.getVinNumber());
        try {
            if (!StringUtils.isEmpty(vehicleInfoRequest.getVinNumber())) {
                vehicleInfoRequest.setVinNumber(vehicleInfoRequest.getVinNumber().toUpperCase());
            }

            if (!StringUtils.isEmpty(vehicleInfoRequest.getNaviId())) {
                vehicleInfoRequest.setNaviId(vehicleInfoRequest.getNaviId().toUpperCase());
            }
            if (vehicleInfoRequest.getSkipNaviId() == null) {
                vehicleInfoRequest.setSkipNaviId(false);
            }

            logger.info("Make request to vin search");
            CarWingsVinSearchResponseDTO carwingsVehicleResponse = null;
            carwingsVehicleResponse = fetchVinDetailsFromCarwings(vehicleInfoRequest, lang);
            /** New Car First registration and Expiry Month check logic */
            if (ADMISSION_SOURCE_HOME.equals(vehicleInfoRequest.getSource())) {
                String firstRegDate =
                        (carwingsVehicleResponse.getFirstRegDate() != null
                                && !carwingsVehicleResponse.getFirstRegDate().isEmpty())
                                ? carwingsVehicleResponse.getFirstRegDate()
                                : "";
                if (firstRegDate != null && !firstRegDate.isEmpty()) {
                    logger.info("Comparing carwings first reg and expiry month");
                    AdmissionV2FetchResponseDTO response =
                            checkVinAndFirstRegisteredDate(
                                    firstRegDate, vehicleInfoRequest.getExpiryDate());
                    if (response != null) return response;
                } else {
                    logger.info("first reg date not available to check date logic");
                }
            }

            if ("0".equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("response success");
                if (!CW_VIN_RESPONSE_IVI_TRUE.equals(carwingsVehicleResponse.getIviFlg())
                        && !vehicleInfoRequest.getSkipNaviId()
                        && (vehicleInfoRequest.getNaviId() == null
                        || vehicleInfoRequest.getNaviId().isEmpty())) {
                    logger.info("IVI falg is false");
                    vehicleInfoResponse.setResponseCode("204");
                    vehicleInfoResponse.setErrorMessage("Navi ID is mandatory for DOP");
                    return vehicleInfoResponse;
                } else if (!vehicleInfoRequest.getSkipNaviId()
                        && vehicleInfoRequest.getNaviId() != null
                        && vehicleInfoRequest.getNaviId().length() > 12) {
                    vehicleInfoResponse.setResponseCode("204");
                    vehicleInfoResponse.setErrorMessage("Navi ID length should be between 1 and 12");
                    return vehicleInfoResponse;
                }

                String vin = carwingsVehicleResponse.getVin();
                if (carwingsVehicleResponse.getModelName() != null) {
                    carwingsVehicleResponse =
                            vinSearchPatternForModel(vehicleInfoRequest, lang, carwingsVehicleResponse);
                    logger.info("set model");
                    String modelName = carwingsVehicleResponse.getModelName();
                    if (CW_LEAF.equals(modelName)) {
                        vehicleInfoResponse.setCwModel(
                                getLeafModelV2(vin, lang, VEHICLE_CATEGORY_NEW_CAR));
                    } else {
                        vehicleInfoResponse.setCwModel(
                                getModelV2(modelName, lang, VEHICLE_CATEGORY_NEW_CAR));
                    }
                } else {
                    vehicleInfoResponse.setCwModel(null);
                }
                vehicleInfoResponse.setModels(getModelV2Info(lang, VEHICLE_CATEGORY_NEW_CAR));

                if (!"0".equals(carwingsVehicleResponse.getResponseCd())) {
                    vehicleInfoResponse.getModels().stream()
                            .filter(
                                    modelDTO -> {
                                        boolean isReturn = false;
                                        if (!(NOTE_MODEL.contains(modelDTO.getName())
                                                || ARIYA_MODEL.contains(modelDTO.getName()))) {
                                            isReturn = true;
                                        }
                                        return isReturn;
                                    })
                            .collect(Collectors.toList());
                }

                vehicleInfoResponse.setPaymentTypes(getPaymentMethod(lang));
                vehicleInfoResponse.setRegistrationDate(vehicleInfoRequest.getRegistrationDate());
                vehicleInfoResponse.setFirstRegistrationDate(vehicleInfoRequest.getFirstRegistrationDate());
                vehicleInfoResponse.setDopFlg(!CW_VIN_RESPONSE_IVI_TRUE.equals(carwingsVehicleResponse.getIviFlg()));
                vehicleInfoResponse.setOldCwId(carwingsVehicleResponse.getUserId());
                vehicleInfoResponse.setVehicleNumber(vehicleInfoRequest.getVehicleNumber());
                if (!vehicleInfoRequest.getSkipNaviId()
                        && vehicleInfoRequest.getNaviId() != null
                        && !vehicleInfoRequest.getNaviId().isEmpty()
                        && vehicleInfoResponse.getDopFlg()) {
                    vehicleInfoResponse.setNaviId(carwingsVehicleResponse.getAdaptorId());
                    if (vehicleInfoResponse.getNaviId() != null && vehicleInfoResponse.getNaviId().length() > 1) {
                        logger.info("check navi reference repo");
                        String adaptorKind = vehicleInfoResponse.getNaviId().substring(0, 1);
                        NaviReference naviReference = naviReferenceRepository.findByAdaptorKind(adaptorKind);
                        if (naviReference != null && NAVI_REFERENCE_FLAG.containsKey(naviReference.getDopFlag())) {
                            vehicleInfoResponse.setDopValue(NAVI_REFERENCE_FLAG.get(naviReference.getDopFlag()));
                            logger.info("navi reference flag : {}", naviReference.getDopFlag());
                        }
                    }
                }
                vehicleInfoResponse.setColors(
                        fetchColor(
                                vehicleInfoRequest.getVinNumber(), carwingsVehicleResponse.getModelName(), lang));
                final CarWingsVinSearchResponseDTO carwingsVehicleResponseDTO = carwingsVehicleResponse;
                Optional<ColorDTO> colors =
                        vehicleInfoResponse.getColors().stream()
                                .filter(
                                        color -> color.getColorCode().equals(carwingsVehicleResponseDTO.getColorName()))
                                .findAny();
                if (colors.isPresent()) {
                    vehicleInfoResponse.setColor(colors.get().getColor());
                    vehicleInfoResponse.setColorCode(colors.get().getColorCode());
                }
                getReasonInfo(lang, vehicleInfoResponse);
                vehicleInfoResponse =
                        validateCarwingsResponse(vehicleInfoResponse, carwingsVehicleResponse, VEHICLE_TYPE_NEW_CAR);
            } else if (VEHICLE_NOT_FOUND.equals(carwingsVehicleResponse.getResponseCd())) {
                vehicleInfoResponse = vinSearchPattern(vehicleInfoResponse, lang, VEHICLE_CATEGORY_NEW_CAR);
                vehicleInfoResponse =
                        validateCarwingsResponse(vehicleInfoResponse, carwingsVehicleResponse, VEHICLE_TYPE_NEW_CAR);
            } else if (VIN_NAVIID_NOT_MATCH.equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("Carwings response error Data code {}", carwingsVehicleResponse.getStatus());
                if (vehicleInfoRequest.getNaviId() != null) {
                    vehicleInfoResponse = vinSearchPattern(vehicleInfoResponse, lang, VEHICLE_CATEGORY_NEW_CAR);
                    vehicleInfoResponse =
                            validateCarwingsResponse(vehicleInfoResponse, carwingsVehicleResponse, VEHICLE_TYPE_NEW_CAR);
                } else {
                    vehicleInfoResponse.setResponseCode(STATUS_206);
                    vehicleInfoResponse.setErrorMessage(VIN_SEARCH_ERROR_DATA);
                }
            } else if (MEMBER_MORE_EXIST.equals(carwingsVehicleResponse.getResponseCd())) {
                logger.info("Carwings response error Data code {}", carwingsVehicleResponse.getStatus());
                vehicleInfoResponse.setResponseCode(STATUS_206);
                vehicleInfoResponse.setErrorMessage(VIN_SEARCH_ERROR_DATA);
            } else {
                logger.info("Carwings response System error code {}", carwingsVehicleResponse.getStatus());
                vehicleInfoResponse.setResponseCode(STATUS_206);
                vehicleInfoResponse.setErrorMessage(VIN_SEARCH_ERROR_DATA);
            }
        } catch (Exception e) {
            logger.info("Error in fetchNewCarVehicleInfo");
            e.printStackTrace();
        }
        return vehicleInfoResponse;
    }

    private AdmissionV2FetchResponseDTO validateCarwingsResponse(
            AdmissionV2FetchResponseDTO vehicleInfoResponse,
            CarWingsVinSearchResponseDTO carwingsVehicleResponse,
            String vehicleType) {
        if (Constants.VEHICLE_TYPE_USED_CAR.equals(vehicleType)) {
            boolean isIVI =
                    (vehicleInfoResponse.getCwModel() != null
                            && vehicleInfoResponse.getCwModel().getIviCategory() != null)
                            ? vehicleInfoResponse.getCwModel().getIviCategory()
                            : false;
            if (CARWINGS_STATUS_SA.equals(carwingsVehicleResponse.getStatus()) && isIVI
                    && StringUtils.isNotEmpty(carwingsVehicleResponse.getUserId())) {
                vehicleInfoResponse = new AdmissionV2FetchResponseDTO();
                vehicleInfoResponse.setResponseCode("205");
                vehicleInfoResponse.setErrorMessage(
                        "Previous vehicle owner has not withdrawn from NissanConnect");
                logger.info("Error Message : Previous vehicle owner has not withdrawn Pattern");
                return vehicleInfoResponse;
            } else if (CARWINGS_STATUS_SA.equals(carwingsVehicleResponse.getStatus()) && isIVI
                    && vehicleInfoResponse.getNaviId() == null) {
                vehicleInfoResponse = new AdmissionV2FetchResponseDTO();
                vehicleInfoResponse.setResponseCode("206");
                vehicleInfoResponse.setErrorMessage("Cannot join to NissanConnect");
                logger.info("Error Message : Cannot join to Nissan Connect Pattern");
                return vehicleInfoResponse;
            }

            if (vehicleInfoResponse.getNaviId() != null && !vehicleInfoResponse.getNaviId().equals(carwingsVehicleResponse.getAdaptorId())) {
                if (CARWINGS_STATUS_SA.equals(carwingsVehicleResponse.getStatus())) {
                    vehicleInfoResponse = new AdmissionV2FetchResponseDTO();
                    vehicleInfoResponse.setResponseCode("206");
                    vehicleInfoResponse.setErrorMessage("Please contact the customer call center");
                    logger.info("Error Message : Please contact the customer call center");
                    return vehicleInfoResponse;
                }
            }
        }
        logger.info("CW Model name in response", vehicleInfoResponse.getCwModel().getCwModelName());
        if (vehicleInfoResponse.getCwModel() != null
                && vehicleInfoResponse.getCwModel().getCwModelName() != null
                && DAYZ_MODEL.contains(vehicleInfoResponse.getCwModel().getCwModelName())) {
            if (OLD_DAYZ.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
                return removeSOSPackagePlanFilter(vehicleInfoResponse);
            }
        }
        return vehicleInfoResponse;
    }

    private CarWingsVinSearchResponseDTO vinSearchPatternForModel(
            VehicleInfoRequestDTO vehicleInfoRequest,
            String lang,
            CarWingsVinSearchResponseDTO vehicleInfoResponse) {
        logger.info("Inside vinSearchPatternForModel");
        logger.info("vehicleModel Name : {}", vehicleInfoResponse.getModelName());
        switch (vehicleInfoResponse.getModelName()) {
            case CW_SKYLINE:
                if (SKYLINE_2019.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    String[] vinNumber = vehicleInfoRequest.getVinNumber().split("-");
                    long vinNumber2 = Long.parseLong(vinNumber[1]);
                    if ("HV37".equals(vinNumber[0]) && (vinNumber2 >= 450001L && vinNumber2 <= 999999L)) {
                        vehicleInfoResponse.setModelName(CW_SKYLINE);
                    } else if ("HNV37".equals(vinNumber[0])
                            && (vinNumber2 >= 550001L && vinNumber2 <= 999999L)) {
                        vehicleInfoResponse.setModelName(CW_SKYLINE);
                    } else if ("RV37".equals(vinNumber[0])
                            && (vinNumber2 >= 100001L && vinNumber2 <= 999999L)) {
                        vehicleInfoResponse.setModelName(CW_SKYLINE);
                    } else {
                        vehicleInfoResponse.setModelName(DB_OTHERS);
                    }
                }
                break;
            case CW_LEAF:
                if (!LEAF.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_E_NV200:
                if (!E_NV200.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_NOTE:
                if (!NOTE.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case DB_DAYZ:
            case CW_DAYZ:
                if (DAYZ.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(CW_DAYZ_DB);
                } else {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_ROOX:
                if (!ROOX.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_KICKS:
                if (!KICKS.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_X_TRAIL:
                if (!X_TRAIL.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_ELGRAND:
                if (!ELGRAND.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case CW_TEANA:
                if (!TEANA.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case DB_FUGA:
            case CW_FUGA:
                if (FUGA.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(CW_FUGA_DB);
                } else {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            case DB_CIMA:
            case CW_CIMA:
                if (CIMA.matcher(vehicleInfoRequest.getVinNumber()).matches()) {
                    vehicleInfoResponse.setModelName(CW_CIMA_DB);
                } else {
                    vehicleInfoResponse.setModelName(DB_OTHERS);
                }
                break;
            default:
                vehicleInfoResponse.setModelName(DB_OTHERS);
                break;
        }
        logger.info("Inside VinSearchPattern For Model {}", vehicleInfoResponse.getModelName());
        return vehicleInfoResponse;
    }

    private AdmissionV2FetchResponseDTO vinSearchPattern(
            AdmissionV2FetchResponseDTO vehicleInfoResponse, String lang, Set<String> vehicleType) {
        if (SKYLINE_2019.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_SKYLINE, lang, vehicleType));
        } else if (LEAF.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(
                    getLeafModelV2(vehicleInfoResponse.getVinNumber(), lang, vehicleType));
        } else if (E_NV200.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_E_NV200, lang, vehicleType));
        } else if (NOTE.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_NOTE, lang, vehicleType));
        } else if (DAYZ.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_DAYZ_DB, lang, vehicleType));
        } else if (ROOX.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_ROOX, lang, vehicleType));
        } else if (KICKS.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_KICKS, lang, vehicleType));
        } else if (X_TRAIL.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_X_TRAIL, lang, vehicleType));
        } else if (ELGRAND.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_ELGRAND, lang, vehicleType));
        } else if (TEANA.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_TEANA, lang, vehicleType));
        } else if (FUGA.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_FUGA_DB, lang, vehicleType));
        } else if (CIMA.matcher(vehicleInfoResponse.getVinNumber()).matches()) {
            vehicleInfoResponse.setCwModel(getModelV2(CW_CIMA_DB, lang, vehicleType));
        } else {
            vehicleInfoResponse.setCwModel(getModelV2(DB_OTHERS, lang, vehicleType));
        }
        logger.info("Inside VinSearchPattern For Error {}", vehicleInfoResponse.getCwModel().getCwModelName());
        vehicleInfoResponse.setPaymentTypes(getPaymentMethod(lang));
        vehicleInfoResponse.setRegistrationDate(vehicleInfoResponse.getRegistrationDate());
        vehicleInfoResponse.setVinNumber(vehicleInfoResponse.getVinNumber());

        vehicleInfoResponse.setColors(
                fetchColor(
                        vehicleInfoResponse.getVinNumber(),
                        vehicleInfoResponse.getCwModel().getCwModelName(),
                        lang));
        getReasonInfo(lang, vehicleInfoResponse);
        return vehicleInfoResponse;
    }

    private AdmissionV2FetchResponseDTO removeSOSPackagePlanFilter(
            AdmissionV2FetchResponseDTO vehicleInfoResponse) {
        logger.info("Old DAYZ remove SOS package plan");
        Iterator<GradeV2DTO> grade = vehicleInfoResponse.getCwModel().getGrades().iterator();
        while (grade.hasNext()) {
            GradeV2DTO gradeV2DTO = grade.next();
            Iterator<NaviV2DTO> navi = gradeV2DTO.getNaviTypes().iterator();
            while (navi.hasNext()) {
                NaviV2DTO naviV2DTO = navi.next();
                if (NAVI_TYPE_SOS.equals(naviV2DTO.getName())) {
                    navi.remove();
                    logger.info("Old DAYZ remove navi {}", naviV2DTO.getName());
                }
            }
        }
        return vehicleInfoResponse;
    }

    @Transactional
    private ModelV2DTO getLeafModelV2(String vin, String lang, Set<String> vehicleType) {
        logger.info("Inside get leaf model v2");
        String[] vinNumber = vin.split("-");
        long vinNumber2 = Long.parseLong(vinNumber[1]);
        String modelName = "";
        if (vinNumber2 > MIN_LEAF_RANGE && vinNumber2 < MAX_LEAF_RANGE) {
            modelName = JP.equals(lang) ? DB_LEAF_2019_JP : DB_LEAF_2019_EN;
        } else if (vinNumber2 > MAX_LEAF_RANGE) {
            modelName = JP.equals(lang) ? DB_LEAF_2020_JP : DB_LEAF_2020_EN;
        }
        ModelV2DTO res = null;
        try {
            mylogger.info(
                    org.owasp.esapi.Logger.SECURITY_SUCCESS,
                    "modelName :"+ modelName
                            +"lang :"+lang
                            + "vechicleType :"+objectMapper.writeValueAsString(vehicleType));
            res =
                    convertModelV2EntityToDTO(
                            modelV2Repository.findByModelNameAndLangCodeAndVehicleTypeIn(
                                    modelName, lang, vehicleType),
                            vehicleType);
        } catch (Exception e) {
            logger.error("Error in getModelV2");
            e.printStackTrace();
        }
        return res;
    }

    private List<ResultDto> getResponseListDto(RestTemplate restTemplate, List<Object> orderInfo)
            throws JsonProcessingException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
            BadPaddingException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        CarWingsRequestDto carWingsRequestDto = new CarWingsRequestDto();
        carWingsRequestDto.setAspUser(ASP_USER);
        carWingsRequestDto.setAspPassword(userPassword);
        carWingsRequestDto.setRecordCount(orderInfo.size());
        OrderList orderList = new OrderList();
        orderList.setOrderInfo(orderInfo);
        logger.info("orders list={}", orderInfo);
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        /** Converting the Object to JSONString */
        String jsonString = mapper.writeValueAsString(orderList);
        carWingsRequestDto.setOrderList(orderList);
        String resultString = mapper.writeValueAsString(carWingsRequestDto);
        logger.info("car wings dto={}", resultString);
        HttpEntity<String> entity = new HttpEntity<>(resultString, headers);
        CarWingsResponseDto response =
                restTemplate.postForEntity(carWingsUrl, entity, CarWingsResponseDto.class).getBody();
        logger.info("car wings response={}", response.getResponseList());
        byte[] IV = new byte[16];
        IvParameterSpec ivSpec = new IvParameterSpec(IV);
        SecretKeySpec skeySpec = new SecretKeySpec(secretKey.getBytes(), "AES");

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivSpec);
        byte[] original = cipher.doFinal(Base64.decodeBase64(response.getResponseList()));
        String decryptedString = new String(original);
        logger.info("decrypted json={}", decryptedString);
        int index = decryptedString.indexOf("{");
        String subString = decryptedString.substring(0, index);
        logger.info("subString json={}", subString);
        String responseString = decryptedString.substring(index);
        logger.info("responseString json={}", responseString);
        ResponseListDto responseListDto = mapper.readValue(responseString, ResponseListDto.class);
        return responseListDto.getResultList().getResultInfo();
    }

    private List<ColorDTO> fetchColor(String vin, String modelName, String lang) {
        List<ColorDTO> colors = null;
        if (CW_LEAF.equals(modelName)) {
            String[] vinNumber = vin.split("-");
            long vinNumber2 = Long.parseLong(vinNumber[1]);
            if (vinNumber2 > MIN_LEAF_RANGE && vinNumber2 < MAX_LEAF_RANGE) {
                modelName = DB_LEAF_2019_JP;
            } else if (vinNumber2 > MAX_LEAF_RANGE) {
                modelName = DB_LEAF_2020_JP;
            }
        } else if (CW_SKYLINE.equals(modelName)) {
            modelName = DB_SKYLINE;
        } else if (CW_NOTE.equals(modelName) || DB_NOTE.equals(modelName)) {
            modelName = C_NOTE;
        }
        colors =
                colorRepository.getColorListByModelName(modelName, lang).stream()
                        .map(this::convertColorEntityToDTO)
                        .collect(Collectors.toList());
        return colors;
    }

    @Override
    public void sendD01fileToKameari() {
        logger.info("Start : Send D01 file to Kameari.");
        String tmpDirName = "/kamearitemp/";
        File tempDir = new File(tmpDirName);
        if (!tempDir.exists()) {
            tempDir.mkdir();
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(D01_DATE_FORMAT);
        String today = LocalDateTime.now().format(formatter);
        String do1FilePath = tmpDirName + "PRCARWIN_" + today + ".D01";
        String zipFilePath = tmpDirName + "PRCARWIN_" + today + ".7z";
        logger.info("D01 file name : {}", do1FilePath);
        logger.info("D01 7z file name : {}", zipFilePath);
        try (BufferedWriter writer =
                     new BufferedWriter(
                             new OutputStreamWriter(new FileOutputStream(do1FilePath), Charset.forName("SJIS")))) {
            List<KameariD01DataDto> dataList = getKameariData();
            logger.info("Kameari D01 data count : {}", dataList.size());
            for (KameariD01DataDto rowData : dataList) {
                writer.write(rowData.convertToD01Content());
                writer.newLine();
            }
            writer.flush();
            logger.info("Created local copy of D01 file.");
            File d01Zip = DemoCarUtil.sevenZipSingleFile(do1FilePath, zipFilePath);
            logger.info("file compressed");
//            SftpPropertiesDTO sftpProperties = new SftpPropertiesDTO();
//            sftpProperties.setHost(remoteHost);
//            sftpProperties.setUsername(userName);
//            sftpProperties.setPort(22);
//            sftpProperties.setPrivateKey(kamaeriKey);
//            sftpProperties.setPassphrase(sftpKeyPassphrase);
//            sftpProperties.setRoot("/input/");
//            logger.info("file compressed path ={}", d01Zip.getAbsolutePath());
//            sftpProperties.setSource(d01Zip.getAbsolutePath());
            sftpUpload.uploadByDemocar(d01Zip.getAbsolutePath(), democarKameriFolder);
            logger.info("Created D01 file and sent to Kameari.");
        } catch (Exception e) {
            logger.error("Failed to create D01 file : {}", e);
        } finally {
            try {
                FileUtils.deleteDirectory(tempDir);
            } catch (IOException e) {
                logger.error("Failed to delete kameari temp directory : {}", e.getMessage());
            }
        }
    }

    private List<KameariD01DataDto> getKameariData() {
        List<KameariD01DataDto> dataList = new ArrayList<>();
        List<VinDetails> vinDetailsList = vinDetailsRepository.findByStatus("Applying");
        logger.info("VINs in Applying status count : {}", vinDetailsList.size());
        KameariD01DataDto d01Dto = null;
        int count = 1;
        for (VinDetails vinDetails : vinDetailsList) {
            d01Dto = new KameariD01DataDto();
            // NCAS
            String vin = vinDetails.getVin() == null ? "" : vinDetails.getVin();
            String[] slipttedVin = vin.split("-");
            if (null != slipttedVin && slipttedVin.length == 2) {
                d01Dto.setVinChassisNumber(slipttedVin[1]);
                d01Dto.setVinChassisModel(slipttedVin[0]);
            } else {
                logger.info("Invalid VIN number", vin);
            }
            String naviId = vinDetails.getCwNaviId() == null ? "" : vinDetails.getCwNaviId();
            d01Dto.setNaviId(naviId);

            if (null != vinDetails.getEnrollmentDate()) {
                StringBuilder orderNo = new StringBuilder("N");
                DateTimeFormatter datePartFormatter = DateTimeFormatter.ofPattern("MMdd");
                String datePart = vinDetails.getEnrollmentDate().format(datePartFormatter);
                orderNo.append(datePart).append(String.format("%04d", count++));
                d01Dto.setOrderNo(orderNo.toString());

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern(D01_DATE_FORMAT);
                String regDate = vinDetails.getEnrollmentDate().format(formatter);
                d01Dto.setCwRegistDate(regDate);
                d01Dto.setProfitAplicationDate(regDate);
                d01Dto.setProfitLastUpdated(regDate);
                d01Dto.setProfitCWdataTransmissionDate(regDate);
            }
            // Tempo.net
            TempoDotNet tempoDotNet =
                    tempoDotNetRepository.findByCaCompanyCode(vinDetails.getProfitDealerCode());
            if (null != tempoDotNet) {
                logger.info("Recieved TempoDotNet for VIN : {}", vinDetails.getVin());
                String profitDealerCode =
                        tempoDotNet.getProfitDealerCompanyCodeWithBlockCode() == null
                                ? ""
                                : tempoDotNet.getProfitDealerCompanyCodeWithBlockCode();
                d01Dto.setProfitDealerCode(profitDealerCode);
                if (!StringUtils.isEmpty(tempoDotNet.getDealerCompanyPhoneNumber())
                        && tempoDotNet.getDealerCompanyPhoneNumber().length() == 10) {
                    d01Dto.setCaShopTel1(tempoDotNet.getDealerCompanyPhoneNumber().substring(0, 3));
                    d01Dto.setCaShopTel2(tempoDotNet.getDealerCompanyPhoneNumber().substring(3, 6));
                    d01Dto.setCaShopTel3(tempoDotNet.getDealerCompanyPhoneNumber().substring(6, 10));
                } else {
                    d01Dto.setCaShopTel1("000");
                    d01Dto.setCaShopTel2("000");
                    d01Dto.setCaShopTel3("0000");
                }
            } else {
                d01Dto.setProfitDealerCode("");
                d01Dto.setCaShopTel1("000");
                d01Dto.setCaShopTel2("000");
                d01Dto.setCaShopTel3("0000");
            }
            // GD
            DealerEntity dealer = vinDetails.getDealer();
            if (null != dealer) {
                logger.info("Recieved DealerEntity for VIN : {}", vinDetails.getVin());
                String dealerName = dealer.getCompanyName() == null ? "" : dealer.getCompanyName();
                d01Dto.setDealerName(dealerName);
                String caName = dealer.getCaName() == null ? "" : dealer.getCaName();
                d01Dto.setCaName(caName);
                String dealerTel = dealer.getPhoneNumber() == null ? "" : dealer.getPhoneNumber();
                d01Dto.setDealerTel(dealerTel);
            } else {
                d01Dto.setDealerName("");
                d01Dto.setCaName("");
                d01Dto.setDealerTel("");
            }
            dataList.add(d01Dto);
        }
        logger.info("Generated Kameari Data.");
        return dataList;
    }

    @Override
    public ResetPasswordResponseDTO resetPassword(@Valid ResetPasswordRequestDTO resetPasswordRequestDTO) {
        ResetPasswordResponseDTO response = null;
        try {
            RestTemplate restTemplate = cwInitialSetUp();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            resetPasswordRequestDTO.setAspUser(ASP_USER);
            resetPasswordRequestDTO.setAspPassword(userPassword);
            String resultString = objectMapper.writeValueAsString(resetPasswordRequestDTO);
            logger.info("CW reset password request DTO = {}", resultString);
            HttpEntity<String> entity = new HttpEntity<>(resultString, headers);
            response = restTemplate.postForEntity(cwResetPasswordUrl, entity, ResetPasswordResponseDTO.class).getBody();
        } catch (Exception e) {
            logger.error("CW reset password failed", e);
        }
        return response;
    }

    public void sendInvalidPOMailCA(Long orderId) {
        logger.info("Invalid PO Mail to CA  {} {} {}", orderId, NOTIFICATION_SERVICE, PO_MAIL_CA);
        String serviceLocation = serviceResolver.resolve(NOTIFICATION_SERVICE);
        logger.info("API service URL {}", serviceLocation);
        String url = HTTP + serviceLocation + PO_MAIL_CA;
        HttpHeaders headers = new HttpHeaders();
        headers.set("orderId", orderId.toString());
        HttpEntity<String> request = new HttpEntity<>(headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<ResponseDTO> response =
                restTemplate.exchange(url, HttpMethod.GET, request, ResponseDTO.class);
        logger.info("Carwings response Invalid PO mail status {}", response.getBody().getStatus());
    }
}
