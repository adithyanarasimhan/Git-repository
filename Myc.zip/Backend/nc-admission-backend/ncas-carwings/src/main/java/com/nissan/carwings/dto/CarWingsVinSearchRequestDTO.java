package com.nissan.carwings.dto;

import lombok.Data;

@Data
public class CarWingsVinSearchRequestDTO {
    private String aspUser;
    private String aspPassword;
    private String vin;
    private String naviId;
}
