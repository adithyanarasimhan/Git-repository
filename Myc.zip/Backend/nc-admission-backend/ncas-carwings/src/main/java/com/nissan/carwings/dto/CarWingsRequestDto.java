package com.nissan.carwings.dto;

import com.nissan.common.dto.OrderList;
import lombok.Data;

@Data
public class CarWingsRequestDto {
  private String aspUser;
  private String aspPassword;
  private Integer recordCount;
  OrderList orderList;
}
