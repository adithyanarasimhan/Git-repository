package com.nissan.carwings.dto;

import lombok.Data;

@Data
public class CarWingsResponseDto {
  private Integer recordCount;
  private String responseCd;
  private String errorMessage;
  private String responseList;
}
