package com.nissan.carwings.dto;

import lombok.Data;

@Data
public class ResponseListDto {
    ResultList resultList;
}
