package com.nissan.carwings.dto;

import com.nissan.common.dto.ResultDto;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ResultList {
    List<ResultDto> resultInfo = new ArrayList<>();
}
