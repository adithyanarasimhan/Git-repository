package com.nissan.carwings.service;

import com.nissan.common.dto.ResultDto;
import com.nissan.common.dto.VehicleInfoRequestDTO;
import com.nissan.common.dto.AdmissionV2FetchResponseDTO;
import com.nissan.common.dto.ResetPasswordRequestDTO;
import com.nissan.common.dto.ResetPasswordResponseDTO;
import com.nissan.common.entity.AdmissionV2;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.validation.Valid;

import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.List;

public interface CommunicationService {
    void getOrderDetails() throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, NoSuchPaddingException, InvalidAlgorithmParameterException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException;

    void sendFiles();

    AdmissionV2FetchResponseDTO fetchVehicleInfo(VehicleInfoRequestDTO vehicleInfoRequest, String lang);

    void sendNcIdToNewCarCus();

    void sendNcIdToUsedCarCus();

    void sendV2FilesToKameri();

    List<ResultDto> fetchMemberInfoByVinNumber(List<String> vin) throws KeyManagementException, CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, NoSuchPaddingException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException;

	void sendD01fileToKameari();

	ResetPasswordResponseDTO resetPassword(@Valid ResetPasswordRequestDTO resetPasswordRequestDTO);

	void sendDOPEnhancementFilesToKameri() throws KeyManagementException, CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, InvalidAlgorithmParameterException, NoSuchPaddingException;
}
