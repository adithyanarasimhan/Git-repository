package com.nissan.carwings.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nissan.carwings.service.CommunicationService;
import com.nissan.common.dto.*;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.List;

@Description(value = "Public API to communicate with carwings")
@RestController
@RequestMapping("api/v1")
public class CarwingsController {

  private static final Logger logger = LoggerFactory.getLogger(CarwingsController.class);

  @Autowired CommunicationService communicationService;

  @GetMapping(value = "ping")
  public String ping() {
    return "Carwings Controller pinged at : " + System.currentTimeMillis();
  }

  @PostMapping(value = "{langCode}/vehicleinfo", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchVehicleInfo(
      HttpServletRequest httpServletRequest,
      @Valid @RequestBody VehicleInfoRequestDTO vehicleInfoRequest,
      @PathVariable(name = "langCode") String lang)
      throws JsonProcessingException {
    AdmissionV2FetchResponseDTO vehicleInfoResponse =
        communicationService.fetchVehicleInfo(vehicleInfoRequest, lang);
    if (vehicleInfoResponse == null) {
      logger.info("Error in fetch vehicle info");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "500", "Error in fetch vehicle info"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "Vehicle info retrieved successfully");
    response.setData(vehicleInfoResponse);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @PostMapping(value = "{langCode}/memberinfo", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchMemberInfo(
      HttpServletRequest httpServletRequest,
      @Valid @RequestBody MemberInfoRequestDto memberInfoRequestDto,
      @PathVariable(name = "langCode") String lang)
      throws IOException, CertificateException, NoSuchAlgorithmException, InvalidKeyException,
          InvalidAlgorithmParameterException, NoSuchPaddingException, BadPaddingException,
          KeyStoreException, IllegalBlockSizeException, KeyManagementException {
    List<ResultDto> resultDtos =
        communicationService.fetchMemberInfoByVinNumber(memberInfoRequestDto.getVin());
    if (resultDtos == null) {
      logger.info("Error in fetch member info");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "500", "Error in fetch vehicle info"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "Vehicle info retrieved successfully");
    response.setData(resultDtos);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
  
  @PostMapping(value = "{langCode}/resetpassword", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO<ResetPasswordResponseDTO>> resetPassword(
      HttpServletRequest httpServletRequest,
      @Valid @RequestBody ResetPasswordRequestDTO resetPasswordRequestDTO,
      @PathVariable(name = "langCode") String lang)
      throws IOException, CertificateException, NoSuchAlgorithmException, InvalidKeyException,
          InvalidAlgorithmParameterException, NoSuchPaddingException, BadPaddingException,
          KeyStoreException, IllegalBlockSizeException, KeyManagementException {
	  ResetPasswordResponseDTO resetResponse =
        communicationService.resetPassword(resetPasswordRequestDTO);
    if (resetResponse == null) {
      logger.info("Error in resetting password.");
      return new ResponseEntity<>(
          new ResponseDTO<ResetPasswordResponseDTO>(Constants.FAILED, "500", "Error in resetting password."),
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
    ResponseDTO<ResetPasswordResponseDTO> response =
        new ResponseDTO<>(Constants.SUCCESS, "200", "Reset password successfully.");
    response.setData(resetResponse);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
