package com.nissan.admission.service;

import com.nissan.common.dto.CustomerGetResponseDTO;
import com.nissan.common.dto.CustomerSummaryDTOV2;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.service.impl.CustomerServiceImplV2;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@SpringBootTest
public class CustomerServiceImplV2Test {

    @InjectMocks CustomerServiceImplV2 customerServiceImplV2;

    @Mock private CustomerRepository customerRepository;
    @Mock private PaymentRepository paymentRepository;
    @Mock private UserRepository userRepository;
    @Mock private CardBrandRepository cardBrandRepository;
    @Mock private AdmissionV2Repository admissionV2Repository;
    @Mock private OrdersV2Repository ordersV2Repository;
    @Mock private PaymentMethodRepository paymentMethodRepository;
    @Mock List<CardBrand> listOfCards;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void fetchCustomerPlanDetailsV2() {
        when(userRepository.findById(anyLong()).get()).thenReturn(any(User.class));
        when(admissionV2Repository.fetchByUserId(anyLong())).thenReturn(any(AdmissionV2.class));
        when(ordersV2Repository.findByAdmissionId(anyLong())).thenReturn(any(OrdersV2.class));
        when(cardBrandRepository.findByLangCode(anyString())).thenReturn(listOfCards);
        when(customerRepository.findByUserId(anyLong()).orElse(any(Customer.class))).thenReturn(any(Customer.class));
        CustomerGetResponseDTO customerGetResponseDTO = new CustomerGetResponseDTO();
        customerGetResponseDTO.setEmail(anyString());
        assertNotNull(customerGetResponseDTO);
    }

    @Test
    public void fetchCustomerByUserAndLangCodeV2() {
        when(userRepository.findById(anyLong()).get()).thenReturn(any(User.class));
        when(customerRepository.findByUserId(anyLong()).orElse(any(Customer.class))).thenReturn(any(Customer.class));
        when(paymentRepository.fetchByCustomerId(anyLong())).thenReturn(any(Payment.class));
        when(cardBrandRepository.fetchByLangCodeAndId(anyLong())).thenReturn(any(CardBrand.class));
        when(admissionV2Repository.fetchByUserId(anyLong())).thenReturn(any(AdmissionV2.class));
        when(ordersV2Repository.findByAdmissionId(anyLong())).thenReturn(any(OrdersV2.class));
        CustomerSummaryDTOV2 customerSummaryDto = new CustomerSummaryDTOV2();
        customerSummaryDto.setFirstName(anyString());
        assertNotNull(customerSummaryDto);
    }
}
