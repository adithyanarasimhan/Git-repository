package com.nissan.admission.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.dto.CustomerGetResponseDTO;
import com.nissan.common.dto.CustomerSummaryDTOV2;
import com.nissan.common.entity.Customer;
import com.nissan.common.service.CustomerServiceV2;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
public class CustomerControllerV2Test {

  @InjectMocks private CustomerControllerV2 customerControllerV2;
  private MockMvc mockMvc;
  @Mock HttpServletRequest httpServletRequest;
  @Mock CustomerServiceV2 customerService;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(customerControllerV2).build();
  }

  @Test
  public void fetchCustomerPlanDetails() throws Exception {
    String principalId = "3";
    when(httpServletRequest.getHeader("principalId")).thenReturn(principalId);

    CustomerGetResponseDTO cardBrands = new CustomerGetResponseDTO();
    cardBrands.setEmail("email");

    when(customerService.fetchCustomerPlanDetailsV2(anyString(), anyString()))
        .thenReturn(cardBrands);

    MvcResult result =
        mockMvc
            .perform(get("/secured/api/v2/{langCode}/customer", "en"))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }

  @Test
  public void fetchCustomer() throws Exception {
    String principalId = "1";
    when(httpServletRequest.getHeader("principalId")).thenReturn(principalId);

    CustomerSummaryDTOV2 customerSummaryDTOV2 = new CustomerSummaryDTOV2();
    customerSummaryDTOV2.setFirstName("name");

    when(customerService.fetchCustomerByUserAndLangCodeV2(principalId, "en"))
        .thenReturn(customerSummaryDTOV2);

    MvcResult result =
        mockMvc
            .perform(get("/secured/api/v2/{langCode}/customers", "en"))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }
}
