package com.nissan.admission.controller;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.service.AWSS3Service;
import com.nissan.admission.service.AdmissionServiceV2;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
public class AdmissionControllerV2Test {
  @InjectMocks private AdmissionControllerV2 admissionControllerV2;
  private MockMvc mockMvc;
  @Mock HttpServletRequest httpRequest;
  @Mock private DealerRepository dealerRepository;
  @Mock private AdmissionServiceV2 admissionService;
  @Mock private AWSS3Service awss3Service;

  private MediaType contentType =
      new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype());

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(admissionControllerV2).build();
  }

  @Test
  public void saveAdmissionV2() throws Exception {
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);

    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    dealerEntity.setDealerId("PGM-PPL-9001");

    AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO = new AdmissionSaveRequestV2DTO();
    admissionSaveRequestV2DTO.setModelId(1L);

    AdmissionSaveResponseV2DTO admissionSaveResponseV2DTO = new AdmissionSaveResponseV2DTO();
    admissionSaveResponseV2DTO.setModelId(1L);

    when(httpRequest.getHeader("principalId")).thenReturn("1");
    when(dealerRepository.findByUserId(anyLong())).thenReturn(dealerEntity);
    Mockito.when(
            admissionService.saveAdmissionInfo(
                admissionSaveRequestV2DTO, dealerEntity.getDealerId(), "en"))
        .thenReturn(admissionSaveResponseV2DTO);
    MvcResult result =
        mockMvc
            .perform(
                post("/secured/api/v1/{langCode}/usedadmission", "en")
                    .contentType(contentType)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString(admissionSaveRequestV2DTO)))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }

  @Test
  public void uploadFile() throws Exception {

    String principalId = "1";
    PutObjectResult putObjectResult = new PutObjectResult();
    putObjectResult.setETag("Tag");
    putObjectResult.setExpirationTime(new Date());
    MockMultipartFile jsonFile =
        new MockMultipartFile(
            "userFile", "CAR.jpg", "application/json", "{\"json\": \"someValue\"}".getBytes());
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);

    Mockito.when(awss3Service.uploadFile(jsonFile, principalId)).thenReturn(putObjectResult);
    MvcResult result =
        mockMvc
            .perform(
                multipart("/secured/api/v1/upload")
                    .file(jsonFile)
                    .contentType(contentType)
                    .header("principalId", principalId)
                    .content(new ObjectMapper().writeValueAsString(putObjectResult)))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }

  @Test
  public void downloadFile() throws Exception {
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);

    Mockito.when(awss3Service.getInceptionDocName(principalId)).thenReturn("fileName");
    Mockito.when(awss3Service.downloadFile("fileName")).thenReturn("encodeFile");
    MvcResult result =
        mockMvc
            .perform(
                get("/secured/api/v1/download")
                    .contentType(contentType)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString("Success")))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }

  @Test
  public void deleteFile() throws Exception {
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);

    Mockito.when(awss3Service.deleteFile(principalId)).thenReturn("OrderNumber");
    MvcResult result =
        mockMvc
            .perform(
                delete("/secured/api/v1/delete")
                    .contentType(contentType)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString("Success")))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }

  @Test
  public void saveAdmissionForCustomer() throws Exception {
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);

    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    dealerEntity.setDealerId("PGM-PPL-9001");

    AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO = new AdmissionSaveRequestV2DTO();
    admissionSaveRequestV2DTO.setModelId(1L);

    AdmissionSaveResponseV2DTO admissionSaveResponseV2DTO = new AdmissionSaveResponseV2DTO();
    admissionSaveResponseV2DTO.setModelId(1L);

    when(httpRequest.getHeader("principalId")).thenReturn("1");
    when(dealerRepository.findByUserId(anyLong())).thenReturn(dealerEntity);
    Mockito.when(
            admissionService.saveAdmissionInfo(
                admissionSaveRequestV2DTO, dealerEntity.getDealerId(), "en"))
        .thenReturn(admissionSaveResponseV2DTO);
    MvcResult result =
        mockMvc
            .perform(
                post("/secured/api/v1/{langCode}/homeadmission", "en")
                    .contentType(contentType)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString(admissionSaveRequestV2DTO)))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("success", 200, result.getResponse().getStatus());
  }
}
