package com.nissan.admission.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.admission.service.AdmissionService;
import com.nissan.common.dto.FetchRecentAdmissionDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@SpringBootTest
public class AdmissionControllerTest {

  public static final String PRINCIPAL_ID = "principalId";
  public static final String ONE = "1";
  public static final String APPLICATION_JSON = "application/json";
  public static final String ADMISSIONS_RECENT = "/secured/api/v1/{langCode}/admissions:recent";
  @InjectMocks private AdmissionController admissionController;
  private MockMvc mockMvc;
  @Mock HttpServletRequest httpRequest;
  @Mock private DealerRepository dealerRepository;
  @Mock private AdmissionService admissionService;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(admissionController).build();
  }

  @Test
  public void return_ok_when_recent_admissions_available() throws Exception {
    FetchRecentAdmissionDTO recentAdmissions = new FetchRecentAdmissionDTO();
    when(httpRequest.getHeader(PRINCIPAL_ID)).thenReturn(ONE);
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    when(httpRequest.getHeader(PRINCIPAL_ID)).thenReturn(ONE);
    when(dealerRepository.findByUserId(any())).thenReturn(dealerEntity);
    when(admissionService.fetchRecentAdmissions(any(DealerEntity.class), anyString(), any(), any()))
        .thenReturn(recentAdmissions);
    ResultActions result =
        mockMvc
            .perform(
                get("/secured/api/v1/{langCode}/admissions:recent", 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString(dealerEntity)))
            .andExpect(status().isOk());
    assertEquals(200, result.andReturn().getResponse().getStatus());
  }

  @Test
  public void return_ok_when_recent_admissions_not_unavailable() throws Exception {
    when(httpRequest.getHeader(PRINCIPAL_ID)).thenReturn(ONE);
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    when(httpRequest.getHeader(PRINCIPAL_ID)).thenReturn(ONE);
    when(dealerRepository.findByUserId(any())).thenReturn(dealerEntity);
    when(admissionService.fetchRecentAdmissions(any(DealerEntity.class), anyString(), any(), any()))
        .thenReturn(null);
    ResultActions result =
        mockMvc
            .perform(
                get(ADMISSIONS_RECENT, 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString(dealerEntity)))
            .andExpect(status().isOk());
    assertEquals(200, result.andReturn().getResponse().getStatus());
  }

  @Test
  public void return_not_found_when_dealer_is_null() throws Exception {
    when(dealerRepository.findByUserId(any())).thenReturn(null);
    ResultActions result =
        mockMvc
            .perform(
                get("/secured/api/v1/{langCode}/admissions:recent", 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header(PRINCIPAL_ID, ONE)
                    .contentType(APPLICATION_JSON))
            .andExpect(status().isNotFound());
    assertEquals(404, result.andReturn().getResponse().getStatus());
  }
}
