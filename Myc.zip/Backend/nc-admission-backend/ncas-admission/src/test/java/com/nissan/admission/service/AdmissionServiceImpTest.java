package com.nissan.admission.service;

import com.nissan.admission.dto.AdmissionFetchResponseDTO;
import com.nissan.admission.dto.ModelDTO;
import com.nissan.admission.service.impl.AdmissionServiceImpl;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class AdmissionServiceImpTest {

  public static final String TEST = "test";
  public static final String USER_ID = "1";
  public static final String EN = "en";
  public static final String TYPE = "1";
  public static final String ORDER_101 = "order101";
  public static final String USED_CAR = "usedCar";
  @InjectMocks private AdmissionServiceImpl admissionService;

  @Mock AdmissionRepository admissionRepository;
  @Mock private UserRepository userRepository;
  @Mock private OrdersRepository ordersRepository;
  @Mock private OptionsRepository optionsRepository;
  @Mock private PackagePlanRepository packagePlanRepository;
  @Mock private ModelRepository modelRepository;
  @Mock private ReasonRepository reasonRepository;
  @Mock private GradeRepository gradeRepository;
  @Mock private NaviRepository naviRepository;
  @Mock private AdmissionV2Repository admissionV2Repository;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void method_executed_when_recent_admissions_is_empty() throws Exception {
    User user = getUser();
    LocalDateTime currentDateTime = LocalDateTime.now();
    Timestamp endDate = Timestamp.valueOf(currentDateTime);
    LocalDateTime localdateTime = currentDateTime.minusDays(7);
    Timestamp startDate = Timestamp.valueOf(localdateTime);
    Optional<User> userOptional = Optional.of(user);
    String UserId = USER_ID;
    when(userRepository.findById(any())).thenReturn(userOptional);
    DealerEntity dealerEntity = getDealerEntity();
    Admission admission = getAdmission(user, dealerEntity);
    when(admissionRepository.fetchByUserId(any())).thenReturn(admission);
    Model model = getModel();
    PackagePlan plan = getPackagePlan();
    PaymentMethod paymentMethod = getPaymentMethod();
    Orders orders = new Orders();
    orders.setOrdersNumber(ORDER_101);
    orders.setAdmission(admission);
    orders.setModel(model);
    orders.setPackagePlan(plan);
    orders.setPaymentMethod(paymentMethod);
    when(ordersRepository.findByAdmissionId(any())).thenReturn(orders);
    AdmissionFetchResponseDTO admissionFetchResponse = new AdmissionFetchResponseDTO();
    admissionFetchResponse.setModels(getModelInfo());
    getReasonInfo(EN, admissionFetchResponse);
    Reason reason = getReason();
    Optional<Reason> optionalReason = Optional.of(reason);
    when(reasonRepository.findById(any())).thenReturn(optionalReason);
    FetchRecentAdmissionDTO recentAdmissionResponseDTOS =
        admissionService.fetchRecentAdmissions(dealerEntity, EN, startDate, endDate);
    assertEquals(0,recentAdmissionResponseDTOS.getRecentAdmissions().size());
  }

  @Test
  public void method_executed_when_recent_admissions_is__not_empty() throws Exception {
    LocalDateTime currentDateTime = LocalDateTime.now();
    Timestamp endDate = Timestamp.valueOf(currentDateTime);
    LocalDateTime localdateTime = currentDateTime.minusDays(7);
    Timestamp startDate = Timestamp.valueOf(localdateTime);
    User user = getUser();
    Optional<User> userOptional = Optional.of(user);
    String UserId = USER_ID;
    when(userRepository.findById(any())).thenReturn(userOptional);
    DealerEntity dealerEntity = getDealerEntity();
    Admission admission = getAdmission(user, dealerEntity);
    when(admissionRepository.fetchByUserId(any())).thenReturn(admission);
    Model model = getModel();
    PackagePlan plan = getPackagePlan();
    PaymentMethod paymentMethod = getPaymentMethod();
    Orders orders = new Orders();
    orders.setOrdersNumber(ORDER_101);
    orders.setAdmission(admission);
    orders.setModel(model);
    orders.setPackagePlan(plan);
    orders.setPaymentMethod(paymentMethod);
    when(ordersRepository.findByAdmissionId(any())).thenReturn(orders);
    AdmissionFetchResponseDTO admissionFetchResponse = new AdmissionFetchResponseDTO();
    admissionFetchResponse.setModels(getModelInfo());
    getReasonInfo(EN, admissionFetchResponse);
    Reason reason = getReason();
    Optional<Reason> optionalReason = Optional.of(reason);
    when(reasonRepository.findById(any())).thenReturn(optionalReason);
    List<RecentAdmissionV1Dto> recentAdmissions = new ArrayList<>();
    RecentAdmissionV1Dto recentAdmissionResponseDTO = new RecentAdmissionV1Dto();
    recentAdmissionResponseDTO.setVersion(USED_CAR);
    recentAdmissionResponseDTO.setReasonId(1L);
    recentAdmissions.add(recentAdmissionResponseDTO);
    when(admissionRepository.fetchRecentAdmissions(dealerEntity, startDate, endDate))
        .thenReturn(recentAdmissions);
    FetchRecentAdmissionDTO recentAdmissionResponseDTOS =
        admissionService.fetchRecentAdmissions(dealerEntity, EN, startDate, endDate);
    assertNotNull(recentAdmissionResponseDTOS);
  }

  private Reason getReason() {
    Reason reason = new Reason();
    reason.setId(1L);
    reason.setType(TYPE);
    reason.setDisplayName(TEST);
    reason.setReasonName(TEST);
    return reason;
  }

  private Model getModel() {
    Model modelname = new Model();
    modelname.setModelName("model1");
    return modelname;
  }

  private PackagePlan getPackagePlan() {
    PackagePlan plan = new PackagePlan();
    plan.setPackagePlanName("plan1");
    return plan;
  }

  private PaymentMethod getPaymentMethod() {
    PaymentMethod paymentMethod = new PaymentMethod();
    paymentMethod.setId(1L);
    paymentMethod.setName("test");
    paymentMethod.setDisplayName("test");
    paymentMethod.setLangCode("test");
    return paymentMethod;
  }

  private Admission getAdmission(User user, DealerEntity dealerEntity) {
    Admission admission = new Admission();
    admission.setUser(user);
    admission.setId(1L);
    admission.setLangCode("lang");
    admission.setStatus("EMAIL_SENT");
    admission.setDealer(dealerEntity);
    admission.setUser(user);
    return admission;
  }

  private DealerEntity getDealerEntity() {
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    dealerEntity.setDealershipName("test");
    dealerEntity.setCompanyName("test");
    dealerEntity.setCaName("test");
    dealerEntity.setCompanyCode("11");
    return dealerEntity;
  }

  private User getUser() {
    User user = new User();
    user.setId(1L);
    user.setUsername(TEST);
    return user;
  }

  private List<ModelDTO> getModelInfo() {
    List<Model> model = new ArrayList<>();
    Model model1 = new Model();
    model.add(model());
    List<ModelDTO> modelDTOList = new ArrayList<>();
    modelDTOList.add(convertModelEntityToDTO(model1));
    when(modelRepository.findByLangCodeOrderByModelDisplayOrderAsc(anyString())).thenReturn(model);
    return modelDTOList;
  }

  private Model model() {
    Model model = new Model();
    model.setModelName("test1");
    model.setDisplayName("test1");
    model.setId(1L);
    model.setLangCode("lang");
    return model;
  }

  private ModelDTO convertModelEntityToDTO(final Model model) {
    final ModelDTO modelDTO = new ModelDTO();
    model.setId(1L);
    model.setModelName("testm");
    model.setDisplayName("testmd");
    model.setUrl("http://test");
    modelDTO.setId(model.getId());
    modelDTO.setName(model.getModelName());
    modelDTO.setDisplayName(model.getDisplayName());
    modelDTO.setImgUrl(model.getUrl());
    modelDTO.setGrades(getGradeListByModelId(model.getModelName()));
    return modelDTO;
  }

  private List<GradeDTO> getGradeListByModelId(final String modelName) {
    List<Grade> gradeDTOList = new ArrayList<>();
    Grade grade = new Grade();
    gradeDTOList.add(grade());
    List<GradeDTO> gradeList = new ArrayList<>();
    when(gradeRepository.getGradesByModelName(anyString())).thenReturn(gradeDTOList);
    gradeList.add(convertGradeEntityToGradeDTO(grade));
    return gradeList;
  }

  private GradeDTO convertGradeEntityToGradeDTO(final Grade grade) {
    final GradeDTO gradeDTO = new GradeDTO();
    Model model = new Model();
    model.setId(1L);
    model.setModelName("test1");
    grade.setId(1L);
    grade.setModel(model);
    grade.setGradeName("test");
    grade.setDisplayName("test");
    gradeDTO.setId(grade.getId());
    gradeDTO.setModelName(grade.getModel().getModelName());
    gradeDTO.setName(grade.getGradeName());
    gradeDTO.setDisplayName(grade.getDisplayName());
    gradeDTO.setNaviTypes(getNaviListByGradeName(grade.getId()));
    return gradeDTO;
  }

  private List<NaviDTO> getNaviListByGradeName(final long gradeId) {
    List<Navi> navis = new ArrayList<>();
    Navi navi = new Navi();
    navis.add(navi());
    List<NaviDTO> naviDTOList = new ArrayList<>();
    naviDTOList.add(convertNaviEntityToDTO(navi));
    when(naviRepository.getNaviListByGradeName(gradeId)).thenReturn(navis);
    return naviDTOList;
  }

  private NaviDTO convertNaviEntityToDTO(final Navi navi) {
    final NaviDTO naviDTO = new NaviDTO();
    Grade grade = new Grade();
    grade.setId(1L);
    grade.setGradeName("test");
    grade.setModel(model());
    navi.setId(1L);
    navi.setNaviName("testn");
    navi.setGrade(grade);
    navi.setDisplayName("testd");
    naviDTO.setId(navi.getId());
    naviDTO.setGradeId(navi.getGrade().getId());
    naviDTO.setName(navi.getNaviName());
    naviDTO.setDisplayName(navi.getDisplayName());
    naviDTO.setPackagePlans(getPlanListByNaviName(navi.getId()));
    naviDTO.setOptions(getOptionsByNavi(navi.getId()));
    return naviDTO;
  }

  private List<PackagePlanDTO> getPlanListByNaviName(final long naviId) {
    List<PackagePlan> packagePlanList = new ArrayList<>();
    PackagePlan plan = new PackagePlan();
    packagePlanList.add(packagePlan());
    List<PackagePlanDTO> packagePlanDTOList = new ArrayList<>();
    packagePlanDTOList.add(convertPackagePlanEntityToDTO(plan));
    when(packagePlanRepository.getPackageListByNaviId(naviId)).thenReturn(packagePlanList);
    return packagePlanDTOList;
  }

  private void getReasonInfo(String lang, AdmissionFetchResponseDTO admissionFetchResponse) {
    admissionFetchResponse.setReasonTypesNoThanks(new ArrayList<>());
    admissionFetchResponse.setReasonTypesPaper(new ArrayList<>());
    List<Reason> reasons = new ArrayList<>();
    Reason reason1 = new Reason();
    reason1.setType("reasonTypesPaper");
    reasons.add(reason());
    List<ReasonDTO> reasonDTOS = new ArrayList<>();
    reasonDTOS.add(reasonDTO());
    Reason reasonD = new Reason();
    reasonD.setReasonName("testre");
    reasonD.setId(1L);
    reasonD.setDisplayName("testre");
    when(reasonRepository.findByLangCode(anyString())).thenReturn(reasons);
    if ("reasonTypesPaper".equals(reason1.getType())) {
      admissionFetchResponse.setReasonTypesPaper(getReasonTypesPaper());
    } else if ("reasonsTypesNoThanks".equals(reason1.getType())) {
      admissionFetchResponse.setReasonTypesNoThanks(getReasonTypesNoThanks());
    }
  }

  private Reason reason() {
    Reason reason = new Reason();
    reason.setReasonName("test");
    return reason;
  }

  private ReasonDTO reasonDTO() {
    ReasonDTO reasonDTO = new ReasonDTO();
    reasonDTO.setId(1L);
    reasonDTO.setName("reason1");
    return reasonDTO;
  }

  private List<ReasonDTO> getReasonTypesPaper() {
    List<ReasonDTO> reasonDTOS = new ArrayList<>();
    reasonDTOS.add(reasonDTO());
    return reasonDTOS;
  }

  private List<ReasonDTO> getReasonTypesNoThanks() {
    List<ReasonDTO> reasonDTOS = new ArrayList<>();
    reasonDTOS.add(reasonDTO());
    return reasonDTOS;
  }

  private Grade grade() {
    Model model = new Model();
    model.setModelName("test1");
    model.setDisplayName("test1");
    model.setId(1L);
    model.setLangCode("lang");
    Grade grade = new Grade();
    grade.setId(1L);
    grade.setDisplayName("test");
    grade.setGradeName("test");
    grade.setModel(model);
    return grade;
  }

  private Navi navi() {
    Navi navi = new Navi();
    navi.setId(1L);
    navi.setNaviName("test");
    navi.setDisplayName("test");
    Grade grade = new Grade();
    grade.setId(1L);
    grade.setGradeName("test");
    grade.setModel(model());
    navi.setGrade(grade);
    return navi;
  }

  private PackagePlan packagePlan() {
    PackagePlan packagePlan = new PackagePlan();
    packagePlan.setId(1L);
    packagePlan.setDisplayName("test");
    packagePlan.setPackagePlanName("test");
    packagePlan.setPrice(1L);
    packagePlan.setPatternName("test");
    packagePlan.setTermsName("test");
    packagePlan.setNavi(navi());
    return packagePlan;
  }

  private List<OptionDTO> getOptionsByNavi(final long naviId) {
    List<Options> options = new ArrayList<>();
    Options options1 = new Options();
    options.add(options());
    List<OptionDTO> optionDTOS = new ArrayList<>();
    optionDTOS.add(convertOptionEntityToDTO(options1));
    when(optionsRepository.getOptionsListByNaviId(naviId)).thenReturn(options);
    return optionDTOS;
  }

  private OptionDTO convertOptionEntityToDTO(final Options option) {
    final OptionDTO optionDTO = new OptionDTO();
    option.setId(1L);
    option.setOptionsName("testo");
    option.setDisplayName("testd");
    Navi navi = new Navi();
    navi.setId(1L);
    option.setNavi(navi);
    optionDTO.setId(option.getId());
    optionDTO.setName(option.getOptionsName());
    optionDTO.setDisplayName(option.getDisplayName());
    optionDTO.setNaviId(option.getNavi().getId());
    return optionDTO;
  }

  private PackagePlanDTO convertPackagePlanEntityToDTO(final PackagePlan packagePlan) {
    final PackagePlanDTO packagePlanDTO = new PackagePlanDTO();
    packagePlan.setId(1L);
    packagePlan.setPackagePlanName("testp");
    packagePlan.setDisplayName("testd");
    Navi navi = new Navi();
    navi.setId(1L);
    packagePlan.setNavi(navi);
    packagePlan.setPrice(1000L);
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    return packagePlanDTO;
  }

  private Options options() {
    Options options = new Options();
    options.setId(1L);
    options.setDisplayName("test");
    options.setNavi(navi());
    return options;
  }
}
