package com.nissan.admission.service;

import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.service.impl.AdmissionProcessorV2;
import com.nissan.admission.service.impl.AdmissionServiceImplV2;
import com.nissan.common.dto.UserDto;
import com.nissan.common.entity.User;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
public class AdmissionServiceImplV2Test {
  @InjectMocks private AdmissionServiceImplV2 admissionServiceImplV2;
  @Mock UserService userService;
  @Mock AuthorisationService authorisationService;
  @Mock UserRepository userRepository;
  @Mock AdmissionProcessorV2 admissionProcessorV2;
  @Mock AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO;
  @Mock AdmissionProcessorChainV2 paperAdmissionProcessorV2;
  @Mock AdmissionProcessorChainV2 digitalAdmissionProcessorV2;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  private void saveAdmissionInfo() {
    when(userService.saveUser(any(UserDto.class))).thenReturn(any(User.class));
    when(authorisationService.generateTokenOnUser(anyLong())).thenReturn(anyString());
    when(userRepository.findById(anyLong()).get()).thenReturn(any(User.class));
    when(userRepository.save(any(User.class))).thenReturn(any(User.class));
    admissionProcessorV2.setRequest(admissionSaveRequestV2DTO, anyString(), anyLong(), "dealer");
    paperAdmissionProcessorV2.setNextChain(digitalAdmissionProcessorV2);
    when(paperAdmissionProcessorV2.saveAdmissionInfo(admissionProcessorV2, anyString()))
        .thenReturn(any(AdmissionSaveResponseV2DTO.class));
  }
}
