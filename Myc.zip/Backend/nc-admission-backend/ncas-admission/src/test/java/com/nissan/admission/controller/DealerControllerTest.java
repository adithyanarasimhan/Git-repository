package com.nissan.admission.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nissan.common.service.MapionService;
import com.nissan.common.dto.DealerAddressDTO;
import com.nissan.common.dto.ZipCodeResponseDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.service.CustomerService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
public class DealerControllerTest {

  public static final String PRINCIPAL_ID = "principalId";
  public static final String ONE = "1";
  public static final String APPLICATION_JSON = "application/json";

  @InjectMocks private DealerController dealerController;
  private MockMvc mockMvc;
  @Mock HttpServletRequest httpRequest;
  @Mock private DealerRepository dealerRepository;
  @Mock private MapionService mapionService;
  @Mock private CustomerService customerService;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(dealerController).build();
  }

  @Test
  public void getAddressByZip() throws Exception {
    List<DealerAddressDTO> dealerAddressDTOS = new ArrayList<>();
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    when(dealerRepository.findByUserId(any())).thenReturn(dealerEntity);
    when(mapionService.getAddressByZip(anyString(), anyInt())).thenReturn(dealerAddressDTOS);
    ResultActions result =
        mockMvc
            .perform(
                get("/secured/api/v1/{langCode}/dealers/zipCode", 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("principalId", "1")
                    .param("zipCode", "2200001")
                    .param("radius", "10")
                    .content(new ObjectMapper().writeValueAsString(dealerEntity)))
            .andExpect(status().isOk());
    assertEquals(200, result.andReturn().getResponse().getStatus());
  }

  @Test
  public void getAddressByLoc() throws Exception {
    List<DealerAddressDTO> dealerAddressDTOS = new ArrayList<>();
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    when(dealerRepository.findByUserId(any())).thenReturn(dealerEntity);
    when(mapionService.getAddressByLoc(anyString(), anyString(), anyString(), anyInt())).thenReturn(dealerAddressDTOS);
    ResultActions result =
        mockMvc
            .perform(
                get("/secured/api/v1/{langCode}/dealers/prefecture", 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("principalId", "1")
                    .param("loc", "神奈川県")
                    .param("municipality", "神奈川県")
                    .param("radius", "10")
                    .content(new ObjectMapper().writeValueAsString(dealerEntity)))
            .andExpect(status().isOk());
    assertEquals(200, result.andReturn().getResponse().getStatus());
  }

  @Test
  public void zipCode() throws Exception {
    ZipCodeResponseDTO zipCodeResponseDTO = new ZipCodeResponseDTO();
    zipCodeResponseDTO.setAddress1("Test Address");
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    when(dealerRepository.findByUserId(any())).thenReturn(dealerEntity);
    when(customerService.fetchPrefecture(anyString(), anyString())).thenReturn(zipCodeResponseDTO);
    ResultActions result =
        mockMvc
            .perform(
                get("/secured/api/v1/{langCode}/dealers/zip-code", 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("principalId", "1")
                    .param("zipCode", "2200001")
                    .content(new ObjectMapper().writeValueAsString(dealerEntity)))
            .andExpect(status().isOk());
    assertEquals(200, result.andReturn().getResponse().getStatus());
  }

  @Test
  public void saveDealer() throws Exception {
    DealerAddressDTO dealerAddressDTO = new DealerAddressDTO();
    dealerAddressDTO.setCompanyCode("1300");
    dealerAddressDTO.setCompanyName("日産プリンス神奈川販売株式会社");
    dealerAddressDTO.setDealerName("保土ヶ谷店");
    dealerAddressDTO.setDealershipCode("1L2");
    dealerAddressDTO.setAddress("横浜市保土ヶ谷区和田1-7-24");
    dealerAddressDTO.setPrefectureName("神奈川県");
    String principalId = "1";
    when(httpRequest.getHeader("principalId")).thenReturn(principalId);
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setUserId(1L);
    when(dealerRepository.findByUserId(any())).thenReturn(dealerEntity);

    ResultActions result =
        mockMvc
            .perform(
                post("/secured/api/v1/{langCode}/dealer/saveAddress", 1L)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("principalId", "1")
                    .content(new ObjectMapper().writeValueAsString(dealerAddressDTO)))
            .andExpect(status().isOk());
    assertEquals(200, result.andReturn().getResponse().getStatus());
  }
}
