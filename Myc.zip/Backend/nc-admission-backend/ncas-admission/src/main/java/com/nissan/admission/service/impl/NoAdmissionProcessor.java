package com.nissan.admission.service.impl;

import com.nissan.common.entity.Admission;
import com.nissan.common.entity.Comment;
import com.nissan.common.entity.Orders;
import com.nissan.common.util.Constants;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.service.AdmissionProcessorChain;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

public class NoAdmissionProcessor implements AdmissionProcessorChain {
  private AdmissionProcessorChain nextChain;
  private static final Logger logger = LoggerFactory.getLogger(NoAdmissionProcessor.class);

  @Override
  public void setNextChain(AdmissionProcessorChain admissionProcessorChain) {
    this.nextChain = admissionProcessorChain;
  }

  @Override
  public AdmissionSaveResponseDTO saveAdmissionInfo(AdmissionProcessor admissionProcessor, String lang) {
    logger.info("Inside No admission processor");
    AdmissionSaveResponseDTO saveResponse = null;
    if (AdmissionProcessor.ADMISSION_TYPE_NOT_INTERESTED == admissionProcessor.getSaveRequestDTO().getAdmissionType()) {
      saveResponse = saveNotInterestedInfo(admissionProcessor, lang);
    } else if (this.nextChain != null) {
      saveResponse = this.nextChain.saveAdmissionInfo(admissionProcessor, lang);
    }
    return saveResponse;
  }

  @Transactional
  private AdmissionSaveResponseDTO saveNotInterestedInfo(AdmissionProcessor admissionProcessor, String lang) {
    logger.info("Save not interested admission");
    Admission admission = admissionProcessor.getAdmissionInfo(lang);
    admission.setStatus(Constants.STATUS_DEALER_COMPLETED);
    admission.setStatusJp(Constants.NO_THANKS_DEALER_COMPLETED_JP);
    Admission newAdmission = admissionProcessor.getAdmissionRepository().save(admission);
    admissionProcessor.getActivityUtil().createActivityLog(newAdmission);

    Orders orders = admissionProcessor.getOrdersInfo(newAdmission, lang);
    Orders newOrder = admissionProcessor.getOrdersRepository().save(orders);

    Comment comment = admissionProcessor.getCommentInfo(newOrder, lang);
    Comment newComment = admissionProcessor.getCommentRepository().save(comment);

    return admissionProcessor.getAdmissionResponse(newAdmission, newOrder, newComment, null);
  }
}
