package com.nissan.admission.dto;

import lombok.Data;

import java.util.List;

@Data
public class ResultInfo {
  List<Object> objects;
}
