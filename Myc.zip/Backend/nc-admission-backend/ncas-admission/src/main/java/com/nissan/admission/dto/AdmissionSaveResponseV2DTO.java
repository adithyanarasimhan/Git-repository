package com.nissan.admission.dto;

import lombok.Data;

@Data
public class AdmissionSaveResponseV2DTO {
    private Long admissionId;
    private String vinNumber;
    private String registrationDate;
    private Long modelId;
    private Long gradeId;
    private Long naviId;
    private Long packagePlanId;
    private Long paymentMethodId;
    private Long optionId;
    private String colorCode;
    private String color;
    private String orderNumber;
    private Long userId;
    private String token;
    private Long reasonId;
    private String comments;
}
