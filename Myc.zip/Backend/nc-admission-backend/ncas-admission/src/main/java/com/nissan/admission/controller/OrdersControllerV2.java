package com.nissan.admission.controller;

import com.nissan.admission.dto.*;
import com.nissan.admission.dto.ActivityLogResponseDTO;
import com.nissan.admission.dto.OrdersUpdateResponseDTO;
import com.nissan.admission.service.OrdersServiceV2;
import com.nissan.common.dto.*;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.util.Constants;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("secured/api/v2")
public class OrdersControllerV2 {

  private static final Logger logger = LoggerFactory.getLogger(OrdersControllerV2.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(OrdersControllerV2.class);

  @Autowired private DealerRepository dealerRepository;
  @Autowired OrdersServiceV2 ordersService;

  @PostMapping(value = "{langCode}/p2/orders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchOrderV2Details(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "langCode") String lang,
      @RequestBody OrderListRequestDto orderListRequestDto) {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "404", "Dealer not found"), HttpStatus.NOT_FOUND);
    }
    FetchOrdersV2Dto orders =
        ordersService.fetchOrdersV2ByDealerId(dealer, lang, orderListRequestDto);
    if (orders == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Could not fetch Orders details"),
          HttpStatus.NOT_FOUND);
    }
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "Orders Retrieved Successfully");
    response.setData(orders);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @GetMapping(
      value = "{langCode}/orders/{orderNumber}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchOrderDetails(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "orderNumber") String orderNumber,
      @PathVariable(name = "langCode") String lang) {
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"principalId in fetchOrderDetails :"+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    logger.info("dealer user id : " + dealer.getDealerId(), dealer.getUserId());
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    FetchOrderV2ResponseDTO fetchResponse =
        ordersService.fetchOrderV2ByOrderNumber(orderNumber, dealer, lang);
    if (fetchResponse == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Could not fetch Orders details"),
          HttpStatus.NOT_FOUND);
    }
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "Orders Retrieved Successfully");
    response.setData(fetchResponse);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @GetMapping(
      value = "{langCode}/orders-download",
      produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public ResponseEntity<ResponseDTO> downloadOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      @PathVariable(name = "langCode") String langCode,
      @RequestParam(required = false, name = "startDate") String startDate,
      @RequestParam(required = false, name = "endDate") String endDate)
      throws IOException {
    logger.info("Inside download api");
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.NOT_FOUND);
    }
    String status =
        ordersService.downloadOrders(
            httpServletRequest, httpServletResponse, dealer, langCode, startDate, endDate);
    if (Constants.SUCCESS.equals(status)) {
      return ResponseEntity.ok()
          .contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
          // .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" +
          // resource.getFilename() + "\"")
          .body(null);
      //      return new ResponseEntity<>(
      //          new ResponseDTO(Constants.SUCCESS, "200", "CSV fetched successfully"),
      // HttpStatus.OK);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "404", "Csv not fetched"), HttpStatus.NOT_FOUND);
    }
  }

  @DeleteMapping(
      value = "{langCode}/orders/{orderNumber}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> deleteOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      @PathVariable(name = "langCode") String langCode,
      @PathVariable(name = "orderNumber") String orderNumber) {
    logger.info("Inside delete order API");
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"principalId in delete order :"+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"delete order number : "+orderNumber + "dealer : "+dealer.getDealerId());
    String status = ordersService.deleteOrders(orderNumber, dealer);
    if (Constants.SUCCESS.equals(status)) {
      logger.info("delete order success");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "Order Deleted Successfully"), HttpStatus.OK);
    }
    return new ResponseEntity<>(
        new ResponseDTO(Constants.FAILED, "500", "Could not delete orders"),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @GetMapping(
      value = "{langCode}/orders/activity-log/{orderNumber}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchOrdersActivityLog(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "orderNumber") String orderNumber,
      @PathVariable(name = "langCode") String lang) {
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"****principalId in fetchOrderDetails :  "+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    logger.info("dealer id : " + dealer.getDealerId());
    logger.info("dealer user id : " + dealer.getUserId());
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    List<ActivityLogResponseDTO> activityLogResponseDTOS =
        ordersService.fetchOrderActivityLog(orderNumber, dealer, lang);
    if (activityLogResponseDTOS == null) {
      ResponseDTO response =
          new ResponseDTO(Constants.SUCCESS, "200", "Activity Log details not found");
      response.setData(new ArrayList<>());
      return new ResponseEntity<>(response, HttpStatus.OK);
    } else {
      ResponseDTO response =
          new ResponseDTO(Constants.SUCCESS, "200", "Activity Log details Retrieved Successfully");
      response.setData(activityLogResponseDTOS);
      return new ResponseEntity<>(response, HttpStatus.OK);
    }
  }

  @PostMapping(value = "{langCode}/orders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> updateOrders(
          HttpServletRequest httpServletRequest,
          @RequestBody OrdersV2UpdateRequestDTO updateRequestDTO,
          @PathVariable(name = "langCode") String langCode)
          throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    OrdersUpdateResponseDTO updateResponseDTO =
            ordersService.updateOrders(updateRequestDTO, langCode, dealer);
    if (Constants.SUCCESS.equals(updateResponseDTO.getStatus())) {
      ResponseDTO response =
              new ResponseDTO(Constants.SUCCESS, "200", "Order updated successfully");
      response.setData(updateResponseDTO);
      return new ResponseEntity<>(response, HttpStatus.OK);
    }
    return new ResponseEntity<>(
            new ResponseDTO(Constants.FAILED, "500", "Could not update orders"),
            HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @PutMapping(value = "{langCode}/mapVehicleNumber", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> mapVehicleNumber(
          HttpServletRequest httpServletRequest,
          @Valid @RequestBody VehicleNumberMappingDTO mappingDTO,
          @PathVariable(name = "langCode") String langCode) {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    String status = ordersService.mapVehicleNumber(mappingDTO, dealer, langCode);
    if (Constants.SUCCESS.equals(status)) {
      if (Constants.EN.equals(langCode)) {
        return new ResponseEntity<>(
                new ResponseDTO(Constants.SUCCESS, "200", "Vehicle Number mapped successfully"), HttpStatus.OK);
      } else {
        return new ResponseEntity<>(
                new ResponseDTO(Constants.SUCCESS, "200", "車両Noおよび車両登録年月、初度登録年月を登録しました。"), HttpStatus.OK);
      }

    }
    return new ResponseEntity<>(
            new ResponseDTO(Constants.FAILED, "500", "Could not map Vehicle Number to order"),
            HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
