package com.nissan.admission.dto;

import lombok.Data;

import java.util.List;

@Data
public class OrderListRequestDto {
  private boolean mop;
  private boolean dop;
  private List<ModelIdDto> models;
  private String ncasNumber;
  private String vin;
  private Long naviid;
  private String caName;
  private String caNameKana;
  private String caCompName;
  private String customerName;
  private String customerNameKana;
  private String customerPhoneNumber;
  private String customerZipCode;
  private Integer offset;
  private Integer limit;
  private String sortBy;
  private String sortOrder;
  private String vehicleType;
}
