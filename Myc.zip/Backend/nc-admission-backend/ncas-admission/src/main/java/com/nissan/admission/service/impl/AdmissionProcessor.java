package com.nissan.admission.service.impl;

import com.nissan.admission.dto.AdmissionSaveRequestDTO;
import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.entity.Signature;
import com.nissan.admission.repository.SignatureRepository;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdmissionProcessor {

  @Getter private AdmissionSaveRequestDTO saveRequestDTO;
  @Getter private String dealerId;
  @Getter private Integer userId;

  @Getter @Autowired AuthorisationService authorisationService;

  @Getter @Autowired ModelRepository modelRepository;
  @Getter @Autowired GradeRepository gradeRepository;
  @Getter @Autowired NaviRepository naviRepository;
  @Getter @Autowired PackagePlanRepository packagePlanRepository;
  @Getter @Autowired ReasonRepository reasonRepository;
  @Getter @Autowired AdmissionRepository admissionRepository;
  @Getter @Autowired OrdersRepository ordersRepository;
  @Getter @Autowired CommentRepository commentRepository;
  @Getter @Autowired SignatureRepository signatureRepository;
  @Getter @Autowired UserRepository userRepository;
  @Getter @Autowired DealerRepository dealerRepository;
  @Getter @Autowired PaymentMethodRepository paymentMethodRepository;
  @Getter @Autowired OptionsRepository optionsRepository;
  @Getter @Autowired ColorRepository colorRepository;
  @Getter @Autowired ActivityUtil activityUtil;

  public static final String PAYMENT_METHOD_DIGITAL = "digital";
  public static final String PAYMENT_METHOD_BANK = "bank";
  public static final String PAYMENT_METHOD_PAPER = "paper";
  public static final String NAVIGATION_TYPE_MOP = "m-op";
  public static final Integer ADMISSION_TYPE_INTERESTED = 1;
  public static final Integer ADMISSION_TYPE_NOT_INTERESTED = 2;

  private static final Logger logger = LoggerFactory.getLogger(AdmissionProcessor.class);

  public void setRequest(AdmissionSaveRequestDTO requestDTO, String dealerId, Integer userId) {
    this.saveRequestDTO = requestDTO;
    this.dealerId = dealerId;
    this.userId = userId;
  }

  public Comment getCommentInfo(Orders orderInfo, String lang) {
    logger.info("inside comment info");
    Comment comment = new Comment();
    comment.setOrdersId(orderInfo.getId());
    comment.setReasonId(saveRequestDTO.getReasonType());
    comment.setComment(saveRequestDTO.getComments());
    comment.setLangCode(lang);
    comment.setCreatedBy(String.valueOf(userId));
    comment.setActive(true);
    return comment;
  }

  public Orders getOrdersInfo(Admission admissionInfo, String lang) {
    logger.info("inside orders info");
    Orders orders = new Orders();
    orders.setAdmission(admissionRepository.getOne(admissionInfo.getId()));
    orders.setOrdersNumber(generateOrderNumber(admissionInfo.getId()));
    orders.setAdmissionType(saveRequestDTO.getAdmissionType());
    orders.setModel(modelRepository.findById(saveRequestDTO.getModel().longValue()).get());
    orders.setGrade(gradeRepository.getOne(saveRequestDTO.getGrade().longValue()));
    if (saveRequestDTO.getNaviType() != null)
      orders.setNavi(naviRepository.getOne(saveRequestDTO.getNaviType().longValue()));
    if (saveRequestDTO.getOption() != null && saveRequestDTO.getOption() > 0) {
      orders.setOptions(optionsRepository.getOne(saveRequestDTO.getOption()));
    }
    if (saveRequestDTO.getPackagePlan() != null && saveRequestDTO.getPackagePlan() > 0) {
      orders.setPackagePlan(
          packagePlanRepository.getOne(saveRequestDTO.getPackagePlan().longValue()));
    }
    if (saveRequestDTO.getPaymentType() != null && saveRequestDTO.getPaymentType() > 0) {
      orders.setPaymentMethod(paymentMethodRepository.getOne(saveRequestDTO.getPaymentType()));
    }
    orders.setVehicleTransfer(Boolean.valueOf(saveRequestDTO.getVehicleTransfer()));
    orders.setVinNumber(saveRequestDTO.getVinNumber());
    orders.setLangCode(lang);
    orders.setTerms(saveRequestDTO.getTermsAndConditions());
    orders.setCreatedBy(String.valueOf(dealerId));
    orders.setActive(true);
    orders.setUploadKameri(false);
    // added inorder to perform edit order functionality
    if (saveRequestDTO.getDealerDetails() != null) {
      orders.setCompanyName(saveRequestDTO.getDealerDetails().getCompanyName());
      orders.setDealershipName(saveRequestDTO.getDealerDetails().getDealershipName());
      orders.setPhoneNumber(saveRequestDTO.getDealerDetails().getPhoneNumber());
      orders.setCaName(saveRequestDTO.getDealerDetails().getCaName());
      orders.setCaNameKana(saveRequestDTO.getDealerDetails().getCaNameKana());
      orders.setCaCode(saveRequestDTO.getDealerDetails().getCaCode());
    }
    return orders;
  }

  private String generateOrderNumber(Long admissionId) {
    // TODO : generate order number
    return "orders" + admissionId;
  }

  public Admission getAdmissionInfo(String lang) {
    logger.info("inside admission info");
    Admission admission = new Admission();
    admission.setDealer(dealerRepository.findByDealerId(dealerId));
    admission.setUser(userRepository.getOne(userId.longValue()));
    admission.setCreatedBy(String.valueOf(dealerId));
    admission.setLangCode(lang);
    admission.setActive(true);
    return admission;
  }

  public AdmissionSaveResponseDTO getAdmissionResponse(
      Admission admission, Orders orders, Comment comment, Signature signature) {
    logger.info("inside get admission response");
    AdmissionSaveResponseDTO admissionSaveResponse = new AdmissionSaveResponseDTO();

    logger.info("userId: {}", userId);
    if (userId != null ) {
      logger.info("generate token for user");
      String token = authorisationService.generateTokenOnUser(userId.longValue());
      String encodedTokenToken = token.substring(token.length() - 8);
      User user = userRepository.findById(Long.valueOf(userId)).get();
      user.setEncodedToken(encodedTokenToken);
      user.setToken(token);
      userRepository.save(user);
      if (token != null) admissionSaveResponse.setToken(encodedTokenToken);
    }

    if (admission != null) {
      admissionSaveResponse.setAdmissionId(admission.getId());
      admissionSaveResponse.setUserId(admission.getUser().getId().intValue());
    }

    if (orders != null) {
      admissionSaveResponse.setOrderNumber(orders.getOrdersNumber());
      admissionSaveResponse.setAdmissionType(orders.getAdmissionType());
      admissionSaveResponse.setModel(orders.getModel().getId().intValue());
      admissionSaveResponse.setGrade(orders.getGrade().getId().intValue());
      if (orders.getNavi() != null)
        admissionSaveResponse.setNaviType(orders.getNavi().getId().intValue());
      if (orders.getPaymentMethod() != null)
        admissionSaveResponse.setPaymentMethod(orders.getPaymentMethod().getId().intValue());
      if (orders.getPackagePlan() != null)
        admissionSaveResponse.setPackagePlan(orders.getPackagePlan().getId().intValue());
      admissionSaveResponse.setVehicleTransfer(String.valueOf(orders.getVehicleTransfer()));
      admissionSaveResponse.setVinNumber(orders.getVinNumber());
    }

    if (comment != null) {
      admissionSaveResponse.setReasonType(comment.getReasonId());
      admissionSaveResponse.setComments(comment.getComment());
    }

    if (signature != null) {
      admissionSaveResponse.setSignature(signature.getSignature().toString());
      admissionSaveResponse.setUserName(signature.getUserName());
    }

    return admissionSaveResponse;
  }

  public String getNotificationMethod(Long paymentTypeId) {
    logger.info("inside getNotificationMethod");
    Optional<PaymentMethod> paymentMethod = paymentTypeId != null ?
        paymentMethodRepository.findById(paymentTypeId) : null;
    return Optional.ofNullable(paymentMethod)
        .map(pay -> pay.get().getName())
        .orElse(PAYMENT_METHOD_PAPER);
  }
}
