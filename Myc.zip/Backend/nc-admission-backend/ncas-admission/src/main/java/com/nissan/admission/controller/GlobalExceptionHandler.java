package com.nissan.admission.controller;

import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import com.nissan.admission.dto.ErrorResult;
import com.nissan.admission.dto.FieldValidationError;
import com.nissan.admission.exception.FileProcessException;
import com.nissan.admission.model.StatusMessage;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.exception.AlreadyExistException;
import com.nissan.common.exception.DetailsNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@ControllerAdvice
@Component
public class GlobalExceptionHandler {

  private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(MethodArgumentNotValidException.class)
  @ResponseBody
  public ErrorResult handleMethodArgumentNotValidException(
      MethodArgumentNotValidException exception) {
    ErrorResult errorResult = new ErrorResult();
    for (FieldError fieldError : exception.getBindingResult().getFieldErrors()) {
      errorResult
          .getResult()
          .add(new FieldValidationError(fieldError.getField(), fieldError.getDefaultMessage()));
    }
    return errorResult;
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(value = {AlreadyExistException.class})
  public ResponseEntity<StatusMessage> noHandlerFoundException(Exception ex) {

    return new ResponseEntity<>(
        new StatusMessage(BAD_REQUEST.value(), "Data is already exist in the application"),
        BAD_REQUEST);
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(value = {DetailsNotFoundException.class})
  public ResponseEntity<StatusMessage> DetailsNotFound(Exception ex) {

    return new ResponseEntity<>(
        new StatusMessage(BAD_REQUEST.value(), "Data is not found"), BAD_REQUEST);
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({AccessDeniedException.class})
  public Object handleAll(final Exception ex, final WebRequest request) {
    return new ResponseEntity<>(
        new ResponseDTO<>(
            "resource is permitted to access",
            HttpStatus.FORBIDDEN.toString(),
            ex.getLocalizedMessage()),
        HttpStatus.FORBIDDEN);
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({DataIntegrityViolationException.class})
  public Object handleDataIntegrity(
          final DataIntegrityViolationException ex, final WebRequest request) {
    return new ResponseEntity<>(
        new ResponseDTO<>("error", INTERNAL_SERVER_ERROR.toString(), "Duplicate value is entered"),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({ResourceNotFoundException.class})
  public ResponseEntity<StatusMessage> resourceNotFound(
      final ResourceNotFoundException ex, final WebRequest request) {
    return new ResponseEntity<>(
        new StatusMessage(BAD_REQUEST.value(), "Record is not found"), BAD_REQUEST);
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({FileProcessException.class})
  public ResponseEntity<StatusMessage> fileProcess(
          final FileProcessException ex, final WebRequest request) {
    return new ResponseEntity<>(
            new StatusMessage(BAD_REQUEST.value(), "File process Exception"), BAD_REQUEST);
  }
}
