package com.nissan.admission.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;

@Data
@NoArgsConstructor
public class RegisterMailDto {

    @Email(message = "Email should be valid ")
    private String email;

    public RegisterMailDto setEmail(String email) {
        this.email = email;
        return this;
    }
}
