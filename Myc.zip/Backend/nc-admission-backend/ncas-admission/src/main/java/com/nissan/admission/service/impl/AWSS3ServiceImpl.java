package com.nissan.admission.service.impl;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.nissan.admission.exception.FileProcessException;
import com.nissan.admission.service.AWSS3Service;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.entity.OrdersV2;
import com.nissan.common.entity.User;
import com.nissan.common.repository.AdmissionV2Repository;
import com.nissan.common.repository.OrdersV2Repository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
public class AWSS3ServiceImpl implements AWSS3Service {

  private static final Logger LOGGER = LoggerFactory.getLogger(AWSS3ServiceImpl.class);

  public static final String HYPHEN = "-";

  @Value("${aws.s3.bucket}")
  private String bucketName;

  @Autowired private AmazonS3 amazonS3;

  @Autowired private UserRepository userRepository;

  @Autowired private AdmissionV2Repository admissionV2Repository;

  @Autowired private OrdersV2Repository ordersV2Repository;

  @Autowired ActivityUtil activityUtil;

  /**
   * Vehicle inspection document upload to S3
   *
   * @param multipartFile
   * @return
   */
  @Override
  public PutObjectResult uploadFile(final MultipartFile multipartFile, String userName) {
    LOGGER.info("Inside file upload method");
    User user = userRepository.findById(Long.valueOf(userName)).get();
    LOGGER.info("Finding admission by user ID {}", user.getId());
    AdmissionV2 admission = admissionV2Repository.fetchByUserId(user.getId());
    OrdersV2 order = ordersV2Repository.findByAdmissionId(admission.getId());

    String orderNumber = order.getOrdersNumber();
    LOGGER.info("File upload in progress.");
    PutObjectResult putObjectResult;
    try {
      String s3Key = orderNumber + HYPHEN + multipartFile.getOriginalFilename();
      byte[] fileContent = multipartFile.getBytes();
      LOGGER.info("Base64 file String {}", Base64.getEncoder().encodeToString(fileContent));
      byte[] encodedString = Base64.getEncoder().encode(fileContent);
      InputStream stream = new ByteArrayInputStream(encodedString);
      putObjectResult = uploadFileToS3Bucket(bucketName, stream, s3Key);
      LOGGER.info("File upload completed.");

      admission.setDocumentName(multipartFile.getOriginalFilename());
      AdmissionV2 updatedAdmission = admissionV2Repository.save(admission);
      if (Constants.ADMISSION_SOURCE_DEALER.equals(StringUtils.isNotEmpty(order.getSource()))
          && StringUtils.isNotEmpty(updatedAdmission.getDocumentName())
          && StringUtils.isNotEmpty(order.getVehicleNumber())
          && StringUtils.isNotEmpty(order.getFirstRegistrationDate())
          && StringUtils.isNotEmpty(order.getRegistrationDate())) {
        updatedAdmission.setStatus(Constants.STATUS_DEALER_ALL_COMPLETED);
        updatedAdmission.setStatusJp(Constants.STATUS_DEALER_ALL_COMPLETED_JP);
        updatedAdmission = admissionV2Repository.save(updatedAdmission);
        activityUtil.createActivityLogV2(updatedAdmission);
      }
    } catch (final AmazonServiceException | IOException e) {
      LOGGER.info("S3 upload failed {} ", multipartFile.getOriginalFilename());
      LOGGER.error("Error {} while uploading file.", e.getMessage());
      throw new FileProcessException("Amazon S3 couldn't process the request", e);
    }
    return putObjectResult;
  }

  /**
   * Vehicle inspection document download to view from S3
   *
   * @param fileName
   * @return
   * @throws IOException
   */
  @Override
  public String downloadFile(String fileName) throws IOException {
    String base64File = null;
    LOGGER.info("Downloading Inception Doc for order {}", fileName);
    final S3Object s3Object = amazonS3.getObject(bucketName, fileName);
    final S3ObjectInputStream inputStream = s3Object.getObjectContent();
    try {
      base64File = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
      LOGGER.info("File downloaded successfully.");
      s3Object.close();
    } catch (final IOException ex) {
      LOGGER.info("Inception Doc download error {}", ex.getMessage());
      throw new IOException(ex.getMessage());
    }
    return base64File;
  }

  /**
   * Vehicle inspection document delete from S3
   *
   * @param userName
   * @return
   */
  @Override
  public String deleteFile(String userName) {
    String fileName = getInceptionDocName(userName);
    LOGGER.info("Deleting Inception Doc for order {} ", fileName);
    ObjectListing objectList = this.amazonS3.listObjects(this.bucketName, fileName);
    if (objectList.getObjectSummaries().size() > 0) {
      for (S3ObjectSummary objectSummary : objectList.getObjectSummaries()) {
        final DeleteObjectRequest deleteObjectRequest =
            new DeleteObjectRequest(bucketName, objectSummary.getKey());
        amazonS3.deleteObject(deleteObjectRequest);
      }
      User user = userRepository.findById(Long.valueOf(userName)).get();
      LOGGER.info("Finding admission by user ID {}", user.getId());
      AdmissionV2 admission = admissionV2Repository.fetchByUserId(user.getId());
      admission.setDocumentName("");
      admissionV2Repository.save(admission);
    } else {
      LOGGER.info("S3 file delete failed {} ", fileName);
      return "";
    }
    LOGGER.info("File deleted successfully.");
    return fileName.substring(fileName.lastIndexOf(HYPHEN) + 1);
  }

  private PutObjectResult uploadFileToS3Bucket(
      final String bucketName, final InputStream file, final String key) throws IOException {
    LOGGER.info("S3 document file name : {} ", key);
    ObjectMetadata metadata = new ObjectMetadata();
    metadata.setContentLength(file.available());
    return amazonS3.putObject(bucketName, key, file, metadata);
  }

  public String getInceptionDocName(String userName) {
    User user = userRepository.findById(Long.valueOf(userName)).get();
    LOGGER.info("Finding admission by user ID {}", user.getId());
    AdmissionV2 admission = admissionV2Repository.fetchByUserId(user.getId());
    OrdersV2 order = ordersV2Repository.findByAdmissionId(admission.getId());
    return order.getOrdersNumber() + HYPHEN + admission.getDocumentName();
  }
}
