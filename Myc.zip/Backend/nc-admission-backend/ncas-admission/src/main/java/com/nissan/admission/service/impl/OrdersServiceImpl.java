package com.nissan.admission.service.impl;

import com.nissan.admission.dto.ActivityLogResponseDTO;
import com.nissan.admission.dto.MappingDTO;
import com.nissan.admission.dto.OrdersUnMapDTO;
import com.nissan.admission.dto.OrdersUpdateResponseDTO;
import com.nissan.admission.dto.UpdateCustomerDTO;
import com.nissan.admission.entity.AdmissionType;
import com.nissan.admission.repository.AdmissionTypeRepository;
import com.nissan.admission.service.OrdersService;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.exception.DetailsNotFoundException;
import com.nissan.common.exception.IncompleteOrderException;
import com.nissan.common.exception.InvalidOrderException;
import com.nissan.common.repository.*;
import com.nissan.common.service.CustomerService;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import com.nissan.common.util.FormatValue;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.nissan.common.util.Constants.*;

@Service
public class OrdersServiceImpl implements OrdersService {
  private static final Logger logger = LoggerFactory.getLogger(OrdersServiceImpl.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(OrdersServiceImpl.class);
  @Autowired AdmissionRepository admissionRepository;
  @Autowired OrdersRepository ordersRepository;
  @Autowired PackagePlanRepository packagePlanRepository;
  @Autowired CustomerService customerService;
  @Autowired DealerRepository dealerRepository;
  @Autowired CustomerRepository customerRepository;
  @Autowired ActivityLogRepository activityLogRepository;
  @Autowired CommentRepository commentRepository;
  @Autowired PaymentRepository paymentRepository;
  @Autowired AdmissionTypeRepository admissionTypeRepository;
  @Autowired ActivityUtil activityUtil;
  @Autowired OrdersV2Repository ordersV2Repository;

  @Override
  @Transactional
  public FetchOrdersDTO fetchOrdersByDealerId(
      DealerEntity dealer,
      String lang,
      Integer offset,
      Integer limit,
      String filterType,
      String sortBy,
      String sortOrder) {
    logger.info("Inside fetch orders");
    if (dealer.getDealerType() == null || dealer.getDealerType().isEmpty()) {
      logger.error(
          "Dealer type is not available for dealer id : {} user id : {}",
          dealer.getDealerId(),
          dealer.getUserId());
      throw new RuntimeException("Dealer type is not available");
    }
    FetchOrdersDTO fetchOrdersDTO = new FetchOrdersDTO();
    List<OrdersFetchResponseDTO> orders = null;
    Pageable pageable = getPaginationForFetchOrders(offset, limit, sortBy, sortOrder, lang);
    switch (dealer.getDealerType()) {
      case DEALER_TYPE_CA:
        orders = getOrdersForDealerTypeCA(dealer, filterType, fetchOrdersDTO, pageable);
        break;
      case DEALER_TYPE_IB4:
      case DEALER_TYPE_JF0:
      case DEALER_TYPE_KAMEARI:
      case DEALER_TYPE_BUSINESS:
        orders =
            getOrdersForDealerTypeBusiness(dealer, filterType, fetchOrdersDTO, pageable);
        break;
      default:
        logger.error("Unexpected dealer type : " + dealer.getDealerType());
        throw new IllegalStateException("Unexpected dealer type : " + dealer.getDealerType());
    }
    fetchOrdersDTO.setOrders(orders);
    setAdmissionType(fetchOrdersDTO.getOrders(), lang);
    return fetchOrdersDTO;
  }

  private Pageable getPaginationForFetchOrders(
      Integer offset, Integer limit, String sortBy, String sortOrder, String lang) {
    Sort.Direction direction =
        (sortOrder != null && Constants.SORT_ASCENDING.equals(sortOrder))
            ? Sort.Direction.ASC
            : Sort.Direction.DESC;
    sortBy = (sortBy != null && "status".equals(sortBy) && "jp".equals(lang)) ? "statusJp" : sortBy;
    sortBy =
        (sortBy != null && sortBy.length() > 0 && Constants.SORTING_KEYS.containsKey(sortBy))
            ? Constants.SORTING_KEYS.get(sortBy)
            : Constants.SORTING_KEYS.get("admissionDate");
    return PageRequest.of(offset, limit, direction, sortBy);
  }

  private List<OrdersV2FetchResponseDto> getOrders(
      DealerEntity dealer, FetchOrdersV2Dto fetchOrdersDTO, Pageable pageable) {
    List<OrdersV2FetchResponseDto> orders = null;
    if (dealer.getCompanyCode() == null || dealer.getCompanyCode().isEmpty()) {
      logger.error(
          "Dealer company code is not available for dealer id : {} user id : {}",
          dealer.getDealerId(),
          dealer.getUserId());
      throw new RuntimeException("Dealer company code is not available");
    }
    LocalDateTime startDate = LocalDateTime.now().minusYears(1);
    Timestamp admissionCreatedDate = Timestamp.valueOf(startDate);

    orders =
        ordersV2Repository.fetchOrders(dealer.getCompanyCode(), pageable, admissionCreatedDate);
    fetchOrdersDTO.setTotalCount(
        ordersV2Repository.countOrders(dealer.getCompanyCode(), admissionCreatedDate));
    return orders;
  }

  @Transactional
  private void setAdmissionTypeDownloadDto(DownloadCsvOrderListDTO order, String langCode) {
    try {
      logger.info("*****Inside set admission type name");
      AdmissionType admissionType = null;
      if (AdmissionProcessor.ADMISSION_TYPE_NOT_INTERESTED.equals(order.getAdmissionType())) {
        admissionType = admissionTypeRepository.findByNameAndLangCode("nothanks", langCode);
      } else if (order.getNaviName() != null) {
        switch (order.getNaviName()) {
          case "m-op":
            if (order.getName() != null && !"bank".equals(order.getName())) {
              admissionType = admissionTypeRepository.findByNameAndLangCode("m-op", langCode);
            } else {
              admissionType =
                  admissionTypeRepository.findByNameAndLangCode("m-op(paper)", langCode);
            }
            break;
          case "d-op":
          case "d-op+s-os":
          case "s-os":
          case "m-op-free-plan":
            admissionType = admissionTypeRepository.findByNameAndLangCode("d-op", langCode);
            break;
        }
      } else {
        throw new InvalidOrderException("Navi type not found");
      }
      logger.info("*****Setting admission type Name");
      order.setAdmissionTypeName(admissionType.getDisplayName());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static DealerDTO convertDealerEntityToDTO(DealerEntity dealerEntity) {
    logger.info("dealer ca name : " + dealerEntity.getCaName());
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyCode(dealerEntity.getCompanyCode());
    dealerDTO.setCompanyName(dealerEntity.getCompanyName());
    dealerDTO.setDealershipName(dealerEntity.getDealershipName());
    dealerDTO.setPhoneNumber(dealerEntity.getPhoneNumber());
    dealerDTO.setCaName(dealerEntity.getCaName());
    dealerDTO.setCaNameKana(dealerEntity.getCaNameKana());
    dealerDTO.setCaCode(dealerEntity.getCaCode());
    dealerDTO.setDealerId(dealerEntity.getDealerId());
    dealerDTO.setUserId(dealerEntity.getUserId());
    dealerDTO.setDealerType(dealerEntity.getDealerType());
    dealerDTO.setEmail(dealerEntity.getEmail());
    return dealerDTO;
  }

  // added the method to set dealer details from order table
  private static DealerDTO convertOrderEntityToDTO(Orders orders) {
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"dealer ca name : "+ orders.getCaName());
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyName(orders.getCompanyName());
    dealerDTO.setDealershipName(orders.getDealershipName());
    dealerDTO.setPhoneNumber(orders.getPhoneNumber());
    dealerDTO.setCaName(orders.getCaName());
    dealerDTO.setCaNameKana(orders.getCaNameKana());
    dealerDTO.setCaCode(orders.getCaCode());
    return dealerDTO;
  }

  @Override
  @Transactional
  public List<ActivityLogResponseDTO> fetchOrderActivityLog(
      String orderNumber, DealerEntity dealerEntity, String lang) {
    logger.info("****Inside fetch order by number activity log");
    Orders orders = ordersRepository.findByOrdersNumber(orderNumber);
    if (orders == null) {
      logger.info("****No order details found for activity log");
      throw new DetailsNotFoundException("Order details not found");
    }
    Admission admission = orders.getAdmission();
    List<ActivityLog> activityLogs =
        activityLogRepository.fetchByAdmissionIdAndTime(admission.getId());
    logger.info("****Activity logs fetched" + activityLogs);
    if (!activityLogs.isEmpty()) {
      List<ActivityLogResponseDTO> activityLogResponseDTOS = new ArrayList<>();
      for (ActivityLog activityLog : activityLogs) {
        logger.info("****inside activity log loop");
        ActivityLogResponseDTO activityLogResponseDTO = new ActivityLogResponseDTO();
        if (lang.equals("en")) {
          activityLogResponseDTO.setMessage(activityLog.getMessage());
        } else {
          activityLogResponseDTO.setMessage(activityLog.getMessageJp());
        }
        activityLogResponseDTO.setType(activityLog.getType());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm a");
        String formatDateTime = activityLog.getTime().format(formatter);
        activityLogResponseDTO.setTime(formatDateTime);
        activityLogResponseDTOS.add(activityLogResponseDTO);
      }
      return activityLogResponseDTOS;
    } else {
      return null;
    }
  }

  @Override
  public FetchOrdersV2Dto fetchOrdersV2ByDealerId(
      DealerEntity dealer,
      String lang,
      Integer offset,
      Integer limit,
      String sortBy,
      String sortOrder) {
    logger.info("Inside fetch orders");
    if (dealer.getDealerType() == null || dealer.getDealerType().isEmpty()) {
      logger.error(
          "Dealer type is not available for dealer id : {} user id : {}",
          dealer.getDealerId(),
          dealer.getUserId());
      throw new RuntimeException("Dealer type is not available");
    }
    FetchOrdersV2Dto fetchOrdersDTO = new FetchOrdersV2Dto();
    List<OrdersV2FetchResponseDto> orders = null;
    Pageable pageable = getPaginationForFetchOrders(offset, limit, sortBy, sortOrder, lang);
    orders = getOrders(dealer, fetchOrdersDTO, pageable);
    fetchOrdersDTO.setOrders(orders);
    return fetchOrdersDTO;
  }

  private PackagePlanDTO convertPackagePlanEntityToDTO(final PackagePlan packagePlan) {
    final PackagePlanDTO packagePlanDTO = new PackagePlanDTO();
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    return packagePlanDTO;
  }

  @Override
  @Transactional
  public OrdersUpdateResponseDTO updateOrders(
      OrdersUpdateRequestDTO updateRequest, String lang, DealerEntity dealer) throws Exception {
    logger.info("Inside update orders");
    OrdersUpdateResponseDTO updateResponse = new OrdersUpdateResponseDTO();
    updateResponse.setStatus(Constants.FAILED);

    Orders orders = ordersRepository.findByOrdersNumber(updateRequest.getOrderNumber());
    if (!isValidOrder(orders, dealer) || !isUpdateOrderAllowed(orders)) {
      return updateResponse;
    }
    if (updateRequest.getCustomerDetails() != null) {
      CustomerResponseDTO updateCustomer =
          updateCustomerDetails(
              updateRequest.getCustomerDetails().getUserId(),
              updateRequest.getCustomerDetails(),
              lang);
      if (updateCustomer == null) return updateResponse;
    }
    if (orders != null) {
      orders = setOrderDetails(orders, updateRequest);
      Orders updatedOrders = ordersRepository.save(orders);
      if (Constants.STATUS_CUSTOMER_COMPLETED.equals(updatedOrders.getAdmission().getStatus())) {
        Admission admission = updatedOrders.getAdmission();
        admission.setStatus(Constants.STATUS_DEALER_WORKING);
        admission.setStatusJp(Constants.STATUS_DEALER_WORKING_JP);
        activityUtil.createActivityLog(admission);
        admissionRepository.save(admission);
      }
      if (updatedOrders == null) return updateResponse;
    }
    updateResponse.setStatus(Constants.SUCCESS);
    return updateResponse;
  }

  private Boolean isUpdateOrderAllowed(Orders orders) {
    if (orders.getUploadKameri() != null && orders.getUploadKameri()) {
      logger.info("Cannot update orders uploaded to kameri");
      throw new InvalidOrderException("Cannot update orders uploaded to kameri");
    }
    return true;
  }

  private CustomerResponseDTO updateCustomerDetails(
      Long userId, CustomerDTO customerDTO, String lang) {
    logger.info("Inside update customer details using customer service");
    CustomerResponseDTO response = null;
    try {
      if (customerDTO.getCustomerType() == null || userId == null)
        throw new RuntimeException("Customer type or userId is missing in request");
      response = customerService.updateCustomerById(customerDTO, String.valueOf(userId), lang);
    } catch (Exception e) {
      logger.info("Exception in update Customer Details : " + e.getMessage());
    }
    return response;
  }

  private Customer updateCustomerDetails(UpdateCustomerDTO updateCustomerDTO) {
    Customer customer = null;
    try {
      customer = customerRepository.findByEmail(updateCustomerDTO.getEmail());
      if (customer != null) {
        if (updateCustomerDTO.getFirstName() != null)
          customer.setFirstName(updateCustomerDTO.getFirstName());
        if (updateCustomerDTO.getFamilyName() != null)
          customer.setFamilyName(updateCustomerDTO.getFamilyName());
        if (updateCustomerDTO.getAddress1() != null)
          customer.setAddress1(updateCustomerDTO.getAddress1());
        if (updateCustomerDTO.getAddress2() != null)
          customer.setAddress2(updateCustomerDTO.getAddress2());
        if (updateCustomerDTO.getZipCode() != null) {
          Map<String, String> zip = FormatValue.formatZipCode(updateCustomerDTO.getZipCode());
          customer.setZipCode1(zip.get("firstThreeDigits"));
          customer.setZipCode2(zip.get("lastFourDigits"));
        }
        return customerRepository.save(customer);
      }
    } catch (Exception e) {
      logger.info("Exception in update Customer Details : " + e.getMessage());
    }
    return customer;
  }

  private Orders setOrderDetails(Orders ordersInfo, OrdersUpdateRequestDTO updateRequestInfo) {
    try {
      if (updateRequestInfo.getPackagePlan() != null) {
        ordersInfo.setPackagePlan(
            (packagePlanRepository.findById(updateRequestInfo.getPackagePlan().longValue()).get()));
      }
      if (updateRequestInfo.getVehicleTransfer() != null) {
        ordersInfo.setVehicleTransfer(updateRequestInfo.getVehicleTransfer());
      }
      if (updateRequestInfo.getVinNumber() != null) {
        ordersInfo.setVinNumber(updateRequestInfo.getVinNumber());
      }
      // edit order functionality for dealer
      if (updateRequestInfo.getDealerDetails() != null) {
        if (updateRequestInfo.getDealerDetails().getCompanyName() != null) {
          ordersInfo.setCompanyName(updateRequestInfo.getDealerDetails().getCompanyName());
        }
        if (updateRequestInfo.getDealerDetails().getDealershipName() != null) {
          ordersInfo.setDealershipName(updateRequestInfo.getDealerDetails().getDealershipName());
        }
        if (updateRequestInfo.getDealerDetails().getPhoneNumber() != null) {
          ordersInfo.setPhoneNumber(updateRequestInfo.getDealerDetails().getPhoneNumber());
        }
        if (updateRequestInfo.getDealerDetails().getCaName() != null) {
          ordersInfo.setCaName(updateRequestInfo.getDealerDetails().getCaName());
        }
        if (updateRequestInfo.getDealerDetails().getCaNameKana() != null) {
          ordersInfo.setCaNameKana(updateRequestInfo.getDealerDetails().getCaNameKana());
        }
        if (updateRequestInfo.getDealerDetails().getCaCode() != null) {
          ordersInfo.setCaCode(updateRequestInfo.getDealerDetails().getCaCode());
        }
      }
    } catch (Exception e) {
      logger.info("Exception in set Order Details : " + e.getMessage());
    }
    return ordersInfo;
  }

  @Override
  @Transactional
  public String mapOrders(MappingDTO mappingDTO, DealerEntity dealer, String lang) {
    logger.info("Inside map order");
    Orders orders = ordersRepository.findByOrdersNumber(mappingDTO.getOrderNumber());
    if (!isValidOrder(orders, dealer)
        || !isOrderMappingAllowed(orders)
        || !isValidProfitNumber(mappingDTO, orders, dealer, lang)) {
      return Constants.FAILED;
    }
    orders.setOrderNumberPs(mappingDTO.getProfitSystemOrderNumber());
    Orders updatedOrder = ordersRepository.save(orders);
    logger.info("order updated : " + updatedOrder.getOrdersNumber());
    Optional<Customer> customer =
        customerRepository.findByUserId(orders.getAdmission().getUser().getId());
    if (updatedOrder != null
        && mappingDTO.getProfitSystemOrderNumber().equals(updatedOrder.getOrderNumberPs())) {
      Admission admission = orders.getAdmission();
      admission.setStatus(Constants.STATUS_DEALER_COMPLETED);
      admission.setStatusJp(Constants.STATUS_DEALER_COMPLETED_JP);
      activityUtil.createActivityLog(admission);
      Admission updatedAdmission = admissionRepository.save(admission);
      if (Constants.STATUS_DEALER_COMPLETED.equals(updatedAdmission.getStatus())) {
        /*try {
          logger.info("sending mail to customer after map");
          final Mail mailtoca = mailToCaAfterMap(customer.get(), orders);
          emailSenderService.sendEmail(mailtoca);
        } catch (MessagingException exception) {
          logger.error("exception occurred while sending mail={}", exception.getMessage());
        }
        logger.info("mapped and mail sent successfully");*/
        return Constants.SUCCESS;
      }
    }
    return Constants.FAILED;
  }

  private Boolean isValidProfitNumber(
      MappingDTO mappingDTO, Orders orders, DealerEntity dealer, String lang) {
    String profitNumber = mappingDTO.getProfitSystemOrderNumber();
    Orders existingOrder =
        ordersRepository.findByOrderNumberPsAndCompanyCode(profitNumber, dealer.getCompanyCode());
    if (existingOrder != null) {
      mylogger.info(org.owasp.esapi.Logger.SECURITY_FAILURE,
              "The Profit system order no :"+ profitNumber +
              "is already mapped to "+
               existingOrder.getOrdersNumber());
      String message =
          "jp".equals(lang)
              ? "指定されたPROFIT注文書No.は、既に登録されています。"
              : "The Order no : " + profitNumber + " is already mapped";
      throw new InvalidOrderException(message);
    }
    return true;
  }

  private Boolean isOrderMappingAllowed(Orders orders) {
    if (Constants.STATUS_CUSTOMER_FILLING.equals(orders.getAdmission().getStatus())) {
      logger.info("cannot map incomplete order");
      throw new IncompleteOrderException("Cannot map incomplete order");
    }
    if (orders.getUploadKameri() != null && orders.getUploadKameri()) {
      logger.info("Cannot map orders uploaded to kameri");
      throw new InvalidOrderException("Cannot map orders uploaded to kameri");
    }
    if (AdmissionProcessor.ADMISSION_TYPE_NOT_INTERESTED == orders.getAdmissionType()) {
      logger.info("Order mapping not allowed for Admission Type Not Interested");
      throw new InvalidOrderException(
          "Order mapping not allowed for Admission Type Not Interested");
    }
    return true;
  }

  @Override
  @Transactional
  public String unMapOrders(OrdersUnMapDTO unMapDTO, DealerEntity dealer) {
    logger.info("Inside unmap order");
    Orders orders = ordersRepository.findByOrderNumberPs(unMapDTO.getProfitSystemOrderNumber());
    if (!isValidOrder(orders, dealer)) {
      return Constants.FAILED;
    }
    orders.setOrderNumberPs(null);
    Admission admission = orders.getAdmission();
    admission.setStatus(Constants.STATUS_DEALER_WORKING);
    admission.setStatusJp(Constants.STATUS_DEALER_WORKING_JP);
    activityUtil.createActivityLog(admission);
    Orders updatedOrders = ordersRepository.save(orders);
    Admission updatedAdmission = admissionRepository.save(admission);
    return (null == updatedOrders.getOrderNumberPs()
            && updatedAdmission != null
            && Constants.STATUS_DEALER_WORKING.equals(updatedAdmission.getStatus()))
        ? Constants.SUCCESS
        : Constants.FAILED;
  }

  @Override
  public String downloadOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      DealerEntity dealer,
      String lang,
      String startDate,
      String endDate,
      Boolean active)
      throws IOException {
    logger.info("*****Inside download orders");
    String status = Constants.FAILED;
    try {
      String fileName = "orderDetail.csv";
      httpServletResponse.setContentType("text/csv");
      httpServletResponse.setHeader("Content-Disposition", "attachment;filename=" + fileName);
      Writer writer = new OutputStreamWriter(httpServletResponse.getOutputStream());
      ICsvBeanWriter csvWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);
      String[] header1 = {
        "Application date time",
        "Status",
        "Admission type",
        "Dealer/Home",
        "New/Used vehicle",
        "NCAS #",
        "Profit Order #",
        "Dealer Company Code",
        "Dealer Company Name",
        "Dealsership Name",
        "Dealer phone #",
        "C/A Name",
        "C/A Name(Kana)",
        "C/A Code",
        "C/A E-mail",
        "Customer type",
        "Vehicle Model",
        "Vehicle Grade",
        "Navi type",
        "Vehicle Option 2",
        "Package plan",
        "IVI flag",
        "SOS flag",
        "VIN",
        "First registered date",
        "VIN registered date",
        "NC-ID",
        "NC status",
        "NC join date",
        "Charge start date",
        "Service update date",
        "Navi ID",
        "Register Number",
        "Vehicle Model(from CW)",
        "Service annual price",
        "E-mail sent date",
        "Payment method",
        "Transfer",
        "Old vehicle VIN",
        "Paper Reason",
        "Paper Reason free comment",
        "Active"
      };
      String[] headerJp = {
        "入会日時",
        "状態",
        "入会区分",
        "入会番号",
        "申し込み場所",
        "新車/中古車区分",
        "Profit注文書番号",
        "販売会社コード",
        "販売会社名",
        "店舗名",
        "店舗電話番号",
        "販売担当名",
        "販売担当名(かな)",
        "販売担当コード",
        "販売担当E-mail",
        "個人/法人",
        "申込車種",
        "グレード",
        "ナビタイプ",
        "オプション",
        "パッケージプラン",
        "IVIフラグ",
        "SOSコールサービスフラグ",
        "車台番号",
        "初度登録年月",
        "車両登録日",
        "NC-ID",
        "CWステータス",
        "NC入会日",
        "課金予定日",
        "更新予定日",
        "車載機ID",
        "登録番号",
        "車種(CW情報)",
        "サービス料金年額",
        "E-mail送信日",
        "支払い方法",
        "乗り換え",
        "乗り換え前車両のVIN",
        "紙申込理由",
        "フリーコメント",
        "有効(値がFalseの場合は削除済)"
      };
      String[] fieldMapping = {
        "createdDate",
        "status",
        "admissionTypeName",
        "id",
        "ordersNumber",
        "companyCode",
        "companyName",
        "dealershipName",
        "phoneNumber",
        "caName",
        "caNameKana",
        "caCode",
        "email",
        "customerType",
        "modelName",
        "gradeName",
        "naviName",
        "optionsName",
        "packagePlanName",
        "cwVinNumber",
        "firstRegisteredDate",
        "vinRegisteredDate",
        "ncId",
        "ncStatus",
        "ncJoinedDate",
        "chargeStartDate",
        "serviceUpdateDate",
        "adopterId",
        "registerNumber",
        "modelNameCw",
        "planPrice",
        "emailSendDate",
        "name",
        "vehicleTransfer",
        "vinNumber",
        "active"
      };
      csvWriter.writeHeader(header1);
      csvWriter.writeHeader(headerJp);
      logger.info("Header written to csv");
      Timestamp startDateTimeStamp = convertToSqlTimeStamp(startDate);
      Timestamp endDateTimeStamp = convertToSqlTimeStampEndDate(endDate);
      List<DownloadCsvOrderListDTO> orders =
              dealerRepository.fetchOrdersDetails(startDateTimeStamp,endDateTimeStamp, active);
      List<DownloadCsvOrderListDTO> ordersV2 =
          dealerRepository.fetchOrdersV2Details(startDateTimeStamp, endDateTimeStamp, active);
      orders.addAll(ordersV2);
      for (DownloadCsvOrderListDTO order : orders) {
        try {
          logger.info("*****Setting admission type for download file");
          setAdmissionTypeDownloadDto(order, lang);
          logger.info("*****Successfully set admission type in download file");
          csvWriter.write(order, fieldMapping);
        } catch (IOException e) {
          logger.info("exception in write order to csv : " + e.getMessage());
          e.printStackTrace();
          return null;
        }
      }
      csvWriter.close();
      logger.info("file written completed");
      status = Constants.SUCCESS;
      logger.info("status : " + status);
    } catch (Exception e) {
      logger.info("Exception in download orders : " + e.getMessage());
    }
    return status;
  }

  private Timestamp convertToSqlTimeStamp(String date) throws ParseException {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    Date parsedTimeStamp = dateFormat.parse(date);
    Timestamp timestamp = new Timestamp(parsedTimeStamp.getTime());
    return timestamp;
  }

  private Timestamp convertToSqlTimeStampEndDate(String date) throws ParseException {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    Date parsedTimeStamp = dateFormat.parse(date);
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(parsedTimeStamp);
    calendar.set(Calendar.HOUR_OF_DAY, 23);
    calendar.set(Calendar.MINUTE, 59);
    calendar.set(Calendar.SECOND, 59);
    calendar.set(Calendar.MILLISECOND, 999);
    Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
    return timestamp;
  }

  @Override
  public String deleteOrders(String orderNumber, DealerEntity dealer) {
    logger.info("Inside delete orders");
    String status = Constants.FAILED;
    Orders orders = ordersRepository.findByOrdersNumber(orderNumber);
    if (!isValidOrder(orders, dealer)) {
      return status;
    }
    if (null != orders.getAdmission() && null != orders.getAdmission().getCwStatus()) {
      if (orders.getAdmission().getCwStatus().equalsIgnoreCase(CARWINGS_STATUS_SA)) {
        logger.error("Order cannot be deleted as the status is SA");
        throw new InvalidOrderException("Order cannot be deleted");
      }
    }
    Comment comment = commentRepository.findByOrdersId(orders.getId());
    Optional<Customer> optionalCustomer =
        customerRepository.findByUserId(orders.getAdmission().getUser().getId());
    Customer customer = null;
    Payment payment = null;
    if (optionalCustomer.isPresent()) {
      customer = optionalCustomer.get();
      payment = paymentRepository.fetchByCustomerId(customer.getId());
    }
    status = deactivateOrders(orders, customer, payment, comment);
    return status;
  }

  @Transactional
  private String deactivateOrders(
      Orders orders, Customer customer, Payment payment, Comment comment) {
    logger.info("Inside deactivate orders");
    String status = Constants.FAILED;
    try {
      orders.setActive(false);
      ordersRepository.save(orders);
      orders.getAdmission().setActive(false);
      logger.info("Admission number to delete {}", orders.getAdmission().getId());
      admissionRepository.save(orders.getAdmission());
      if (customer != null) {
        customer.setActive(false);
        customerRepository.save(customer);
        if (payment != null) {
          payment.setActive(false);
          paymentRepository.save(payment);
        }
      }
      if (comment != null) {
        comment.setActive(false);
        commentRepository.save(comment);
      }
      status = Constants.SUCCESS;
    } catch (Exception e) {
      logger.info("Exception in deactivate orders : " + e.getMessage());
    }
    return status;
  }

  private Boolean isValidOrder(Orders orders, DealerEntity dealer) {
    logger.info("Inside is Valid Order");
    if (orders != null
        && !orders.getAdmission().getDealer().getCompanyCode().equals(dealer.getCompanyCode())) {
      DealerEntity orderDealerInfo = orders.getAdmission().getDealer();
      logger.error(
          "This order is not made through this dealer {} company : {} ",
          dealer.getDealerId(),
          dealer.getCompanyCode());
      logger.error(
          "order : {} comes under dealer id : {} of company {} user id : {}",
          orders.getOrdersNumber(),
          orderDealerInfo.getDealerId(),
          orderDealerInfo.getCompanyCode(),
          orderDealerInfo.getUserId());
      throw new InvalidOrderException("This order is not made through logged in dealer company");
    } else if (orders == null) {
      logger.error("Order details not found");
      throw new DetailsNotFoundException("Order details not found");
    }
    return true;
  }

  @Override
  @Transactional
  public FetchOrderResponseDTO fetchOrderByOrderNumber(
      String orderNumber, DealerEntity dealerEntity, String lang) {
    logger.info("Inside fetch order by number");
    FetchOrderResponseDTO fetchOrderResponse = new FetchOrderResponseDTO();
    try {
      Orders orders = ordersRepository.findByOrdersNumber(orderNumber);
      if (DEALER_TYPE_CA.equals(dealerEntity.getDealerType())) {
        isValidOrder(orders, dealerEntity);
      }
      Customer customer =
          customerRepository.findByUserId(orders.getAdmission().getUser().getId()).orElse(null);
      fetchOrderResponse.setOrderDetails(new OrdersFetchResponseDTO(orders, customer));
      if (orders.getNavi() != null) {
        List<PackagePlan> planList =
            packagePlanRepository.getPackageListByNaviId(orders.getNavi().getId());
        fetchOrderResponse.setPlanDetails(
            planList.stream()
                .map(this::convertPackagePlanEntityToDTO)
                .collect(Collectors.toList()));
      }
      fetchOrderResponse.setDealerDetails(convertOrderEntityToDTO(orders));
    } catch (Exception e) {
      logger.info("Exception in fetchOrderByOrderNumber : " + e.getMessage());
      throw new RuntimeException(e.getMessage());
    }
    return fetchOrderResponse;
  }

  private List<OrdersFetchResponseDTO> getOrdersForDealerTypeCA(
      DealerEntity dealer, String filterType, FetchOrdersDTO fetchOrdersDTO, Pageable pageable) {
    List<OrdersFetchResponseDTO> orders;
    if (dealer.getCompanyCode() == null || dealer.getCompanyCode().isEmpty()) {
      logger.error(
          "Dealer company code is not available for dealer id : {} user id : {}",
          dealer.getDealerId(),
          dealer.getUserId());
      throw new RuntimeException("Dealer company code is not available");
    }
    LocalDateTime startDate = LocalDateTime.now().minusYears(1);
    Timestamp admissionCreatedDate = Timestamp.valueOf(startDate);
    switch (filterType) {
      case "mapped":
        orders =
            ordersRepository.fetchMappedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), pageable, admissionCreatedDate);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countMappedOrders(dealer.getCompanyCode(), dealer.getDealerShipCode(), admissionCreatedDate));
        break;
      case "unmapped":
        orders =
            ordersRepository.fetchUnMappedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), pageable, admissionCreatedDate);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countUnMappedOrders(dealer.getCompanyCode(), dealer.getDealerShipCode(), admissionCreatedDate));
        break;
      case "others_mapped":
        orders =
            ordersRepository.fetchOtherMappedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), pageable, admissionCreatedDate);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countOtherMappedOrders(dealer.getCompanyCode(), dealer.getDealerShipCode(), admissionCreatedDate));
        break;
      case "others_unmapped":
        orders =
            ordersRepository.fetchOtherUnMappedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), pageable, admissionCreatedDate);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countOtherUnMappedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), admissionCreatedDate));
        break;
      case "not_interested":
        orders =
            ordersRepository.fetchNotInterestedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), pageable, admissionCreatedDate);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countNotInterestedOrders(
                dealer.getCompanyCode(), dealer.getDealerShipCode(), admissionCreatedDate));
        break;
      default:
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Unexpected filter type : "+ filterType);
        throw new IllegalStateException("Unexpected filter type: " + filterType);
    }
    return orders;
  }

  private List<OrdersFetchResponseDTO> getOrdersForDealerTypeBusiness(
      DealerEntity dealer, String filterType, FetchOrdersDTO fetchOrdersDTO, Pageable pageable) {
    List<OrdersFetchResponseDTO> orders;
    LocalDateTime startDate = LocalDateTime.now().minusYears(1);
    Timestamp admissionCreatedDate = Timestamp.valueOf(startDate);
    switch (filterType) {
      case "mapped":
        orders = ordersRepository.fetchMappedOrdersForBusiness(pageable, admissionCreatedDate, true);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countMappedOrdersForBusiness(admissionCreatedDate, true));
        break;
      case "unmapped":
        orders = ordersRepository.fetchUnMappedOrdersForBusiness(pageable, admissionCreatedDate, true);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countUnMappedOrdersForBusiness(admissionCreatedDate, true));
        break;
      case "others_mapped":
        orders = ordersRepository.fetchOtherMappedOrdersForBusiness(pageable, admissionCreatedDate,  true);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countOtherMappedOrdersForBusiness(admissionCreatedDate,  true));
        break;
      case "others_unmapped":
        orders =
            ordersRepository.fetchOtherUnMappedOrdersForBusiness(pageable, admissionCreatedDate, true);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countOtherUnMappedOrdersForBusiness(admissionCreatedDate,true));
        break;
      case "not_interested":
        orders =
            ordersRepository.fetchNotInterestedOrdersForBusiness(pageable, admissionCreatedDate, true);
        fetchOrdersDTO.setTotalCount(
            ordersRepository.countNotInterestedOrdersForBusiness(admissionCreatedDate, true));
        break;
      default:
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Unexpected filter type : "+ filterType);
        throw new IllegalStateException("Unexpected filter type: " + filterType);
    }
    return orders;
  }

  private List<OrdersFetchResponseDTO> getDeletedOrdersForDealerTypeBusiness(
          DealerEntity dealer, String filterType, FetchOrdersDTO fetchOrdersDTO, Pageable pageable) {
    List<OrdersFetchResponseDTO> orders;
    LocalDateTime startDate = LocalDateTime.now().minusYears(1);
    Timestamp admissionCreatedDate = Timestamp.valueOf(startDate);
    switch (filterType) {
      case "mapped":
        orders = ordersRepository.fetchMappedOrdersForBusiness(pageable, admissionCreatedDate,  false);
        fetchOrdersDTO.setTotalCount(ordersRepository.countMappedOrdersForBusiness(admissionCreatedDate,  false));
        break;
      case "unmapped":
        orders = ordersRepository.fetchUnMappedOrdersForBusiness(pageable, admissionCreatedDate, false);
        fetchOrdersDTO.setTotalCount(ordersRepository.countUnMappedOrdersForBusiness(admissionCreatedDate,  false));
        break;
      case "others_mapped":
        orders = ordersRepository.fetchOtherMappedOrdersForBusiness(pageable, admissionCreatedDate, false);
        fetchOrdersDTO.setTotalCount(ordersRepository.countOtherMappedOrdersForBusiness(admissionCreatedDate, false));
        break;
      case "others_unmapped":
        orders = ordersRepository.fetchOtherUnMappedOrdersForBusiness(pageable, admissionCreatedDate,  false);
        fetchOrdersDTO.setTotalCount(ordersRepository.countOtherUnMappedOrdersForBusiness(admissionCreatedDate, false));
        break;
      case "not_interested":
        orders = ordersRepository.fetchNotInterestedOrdersForBusiness(pageable, admissionCreatedDate, false);
        fetchOrdersDTO.setTotalCount(ordersRepository.countNotInterestedOrdersForBusiness(admissionCreatedDate,  false));
        break;
      default:
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Unexpected filter type : "+ filterType);
        throw new IllegalStateException("Unexpected filter type: " + filterType);
    }
    return orders;
  }

  private void setAdmissionType(List<OrdersFetchResponseDTO> orders, String langCode) {
    if (orders != null && !orders.isEmpty()) {
      orders.forEach(
          order -> {
            setAdmissionType(order, langCode);
          });
    }
  }

  @Transactional
  private void setAdmissionType(OrdersFetchResponseDTO order, String langCode) {
    try {
      AdmissionType admissionType = null;
      logger.info("getAdmissionType for order : {}", order.getTempOrdersNumber());
      if (AdmissionProcessor.ADMISSION_TYPE_NOT_INTERESTED.equals(order.getAdmissionType())) {
        admissionType = admissionTypeRepository.findByNameAndLangCode("nothanks", langCode);
      } else if (order.getNavi() != null) {
        NaviDTO navi = order.getNavi();
        switch (navi.getName()) {
          case "m-op":
            if (order.getPaymentMethod() != null
                && !PAYMENT_METHOD_PAPER.equals(order.getPaymentMethod().getName())) {
              admissionType = admissionTypeRepository.findByNameAndLangCode("m-op", langCode);
            } else {
              admissionType =
                  admissionTypeRepository.findByNameAndLangCode("m-op(paper)", langCode);
            }
            break;
          case "d-op":
          case "d-op+s-os":
          case "s-os":
          case "m-op-free-plan":
            admissionType = admissionTypeRepository.findByNameAndLangCode("d-op", langCode);
            break;
        }
      } else {
        throw new InvalidOrderException("Navi type not found");
      }
      order.setAdmissionTypeName(admissionType.getDisplayName());
    } catch (Exception e) {
      e.printStackTrace();
      logger.error("Error in getAdmissionType for order : {}", order.getTempOrdersNumber());
    }
  }

  @Transactional
  private String restoreOrders(
          Orders orders, Customer customer, Payment payment, Comment comment) {
    logger.info("Inside restore orders");
    String status = Constants.FAILED;
    try {
      orders.setActive(true);
      ordersRepository.save(orders);
      orders.getAdmission().setActive(true);
      logger.info("Admission number to restore {}", orders.getAdmission().getId());
      admissionRepository.save(orders.getAdmission());
      if (customer != null) {
        customer.setActive(true);
        customerRepository.save(customer);
        if (payment != null) {
          payment.setActive(true);
          paymentRepository.save(payment);
        }
      }
      if (comment != null) {
        comment.setActive(true);
        commentRepository.save(comment);
      }
      status = Constants.SUCCESS;
    } catch (Exception e) {
      logger.info("Exception in restore orders : " + e.getMessage());
    }
    return status;
  }

  @Override
  @Transactional
  public FetchOrdersDTO fetchDeletedOrdersByDealerId(DealerEntity dealer, String lang, Integer offset, Integer limit, String filterType, String sortBy, String sortOrder) {
    {
      logger.info("Inside fetch orders");
      if (dealer.getDealerType() == null || dealer.getDealerType().isEmpty()) {
        logger.error("Dealer type is not available for dealer id : {} user id : {}", dealer.getDealerId(), dealer.getUserId());
        throw new RuntimeException("Dealer type is not available");
      }
      FetchOrdersDTO fetchOrdersDTO = new FetchOrdersDTO();
      List<OrdersFetchResponseDTO> orders = null;
      Pageable pageable = getPaginationForFetchOrders(offset, limit, sortBy, sortOrder, lang);
      switch (dealer.getDealerType()) {
        case DEALER_TYPE_BUSINESS:
        case DEALER_TYPE_JF0:
        case DEALER_TYPE_KAMEARI:
          orders = getDeletedOrdersForDealerTypeBusiness(dealer, filterType, fetchOrdersDTO, pageable);
          break;
        default:
          logger.error("Permission denied : " + dealer.getDealerType());
          throw new IllegalStateException("Permission denied : " + dealer.getDealerType());
      }
      fetchOrdersDTO.setOrders(orders);
      setAdmissionType(fetchOrdersDTO.getOrders(), lang);
      return fetchOrdersDTO;
    }
  }

  @Override
  public String restoreOrders(String orderNumber, DealerEntity dealer) {
    logger.info("Inside restore orders");
    String status = Constants.FAILED;
    Orders orders = ordersRepository.findByOrdersNumber(orderNumber);
    if (orders == null) {
      logger.error("Order details not found");
      throw new DetailsNotFoundException("Order details not found");
    }
    if(null != orders.getOrderNumberPs() ) {
      Orders existingOrder = ordersRepository.findByOrderNumberPsAndCompanyCode(orders.getOrderNumberPs(), dealer.getCompanyCode());
      if (existingOrder != null) {
        logger.error("Order cannot be restore, Duplicate data");
        throw new InvalidOrderException("Order cannot be restore, Duplicate data");
      }
    }
    Comment comment = commentRepository.findByOrdersId(orders.getId());
    Optional<Customer> optionalCustomer =
            customerRepository.findByUserId(orders.getAdmission().getUser().getId());
    Customer customer = null;
    Payment payment = null;
    if (optionalCustomer.isPresent()) {
      customer = optionalCustomer.get();
      payment = paymentRepository.fetchByCustomerId(customer.getId());
    }
    status = restoreOrders(orders, customer, payment, comment);
    try {
      Admission admission = orders.getAdmission();
      ActivityLog activityLog = new ActivityLog();
      activityLog.setAdmissionId(admission.getId());
      activityLog.setTime(LocalDateTime.now());
      activityLog.setType(Constants.STATUS);
      activityLog.setMessage(Constants.STATUS_RESTORED_ORDER);
      activityLog.setMessageJp(Constants.STATUS_RESTORED_ORDER_JP);
      activityLogRepository.save(activityLog);
    }catch (Exception e)
    {
      logger.error("Exception while updating activity",e.getMessage());
    }
    return status;
  }
}
