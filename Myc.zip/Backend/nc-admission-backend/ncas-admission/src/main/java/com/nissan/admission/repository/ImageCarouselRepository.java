package com.nissan.admission.repository;

import com.nissan.admission.entity.ImageCarousel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface ImageCarouselRepository
    extends JpaRepository<ImageCarousel, Long>, QuerydslPredicateExecutor<ImageCarousel> {}
