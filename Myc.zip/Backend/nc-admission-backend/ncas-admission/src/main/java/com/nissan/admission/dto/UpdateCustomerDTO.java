package com.nissan.admission.dto;

import lombok.Data;

@Data
public class UpdateCustomerDTO {
    private String email;
    private String firstName;
    private String familyName;
    private String zipCode;
    private String address1;
    private String address2;
}
