package com.nissan.admission.repository;

import com.nissan.admission.entity.AdmissionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface AdmissionTypeRepository
    extends JpaRepository<AdmissionType, Long>,
        QuerydslPredicateExecutor<AdmissionType>,
        PagingAndSortingRepository<AdmissionType, Long> {

    AdmissionType findByNameAndLangCode(String name, String langCode);
}
