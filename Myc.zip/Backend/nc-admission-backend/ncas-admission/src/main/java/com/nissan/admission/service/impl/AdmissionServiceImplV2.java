package com.nissan.admission.service.impl;

import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.service.AdmissionProcessorChain;
import com.nissan.admission.service.AdmissionProcessorChainV2;
import com.nissan.admission.service.AdmissionServiceV2;
import com.nissan.common.dto.UserDto;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.entity.OrdersV2;
import com.nissan.common.entity.PaymentMethod;
import com.nissan.common.entity.User;
import com.nissan.common.repository.*;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.service.UserService;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.Date;
import java.util.Random;

@Service
public class AdmissionServiceImplV2 implements AdmissionServiceV2 {

  private static final Logger logger = LoggerFactory.getLogger(AdmissionServiceImplV2.class);

  @Autowired AdmissionV2Repository admissionV2Repository;
  @Autowired OrdersV2Repository ordersV2Repository;
  @Autowired UserService userService;
  @Autowired AuthorisationService authorisationService;
  @Autowired UserRepository userRepository;
  @Autowired AdmissionProcessorV2 admissionProcessorV2;
  @Autowired ColorRepository colorRepository;
  @Autowired GradeV2Repository gradeV2Repository;
  @Autowired ModelV2Repository modelV2Repository;
  @Autowired OptionsV2Repository optionsV2Repository;
  @Autowired NaviV2Repository naviV2Repository;
  @Autowired PaymentMethodRepository paymentMethodRepository;
  @Autowired PackagePlanV2Repository packagePlanV2Repository;
  @Autowired AdmissionProcessor admissionProcessor;

  @Override
  @Transactional
  public AdmissionSaveResponseV2DTO saveAdmissionInfo(
      AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, String dealerId, String lang) {
    AdmissionSaveResponseV2DTO response = null;
    try{
      logger.info("Inside saveAdmissionInfo");
      String userName = admissionSaveRequestV2DTO.getCustomerName();
      if(Constants.VEHICLE_TYPE_NEW_CAR.equals(admissionSaveRequestV2DTO.getVehicleType())) {
        response = saveAdmissionNewCarFromDealer(admissionSaveRequestV2DTO, dealerId, lang, userName);
      } else if(Constants.VEHICLE_TYPE_USED_CAR.equals(admissionSaveRequestV2DTO.getVehicleType()))
        response = saveAdmissionUsedCarFromDealer(admissionSaveRequestV2DTO, dealerId, lang, userName);
    } catch (Exception e) {
      logger.info("Exception in save admission");
      e.printStackTrace();
    }
    return response;
  }

  private AdmissionSaveResponseV2DTO saveAdmissionNewCarFromDealer(AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, String dealerId, String lang, String userName) {
    logger.info("Inside saveAdmissionNewCarFromDealer");
    AdmissionSaveResponseV2DTO response = null;
    User user = saveUserAndGenerateToken(userName);
    admissionProcessorV2.setRequest(
            admissionSaveRequestV2DTO, dealerId, user.getId(), Constants.ADMISSION_SOURCE_DEALER, Constants.VEHICLE_TYPE_NEW_CAR);

    AdmissionProcessorChainV2 paperAdmissionProcessorV2 = new PaperAdmissionProcessorV2();
    AdmissionProcessorChainV2 digitalAdmissionProcessorV2 = new DigitalAdmissionProcessorV2();

    paperAdmissionProcessorV2.setNextChain(digitalAdmissionProcessorV2);
    response = paperAdmissionProcessorV2.saveAdmissionInfo(admissionProcessorV2, lang);
    return response;
  }

  private AdmissionSaveResponseV2DTO saveAdmissionUsedCarFromDealer(AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, String dealerId, String lang, String userName) {
    logger.info("Inside saveAdmissionUsedCarFromDealer");
    AdmissionSaveResponseV2DTO response = null;
    User user = saveUserAndGenerateToken(userName);
    admissionProcessorV2.setRequest(
        admissionSaveRequestV2DTO, dealerId, user.getId(), Constants.ADMISSION_SOURCE_DEALER, Constants.VEHICLE_TYPE_USED_CAR);

    AdmissionProcessorChainV2 paperAdmissionProcessorV2 = new PaperAdmissionProcessorV2();
    AdmissionProcessorChainV2 digitalAdmissionProcessorV2 = new DigitalAdmissionProcessorV2();

    paperAdmissionProcessorV2.setNextChain(digitalAdmissionProcessorV2);
    response = paperAdmissionProcessorV2.saveAdmissionInfo(admissionProcessorV2, lang);
    return response;
  }

  private UserDto getNewUserInfo(String customerName) {
    logger.info("Inside getNewUserInfo");
    UserDto userDto = new UserDto();
    if (customerName != null) {
      userDto.setFirstName(customerName);
    }
    userDto.setUsername("user" + (new SecureRandom().ints().findFirst().getAsInt()));
    userDto.setPassword("password" + (new SecureRandom().ints().findFirst().getAsInt()));
    userDto.setType(Constants.ROLE_CUSTOMER);
    userDto.setValidToken(true);
    return userDto;
  }

  private User saveUserAndGenerateToken(String email) {
    logger.info("Inside saveUserAndGenerateToken");
    User user = userService.saveUser(getNewUserInfo(email));
    Long userId = user.getId();
    String token = authorisationService.generateTokenOnUser(userId);
    String encodedTokenToken = token.substring(token.length() - 8);
    user = userRepository.findById(userId).get();
    user.setEncodedToken(encodedTokenToken);
    user.setToken(token);
    return userRepository.save(user);
  }

  @Override
  @Transactional
  public AdmissionSaveResponseV2DTO saveHomeAdmissionInfo(
      AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, User user, String lang) {
    logger.info("Inside saveHomeAdmissionInfo");
    AdmissionSaveResponseV2DTO response = null;
    try {
      if (Constants.VEHICLE_TYPE_NEW_CAR.equals(admissionSaveRequestV2DTO.getVehicleType())) {
        response = saveAdmissionNewCarFromHome(admissionSaveRequestV2DTO, user, lang);
      } else if (Constants.VEHICLE_TYPE_USED_CAR.equals(admissionSaveRequestV2DTO.getVehicleType())) {
        response = saveAdmissionUsedCarFromHome(admissionSaveRequestV2DTO, user, lang);
      }
    } catch (Exception e) {
      logger.info("Exception in save admission");
      e.printStackTrace();
    }
    return response;
  }

  private AdmissionSaveResponseV2DTO saveAdmissionNewCarFromHome(AdmissionSaveRequestV2DTO saveRequestDTO, User user, String lang) {
    logger.info("Inside saveAdmissionNewCarFromHome");
    AdmissionSaveResponseV2DTO response = null;
    admissionProcessorV2.setRequest(
            saveRequestDTO, null, user.getId(), Constants.ADMISSION_SOURCE_HOME, Constants.VEHICLE_TYPE_NEW_CAR);

    AdmissionProcessorChainV2 digitalAdmissionProcessorV2 = new DigitalAdmissionProcessorV2();

    response = digitalAdmissionProcessorV2.saveAdmissionInfo(admissionProcessorV2, lang);
    return response;
  }

  private AdmissionSaveResponseV2DTO saveAdmissionUsedCarFromHome(AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, User user, String lang) {
    logger.info("Inside saveAdmissionUsedCarFromHome");
    AdmissionSaveResponseV2DTO response = null;
    admissionProcessorV2.setRequest(
            admissionSaveRequestV2DTO, null, user.getId(), Constants.ADMISSION_SOURCE_HOME, Constants.VEHICLE_TYPE_USED_CAR);

    AdmissionProcessorChainV2 digitalAdmissionProcessorV2 = new DigitalAdmissionProcessorV2();

    response = digitalAdmissionProcessorV2.saveAdmissionInfo(admissionProcessorV2, lang);
    return response;
  }
}
