package com.nissan.admission.dto;

import lombok.Data;

@Data
public class ModelIdDto {
  private Long id;
}
