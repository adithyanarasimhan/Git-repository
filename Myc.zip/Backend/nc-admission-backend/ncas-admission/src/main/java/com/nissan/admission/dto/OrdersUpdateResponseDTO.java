package com.nissan.admission.dto;

import lombok.Data;

@Data
public class OrdersUpdateResponseDTO {
    public String status;
}
