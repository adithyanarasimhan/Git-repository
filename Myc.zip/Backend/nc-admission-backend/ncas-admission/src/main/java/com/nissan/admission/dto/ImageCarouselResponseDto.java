package com.nissan.admission.dto;

import lombok.Data;

@Data
public class ImageCarouselResponseDto {
  private String name;
  private String url;
  private String type;
}
