package com.nissan.admission.service;

import com.nissan.common.dto.DealerDTO;

import javax.servlet.http.HttpServletRequest;

public interface DealerService {

  DealerDTO getDealerByCompanyCode(HttpServletRequest httpServletRequest, String langCode);

  String saveDealerDetails(DealerDTO dealerDTO);
}