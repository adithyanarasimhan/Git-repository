package com.nissan.admission.controller;

import com.nissan.admission.dto.ActivityLogResponseDTO;
import com.nissan.admission.dto.MappingDTO;
import com.nissan.admission.dto.OrdersUpdateResponseDTO;
import com.nissan.admission.service.OrdersService;
import com.nissan.common.dto.*;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.util.Constants;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("secured/api/v1")
public class OrdersController {
  @Autowired OrdersService ordersService;
  @Autowired private UserRepository userRepository;

  @Autowired private DealerRepository dealerRepository;

  private static final Logger logger = LoggerFactory.getLogger(OrdersController.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(OrdersController.class);

  @GetMapping(value = "{langCode}/p1/orders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchOrderDetails(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "langCode") String lang,
      @RequestParam(required = false, name = "offset", defaultValue = "0") Integer offset,
      @RequestParam(required = false, name = "limit", defaultValue = "10") Integer limit,
      @RequestParam(name = "filterType") String filterType,
      @RequestParam(required = false, name = "sortBy", defaultValue = "") String sortBy,
      @RequestParam(required = false, name = "sortOrder", defaultValue = "desc") String sortOrder) {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    FetchOrdersDTO orders =
        ordersService.fetchOrdersByDealerId(
            dealer, lang, offset, limit, filterType, sortBy, sortOrder);
    if (orders == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Could not fetch Orders details"),
          HttpStatus.NOT_FOUND);
    }
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "Orders Retrieved Successfully");
    response.setData(orders);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @GetMapping(
      value = "{langCode}/orders/{orderNumber}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchOrderDetails(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "orderNumber") String orderNumber,
      @PathVariable(name = "langCode") String lang) {
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"principalId in fetchOrderDetails :"+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    logger.info("dealer id : " + dealer.getDealerId());
    logger.info("dealer user id : " + dealer.getUserId());
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    FetchOrderResponseDTO fetchResponse =
        ordersService.fetchOrderByOrderNumber(orderNumber, dealer, lang);
    if (fetchResponse == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Could not fetch Orders details"),
          HttpStatus.NOT_FOUND);
    }
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "Orders Retrieved Successfully");
    response.setData(fetchResponse);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @PostMapping(value = "{langCode}/orders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> updateOrders(
      HttpServletRequest httpServletRequest,
      @RequestBody OrdersUpdateRequestDTO updateRequestDTO,
      @PathVariable(name = "langCode") String langCode)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    OrdersUpdateResponseDTO updateResponseDTO =
        ordersService.updateOrders(updateRequestDTO, langCode, dealer);
    if (Constants.SUCCESS.equals(updateResponseDTO.getStatus())) {
      ResponseDTO response =
          new ResponseDTO(Constants.SUCCESS, "200", "Order updated successfully");
      response.setData(updateResponseDTO);
      return new ResponseEntity<>(response, HttpStatus.OK);
    }
    return new ResponseEntity<>(
        new ResponseDTO(Constants.FAILED, "500", "Could not update orders"),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @PutMapping(value = "{langCode}/orders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> mapOrders(
      HttpServletRequest httpServletRequest,
      @Valid @RequestBody MappingDTO mappingDTO,
      @PathVariable(name = "langCode") String langCode) {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    String status = ordersService.mapOrders(mappingDTO, dealer, langCode);
    if (Constants.SUCCESS.equals(status)) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "Order mapped successfully"), HttpStatus.OK);
    }
    return new ResponseEntity<>(
        new ResponseDTO(Constants.FAILED, "500", "Could not map orders"),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @GetMapping(
      value = "{langCode}/orders-download",
      produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public ResponseEntity<ResponseDTO> downloadOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      @PathVariable(name = "langCode") String langCode,
      @RequestParam(required = false, name = "startDate") String startDate,
      @RequestParam(required = false, name = "endDate") String endDate)
      throws IOException {
    logger.info("Inside download api");
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.NOT_FOUND);
    }
    String status =
        ordersService.downloadOrders(
            httpServletRequest, httpServletResponse, dealer, langCode, startDate, endDate, true);
    if (Constants.SUCCESS.equals(status)) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "CSV fetched successfully"), HttpStatus.OK);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Csv not fetched"), HttpStatus.NOT_FOUND);
    }
  }

  @DeleteMapping(
      value = "{langCode}/orders/{orderNumber}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> deleteOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      @PathVariable(name = "langCode") String langCode,
      @PathVariable(name = "orderNumber") String orderNumber) {
    logger.info("Inside delete order API");
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"delete order principalId :"+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"delete order number : "+orderNumber + "dealer : "+dealer.getDealerId());
    String status = ordersService.deleteOrders(orderNumber, dealer);
    if (Constants.SUCCESS.equals(status)) {
      logger.info("delete order success");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "Order Deleted Successfully"), HttpStatus.OK);
    }
    return new ResponseEntity<>(
        new ResponseDTO(Constants.FAILED, "500", "Could not delete orders"),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @GetMapping(
      value = "{langCode}/orders/activity-log/{orderNumber}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchOrdersActivityLog(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "orderNumber") String orderNumber,
      @PathVariable(name = "langCode") String lang) {
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"****principalId in fetchOrderDetails : "+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    logger.info("dealer id : " + dealer.getDealerId());
    logger.info("dealer user id : " + dealer.getUserId());
    if (dealer == null) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    List<ActivityLogResponseDTO> activityLogResponseDTOS =
        ordersService.fetchOrderActivityLog(orderNumber, dealer, lang);
    if (activityLogResponseDTOS == null) {
      ResponseDTO response =
          new ResponseDTO(Constants.SUCCESS, "200", "Activity Log details not found");
      response.setData(new ArrayList<>());
      return new ResponseEntity<>(response, HttpStatus.OK);
    } else {
      ResponseDTO response =
          new ResponseDTO(Constants.SUCCESS, "200", "Activity Log details Retrieved Successfully");
      response.setData(activityLogResponseDTOS);
      return new ResponseEntity<>(response, HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/deletedOrders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO>  fetchDeletedOrderDetails(
          HttpServletRequest httpServletRequest,
          @PathVariable(name = "langCode") String lang,
          @RequestParam(required = false, name = "offset", defaultValue = "0") Integer offset,
          @RequestParam(required = false, name = "limit", defaultValue = "10") Integer limit,
          @RequestParam(name = "filterType") String filterType,
          @RequestParam(required = false, name = "sortBy", defaultValue = "") String sortBy,
          @RequestParam(required = false, name = "sortOrder", defaultValue = "desc") String sortOrder) {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    FetchOrdersDTO orders =
            ordersService.fetchDeletedOrdersByDealerId(dealer, lang, offset, limit, filterType, sortBy, sortOrder);
    if (orders == null) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Could not fetch Deleted Orders details"),
              HttpStatus.NOT_FOUND);
    }
    ResponseDTO response =
            new ResponseDTO(Constants.SUCCESS, "200", "Deleted Orders Retrieved Successfully");
    response.setData(orders);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @PutMapping(
          value = "{langCode}/restore/{orderNumber}",
          produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> restoreOrders(
          HttpServletRequest httpServletRequest,
          HttpServletResponse httpServletResponse,
          @PathVariable(name = "langCode") String langCode,
          @PathVariable(name = "orderNumber") String orderNumber) {
    logger.info("Inside restore order API");
    String principalId = httpServletRequest.getHeader("principalId");
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"restore order principalId :  : "+principalId );
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"restore order number : "+orderNumber + "dealer : "+dealer.getDealerId());
    String status = ordersService.restoreOrders(orderNumber, dealer);
    if (Constants.SUCCESS.equals(status)) {
      logger.info("restore order success");
      return new ResponseEntity<>(
              new ResponseDTO(Constants.SUCCESS, "200", "Order Restored Successfully"),
              HttpStatus.OK);
    }
    return new ResponseEntity<>(
            new ResponseDTO(Constants.FAILED, "500", "Could not Restore orders"),
            HttpStatus.INTERNAL_SERVER_ERROR);
  }
  @GetMapping(value = "{langCode}/deletedOrders-download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public ResponseEntity<ResponseDTO> downloadDeletedOrders(
          HttpServletRequest httpServletRequest,
          HttpServletResponse httpServletResponse,
          @PathVariable(name = "langCode") String langCode,
          @RequestParam(required = false, name = "startDate") String startDate,
          @RequestParam(required = false, name = "endDate") String endDate)
          throws IOException {
    logger.info("Inside download api");
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.NOT_FOUND);
    }
    String status = ordersService.downloadOrders(httpServletRequest, httpServletResponse, dealer, langCode,startDate,endDate,false);
    if (Constants.SUCCESS.equals(status)) {
      return new ResponseEntity<>(
              new ResponseDTO(Constants.SUCCESS, "200", "CSV fetched successfully"), HttpStatus.OK);
    }else{
      return new ResponseEntity<>(
              new ResponseDTO(Constants.FAILED, "204", "Csv not fetched"), HttpStatus.NOT_FOUND);
    }
  }
}
