package com.nissan.admission.service;

import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.service.impl.AdmissionProcessorV2;

public interface AdmissionProcessorChainV2 {
    void setNextChain(AdmissionProcessorChainV2 admissionProcessorChain);

    AdmissionSaveResponseV2DTO saveAdmissionInfo(AdmissionProcessorV2 admissionProcessor, String lang);
}
