package com.nissan.admission.service.impl;

import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.service.AdmissionProcessorChainV2;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.entity.OrdersV2;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

public class DigitalAdmissionProcessorV2 implements AdmissionProcessorChainV2 {

    private static final Logger logger = LoggerFactory.getLogger(DigitalAdmissionProcessorV2.class);
    private AdmissionProcessorChainV2 nextChain;

    @Override
    public void setNextChain(AdmissionProcessorChainV2 admissionProcessorChain) {
        this.nextChain = admissionProcessorChain;
    }

    @Override
    public AdmissionSaveResponseV2DTO saveAdmissionInfo(AdmissionProcessorV2 admissionProcessor, String lang) {
        logger.info("Inside Digital admission processor v2");
        AdmissionSaveResponseV2DTO saveResponse = null;
        if (AdmissionProcessorV2.PAYMENT_METHOD_DIGITAL.equals(admissionProcessor.getPaymentMethodName())) {
            saveResponse = saveDigitalAdmissionInfo(admissionProcessor, lang);
        } else if (this.nextChain != null) {
            saveResponse = this.nextChain.saveAdmissionInfo(admissionProcessor, lang);
        }
        return saveResponse;
    }

    @Transactional
    private AdmissionSaveResponseV2DTO saveDigitalAdmissionInfo(AdmissionProcessorV2 admissionProcessor, String lang) {
        logger.info("save Digital admission info");
        AdmissionSaveResponseV2DTO saveResponse;
        AdmissionV2 admission = admissionProcessor.getAdmissionInfo(lang);
        AdmissionV2 newAdmission = admissionProcessor.getAdmissionV2Repository().save(admission);
        admissionProcessor.getActivityUtil().createActivityLogV2(newAdmission);


        OrdersV2 orders = admissionProcessor.getOrdersInfo(newAdmission, lang);
        OrdersV2 newOrder = admissionProcessor.getOrdersV2Repository().save(orders);

        saveResponse = admissionProcessor.getAdmissionResponse(newAdmission, newOrder, null);
        return saveResponse;
    }
}
