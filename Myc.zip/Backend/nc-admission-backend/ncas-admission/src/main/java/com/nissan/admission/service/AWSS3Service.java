package com.nissan.admission.service;

import com.amazonaws.services.s3.model.PutObjectResult;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface AWSS3Service {

  PutObjectResult uploadFile(MultipartFile multipartFile, String userName);

  String deleteFile(String userName);

  String downloadFile(String userName) throws IOException;

  String getInceptionDocName(String userName);
}
