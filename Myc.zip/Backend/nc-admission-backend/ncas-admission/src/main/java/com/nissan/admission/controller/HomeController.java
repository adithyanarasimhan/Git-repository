package com.nissan.admission.controller;

import com.nissan.admission.dto.ImageCarouselResponseDto;
import com.nissan.common.dto.ResponseDTO;
import org.springframework.context.annotation.Description;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Description(value = "Admission Home screen")
@RestController
@RequestMapping("api/v1")
public class HomeController {

    @GetMapping(value = "imageCarousel", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO> imageCarousel(HttpServletRequest httpServletRequest) throws Exception {
        ImageCarouselResponseDto imageCarouselResponse1 = new ImageCarouselResponseDto();
        ImageCarouselResponseDto imageCarouselResponse2 = new ImageCarouselResponseDto();
        ImageCarouselResponseDto imageCarouselResponse3 = new ImageCarouselResponseDto();
        ImageCarouselResponseDto imageCarouselResponse4 = new ImageCarouselResponseDto();

        imageCarouselResponse1.setName("PC1A");
        imageCarouselResponse1.setUrl(
                "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/PC1A.png");
        imageCarouselResponse1.setType("new");

        imageCarouselResponse2.setName("GTR");
        imageCarouselResponse2.setUrl(
                "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/GTR.png");
        imageCarouselResponse2.setType("used");

        imageCarouselResponse3.setName("Leaf");
        imageCarouselResponse3.setUrl(
                "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/leaf.png");
        imageCarouselResponse3.setType("used");

        imageCarouselResponse4.setName("GTRN");
        imageCarouselResponse4.setUrl(
                "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/GTR.png");
        imageCarouselResponse4.setType("new");

        List<ImageCarouselResponseDto> imageCarouselResponseDtos = new ArrayList<>();
        imageCarouselResponseDtos.add(imageCarouselResponse1);
        imageCarouselResponseDtos.add(imageCarouselResponse2);
        imageCarouselResponseDtos.add(imageCarouselResponse3);
        imageCarouselResponseDtos.add(imageCarouselResponse4);

        ResponseDTO response = new ResponseDTO("success", "200", "Images found");
        response.setData(imageCarouselResponseDtos);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
