package com.nissan.admission.service.impl;

import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.service.AdmissionProcessorChain;
import com.nissan.common.entity.Admission;
import com.nissan.common.entity.Comment;
import com.nissan.common.entity.Orders;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

public class PaperAdmissionProcessor implements AdmissionProcessorChain {
  private AdmissionProcessorChain nextChain;
  private static final Logger logger = LoggerFactory.getLogger(PaperAdmissionProcessor.class);

  @Override
  public void setNextChain(AdmissionProcessorChain admissionProcessorChain) {
    this.nextChain = admissionProcessorChain;
  }

  @Override
  public AdmissionSaveResponseDTO saveAdmissionInfo(
      AdmissionProcessor admissionProcessor, String lang) {
    logger.info("Inside No paper processor");
    AdmissionSaveResponseDTO saveResponse = null;
    String paymentMethod = admissionProcessor.getNotificationMethod(admissionProcessor.getSaveRequestDTO().getPaymentType());
    if (!AdmissionProcessor.PAYMENT_METHOD_DIGITAL.equals(paymentMethod)) {
      saveResponse = savePaperAdmissionInfo(admissionProcessor, lang);
    } else if (this.nextChain != null) {
      saveResponse = this.nextChain.saveAdmissionInfo(admissionProcessor, lang);
    }
    return saveResponse;
  }

  @Transactional
  private AdmissionSaveResponseDTO savePaperAdmissionInfo(
      AdmissionProcessor admissionProcessor, String lang) {
    logger.info("save paper admission info");
    AdmissionSaveResponseDTO saveResponse;
    Admission admission = admissionProcessor.getAdmissionInfo(lang);
    admission.setStatus(Constants.STATUS_DEALER_WORKING);
    admission.setStatusJp(Constants.STATUS_DEALER_WORKING_JP);
    Admission newAdmission = admissionProcessor.getAdmissionRepository().save(admission);
    admissionProcessor.getActivityUtil().createActivityLog(newAdmission);

    Orders orders = admissionProcessor.getOrdersInfo(newAdmission, lang);
    Orders newOrder = admissionProcessor.getOrdersRepository().save(orders);

    Comment comment = admissionProcessor.getCommentInfo(newOrder, lang);
    Comment newComment = admissionProcessor.getCommentRepository().save(comment);

    /*Signature signature = admissionProcessor.getSignatureInfo(newOrder);
    Signature newSignature = admissionProcessor.getSignatureRepository().save(signature);*/

    saveResponse =
        admissionProcessor.getAdmissionResponse(newAdmission, newOrder, newComment, null);
    return saveResponse;
  }
}
