package com.nissan.admission.controller;

import com.nissan.common.dto.*;
import com.nissan.common.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("secured/api/v1")
public class CustomerController {

  @Autowired CustomerService customerService;

  @GetMapping(value = "{langCode}/customers", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchCustomer(
      HttpServletRequest httpServletRequest, @PathVariable("langCode") String langCode)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");

    CustomerSummaryDto updatedCustomer =
        customerService.fetchCustomerByUserAndLangCode(principalId, langCode);

    if (updatedCustomer == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated")
              .setData(updatedCustomer),
          HttpStatus.OK);
  }

  @PostMapping(value = "{langCode}/customers", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> updateCustomer(
      @PathVariable String langCode,
      @Valid @RequestBody CustomerDTO customer,
      HttpServletRequest httpServletRequest)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");

    CustomerResponseDTO updatedCustomer =
        customerService.updateCustomerById(customer, principalId, langCode);
    if (updatedCustomer == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated")
              .setData(updatedCustomer),
          HttpStatus.OK);
  }

  @GetMapping(value = "{langCode}/customer", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchCustomerPlanDetails(
      @PathVariable String langCode, HttpServletRequest httpServletRequest) throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");
    CustomerGetResponseDTO cardBrands =
        customerService.fetchCustomerPlanDetails(principalId, langCode);
    return new ResponseEntity<>(
        new ResponseDTO("success", "200", "Customer details found").setData(cardBrands),
        HttpStatus.OK);
  }

  @GetMapping(value = "{langCode}/customers/info", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchCustomerNcNameMob(
      HttpServletRequest httpServletRequest, @PathVariable("langCode") String langCode)
      throws Exception {
    String token = httpServletRequest.getHeader("Authorization");

    CustomerInfoDTO customerInfoDTO = customerService.fetchCustomerNcNameMob(token, langCode);

    if (customerInfoDTO == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details fetched").setData(customerInfoDTO),
          HttpStatus.OK);
  }

  @GetMapping(value = "{langCode}/customers/zip-code", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> zipCode(
      @PathVariable("langCode") String langCode, @RequestParam("zipCode") String zipCode)
      throws Exception {

    ZipCodeResponseDTO zipCodeResponseDTO = customerService.fetchPrefecture(zipCode, langCode);
    if (zipCodeResponseDTO.getAddress1() == null && zipCodeResponseDTO.getAddress2() == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "zipCode details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "ZipCode details fetched").setData(zipCodeResponseDTO),
          HttpStatus.OK);
  }

  @GetMapping(value = "{langCode}/customers/temp-pwd", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchTemporaryPwd(
          HttpServletRequest httpServletRequest, @PathVariable("langCode") String langCode)
          throws Exception {
    String token = httpServletRequest.getHeader("Authorization");

    TempPwdDTO ncPwd = customerService.fetchTemporaryPwd(token, langCode);

    if (ncPwd == null) {
      return new ResponseEntity<>(
              new ResponseDTO("failed", "204", "Admission details not found"),
              HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
              new ResponseDTO("success", "200", "Customer details fetched").setData(ncPwd),
              HttpStatus.OK);
  }

}
