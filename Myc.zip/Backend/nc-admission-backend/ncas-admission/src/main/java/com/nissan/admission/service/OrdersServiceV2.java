package com.nissan.admission.service;

import com.nissan.admission.dto.ActivityLogResponseDTO;
import com.nissan.admission.dto.OrderListRequestDto;
import com.nissan.admission.dto.OrdersUpdateResponseDTO;
import com.nissan.admission.dto.VehicleNumberMappingDTO;
import com.nissan.common.dto.FetchOrderV2ResponseDTO;
import com.nissan.common.dto.FetchOrdersV2Dto;
import com.nissan.common.dto.OrdersV2UpdateRequestDTO;
import com.nissan.common.entity.DealerEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public interface OrdersServiceV2 {
  FetchOrdersV2Dto fetchOrdersV2ByDealerId(
      DealerEntity dealer, String lang, OrderListRequestDto orderListRequestDto);

  FetchOrderV2ResponseDTO fetchOrderV2ByOrderNumber(
      String orderNumber, DealerEntity dealer, String lang);

  String downloadOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      DealerEntity dealer,
      String lang,
      String startDate,
      String endDate)
      throws IOException;

  String deleteOrders(String orderNumber, DealerEntity dealer);

  List<ActivityLogResponseDTO> fetchOrderActivityLog(
      String orderNumber, DealerEntity dealerEntity, String lang);

  OrdersUpdateResponseDTO updateOrders(
      OrdersV2UpdateRequestDTO updateRequest, String lang, DealerEntity dealer) throws Exception;

  String mapVehicleNumber(VehicleNumberMappingDTO mappingDTO, DealerEntity dealer, String lang);
}
