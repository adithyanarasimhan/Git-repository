package com.nissan.admission.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class WrongProfitOrderDto {

    private Long id;
    private String dealerName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd, HH:mm a")
    private Date createdDate;
    private String replaceNullFirstParameters(String value) {
        if (value == null) {
            return "";
        } else {
            return value;
        }
    }

}
