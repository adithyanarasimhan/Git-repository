package com.nissan.admission.dto;

import com.nissan.common.dto.DealerDetailsRequestDTO;
import lombok.Data;

@Data
public class AdmissionSaveRequestDTO {
  private Integer admissionType;
  private Integer model;
  private Integer grade;
  private Integer naviType;
  private String vehicleTransfer;
  private String vinNumber;
  private Integer packagePlan;
  private Long reasonType;
  private String comments;
  private String customerName;
  private String signature;
  private Boolean termsAndConditions;
  private Long paymentType;
  private Long option;
  private DealerDetailsRequestDTO dealerDetails;
}
