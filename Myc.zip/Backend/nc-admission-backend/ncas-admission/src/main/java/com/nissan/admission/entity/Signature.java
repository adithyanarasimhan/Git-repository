package com.nissan.admission.entity;

import com.nissan.common.audit.Auditable;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Table(name = "signature")
@EntityListeners(AuditingEntityListener.class)
public class Signature extends Auditable<String> {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "orders_id")
  private Long ordersId;

  @Column(name = "signature")
  private byte[] signature;

  @Column(name = "user_name")
  private String userName;

}
