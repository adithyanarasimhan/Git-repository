package com.nissan.admission.controller;

import com.nissan.common.dto.*;
import com.nissan.common.repository.AdmissionV2Repository;
import com.nissan.common.service.CustomerServiceV2;
import com.nissan.common.service.MapionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("secured/api/v2")
public class CustomerControllerV2 {

  @Autowired CustomerServiceV2 customerService;

  @Autowired private MapionService mapionService;

  @Autowired private AdmissionV2Repository admissionRepository;

  @GetMapping(value = "{langCode}/customer", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchCustomerPlanDetails(
      HttpServletRequest httpServletRequest, @PathVariable String langCode) throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");
    CustomerGetResponseDTO cardBrands =
        customerService.fetchCustomerPlanDetailsV2(principalId, langCode);
    if (cardBrands == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated")
              .setData(cardBrands),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/customers", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchCustomer(
      HttpServletRequest httpServletRequest, @PathVariable("langCode") String langCode)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");

    CustomerSummaryDTOV2 updatedCustomer =
        customerService.fetchCustomerByUserAndLangCodeV2(principalId, langCode);

    if (updatedCustomer == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated")
              .setData(updatedCustomer),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/customer/zipCode", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchAddress(
      @RequestParam("zipCode") String zipCode, @RequestParam("radius") int radius)
      throws Exception {

    List<DealerAddressDTO> dealerAddress = mapionService.getAddressByZip(zipCode, radius);
    if (StringUtils.isEmpty(dealerAddress)) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Address details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Address list fetched").setData(dealerAddress),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/customer/address", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchAddress(
      @RequestParam("prefecture") String prefecture,
      @RequestParam("city1") String city1,
      @RequestParam("city2") String city2,
      @RequestParam("radius") int radius)
      throws Exception {

    String address = prefecture + city1 + city2;
    List<DealerAddressDTO> dealerAddress =
        mapionService.getAddressByLoc(prefecture, city1, city2, radius);
    if (StringUtils.isEmpty(dealerAddress)) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Address details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Address list fetched").setData(dealerAddress),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/customer/cityList", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchCity(
      @RequestParam("prefecture") Optional<String> prefecture,
      @RequestParam("city1") Optional<String> city1)
      throws Exception {

    List<String> cityList = mapionService.getCityDetails(prefecture, city1);
    if (cityList.isEmpty()) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "City list not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "City list fetched").setData(cityList), HttpStatus.OK);
    }
  }

  @PostMapping(
      value = "{langCode}/customer/saveAddress",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> saveAddress(
      HttpServletRequest httpServletRequest, @RequestBody DealerAddressDTO addressDTO)
      throws Exception {

    String principalId = httpServletRequest.getHeader("principalId");
    DealerAddressResponseDTO dealerAddress = mapionService.saveDealer(principalId, addressDTO);
    if (dealerAddress == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Dealer Address not saved"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Dealer Address saved").setData(addressDTO),
          HttpStatus.OK);
    }
  }

  @PostMapping(value = "{langCode}/customers", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> updateCustomer(
      @PathVariable String langCode,
      @Valid @RequestBody CustomerDTO customer,
      HttpServletRequest httpServletRequest)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");

    CustomerResponseDTO updatedCustomer =
        customerService.updateCustomerById(customer, principalId, langCode);
    if (updatedCustomer == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated")
              .setData(updatedCustomer),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/customers/stepcount", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> stepCount(
      @PathVariable("langCode") String langCode,
      @RequestParam("count") String count,
      HttpServletRequest httpServletRequest)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");
    CustomerResponseDTO customer = customerService.saveStepCount(principalId, count);
    if (customer == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated").setData(customer),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/dealerVisit", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> updateDealerVisit(
      @PathVariable String langCode, @RequestParam("key") Optional<String> key) throws Exception {
    String status = mapionService.getDealerVisitStatus(52L);
    if (status == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated").setData(status),
          HttpStatus.OK);
    }
  }

  @GetMapping(value = "{langCode}/customers/temp-pwd", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchTemporaryPwd(
          HttpServletRequest httpServletRequest, @PathVariable("langCode") String langCode)
          throws Exception {
    String token = httpServletRequest.getHeader("Authorization");

    TempPwdDTO ncPwd = customerService.fetchTemporaryPwd(token, langCode);

    if (ncPwd == null) {
      return new ResponseEntity<>(
              new ResponseDTO("failed", "204", "Admission details not found"),
              HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
              new ResponseDTO("success", "200", "Customer details fetched").setData(ncPwd),
              HttpStatus.OK);
  }
}
