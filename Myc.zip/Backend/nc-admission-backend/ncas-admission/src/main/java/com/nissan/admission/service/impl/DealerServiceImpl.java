package com.nissan.admission.service.impl;

import com.nissan.admission.service.DealerService;
import com.nissan.common.dto.DealerDTO;
import com.nissan.common.dto.UserDto;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.User;
import com.nissan.common.exception.AlreadyExistException;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

@Service
public class DealerServiceImpl implements DealerService {
  private static final String CONST_ERROR = "error";
  private static final String CONST_SUCCESS = "success";
  private static final String CONST_DEALER_NOT_FOUND = "Dealer not found for id : ";
  public static final String DEALER = "dealer";

  @Autowired UserRepository userRepository;

  @Autowired private DealerRepository dealerRepositoryRepository;

  @Autowired DealerRepository dealerRepository;

  @Override
  @Transactional
  public DealerDTO getDealerByCompanyCode(HttpServletRequest httpServletRequest, String langCode) {
    String pricipalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepositoryRepository.findByUserId(Long.valueOf(pricipalId));
    DealerDTO dealerDTO = null;
    DealerEntity dealerEntity =
        dealerRepository.findByCompanyCodeAndLangCode(dealer.getCompanyCode(), langCode);
    if (dealerEntity != null) {
      dealerDTO = convertEntityToResource(dealerEntity);
    }
    return dealerDTO;
  }

  @Override
  @Transactional
  public String saveDealerDetails(DealerDTO dealerDTO) {
    UserDto userDto = new UserDto();
    userDto.setType(DEALER);
    userDto.setUsername(dealerDTO.getPhoneNumber());
    userDto.setPassword(dealerDTO.getPhoneNumber());
    User user = null; // userService.saveUser(userDto);
    DealerEntity dealer = dealerRepository.findByCompanyCode(dealerDTO.getCompanyCode());
    if (dealer == null) {
      dealer = createDealer(dealerDTO, user);
    } else {
      throw new AlreadyExistException("dealer is already registered");
    }
    return null;
  }

  private DealerEntity createDealer(DealerDTO dealerDTO, User user) {
    DealerEntity dealerEntity = new DealerEntity();
    dealerEntity.setCompanyCode(dealerDTO.getCompanyCode());
    dealerEntity.setCompanyName(dealerDTO.getCompanyName());
    dealerEntity.setCaCode(dealerDTO.getCaCode());
    dealerEntity.setUserId(user.getId());
    dealerEntity.setCaName(dealerDTO.getCaName());
    dealerEntity.setCaNameKana(dealerDTO.getCaNameKana());
    dealerEntity.setDealershipName(dealerDTO.getDealershipName());
    dealerEntity.setPhoneNumber(dealerDTO.getPhoneNumber());
    return dealerRepository.save(dealerEntity);
  }

  private static DealerDTO convertEntityToResource(DealerEntity dealerEntity) {
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyCode(dealerEntity.getCompanyCode());
    dealerDTO.setCompanyName(dealerEntity.getCompanyName());
    dealerDTO.setDealershipName(dealerEntity.getDealershipName());
    dealerDTO.setPhoneNumber(dealerEntity.getPhoneNumber());
    dealerDTO.setCaName(dealerEntity.getCaName());
    dealerDTO.setCaNameKana(dealerEntity.getCaNameKana());
    dealerDTO.setCaCode(dealerEntity.getCaCode());
    return dealerDTO;
  }
}