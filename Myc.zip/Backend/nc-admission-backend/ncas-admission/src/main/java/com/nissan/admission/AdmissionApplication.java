package com.nissan.admission;

import com.nissan.common.audit.SpringSecurityAuditorAware;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan(basePackages = {"com.nissan.admission", "com.nissan.common"})
@EnableJpaRepositories(
    basePackages = {"com.nissan.admission.repository", "com.nissan.common.repository"})
@EntityScan(basePackages = {"com.nissan.admission.entity", "com.nissan.common.entity"})
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
public class AdmissionApplication {
  @Bean
  public AuditorAware<String> auditorAware() {
    return new SpringSecurityAuditorAware();
  }

  public static void main(String[] args) {
    SpringApplication.run(AdmissionApplication.class, args);
  }
}
