package com.nissan.admission.controller;

import com.nissan.admission.dto.*;
import com.nissan.admission.dto.AdmissionSaveRequestDTO;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.dto.ImageCarouselResponseDto;
import com.nissan.admission.service.AdmissionService;
import com.nissan.common.dto.*;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Description(value = "New Admission Process.")
@RestController
@RequestMapping("secured/api/v1")
public class AdmissionController {

  private static final Logger logger = LoggerFactory.getLogger(AdmissionController.class);

  private static final String SUCCESS = "Success";
  private static final String ERROR_FAILED = "Failed";

  @Autowired private AdmissionService admissionService;

  @Autowired private UserRepository userRepository;

  @Autowired private DealerRepository dealerRepository;

  @GetMapping(value = "{langCode}/admission", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchAdmission(
      HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang) {
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      logger.info("dealer not found");
      return new ResponseEntity<>(
          new ResponseDTO(ERROR_FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    AdmissionFetchResponseDTO admissionFetchResponseDTO =
        admissionService.fetchAdmissionInfo(dealer, lang);
    if (admissionFetchResponseDTO != null
        && admissionFetchResponseDTO.getModels() != null
        && admissionFetchResponseDTO.getReasonTypesNoThanks() != null
        && admissionFetchResponseDTO.getReasonTypesPaper() != null) {
      return new ResponseEntity<>(
          new ResponseDTO(SUCCESS, "200", "success").setData(admissionFetchResponseDTO),
          HttpStatus.OK);
    }
    logger.info("error in load admission details");
    return new ResponseEntity<>(
        new ResponseDTO(ERROR_FAILED, "204", "Could not fetch Admission details"),
        HttpStatus.NO_CONTENT);
  }

  @GetMapping(value = "{langCode}/admissions:recent", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> getRecentAdmissions(
      HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang) {
    logger.info("inside fetch recent admission api");
    String pricipalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(pricipalId));
    LocalDateTime currentDateTime = LocalDateTime.now();
    Timestamp endDate = Timestamp.valueOf(currentDateTime);
    LocalDateTime localdateTime = currentDateTime.minusDays(7);
    Timestamp startDate = Timestamp.valueOf(localdateTime);
    if (dealer == null) {
      logger.info("dealer not found");
      return new ResponseEntity<>(
          new ResponseDTO(ERROR_FAILED, "404", "Dealer not found"), HttpStatus.NOT_FOUND);
    }
    FetchRecentAdmissionDTO recentAdmissionDTO =
        admissionService.fetchRecentAdmissions(dealer, lang, startDate, endDate);
    if (recentAdmissionDTO != null) {
      logger.info("Recent Admissions fetched successfully");
      ResponseDTO response =
          new ResponseDTO(Constants.SUCCESS, "200", "Recent Admissions fetched successfully");
      response.setData(recentAdmissionDTO);
      return new ResponseEntity<>(response, HttpStatus.OK);
    }
    logger.info("No Recent Admissions Available");
    ResponseDTO response =
        new ResponseDTO(Constants.SUCCESS, "200", "No Recent Admissions Available");
    response.setData(new ArrayList<>());
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @PostMapping(value = "{langCode}/admission", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> saveAdmission(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "langCode") String lang,
      @Valid @RequestBody AdmissionSaveRequestDTO admissionSaveRequestDTO) {
    logger.info("inside save admission api");
    String principalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      logger.info("dealer not found");
      return new ResponseEntity<>(
          new ResponseDTO(ERROR_FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    AdmissionSaveResponseDTO saveResponse =
        admissionService.saveAdmissionInfo(admissionSaveRequestDTO, dealer.getDealerId(), lang);
    if (saveResponse != null) {
      logger.info("save admission success");
      if (saveResponse.isPaperAdmission()) {
        admissionService.sendRegistrationMailCA(saveResponse.getAdmissionId());
      }
      return new ResponseEntity<>(
          new ResponseDTO(SUCCESS, "200", "Admission done successfully").setData(saveResponse),
          HttpStatus.OK);
    }
    logger.info("error in save admission");
    return new ResponseEntity<>(
        new ResponseDTO(ERROR_FAILED, "500", "Could not save admission details"),
        HttpStatus.BAD_REQUEST);
  }

  /*@GetMapping(value = "{langCode}/imageCarousel", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> imageCarousel(
      @PathVariable String langCode, HttpServletRequest httpServletRequest) throws Exception {
    List<ImageCarouselResponseDto> imageCarouselResponseDtos =
        admissionService.fetchImageCarousel();
    if (imageCarouselResponseDtos.size() != 0) {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Images found").setData(imageCarouselResponseDtos),
          HttpStatus.OK);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Images not found"), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }*/

  @GetMapping(value = "{langCode}/imageCarousel", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> imageCarousel(
      @PathVariable String langCode, HttpServletRequest httpServletRequest) throws Exception {
    ImageCarouselResponseDto imageCarouselResponse1 = new ImageCarouselResponseDto();
    ImageCarouselResponseDto imageCarouselResponse2 = new ImageCarouselResponseDto();
    ImageCarouselResponseDto imageCarouselResponse3 = new ImageCarouselResponseDto();
    ImageCarouselResponseDto imageCarouselResponse4 = new ImageCarouselResponseDto();

    imageCarouselResponse1.setName("PC1A");
    imageCarouselResponse1.setUrl(
        "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/PC1A.png");
    imageCarouselResponse1.setType("new");

    imageCarouselResponse2.setName("GTR");
    imageCarouselResponse2.setUrl(
        "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/GTR.png");
    imageCarouselResponse2.setType("used");

    imageCarouselResponse3.setName("Leaf");
    imageCarouselResponse3.setUrl(
        "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/leaf.png");
    imageCarouselResponse3.setType("used");

    imageCarouselResponse4.setName("GTRN");
    imageCarouselResponse4.setUrl(
        "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/GTR.png");
    imageCarouselResponse4.setType("new");

    List<ImageCarouselResponseDto> imageCarouselResponseDtos = new ArrayList<>();
    imageCarouselResponseDtos.add(imageCarouselResponse1);
    imageCarouselResponseDtos.add(imageCarouselResponse2);
    imageCarouselResponseDtos.add(imageCarouselResponse3);
    imageCarouselResponseDtos.add(imageCarouselResponse4);

    ResponseDTO response = new ResponseDTO("success", "200", "Images found");
    response.setData(imageCarouselResponseDtos);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @GetMapping(value = "{langCode}/wrongProfitOrders", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> getWrongProfitOrders(
          HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang) {
    logger.info("inside fetch recent admission api");
    String pricipalId = httpServletRequest.getHeader("principalId");
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(pricipalId));
    if (dealer == null) {
      logger.info("dealer not found");
      return new ResponseEntity<>(
              new ResponseDTO(ERROR_FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    List<WrongProfitOrderDto> wrongProfitOrderDto =
            admissionService.fetchWrongOrderDto(dealer.getDealerId());

    if (wrongProfitOrderDto != null) {
      logger.info("Wrong profit orders fetched successfully");
      ResponseDTO response =
              new ResponseDTO(Constants.SUCCESS, "200", "Wrong profit orders fetched successfully");
      response.setData(wrongProfitOrderDto);
      return new ResponseEntity<>(response, HttpStatus.OK);
    }
    logger.info("No Wrong profit orders Available");
    ResponseDTO response =
            new ResponseDTO(Constants.SUCCESS, "200", "No Wrong profit orders available");
    response.setData(new ArrayList<>());
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
