package com.nissan.admission.service.impl;

import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import com.nissan.admission.dto.AdmissionSaveRequestDTO;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.dto.ImageCarouselResponseDto;
import com.nissan.admission.dto.*;
import com.nissan.admission.entity.ImageCarousel;
import com.nissan.admission.repository.ImageCarouselRepository;
import com.nissan.admission.service.AdmissionProcessorChain;
import com.nissan.admission.service.AdmissionService;
import com.nissan.common.config.CloudMapServiceResolver;
import com.nissan.common.dto.ModelDTO;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.service.AuthorisationService;
import com.nissan.common.service.UserService;
import com.nissan.common.util.Constants;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.nissan.common.util.Constants.HTTP;
import static com.nissan.common.util.Constants.NOTIFICATION_SERVICE;

@Service
public class AdmissionServiceImpl implements AdmissionService {

  private static final Logger LOGGER = LoggerFactory.getLogger(AdmissionServiceImpl.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(AdmissionServiceImpl.class);
  public static final String NEW_CAR_REG_CA = "/notification/secured/api/v1/en/registrationMailCA";

  @Autowired ModelRepository modelRepository;
  @Autowired GradeRepository gradeRepository;
  @Autowired NaviRepository naviRepository;
  @Autowired PackagePlanRepository packagePlanRepository;
  @Autowired ReasonRepository reasonRepository;
  @Autowired AdmissionProcessor admissionProcessor;
  @Autowired ImageCarouselRepository imageCarouselRepository;
  @Autowired PaymentMethodRepository paymentMethodRepository;
  @Autowired OptionsRepository optionsRepository;
  @Autowired AdmissionRepository admissionRepository;
  @Autowired CustomerRepository customerRepository;
  @Autowired CloudMapServiceResolver serviceResolver;
  @Autowired OrdersV2Repository ordersV2Repository;
  @Autowired UserService userService;
  @Autowired AuthorisationService authorisationService;
  @Autowired UserRepository userRepository;
  @Autowired AdmissionV2Repository admissionV2Repository;
  @Autowired ModelV2Repository modelV2Repository;
  @Autowired GradeV2Repository gradeV2Repository;
  @Autowired NaviV2Repository naviV2Repository;
  @Autowired PackagePlanV2Repository packagePlanV2Repository;

  @Autowired OptionsV2Repository optionsV2Repository;

  @Override
  @Transactional
  public AdmissionSaveResponseDTO saveAdmissionInfo(
      AdmissionSaveRequestDTO saveRequestDTO, String dealerId, String lang) {

    LOGGER.info("Inside save admission");
    AdmissionSaveResponseDTO admissionSaveResponseDTO = null;
    User user = userService.saveUser(getNewUserInfo(saveRequestDTO.getCustomerName()));
    admissionProcessor.setRequest(saveRequestDTO, dealerId, user.getId().intValue());
    AdmissionProcessorChain noAdmissionChain = new NoAdmissionProcessor();
    AdmissionProcessorChain paperAdmissionChain = new PaperAdmissionProcessor();
    AdmissionProcessorChain digitalAdmissionChain = new DigitalAdmissionProcessor();
    noAdmissionChain.setNextChain(paperAdmissionChain);
    paperAdmissionChain.setNextChain(digitalAdmissionChain);

    LOGGER.info("start admission chain");
    admissionSaveResponseDTO = noAdmissionChain.saveAdmissionInfo(admissionProcessor, lang);

    Integer admissionType = saveRequestDTO.getAdmissionType();
    String paymentMethod = admissionProcessor.getNotificationMethod(saveRequestDTO.getPaymentType());
    if (!AdmissionProcessor.ADMISSION_TYPE_NOT_INTERESTED.equals(admissionType)
        && AdmissionProcessor.PAYMENT_METHOD_PAPER.equals(paymentMethod)) {
      LOGGER.info("Admission PAYMENT METHOD {}", paymentMethod);
      admissionSaveResponseDTO.setPaperAdmission(true);
    }
    return admissionSaveResponseDTO;
  }

  public void sendRegistrationMailCA(Long admissionId) {
    LOGGER.info("Paper CA Mail {} {} {}", admissionId, NOTIFICATION_SERVICE, NEW_CAR_REG_CA);
    String serviceLocation = serviceResolver.resolve(NOTIFICATION_SERVICE);
    LOGGER.info("API service URL {}", serviceLocation);
    String url = HTTP + serviceLocation + NEW_CAR_REG_CA;

    HttpHeaders headers = new HttpHeaders();
    headers.set("admissionId", admissionId.toString());
    HttpEntity<String> request = new HttpEntity<>(headers);
    RestTemplate restTemplate = new RestTemplate();
    ResponseEntity<ResponseDTO> response =
        restTemplate.exchange(url, HttpMethod.GET, request, ResponseDTO.class);
    LOGGER.info("Paper Admission Registration mail status {}", response.getBody().getStatus());
  }

  private UserDto getNewUserInfo(String customerName) {
    UserDto userDto = new UserDto();
    if (customerName != null) {
      userDto.setFirstName(customerName);
    }
    userDto.setUsername("user" + (new SecureRandom().ints().findFirst().getAsInt()));
    userDto.setPassword("password" + (new SecureRandom().ints().findFirst().getAsInt()));
    userDto.setType(Constants.ROLE_CUSTOMER);
    userDto.setValidToken(true);
    return userDto;
  }

  @Autowired
  public AdmissionServiceImpl(final CustomerRepository customerRepositoryR) {
    this.customerRepository = customerRepositoryR;
  }

  @Override
  public AdmissionFetchResponseDTO fetchAdmissionInfo(DealerEntity dealer, String lang) {
    final AdmissionFetchResponseDTO admissionFetchResponse = new AdmissionFetchResponseDTO();
    getReasonInfo(lang, admissionFetchResponse);
    admissionFetchResponse.setPaymentTypes(getPaymentMethod(lang));
    admissionFetchResponse.setModels(getModelInfo(lang));
    admissionFetchResponse.setDealerDetails(convertDealerEntityToDTO(dealer));
    UsedCarsModelDto usedCarsModelDto = new UsedCarsModelDto();
    usedCarsModelDto.setModels(getModelV2Info(lang));
    admissionFetchResponse.setUsedCar(usedCarsModelDto);
    return admissionFetchResponse;
  }

  private static DealerDTO convertDealerEntityToDTO(DealerEntity dealerEntity) {
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"dealer ca name : "+ dealerEntity.getCaName());
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyCode(dealerEntity.getCompanyCode());
    dealerDTO.setCompanyName(dealerEntity.getCompanyName());
    dealerDTO.setDealershipName(dealerEntity.getDealershipName());
    dealerDTO.setPhoneNumber(dealerEntity.getPhoneNumber());
    dealerDTO.setCaName(dealerEntity.getCaName());
    dealerDTO.setCaNameKana(dealerEntity.getCaNameKana());
    dealerDTO.setCaCode(dealerEntity.getCaCode());
    dealerDTO.setDealerId(dealerEntity.getDealerId());
    dealerDTO.setUserId(dealerEntity.getUserId());
    dealerDTO.setDealerType(dealerEntity.getDealerType());
    dealerDTO.setEmail(dealerEntity.getEmail());
    return dealerDTO;
  }

  @Override
  public FetchRecentAdmissionDTO fetchRecentAdmissions(
      DealerEntity dealer, String lang, Timestamp startDate, Timestamp endDate) {
    LOGGER.info("Inside fetch recent admissions");
    FetchRecentAdmissionDTO response = new FetchRecentAdmissionDTO();
    LOGGER.info("fetching recent admissions between {} and {}", startDate, endDate);
    List<RecentAdmissionResponseDTO> recentAdmissions = new ArrayList<>();

    List<RecentAdmissionV1Dto> recentAdmissionV1Dtos =
        admissionRepository.fetchRecentAdmissions(dealer, startDate, endDate);
    recentAdmissionV1Dtos.forEach(
        r -> {
          RecentAdmissionResponseDTO recentAdmissionResponseDTO = new RecentAdmissionResponseDTO();
          recentAdmissionResponseDTO.setVersion(r.getVersion());
          recentAdmissionResponseDTO.setAdmissionId(r.getAdmissionId());
          recentAdmissionResponseDTO.setAdmissionDate(r.getAdmissionDate());
          recentAdmissionResponseDTO.setDealerName(r.getDealerName());
          recentAdmissionResponseDTO.setModelName(r.getModelName());
          recentAdmissionResponseDTO.setGradeName(r.getGradeName());
          recentAdmissionResponseDTO.setNaviName(r.getNaviName());
          recentAdmissionResponseDTO.setNaviDisplayName(r.getNaviDisplayName());
          recentAdmissionResponseDTO.setVehicleTransfer(r.getVehicleTransfer());
          recentAdmissionResponseDTO.setVinNumber(r.getVinNumber());
          recentAdmissionResponseDTO.setPlanName(r.getPlanName());
          recentAdmissionResponseDTO.setPlanAmount(r.getPlanAmount());
          recentAdmissionResponseDTO.setPaymentTypeName(r.getPaymentTypeName());
          recentAdmissionResponseDTO.setPaymentTypeDisplayName(r.getPaymentTypeDisplayName());
          recentAdmissionResponseDTO.setUserId(r.getUserId());
          recentAdmissionResponseDTO.setOptionName(r.getOptionName());
          recentAdmissionResponseDTO.setCustomerName(r.getCustomerName());
          recentAdmissionResponseDTO.setUserName(r.getUserName());
          recentAdmissionResponseDTO.setReasonName(r.getReasonName());
          recentAdmissionResponseDTO.setReasonType(r.getReasonType());
          recentAdmissionResponseDTO.setReasonDisplayName(r.getReasonDisplayName());
          recentAdmissionResponseDTO.setComment(r.getComment());
          recentAdmissionResponseDTO.setOrderNumber(r.getOrderNumber());
          recentAdmissionResponseDTO.setCustomerName(r.getCustomerName());
          recentAdmissionResponseDTO.setCustomerFamilyName(r.getCustomerFamilyName());
          recentAdmissionResponseDTO.setCustomerType(r.getCustomerType());
          recentAdmissionResponseDTO.setAdmissionType(r.getAdmissionType());
          recentAdmissionResponseDTO.setAddress1(r.getAddress1());
          recentAdmissionResponseDTO.setAddress2(r.getAddress2());
          recentAdmissionResponseDTO.setZipCode(r.getZipCode());
          recentAdmissionResponseDTO.setEncodedToken(r.getEncodedToken());
          recentAdmissionResponseDTO.setComment(r.getComment());
          recentAdmissionResponseDTO.setReasonId(r.getReasonId());
          recentAdmissionResponseDTO.setAdminFee(0L);
          recentAdmissions.add(recentAdmissionResponseDTO);
        });
    LOGGER.info("New car admissions fetched");
    recentAdmissions.addAll(
        admissionV2Repository.fetchRecentAdmissions(dealer, startDate, endDate));
    if (!recentAdmissions.isEmpty()) {
      recentAdmissions.forEach(
          admission -> {
            LOGGER.info("recent admission Id : " + admission.getAdmissionId());
            if (admission.getReasonId() != null) {
              Optional<Reason> optionalReason = reasonRepository.findById(admission.getReasonId());
              if (optionalReason.isPresent()) {
                Reason reason = optionalReason.get();
                admission.setReasonName(reason.getReasonName());
                admission.setReasonDisplayName(reason.getDisplayName());
                admission.setReasonType(reason.getType());
              }
            }
          });
    }
    Collections.sort(recentAdmissions,
            Comparator.comparing(RecentAdmissionResponseDTO::getAdmissionDate).reversed());
    response.setRecentAdmissions(recentAdmissions);
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    response.setDateRange(dateFormat.format(startDate) + " - " + dateFormat.format(endDate));
    response.setTotalCount(Long.valueOf(recentAdmissions.size()));
    return response;
  }

  @Transactional
  private List<PaymentMethodDto> getPaymentMethod(String lang) {
    Set<String> paymentMethodNames = new HashSet<>();
    paymentMethodNames.add("digital");
    paymentMethodNames.add("paper");
    return paymentMethodRepository.findByLangCodeAndNameIn(lang, paymentMethodNames).stream()
        .map(this::convertpaymentMethodEntityToDTO)
        .collect(Collectors.toList());
  }

  private PaymentMethodDto convertpaymentMethodEntityToDTO(final PaymentMethod paymentMethod) {
    final PaymentMethodDto paymentMethodDto = new PaymentMethodDto();
    paymentMethodDto.setId(paymentMethod.getId());
    paymentMethodDto.setName(paymentMethod.getName());
    paymentMethodDto.setDisplayName(paymentMethod.getDisplayName());
    paymentMethodDto.setType(paymentMethod.getType());
    return paymentMethodDto;
  }

  @Transactional
  private void getReasonInfo(String lang, AdmissionFetchResponseDTO admissionFetchResponse) {
    admissionFetchResponse.setReasonTypesNoThanks(new ArrayList<>());
    admissionFetchResponse.setReasonTypesPaper(new ArrayList<>());
    reasonRepository.findByLangCode(lang).stream()
        .map(
            reason -> {
              if ("reasonTypesPaper".equals(reason.getType())) {
                if (!(Constants.REASON_NAME_A.equals(reason.getReasonName())
                    || Constants.REASON_NAME_B.equals(reason.getReasonName())
                    || Constants.REASON_NAME_C.equals(reason.getReasonName()))) {
                  admissionFetchResponse
                          .getReasonTypesPaper()
                          .add(convertReasonEntityToDTO(reason));
                }
              } else if ("reasonsTypesNoThanks".equals(reason.getType())) {
                admissionFetchResponse
                    .getReasonTypesNoThanks()
                    .add(convertReasonEntityToDTO(reason));
              }
              return reason;
            })
        .collect(Collectors.toList());
  }

  private ReasonDTO convertReasonEntityToDTO(final Reason reason) {
    final ReasonDTO reasonDTO = new ReasonDTO();
    reasonDTO.setId(reason.getId());
    reasonDTO.setName(reason.getReasonName());
    reasonDTO.setDisplayName(reason.getDisplayName());
    reasonDTO.setShowInDirectDebitPaper(reason.getDirectDebit());
    return reasonDTO;
  }

  @Transactional
  private List<ModelDTO> getModelInfo(String lang) {
    return modelRepository.findByLangCodeActiveTrueOrderByModelDisplayOrderAsc(lang).stream()
        .map(this::convertModelEntityToDTO)
        .collect(Collectors.toList());
  }

  private ModelDTO convertModelEntityToDTO(final Model model) {
    final ModelDTO modelDTO = new ModelDTO();
    modelDTO.setId(model.getId());
    modelDTO.setName(model.getModelName());
    modelDTO.setDisplayName(model.getDisplayName());
    modelDTO.setImgUrl(model.getUrl());
    modelDTO.setGrades(getGradeListByModelId(model.getModelName()));
    return modelDTO;
  }

  @Transactional
  private List<GradeDTO> getGradeListByModelId(final String modelName) {
    return gradeRepository.getGradesByModelName(modelName).stream()
        .map(this::convertGradeEntityToGradeDTO)
        .collect(Collectors.toList());
  }

  private GradeDTO convertGradeEntityToGradeDTO(final Grade grade) {
    final GradeDTO gradeDTO = new GradeDTO();
    gradeDTO.setId(grade.getId());
    gradeDTO.setModelName(grade.getModel().getModelName());
    gradeDTO.setName(grade.getGradeName());
    gradeDTO.setDisplayName(grade.getDisplayName());
    gradeDTO.setNaviTypes(getNaviListByGradeName(grade.getId()));
    return gradeDTO;
  }

  @Transactional
  private List<NaviDTO> getNaviListByGradeName(final long gradeId) {
    return naviRepository.getNaviListByGradeName(gradeId).stream()
        .map(this::convertNaviEntityToDTO)
        .collect(Collectors.toList());
  }

  private NaviDTO convertNaviEntityToDTO(final Navi navi) {
    final NaviDTO naviDTO = new NaviDTO();
    naviDTO.setId(navi.getId());
    naviDTO.setGradeId(navi.getGrade().getId());
    naviDTO.setName(navi.getNaviName());
    naviDTO.setDisplayName(navi.getDisplayName());
    naviDTO.setPackagePlans(getPlan2ListByNaviName(navi.getId()));
    naviDTO.setOptions(getOptionsByNavi(navi.getId()));
    return naviDTO;
  }

  @Transactional
  private List<OptionDTO> getOptionsByNavi(final long naviId) {
    return optionsRepository.getOptionsListByNaviId(naviId).stream()
        .map(this::convertOptionEntityToDTO)
        .collect(Collectors.toList());
  }

  private OptionDTO convertOptionEntityToDTO(final Options option) {
    final OptionDTO optionDTO = new OptionDTO();
    optionDTO.setId(option.getId());
    optionDTO.setName(option.getOptionsName());
    optionDTO.setDisplayName(option.getDisplayName());
    optionDTO.setNaviId(option.getNavi().getId());
    return optionDTO;
  }

  @Transactional
  private List<PackagePlanDTO> getPlan2ListByNaviName(final long naviId) {
    return packagePlanRepository
        .getPackageListByNaviId(naviId).stream()
        .map(this::convertPackagePlanEntityToDTO)
        .collect(Collectors.toList());
  }

  private PackagePlanDTO convertPackagePlanEntityToDTO(final PackagePlan packagePlan) {
    final PackagePlanDTO packagePlanDTO = new PackagePlanDTO();
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    packagePlanDTO.setCheckSheetPattern(packagePlan.getPatternName());
    packagePlanDTO.setTcPattern(packagePlan.getTermsName());
    packagePlanDTO.setCategory(packagePlan.getCategory());
    return packagePlanDTO;
  }

  @Override
  public List<ImageCarouselResponseDto> fetchImageCarousel() {
    LOGGER.info("Fetching list of images");
    List<ImageCarousel> imageCarousels = imageCarouselRepository.findAll();
    if (imageCarousels == null) {
      throw new ResourceNotFoundException("Images not found");
    } else {
      List<ImageCarouselResponseDto> imageCarouselResponseDtos = new ArrayList<>();
      for (ImageCarousel imageCarousel : imageCarousels) {
        ImageCarouselResponseDto imageCarouselResponseDto = new ImageCarouselResponseDto();
        imageCarouselResponseDto.setName(imageCarousel.getName());
        imageCarouselResponseDto.setUrl(imageCarousel.getUrl());
        imageCarouselResponseDtos.add(imageCarouselResponseDto);
      }
      return imageCarouselResponseDtos;
    }
  }

  @Transactional
  public List<ModelV2DTO> getModelV2Info(String lang) {
    return modelV2Repository.findByLangCodeOrderByModelDisplayOrderAsc(lang).stream()
        .map(this::convertModelV2EntityToDTO)
        .collect(Collectors.toList());
  }

  private ModelV2DTO convertModelV2EntityToDTO(final ModelV2 model) {
    final ModelV2DTO modelDTO = new ModelV2DTO();
    modelDTO.setId(model.getId());
    modelDTO.setName(model.getModelName());
    modelDTO.setDisplayName(model.getDisplayName());
    modelDTO.setImgUrl(model.getUrl());
    modelDTO.setGrades(getGradeListByModelId(model.getId()));
    return modelDTO;
  }

  @Transactional
  private List<GradeV2DTO> getGradeListByModelId(final Long modelId) {
    return gradeV2Repository.getGradesByModelId(modelId).stream()
        .map(this::convertGradeEntityToGradeDTO)
        .collect(Collectors.toList());
  }

  private GradeV2DTO convertGradeEntityToGradeDTO(final GradeV2 grade) {
    final GradeV2DTO gradeDTO = new GradeV2DTO();
    gradeDTO.setId(grade.getId());
    gradeDTO.setModelName(grade.getModel().getModelName());
    gradeDTO.setName(grade.getGradeName());
    gradeDTO.setDisplayName(grade.getDisplayName());
    gradeDTO.setNaviTypes(getNavi2ListByGradeName(grade.getId()));
    return gradeDTO;
  }

  @Transactional
  private List<NaviV2DTO> getNavi2ListByGradeName(final long gradeId) {
    return naviV2Repository.getNaviListByGradeId(gradeId).stream()
        .map(this::convertNaviEntityToDTO)
        .collect(Collectors.toList());
  }

  private NaviV2DTO convertNaviEntityToDTO(final NaviV2 navi) {
    final NaviV2DTO naviDTO = new NaviV2DTO();
    naviDTO.setId(navi.getId());
    naviDTO.setGradeId(navi.getGrade().getId());
    naviDTO.setName(navi.getNaviName());
    naviDTO.setDisplayName(navi.getDisplayName());
    naviDTO.setPackagePlans(getPlanListByNaviName(navi.getId()));
    naviDTO.setOptions(getOptions2ByNavi(navi.getId()));
    return naviDTO;
  }

  @Transactional
  private List<PackagePlanV2DTO> getPlanListByNaviName(final long naviId) {
    return packagePlanV2Repository.getPackageListByNaviId(naviId).stream()
        .map(this::convertPackagePlanEntityToDTO)
        .collect(Collectors.toList());
  }

  @Transactional
  private List<OptionsV2DTO> getOptions2ByNavi(final long naviId) {
    return optionsV2Repository.getOptionsListByNaviId(naviId).stream()
        .map(this::convertOptionEntityToDTO)
        .collect(Collectors.toList());
  }

  private PackagePlanV2DTO convertPackagePlanEntityToDTO(final PackagePlanV2 packagePlan) {
    final PackagePlanV2DTO packagePlanDTO = new PackagePlanV2DTO();
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    packagePlanDTO.setAdminFee(packagePlan.getAdminFee());
    packagePlanDTO.setCheckSheetPattern(packagePlan.getPatternName());
    packagePlanDTO.setTcPattern(packagePlan.getTermsName());
    packagePlanDTO.setDescription(packagePlan.getDescription());
    return packagePlanDTO;
  }

  private OptionsV2DTO convertOptionEntityToDTO(final OptionsV2 option) {
    final OptionsV2DTO optionDTO = new OptionsV2DTO();
    optionDTO.setId(option.getId());
    optionDTO.setName(option.getOptionsName());
    optionDTO.setDisplayName(option.getDisplayName());
    optionDTO.setNaviId(option.getNavi().getId());
    return optionDTO;
  }

  @Override
  public List<WrongProfitOrderDto> fetchWrongOrderDto(String dealerId) {
    LOGGER.info("Ready to fetch wrong orders");

    List<Admission> admissions=admissionRepository.fetchByOrderIdAndPoStatus(dealerId);
    List<WrongProfitOrderDto> wrongProfitOrderDto=wrongProfitOrderMapper(admissions);
    LOGGER.info("Successfully fetched wrong orders={}",wrongProfitOrderDto);
    return wrongProfitOrderDto;
  }

  private  List<WrongProfitOrderDto> wrongProfitOrderMapper( List<Admission> admissions)
  {
    List<WrongProfitOrderDto> wrongProfitOrderList = new ArrayList<>();

    for(Admission admission:admissions) {
      WrongProfitOrderDto wrongProfitOrderDto = new WrongProfitOrderDto();
      wrongProfitOrderDto.setId(admission.getId());
      wrongProfitOrderDto.setDealerName(admission.getDealer().getCaName());
      wrongProfitOrderDto.setCreatedDate(admission.getCreatedDate());
      wrongProfitOrderList.add(wrongProfitOrderDto);
    }
    return wrongProfitOrderList;
  }
}
