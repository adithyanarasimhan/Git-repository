package com.nissan.admission.util;

import com.google.common.collect.ImmutableMap;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Operator;
import com.querydsl.core.types.Ops;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.Expressions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

public class GenericPredicate {

  private List<FieldQueryParameter> parameters;
  private Class model;

  private static final Logger logger = LoggerFactory.getLogger(GenericPredicate.class);

  public GenericPredicate(List<FieldQueryParameter> parameters, Class model) {
    this.parameters = parameters;
    this.model = model;
  }

  static Map<String, Operator> operators =
      ImmutableMap.<String, Operator>builder()
          .put("::", Ops.STRING_CONTAINS)
          .put("==", Ops.EQ)
          .put("!=", Ops.NE)
          .put(">", Ops.GT)
          .put("<", Ops.LT)
          .put(">=", Ops.GOE)
          .put("<=", Ops.LOE)
          .put("NOT_NULL", Ops.IS_NOT_NULL)
          .put("&&", Ops.AND)
          .put("||", Ops.OR)
          .build();

  public Predicate getPredicate() {

    BooleanBuilder booleanBuilder = new BooleanBuilder();
    parameters.stream()
        .forEach(
            param -> {
              if (ReflectionUtils.findField(model, param.getFieldKey()) == null) {
                logger.warn(
                    "Skipping predicate matching on [%s]. It is not a known field on domainType %s",
                    param, model.getName());
                return;
              }
              if (StringUtils.hasLength(String.valueOf(param.getFieldValue()))) {
                if (StringUtils.hasLength(String.valueOf(param.getFieldCondition()))) {
                  if (String.valueOf(param.getFieldCondition()).equalsIgnoreCase("||")) {
                    booleanBuilder.or(matchesProperty(param, model));
                  } else {
                    booleanBuilder.and(matchesProperty(param, model));
                  }
                } else {
                  booleanBuilder.and(matchesProperty(param, model));
                }
              }
            });

    logger.debug("Boolean builder value : {}", booleanBuilder.getValue());
    return booleanBuilder;
  }

  private Predicate matchesProperty(FieldQueryParameter param, Class<?> model) {
    return Expressions.predicate(
        operators.get(param.getFieldOperator()),
        Expressions.path(model, param.getFieldKey()),
        Expressions.constant(param.getFieldValue()));
  }
}
