package com.nissan.admission.service;

import com.nissan.admission.dto.*;
import com.nissan.common.dto.FetchRecentAdmissionDTO;
import com.nissan.common.entity.DealerEntity;

import java.sql.Timestamp;
import java.util.List;

public interface AdmissionService {

  AdmissionFetchResponseDTO fetchAdmissionInfo(DealerEntity dealer, String lang);

  FetchRecentAdmissionDTO fetchRecentAdmissions(
      DealerEntity dealer, String lang, Timestamp startDate, Timestamp endDate);

  AdmissionSaveResponseDTO saveAdmissionInfo(
      AdmissionSaveRequestDTO admissionSaveRequestDTO, String dealerId, String lang);

  List<ImageCarouselResponseDto> fetchImageCarousel();

  void sendRegistrationMailCA(Long admissionId);

  List<WrongProfitOrderDto> fetchWrongOrderDto(String dealerId);
}
