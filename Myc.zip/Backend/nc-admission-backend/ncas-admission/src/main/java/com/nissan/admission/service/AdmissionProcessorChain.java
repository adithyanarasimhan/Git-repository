package com.nissan.admission.service;

import com.nissan.admission.service.impl.AdmissionProcessor;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;

public interface AdmissionProcessorChain {
  void setNextChain(AdmissionProcessorChain admissionProcessorChain);

  AdmissionSaveResponseDTO saveAdmissionInfo(AdmissionProcessor admissionProcessor, String lang);
}
