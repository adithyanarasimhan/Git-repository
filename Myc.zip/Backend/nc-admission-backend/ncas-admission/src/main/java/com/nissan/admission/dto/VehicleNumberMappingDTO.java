package com.nissan.admission.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class VehicleNumberMappingDTO {

  @NotNull(message = "Please enter a valid orderNumber")
  private Long orderNumber;

  @NotBlank(message = "Vehicle Number plate information cannot be empty")
  private String vehicleNumber;

  private String registrationDate;
  private String firstRegistrationDate;
  private String expiryDate;
}
