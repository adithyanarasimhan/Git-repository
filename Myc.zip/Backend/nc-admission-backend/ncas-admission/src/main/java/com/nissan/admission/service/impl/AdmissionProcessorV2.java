package com.nissan.admission.service.impl;

import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseDTO;
import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.entity.Signature;
import com.nissan.common.entity.*;
import com.nissan.common.repository.*;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import lombok.Getter;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.Random;

@Service
public class AdmissionProcessorV2 {

  private static final Logger logger = LoggerFactory.getLogger(AdmissionProcessorV2.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(AdmissionProcessorV2.class);
  @Getter private AdmissionSaveRequestV2DTO saveRequestDTO;
  @Getter private String dealerId;
  @Getter private Long userId;
  @Getter private String source;
  @Getter private String vehicleType;

  public static final String PAYMENT_METHOD_PAPER = "paper";
  public static final String PAYMENT_METHOD_DIGITAL = "digital";

  @Getter @Autowired AdmissionV2Repository admissionV2Repository;
  @Getter @Autowired OrdersV2Repository ordersV2Repository;
  @Getter @Autowired CommentV2Repository commentV2Repository;
  @Getter @Autowired ModelV2Repository modelV2Repository;
  @Getter @Autowired GradeV2Repository gradeV2Repository;
  @Getter @Autowired NaviV2Repository naviV2Repository;
  @Getter @Autowired PackagePlanV2Repository packagePlanV2Repository;
  @Getter @Autowired OptionsV2Repository optionsV2Repository;
  @Getter @Autowired ReasonRepository reasonRepository;
  @Getter @Autowired PaymentMethodRepository paymentMethodRepository;
  @Getter @Autowired ColorRepository colorRepository;
  @Getter @Autowired UserRepository userRepository;
  @Getter @Autowired DealerRepository dealerRepository;
  @Getter @Autowired ActivityUtil activityUtil;

  public void setRequest(AdmissionSaveRequestV2DTO requestDTO, String dealerId, Long userId, String source, String vehicleType) {
    this.saveRequestDTO = requestDTO;
    this.dealerId = dealerId;
    this.userId = userId;
    this.source = source;
    this.vehicleType = vehicleType;
  }

  public CommentV2 getCommentInfo(OrdersV2 orderInfo, String lang) {
    logger.info("inside comment info");
    CommentV2 comment = new CommentV2();
    comment.setOrders(orderInfo);
    comment.setReasonId(saveRequestDTO.getReasonType());
    comment.setComment(saveRequestDTO.getComments());
    comment.setLangCode(lang);
    comment.setCreatedBy(String.valueOf(userId));
    comment.setActive(true);
    return comment;
  }

  public OrdersV2 getOrdersInfo(AdmissionV2 admissionInfo, String lang) {
    logger.info("inside orders info");
    OrdersV2 orders = ordersV2Repository.findByAdmissionId(admissionInfo.getId());
    if(orders == null) {
      logger.info("create new order for admission id : {}", admissionInfo.getId());
      orders = new OrdersV2();
      orders.setAdmission(admissionV2Repository.getOne(admissionInfo.getId()));
      orders.setOrdersNumber(generateOrderNumber(admissionInfo.getId()));
    }
    try {
      if(saveRequestDTO.getWithdrawOrder() != null && saveRequestDTO.getWithdrawOrder().length() > 0) {
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"withdraw order available :"+ saveRequestDTO.getWithdrawOrder());
        User user = userRepository.findByEncodedToken(saveRequestDTO.getWithdrawOrder());
        if(user != null) {
          logger.info("user found : {}", user.getId());
          AdmissionV2 admissionV2 = admissionV2Repository.fetchByUserId(user.getId());
          if(admissionV2 != null) {
            logger.info("admission found : {}", admissionV2.getId());
            OrdersV2 ordersV2 = ordersV2Repository.findByAdmissionId(admissionV2.getId());
            ordersV2.setWithdrawCorrectVin(saveRequestDTO.getVinNumber());
            ordersV2Repository.save(ordersV2);
          }
        }
      }
    } catch (Exception e) {
      logger.info("Error in saving correct vin number for vin reset");
      e.printStackTrace();
    }
    orders.setModel(modelV2Repository.findById(saveRequestDTO.getModelId()).get());
    orders.setGrade(gradeV2Repository.getOne(saveRequestDTO.getGradeId()));
    if(saveRequestDTO.getCwNaviId() != null) {
      orders.setCwNaviId(saveRequestDTO.getCwNaviId());
    }
    if (saveRequestDTO.getNaviId() != null) {
      orders.setNavi(naviV2Repository.getOne(saveRequestDTO.getNaviId()));
      if ((Constants.CW_ROOX.equals(orders.getModel().getCwModelName())
              || Constants.CW_KICKS.equals(orders.getModel().getCwModelName()))
          && Constants.NAVI_TYPE_SOS.equals(orders.getNavi().getNaviName())) {
        Long min = Long.valueOf("9198000001");
        Long max = Long.valueOf("9198099999");
        SecureRandom random = new SecureRandom();
        Long randomNaviId = random.longs(min, max).findAny().getAsLong();
        orders.setCwNaviId(randomNaviId.toString());
      }
    }
    if (saveRequestDTO.getOptionId() != null && saveRequestDTO.getOptionId() > 0L) {
      orders.setOptions(optionsV2Repository.getOne(saveRequestDTO.getOptionId()));
    }
    if (saveRequestDTO.getPlanId() != null && saveRequestDTO.getPlanId() > 0L) {
      orders.setPackagePlan(packagePlanV2Repository.getOne(saveRequestDTO.getPlanId()));
    }
    if (saveRequestDTO.getPaymentMethodId() != null && saveRequestDTO.getPaymentMethodId() > 0L) {
      orders.setPaymentMethod(paymentMethodRepository.getOne(saveRequestDTO.getPaymentMethodId()));
    } else if(Constants.ADMISSION_SOURCE_HOME.equals(source)) {
      PaymentMethod pm = paymentMethodRepository.findByNameAndLangCode(PAYMENT_METHOD_DIGITAL, lang);
      orders.setPaymentMethod(pm);
    }
    orders.setColorCode(saveRequestDTO.getColorCode());
    orders.setColorName(saveRequestDTO.getColor());
    orders.setRegistrationDate(saveRequestDTO.getRegistrationDate());
    orders.setFirstRegistrationDate(saveRequestDTO.getFirstRegistrationDate());
    if(saveRequestDTO.getColorId() != null) {
      orders.setColor(colorRepository.getOne(saveRequestDTO.getColorId()));
    }
    orders.setVinNumber(saveRequestDTO.getVinNumber());
    orders.setVehicleTransfer(saveRequestDTO.getVehicleTransfer());
    orders.setOldVinNumber(saveRequestDTO.getOldVinNumber());
    orders.setLangCode(lang);
    orders.setSource(source);
    orders.setVehicleType(vehicleType);
    orders.setVinSearchStatus(saveRequestDTO.getCwVehicleStatus());
    orders.setVinSearchColorCode(saveRequestDTO.getCwColorCd());
    orders.setOldCarwingsId(saveRequestDTO.getOldCwId());
    orders.setVehicleNumber(saveRequestDTO.getVehicleNumber());
    if(dealerId != null) {
      orders.setCreatedBy(dealerId);
    }
    orders.setActive(true);
    orders.setUploadKameri(false);
    if (saveRequestDTO.getDealerDetails() != null) {
      orders.setCompanyName(saveRequestDTO.getDealerDetails().getCompanyName());
      orders.setDealershipName(saveRequestDTO.getDealerDetails().getDealershipName());
      orders.setPhoneNumber(saveRequestDTO.getDealerDetails().getPhoneNumber());
      orders.setCaName(saveRequestDTO.getDealerDetails().getCaName());
      orders.setCaNameKana(saveRequestDTO.getDealerDetails().getCaNameKana());
      orders.setCaCode(saveRequestDTO.getDealerDetails().getCaCode());
    }
    return orders;
  }

  private String generateOrderNumber(Long admissionId) {
    // TODO : generate order number
    return "orders" + admissionId;
  }

  public AdmissionV2 getAdmissionInfo(String lang) {
    logger.info("inside admission info");
    AdmissionV2 admission = admissionV2Repository.fetchByUserId(userId);
    if(admission == null) {
      logger.info("create new admission for user id : {}", userId);
      admission = new AdmissionV2();
    }
    if (dealerId != null) {
      admission.setDealer(dealerRepository.findByDealerId(dealerId));
      admission.setCreatedBy(String.valueOf(dealerId));
    } else if(Constants.ADMISSION_SOURCE_HOME.equals(source)) {
      admission.setCreatedBy(String.valueOf(userId));
    }
    admission.setStatus(Constants.STATUS_CUSTOMER_FILLING);
    admission.setStatusJp(Constants.STATUS_CUSTOMER_FILLING_JP);
    admission.setUser(userRepository.getOne(userId.longValue()));
    admission.setLangCode(lang);
    admission.setActive(true);
    return admission;
  }

  public AdmissionSaveResponseV2DTO getAdmissionResponse(
      AdmissionV2 admission, OrdersV2 orders, CommentV2 comment) {
    logger.info("inside get admission response");
    AdmissionSaveResponseV2DTO admissionSaveResponse = new AdmissionSaveResponseV2DTO();

    if (userId != null && !Constants.ADMISSION_SOURCE_HOME.equals(source)) {
      String encodedTokenToken = admission.getUser().getEncodedToken();
      if (encodedTokenToken != null) admissionSaveResponse.setToken(encodedTokenToken);
    }

    if (admission != null) {
      admissionSaveResponse.setAdmissionId(admission.getId());
      admissionSaveResponse.setUserId(admission.getUser().getId());
    }

    if (orders != null) {
      admissionSaveResponse.setOrderNumber(orders.getOrdersNumber());
      admissionSaveResponse.setModelId(orders.getModel().getId());
      admissionSaveResponse.setGradeId(orders.getGrade().getId());
      if (orders.getNavi() != null) admissionSaveResponse.setNaviId(orders.getNavi().getId());
      if (orders.getPaymentMethod() != null)
        admissionSaveResponse.setPaymentMethodId(orders.getPaymentMethod().getId());
      if (orders.getPackagePlan() != null)
        admissionSaveResponse.setPackagePlanId(orders.getPackagePlan().getId());
      admissionSaveResponse.setVinNumber(orders.getVinNumber());
      admissionSaveResponse.setRegistrationDate(orders.getRegistrationDate());
      admissionSaveResponse.setColor(orders.getColorName());
      admissionSaveResponse.setColorCode(orders.getColorCode());
    }

    if (comment != null) {
      admissionSaveResponse.setReasonId(comment.getReasonId());
      admissionSaveResponse.setComments(comment.getComment());
    }

    return admissionSaveResponse;
  }

  public String getPaymentMethodName() {
      if(saveRequestDTO.getPaymentMethodId() != null) {
          PaymentMethod pm = paymentMethodRepository.getOne(saveRequestDTO.getPaymentMethodId());
          if(pm != null && pm.getName() != null) {
              return pm.getName();
          }
      }
      return (Constants.ADMISSION_SOURCE_HOME.equals(source)) ? PAYMENT_METHOD_DIGITAL : PAYMENT_METHOD_PAPER;
  }
}
