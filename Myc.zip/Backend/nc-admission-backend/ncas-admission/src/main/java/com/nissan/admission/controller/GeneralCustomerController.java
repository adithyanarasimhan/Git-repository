package com.nissan.admission.controller;

import com.nissan.common.service.CustomerService;
import com.nissan.common.dto.OtpDto;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("general/api/v1")
public class GeneralCustomerController {

  @Autowired CustomerService customerService;

  @PostMapping(value = "{langCode}/customers", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> saveCustomer(
      @PathVariable String langCode,
      @Valid @RequestBody OtpDto otpDto,
      HttpServletRequest httpServletRequest)
      throws Exception {
    String principalId = httpServletRequest.getHeader("principalId");

    Customer customer = customerService.saveCustomer(otpDto, principalId, langCode);
    if (customer == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "500", "Customer details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Customer details has been updated").setData(customer),
          HttpStatus.OK);
  }
}
