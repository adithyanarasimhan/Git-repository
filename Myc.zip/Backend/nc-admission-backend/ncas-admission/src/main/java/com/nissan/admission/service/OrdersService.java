package com.nissan.admission.service;

import com.nissan.admission.dto.*;
import com.nissan.common.dto.FetchOrderResponseDTO;
import com.nissan.common.dto.FetchOrdersDTO;
import com.nissan.common.dto.FetchOrdersV2Dto;
import com.nissan.common.dto.OrdersUpdateRequestDTO;
import com.nissan.common.entity.DealerEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public interface OrdersService {

  FetchOrdersDTO fetchOrdersByDealerId(
      DealerEntity dealer,
      String lang,
      Integer offset,
      Integer limit,
      String filterType,
      String sortBy,
      String sortOrder);

  FetchOrderResponseDTO fetchOrderByOrderNumber(
      String orderNumber, DealerEntity dealerEntity, String lang);

  OrdersUpdateResponseDTO updateOrders(
      OrdersUpdateRequestDTO updateRequest, String lang, DealerEntity dealer) throws Exception;

  String mapOrders(MappingDTO mappingDTO, DealerEntity dealer, String lang);

  String unMapOrders(OrdersUnMapDTO unMapDTO, DealerEntity dealer);

  String downloadOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      DealerEntity dealer,
      String lang,
      String startDate,
      String endDate,
      Boolean active)
      throws IOException;

  String deleteOrders(String orderNumber, DealerEntity dealer);

  List<ActivityLogResponseDTO> fetchOrderActivityLog(
      String orderNumber, DealerEntity dealerEntity, String lang);

  FetchOrdersV2Dto fetchOrdersV2ByDealerId(
      DealerEntity dealer,
      String lang,
      Integer offset,
      Integer limit,
      String sortBy,
      String sortOrder);

  FetchOrdersDTO fetchDeletedOrdersByDealerId(
      DealerEntity dealer,
      String lang,
      Integer offset,
      Integer limit,
      String filterType,
      String sortBy,
      String sortOrder);

  String restoreOrders(String orderNumber, DealerEntity dealer);
}
