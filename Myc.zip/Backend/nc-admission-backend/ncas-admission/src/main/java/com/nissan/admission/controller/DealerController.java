package com.nissan.admission.controller;

import com.nissan.admission.service.DealerService;
import com.nissan.common.dto.DealerDTO;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.dto.ZipCodeResponseDTO;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("secured/api/v1")
public class DealerController {

  public static final String ROLE_CA = "ROLE_CA";
  public static final String ROLE_BUSINESS = "ROLE_BUSINESS";
  @Autowired private DealerService dealerService;

  @Autowired private UserRepository userRepository;

  @Autowired private CustomerService customerService;

  private static final String CONST_ERROR = "error";
  private static final String CONST_SUCCESS = "success";
  private static final String CONST_DEALER_NOT_FOUND = "Dealer not found for id : ";

  @Secured({ROLE_CA})
  @GetMapping(value = "/{langCode}/dealers", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> fetchDealerById(
      HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang) {

    DealerDTO dealerDto = dealerService.getDealerByCompanyCode(httpServletRequest, lang);
    if (dealerDto == null) {
      return new ResponseEntity<>(
          new ResponseDTO(CONST_ERROR, "204", CONST_DEALER_NOT_FOUND), HttpStatus.BAD_REQUEST);
    }
    ResponseDTO responseDto =
        new ResponseDTO(CONST_SUCCESS, "200", "Dealer retrieved successfully");
    responseDto.setData(dealerDto);
    return new ResponseEntity<>(responseDto, HttpStatus.OK);
  }

  /**
   * Fetch dealer Address by zip code
   *
   * @param httpServletRequest
   * @param langCode
   * @param zipCode
   * @return Address
   * @throws Exception
   */
  @GetMapping(value = "{langCode}/dealers/zip-code", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> zipCode(
      HttpServletRequest httpServletRequest,
      @PathVariable("langCode") String langCode,
      @RequestParam("zipCode") String zipCode)
      throws Exception {

    ZipCodeResponseDTO zipCodeResponseDTO = customerService.fetchPrefecture(zipCode, langCode);
    if (zipCodeResponseDTO.getAddress1() == null && zipCodeResponseDTO.getAddress2() == null) {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "204", "ZipCode details not found"),
          HttpStatus.INTERNAL_SERVER_ERROR);
    } else
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "ZipCode details fetched").setData(zipCodeResponseDTO),
          HttpStatus.OK);
  }
}
