package com.nissan.admission.dto;

import com.nissan.common.dto.DealerDetailsRequestDTO;
import lombok.Data;

@Data
public class AdmissionSaveRequestV2DTO {
    private String vinNumber;
    private String cwNaviId;
    private String registrationDate;
    private String firstRegistrationDate;
    private String colorCode;
    private String color;
    private String vehicleImage;
    private Long modelId;
    private Long gradeId;
    private Long naviId;
    private Long planId;
    private Long optionId;
    private Long paymentMethodId;
    private Long colorId;
    private Long reasonType;
    private String comments;
    private String customerName;
    private DealerDetailsRequestDTO dealerDetails;
    private Boolean vehicleTransfer;
    private String oldVinNumber;
    private String vehicleType;
    private String cwVehicleStatus;
    private String cwColorCd;
    private String oldCwId;
    private String withdrawOrder;
    private String vehicleNumber;
}
