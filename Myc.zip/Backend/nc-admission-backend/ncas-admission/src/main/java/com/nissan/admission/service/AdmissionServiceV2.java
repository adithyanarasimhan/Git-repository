package com.nissan.admission.service;

import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.common.entity.User;

public interface AdmissionServiceV2 {

    AdmissionSaveResponseV2DTO saveAdmissionInfo(
            AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, String dealerId, String lang);

    Object saveHomeAdmissionInfo(
            AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO, User user, String lang);
}
