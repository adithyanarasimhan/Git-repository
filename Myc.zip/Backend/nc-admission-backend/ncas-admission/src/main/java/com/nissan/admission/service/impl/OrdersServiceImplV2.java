package com.nissan.admission.service.impl;

import com.nissan.admission.dto.ActivityLogResponseDTO;
import com.nissan.admission.dto.OrdersUpdateResponseDTO;
import com.nissan.admission.dto.*;
import com.nissan.admission.entity.AdmissionType;
import com.nissan.admission.repository.AdmissionTypeRepository;
import com.nissan.admission.service.OrdersServiceV2;
import com.nissan.common.config.CloudMapServiceResolver;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.exception.DetailsNotFoundException;
import com.nissan.common.exception.InvalidOrderException;
import com.nissan.common.repository.*;
import com.nissan.common.service.CustomerService;
import com.nissan.common.util.ActivityUtil;
import com.nissan.common.util.Constants;
import com.querydsl.core.BooleanBuilder;
import org.apache.commons.lang.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.nissan.common.util.Constants.*;

@Service
public class OrdersServiceImplV2 implements OrdersServiceV2 {

  private static final Logger logger = LoggerFactory.getLogger(OrdersServiceImplV2.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(OrdersServiceImplV2.class);

  public static final String D_OP = "d-op";
  public static final String M_OP = "m-op";
  public static final String CA = "CA";
  public static final String USED_CAR_UPDATE = "/notification/secured/api/v2/en/updateAdmission";

  @Autowired OrdersV2Repository ordersV2Repository;
  @Autowired CustomerRepository customerRepository;
  @Autowired PackagePlanV2Repository packagePlanV2Repository;
  @Autowired UserRepository userRepository;
  @Autowired CustomerService customerService;
  @Autowired CommentV2Repository commentV2Repository;
  @Autowired ReasonRepository reasonRepository;
  @Autowired PaymentRepository paymentRepository;
  @Autowired AdmissionV2Repository admissionV2Repository;
  @Autowired DealerRepository dealerRepository;
  @Autowired ActivityUtil activityUtil;
  @Autowired AdmissionTypeRepository admissionTypeRepository;
  @Autowired ActivityLogV2Repository activityLogV2Repository;
  @Autowired CloudMapServiceResolver serviceResolver;

  public static final Map<String, String> SORTING_KEYS =
      new HashMap<String, String>() {
        {
          put("tempOrdersNumber", "ordersNumber");
          put("status", "admission_status");
          put("statusJp", "admission_statusJp");
          put("admissionDate", "createdDate");
          put("admissionTime", " createdDate");
        }
      };

  @Override
  public FetchOrdersV2Dto fetchOrdersV2ByDealerId(
      DealerEntity dealer, String lang, OrderListRequestDto orderListRequestDto) {
    logger.info("Inside fetch orders");
    if (dealer.getDealerType() == null || dealer.getDealerType().isEmpty()) {
      logger.error(
          "Dealer type is not available for dealer id : {} user id : {}",
          dealer.getDealerId(),
          dealer.getUserId());
      throw new RuntimeException("Dealer type is not available");
    }

    List<OrdersV2FetchResponseDto> orders = null;
    Pageable pageable =
        getPaginationForFetchOrders(
            orderListRequestDto.getOffset(),
            orderListRequestDto.getLimit(),
            orderListRequestDto.getSortBy(),
            orderListRequestDto.getSortOrder(),
            lang);
    if (orderListRequestDto.getVehicleType() == null
        || orderListRequestDto.getVehicleType().isEmpty()) {
      orderListRequestDto.setVehicleType(VEHICLE_TYPE_USED_CAR);
    }
    OrderListFilterDto orderListFilterDto = getOrderListFilterDto(orderListRequestDto);
    FetchOrdersV2Dto fetchOrdersDTO = new FetchOrdersV2Dto();
    orders = getOrders(dealer, orderListFilterDto, fetchOrdersDTO, pageable, lang);
    fetchOrdersDTO.setOrders(orders);
    return fetchOrdersDTO;
  }

  @Transactional
  private void setAdmissionType(OrdersV2FetchResponseDto order, String langCode) {
    try {
      AdmissionType admissionType = null;
      logger.info("getAdmissionType for order : {}", order.getTempOrdersNumber());
      if (order.getNavi() != null) {
        NaviV2DTO navi = order.getNavi();
        switch (navi.getName()) {
          case "m-op":
            if (order.getPaymentMethod() != null
                    && !PAYMENT_METHOD_PAPER.equals(order.getPaymentMethod().getName())) {
              admissionType = admissionTypeRepository.findByNameAndLangCode("m-op", langCode);
            } else {
              admissionType =
                      admissionTypeRepository.findByNameAndLangCode("m-op(paper)", langCode);
            }
            break;
          case "d-op":
          case "d-op+s-os":
          case "s-os":
          case "m-op-free-plan":
            admissionType = admissionTypeRepository.findByNameAndLangCode("d-op", langCode);
            break;
        }
        if(admissionType != null) {
          order.setAdmissionTypeName(admissionType.getDisplayName());
        } else {
          logger.info("cannot find admission type for order : {}", order.getTempOrdersNumber());
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      logger.error("Error in getAdmissionType for order : {}", order.getTempOrdersNumber());
    }
  }

  @Override
  public FetchOrderV2ResponseDTO fetchOrderV2ByOrderNumber(
      String orderNumber, DealerEntity dealerEntity, String lang) {
    logger.info("Inside fetch order by number");
    FetchOrderV2ResponseDTO fetchOrderResponse = new FetchOrderV2ResponseDTO();
    try {
      OrdersV2 orders = ordersV2Repository.findByOrdersNumber(orderNumber);
      if (DEALER_TYPE_CA.equals(dealerEntity.getDealerType())) {
        isValidOrder(orders, dealerEntity);
      }
      Customer customer =
          customerRepository.findByUserId(orders.getAdmission().getUser().getId()).orElse(null);
      fetchOrderResponse.setOrderDetails(new OrdersV2FetchResponseDto(orders, customer));
      fetchOrderResponse.getOrderDetails().setFileName(orders.getAdmission().getDocumentName());
      if (orders.getNavi() != null) {
        Set<String> vehicleCategory =
            VEHICLE_TYPE_NEW_CAR.equals(orders.getVehicleType())
                ? VEHICLE_CATEGORY_NEW_CAR
                : VEHICLE_CATEGORY_USED_CAR;
        List<PackagePlanV2> planList =
            packagePlanV2Repository.findByNaviAndVehicleTypeIn(orders.getNavi(), vehicleCategory);
        fetchOrderResponse.setPlanDetails(
            planList.stream()
                .map(this::convertPackagePlanEntityToDTO)
                .collect(Collectors.toList()));
      }
      fetchOrderResponse.setDealerDetails(convertOrderEntityToDTO(orders));
    } catch (Exception e) {
      logger.info("Exception in fetchOrderByOrderNumber : " + e.getMessage());
      throw new RuntimeException(e.getMessage());
    }
    return fetchOrderResponse;
  }

  private Boolean isValidOrder(OrdersV2 orders, DealerEntity dealer) {
    logger.info("Inside is Valid Order");
    if (orders != null
        && Constants.ADMISSION_SOURCE_DEALER.equals(orders.getSource())
        && !orders.getAdmission().getDealer().getCompanyCode().equals(dealer.getCompanyCode())) {
      DealerEntity orderDealerInfo = orders.getAdmission().getDealer();
      logger.error(
          "This order is not made through this dealer {} company : {} ",
          dealer.getDealerId(),
          dealer.getCompanyCode());
      logger.error(
          "order : {} comes under dealer id : {} of company {} user id : {}",
          orders.getOrdersNumber(),
          orderDealerInfo.getDealerId(),
          orderDealerInfo.getCompanyCode(),
          orderDealerInfo.getUserId());
      throw new InvalidOrderException("This order is not made through logged in dealer company");
    } else if (orders == null) {
      logger.error("Order details not found");
      throw new DetailsNotFoundException("Order details not found");
    }
    return true;
  }

  private PackagePlanV2DTO convertPackagePlanEntityToDTO(final PackagePlanV2 packagePlan) {
    final PackagePlanV2DTO packagePlanDTO = new PackagePlanV2DTO();
    packagePlanDTO.setId(packagePlan.getId());
    packagePlanDTO.setName(packagePlan.getPackagePlanName());
    packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
    packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
    packagePlanDTO.setPrice(packagePlan.getPrice());
    packagePlanDTO.setAdminFee(packagePlan.getAdminFee());
    packagePlanDTO.setDescription(packagePlan.getDescription());
    return packagePlanDTO;
  }

  private static DealerDTO convertOrderEntityToDTO(OrdersV2 orders) {
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"dealer ca name : " + orders.getCaName());
    DealerDTO dealerDTO = new DealerDTO();
    dealerDTO.setCompanyName(orders.getCompanyName());
    dealerDTO.setDealershipName(orders.getDealershipName());
    dealerDTO.setPhoneNumber(orders.getPhoneNumber());
    dealerDTO.setCaName(orders.getCaName());
    dealerDTO.setCaNameKana(orders.getCaNameKana());
    dealerDTO.setCaCode(orders.getCaCode());
    return dealerDTO;
  }

  private Pageable getPaginationForFetchOrders(
      Integer offset, Integer limit, String sortBy, String sortOrder, String lang) {
    Sort.Direction direction =
        (sortOrder != null && Constants.SORT_ASCENDING.equals(sortOrder))
            ? Sort.Direction.ASC
            : Sort.Direction.DESC;
    sortBy = (sortBy != null && "status".equals(sortBy) && "jp".equals(lang)) ? "statusJp" : sortBy;
    sortBy =
        (sortBy != null && sortBy.length() > 0 && SORTING_KEYS.containsKey(sortBy))
            ? SORTING_KEYS.get(sortBy)
            : SORTING_KEYS.get("admissionDate");
    return PageRequest.of(offset, limit, direction, sortBy);
  }

  private List<OrdersV2FetchResponseDto> getOrders(
      DealerEntity dealer, OrderListFilterDto orderListFilterDto, FetchOrdersV2Dto ordersV2Dto, Pageable pageable, String lang) {
    if (dealer.getCompanyCode() == null || dealer.getCompanyCode().isEmpty()) {
      logger.error(
          "Dealer company code is not available for dealer id : {} user id : {}",
          dealer.getDealerId(),
          dealer.getUserId());
      throw new RuntimeException("Dealer company code is not available");
    }
    LocalDateTime startDate = LocalDateTime.now().minusYears(1);
    Timestamp admissionCreatedDate = Timestamp.valueOf(startDate);
    QOrdersV2 qOrdersV2 = QOrdersV2.ordersV2;
    BooleanBuilder builder = new BooleanBuilder();
    if (orderListFilterDto.isMop()) {
      builder.and(qOrdersV2.navi.naviName.contains(M_OP));
    }
    if (orderListFilterDto.isDop()) {
      builder.or(qOrdersV2.navi.naviName.contains(D_OP));
    }
    if (orderListFilterDto.getVehicleType() != null) {
      builder.and(qOrdersV2.vehicleType.eq(orderListFilterDto.getVehicleType()));
    }
    if (orderListFilterDto.getModels() != null) {
      List<ModelIdDto> models = orderListFilterDto.getModels();
      int i = 0;
      for (ModelIdDto m : models) {
        if (i == 0) {
          builder.and(qOrdersV2.model.id.eq(m.getId()));
        } else {
          builder.or(qOrdersV2.model.id.eq(m.getId()));
        }
        i++;
      }
    }
    if (!StringUtils.isEmpty(orderListFilterDto.getNcasNumber())) {
      builder.and(qOrdersV2.ordersNumber.eq(orderListFilterDto.getNcasNumber()));
    }
    if (!StringUtils.isEmpty(orderListFilterDto.getVin())) {
      builder.and(qOrdersV2.vinNumber.eq(orderListFilterDto.getVin()));
    }

    if (orderListFilterDto.getNaviid() != null && !StringUtils.isEmpty(orderListFilterDto.getNaviid().toString())) {
      builder.and(qOrdersV2.navi.id.eq(orderListFilterDto.getNaviid()));
    }
    if (!StringUtils.isEmpty(orderListFilterDto.getCaName())) {
      builder.and(qOrdersV2.caName.eq(orderListFilterDto.getCaName()));
    }

    if (!StringUtils.isEmpty(orderListFilterDto.getCaNameKana())) {
      builder.and(qOrdersV2.caNameKana.eq(orderListFilterDto.getCaNameKana()));
    }
    if (!StringUtils.isEmpty(orderListFilterDto.getCaCompName())) {
      builder.and(qOrdersV2.companyName.eq(orderListFilterDto.getCaCompName()));
    }

    if (!StringUtils.isEmpty(orderListFilterDto.getCustomerName())) {
      builder.and(qOrdersV2.customerName.eq(orderListFilterDto.getCustomerName()));
    }
    if (!StringUtils.isEmpty(orderListFilterDto.getCustomerNameKana())) {
      builder.and(qOrdersV2.customerNameKana.eq(orderListFilterDto.getCustomerNameKana()));
    }

    if (!StringUtils.isEmpty(orderListFilterDto.getCustomerPhoneNumber())) {
      builder.and(qOrdersV2.customerPhoneNumber.eq(orderListFilterDto.getCustomerPhoneNumber()));
    }

    if (!StringUtils.isEmpty(orderListFilterDto.getCustomerZipCode())) {
      builder.and(qOrdersV2.customerZipCode.eq(orderListFilterDto.getCustomerZipCode()));
    }

    builder.and(qOrdersV2.active.eq(true));
    if (CA.equals(dealer.getDealerType())) {
      builder.and(qOrdersV2.admission.dealer.companyCode.eq(dealer.getCompanyCode()));
      builder.and(qOrdersV2.admission.dealer.dealerShipCode.eq(dealer.getDealerShipCode()));
    }
    builder.and(qOrdersV2.admission.createdDate.goe(admissionCreatedDate));
    Iterable<OrdersV2> iterator = ordersV2Repository.findAll(builder.getValue(), pageable);
    ordersV2Dto.setTotalCount(ordersV2Repository.count(builder.getValue()));
    List<OrdersV2> actualList =
        StreamSupport.stream(iterator.spliterator(), false).collect(Collectors.toList());
    List<OrdersV2FetchResponseDto> ordersV2FetchResponseDtoList = new ArrayList<>();
    actualList.forEach(
        o -> {
          AdmissionV2 admission = o.getAdmission();
          User user = userRepository.findById(admission.getUser().getId()).get();
          logger.info(
              "user id {} for the admission is {}", admission.getUser().getId(), admission.getId());
          Optional<Customer> customer = customerRepository.findByUserId(user.getId());
          OrdersV2FetchResponseDto ordersV2FetchResponseDto = null;
          if (customer.isPresent()) {
            logger.info(
                "customer id {} for the admission is {}",
                customer.get().getId(),
                admission.getId());
            ordersV2FetchResponseDto = new OrdersV2FetchResponseDto(o, customer.get());
          } else {
            ordersV2FetchResponseDto = new OrdersV2FetchResponseDto(o, null, user);
          }
          setAdmissionType(ordersV2FetchResponseDto, lang);
          if(o.getPaymentMethod() != null && PAYMENT_METHOD_PAPER.equals(o.getPaymentMethod().getName())) {
            CommentV2 commentV2 = commentV2Repository.findByOrdersId(o.getId());
            Optional<Reason> opReason = reasonRepository.findById(commentV2.getReasonId());
            if(opReason.isPresent()) {
              ordersV2FetchResponseDto.setPaperReason(opReason.get().getDisplayName());
              ordersV2FetchResponseDto.setPaperReasonFreeComment(commentV2.getComment());
            }
          }
          if(ordersV2FetchResponseDto.getIviFlag() != null) {
            ordersV2FetchResponseDto.setIviFlag(getIVIValue(ordersV2FetchResponseDto.getIviFlag(), lang));
          }
          if(ordersV2FetchResponseDto.getSosFlag() != null) {
            ordersV2FetchResponseDto.setSosFlag(getSOSValue(ordersV2FetchResponseDto.getSosFlag(), lang));
          }
          ordersV2FetchResponseDtoList.add(ordersV2FetchResponseDto);
        });
    /** Sorting based on DEALER_COMPLETED status */
    List <OrdersV2FetchResponseDto> dealerCompleted =  ordersV2FetchResponseDtoList.stream().filter(a->a.getStatus().equals(STATUS_DEALER_COMPLETED)).collect(Collectors.toList());
    List <OrdersV2FetchResponseDto> others =  ordersV2FetchResponseDtoList.stream().filter(a->!a.getStatus().equals(STATUS_DEALER_COMPLETED)).collect(Collectors.toList());

    Comparator<OrdersV2FetchResponseDto> timeComparator = Comparator.comparing(OrdersV2FetchResponseDto::getAdmissionTime).reversed();

    List<OrdersV2FetchResponseDto> sortedDealerCompleted = dealerCompleted.stream()
            .sorted(timeComparator)
            .collect(Collectors.toList());
    List<OrdersV2FetchResponseDto> sortedOthers = others.stream()
            .sorted(timeComparator)
            .collect(Collectors.toList());

    sortedDealerCompleted.addAll(sortedOthers);
    return sortedDealerCompleted;
  }

  private String getIVIValue(String iviValue, String lang) {
    String response = "";
    if(iviValue != null) {
      switch (iviValue)
      {
        case "0":
          response = JP.equals(lang) ? "IVI以外の車両" : "Not IVI";
          break;
        case "1":
          response = JP.equals(lang) ? "IVI車両" : "IVI";
          break;
      }
    }
    return response;
  }

  private String getSOSValue(String sosValue, String lang) {
    String response = "";
    if(sosValue != null) {
      switch (sosValue)
      {
        case "0":
          response = JP.equals(lang) ? "SOSサービス対象外" : "Out of service";
          break;
        case "1":
          response = JP.equals(lang) ? "SOSサービス対象" : "In service";
          break;
      }
    }
    return response;
  }

  private OrderListFilterDto getOrderListFilterDto(OrderListRequestDto orderListRequestDto) {
    OrderListFilterDto orderListFilterDto = new OrderListFilterDto();
    orderListFilterDto.setDop(orderListRequestDto.isDop());
    orderListFilterDto.setMop(orderListRequestDto.isMop());
    orderListFilterDto.setModels(orderListRequestDto.getModels());
    orderListFilterDto.setCaCompName(orderListRequestDto.getCaCompName());
    orderListFilterDto.setCaName(orderListRequestDto.getCaName());
    orderListFilterDto.setCaNameKana(orderListRequestDto.getCaNameKana());
    orderListFilterDto.setCustomerName(orderListRequestDto.getCustomerName());
    orderListFilterDto.setCustomerNameKana(orderListRequestDto.getCustomerNameKana());
    orderListFilterDto.setCustomerPhoneNumber(orderListRequestDto.getCustomerPhoneNumber());
    orderListFilterDto.setCustomerZipCode(orderListRequestDto.getCustomerZipCode());
    orderListFilterDto.setNaviid(orderListRequestDto.getNaviid());
    orderListFilterDto.setNcasNumber(orderListRequestDto.getNcasNumber());
    orderListFilterDto.setVin(orderListRequestDto.getVin());
    orderListFilterDto.setVehicleType(orderListRequestDto.getVehicleType());
    return orderListFilterDto;
  }

  private Timestamp convertToSqlTimeStamp(String date) throws ParseException {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    Date parsedTimeStamp = dateFormat.parse(date);
    Timestamp timestamp = new Timestamp(parsedTimeStamp.getTime());
    return timestamp;
  }

  private Timestamp convertToSqlTimeStampEndDate(String date) throws ParseException {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    Date parsedTimeStamp = dateFormat.parse(date);
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(parsedTimeStamp);
    calendar.set(Calendar.HOUR_OF_DAY, 23);
    calendar.set(Calendar.MINUTE, 59);
    calendar.set(Calendar.SECOND, 59);
    calendar.set(Calendar.MILLISECOND, 999);
    Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
    return timestamp;
  }

  @Override
  @Transactional
  public String deleteOrders(String orderNumber, DealerEntity dealer) {
    logger.info("Inside delete orders");
    String status = Constants.FAILED;
    OrdersV2 orders = ordersV2Repository.findByOrdersNumber(orderNumber);
    if (!isValidOrder(orders, dealer)) {
      return status;
    }
    CommentV2 comment = commentV2Repository.findByOrdersId(orders.getId());
    Optional<Customer> optionalCustomer =
        customerRepository.findByUserId(orders.getAdmission().getUser().getId());
    Customer customer = null;
    Payment payment = null;
    if (optionalCustomer.isPresent()) {
      customer = optionalCustomer.get();
      payment = paymentRepository.fetchByCustomerId(customer.getId());
    }
    status = deactivateOrders(orders, customer, payment, comment);
    return status;
  }

  @Transactional
  private String deactivateOrders(
      OrdersV2 orders, Customer customer, Payment payment, CommentV2 comment) {
    logger.info("Inside deactivate orders");
    String status = Constants.FAILED;
    try {
      orders.setActive(false);
      ordersV2Repository.save(orders);
      orders.getAdmission().setActive(false);
      logger.info("Admission number to delete {}", orders.getAdmission().getId());
      admissionV2Repository.save(orders.getAdmission());
      if (customer != null) {
        customer.setActive(false);
        customerRepository.save(customer);
        if (payment != null) {
          payment.setActive(false);
          paymentRepository.save(payment);
        }
      }
      if (comment != null) {
        comment.setActive(false);
        commentV2Repository.save(comment);
      }
      status = Constants.SUCCESS;
    } catch (Exception e) {
      logger.info("Exception in deactivate orders : " + e.getMessage());
    }
    return status;
  }

  @Override
  public String downloadOrders(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      DealerEntity dealer,
      String lang,
      String startDate,
      String endDate)
      throws IOException {
    logger.info("*****Inside download orders");
    String status = Constants.FAILED;
    try {
      String fileName = "orderDetail.csv";
      httpServletResponse.setContentType("text/csv");
      httpServletResponse.setHeader("Content-Disposition", "attachment;filename=" + fileName);
      Writer writer = new OutputStreamWriter(httpServletResponse.getOutputStream());
      ICsvBeanWriter csvWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);
      String[] header1 = {
        "Application date time",
        "Status",
        "Admission type",
        "Dealer/Home",
        "New/Used vehicle",
        "NCAS #",
        "Order #",
        "Dealer Company Code",
        "Dealer Company Name",
        "Dealsership Name",
        "Dealer phone #",
        "C/A Name",
        "C/A Name(Kana)",
        "C/A Code",
        "C/A E-mail",
        "Customer type",
        "Vehicle Model",
        "Vehicle Grade",
        "Navi type",
        "Vehicle Option 2",
        "Package plan",
        "IVI flag",
        "SOS flag",
        "VIN",
        "First registered date",
        "VIN registered date",
        "NC-ID",
        "NC status",
        "NC join date",
        "Charge start date",
        "Service update date",
        "Navi ID",
        "Register Number",
        "Vehicle Model(from CW)",
        "Service annual price",
        "E-mail sent date",
        "Payment method",
        "Transfer",
        "Old vehicle VIN",
        "Paper Reason",
        "Paper Reason free comment",
        "Active"
      };
      String[] headerJp = {
        "入会日時",
        "状態",
        "入会区分",
        "申し込み場所",
        "新車/中古車区分",
        "入会番号",
        "Profit注文書番号",
        "販売会社コード",
        "販売会社名",
        "店舗名",
        "店舗電話番号",
        "販売担当名",
        "販売担当名(かな)",
        "販売担当コード",
        "販売担当E-mail",
        "個人/法人",
        "申込車種",
        "グレード",
        "ナビタイプ",
        "オプション",
        "パッケージプラン",
        "IVIフラグ",
        "SOSコールサービスフラグ",
        "車台番号",
        "初度登録年月",
        "車両登録日",
        "NC-ID",
        "CWステータス",
        "NC入会日",
        "課金予定日",
        "更新予定日",
        "車載機ID",
        "登録番号",
        "車種(CW情報)",
        "サービス料金年額",
        "E-mail送信日",
        "支払い方法",
        "乗り換え",
        "乗り換え前車両のVIN",
        "紙申込理由",
        "フリーコメント",
        "有効(値がFalseの場合は削除済)"
      };
      String[] fieldMapping = {
        "createdDate",
        "status",
        "id",
        "admissionType",
        "source",
        "vehicleType",
        "ordersNumber",
        "companyCode",
        "companyName",
        "dealershipName",
        "phoneNumber",
        "caName",
        "caNameKana",
        "caCode",
        "email",
        "customerType",
        "modelName",
        "gradeName",
        "naviName",
        "optionsName",
        "packagePlanName",
        "registrationDate",
        "vinRegisteredDate",
        "ncId",
        "planPrice",
        "emailSendDate",
        "name",
        "vehicleTransfer",
        "vinNumber",
        "active"
      };
      csvWriter.writeHeader(header1);
      csvWriter.writeHeader(headerJp);
      logger.info("Header written to csv");
      Timestamp startDateTimeStamp = convertToSqlTimeStamp(startDate);
      Timestamp endDateTimeStamp = convertToSqlTimeStampEndDate(endDate);
      List<DownloadCsvOrderV2ListDTO> orders =
          ordersV2Repository.fetchOrdersDetails(startDateTimeStamp, endDateTimeStamp);
      for (DownloadCsvOrderV2ListDTO order : orders) {
        try {
          logger.info("*****Setting admission type for download file");
          logger.info("*****Successfully set admission type in download file");
          OrdersV2 ordersV2 = ordersV2Repository.findByOrdersNumber(order.getOrdersNumber());
          OrdersV2FetchResponseDto ordersV2FetchResponseDto =
              new OrdersV2FetchResponseDto(ordersV2, null);
          setAdmissionType(ordersV2FetchResponseDto, lang);
          order.setAdmissionType(ordersV2FetchResponseDto.getAdmissionTypeName());
          csvWriter.write(order, fieldMapping);
        } catch (IOException e) {
          logger.info("exception in write order to csv : " + e.getMessage());
          e.printStackTrace();
          return null;
        }
      }
      csvWriter.close();
      logger.info("file written completed");
      status = Constants.SUCCESS;
      logger.info("status : " + status);
    } catch (Exception e) {
      logger.info("Exception in download orders : " + e.getMessage());
    }
    return status;
  }

  @Override
  @Transactional
  public List<com.nissan.admission.dto.ActivityLogResponseDTO> fetchOrderActivityLog(
      String orderNumber, DealerEntity dealerEntity, String lang) {
    logger.info("****Inside fetch order by number activity log");
    OrdersV2 orders = ordersV2Repository.findByOrdersNumber(orderNumber);
    if (orders == null) {
      logger.info("****No order details found for activity log");
      throw new DetailsNotFoundException("Order details not found");
    }
    AdmissionV2 admission = orders.getAdmission();
    List<ActivityLogV2> activityLogs =
        activityLogV2Repository.fetchByAdmissionIdAndTime(admission.getId());
    logger.info("****Activity logs fetched" + activityLogs);
    if (!activityLogs.isEmpty()) {
      List<com.nissan.admission.dto.ActivityLogResponseDTO> activityLogResponseDTOS =
          new ArrayList<>();
      for (ActivityLogV2 activityLog : activityLogs) {
        logger.info("****inside activity log loop");
        com.nissan.admission.dto.ActivityLogResponseDTO activityLogResponseDTO =
            new ActivityLogResponseDTO();
        if (lang.equals("en")) {
          activityLogResponseDTO.setMessage(activityLog.getMessage());
        } else {
          activityLogResponseDTO.setMessage(activityLog.getMessageJp());
        }
        activityLogResponseDTO.setType(activityLog.getType());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm a");
        String formatDateTime = activityLog.getTime().format(formatter);
        activityLogResponseDTO.setTime(formatDateTime);
        activityLogResponseDTOS.add(activityLogResponseDTO);
      }
      return activityLogResponseDTOS;
    } else {
      return null;
    }
  }

  @Override
  @Transactional
  public OrdersUpdateResponseDTO updateOrders(
      OrdersV2UpdateRequestDTO updateRequest, String lang, DealerEntity dealer) throws Exception {
    logger.info("Inside update orders");
    OrdersUpdateResponseDTO updateResponse = new OrdersUpdateResponseDTO();
    updateResponse.setStatus(Constants.FAILED);

    OrdersV2 orders = ordersV2Repository.findByOrdersNumber(updateRequest.getOrderNumber());
    if (!isValidOrder(orders, dealer) || !isUpdateOrderAllowed(orders)) {
      return updateResponse;
    }
    if (updateRequest.getCustomerDetails() != null) {
      CustomerResponseDTO updateCustomer =
          updateCustomerDetails(
              updateRequest.getCustomerDetails().getUserId(),
              updateRequest.getCustomerDetails(),
              lang);
      if (updateCustomer == null) return updateResponse;
    }
    if (orders != null) {
      orders = setOrderDetails(orders, updateRequest);
      OrdersV2 updatedOrders = ordersV2Repository.save(orders);
      if (updatedOrders == null) return updateResponse;
    }
    updateResponse.setStatus(Constants.SUCCESS);
    sendUpdateMail(orders.getAdmission().getUser());
    return updateResponse;
  }

  @Override
  public String mapVehicleNumber(
      VehicleNumberMappingDTO mappingDTO, DealerEntity dealer, String lang) {
    logger.info("Inside map Vehicle Number plate");
    OrdersV2 orders = ordersV2Repository.findByAdmissionId(mappingDTO.getOrderNumber());
    if (!isValidOrder(orders, dealer)) {
      return Constants.FAILED;
    }
    orders.setVehicleNumber(mappingDTO.getVehicleNumber());
    orders.setFirstRegistrationDate(mappingDTO.getFirstRegistrationDate());
    orders.setRegistrationDate(mappingDTO.getRegistrationDate());
    orders.setExpiryDate(mappingDTO.getExpiryDate());
    OrdersV2 updatedOrder = ordersV2Repository.save(orders);
    if (updatedOrder != null) {
      AdmissionV2 admission = updatedOrder.getAdmission();
      if (StringUtils.isNotEmpty(admission.getDocumentName())
              && StringUtils.isNotEmpty(orders.getVehicleNumber())
              && StringUtils.isNotEmpty(orders.getFirstRegistrationDate())
              && StringUtils.isNotEmpty(orders.getRegistrationDate())) {
        admission.setStatus(Constants.STATUS_DEALER_ALL_COMPLETED);
        admission.setStatusJp(Constants.STATUS_DEALER_ALL_COMPLETED_JP);
        AdmissionV2 updatedAdmission = admissionV2Repository.save(admission);
        activityUtil.createActivityLogV2(admission);
        if (Constants.STATUS_DEALER_ALL_COMPLETED.equals(updatedAdmission.getStatus())) {
          mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"order updated : "+ updatedOrder.getVehicleNumber());
          return Constants.SUCCESS;
        }
      }
      return Constants.SUCCESS;
    }
    return Constants.FAILED;
  }

  private Boolean isUpdateOrderAllowed(OrdersV2 orders) {
    if (orders.getUploadKameri() != null && orders.getUploadKameri()) {
      logger.info("Cannot update orders uploaded to kameri");
      throw new InvalidOrderException("Cannot update orders uploaded to kameri");
    }
    return true;
  }

  private CustomerResponseDTO updateCustomerDetails(
      Long userId, CustomerDTO customerDTO, String lang) {
    logger.info("Inside update customer details using customer service");
    CustomerResponseDTO response = null;
    try {
      if (customerDTO.getCustomerType() == null || userId == null)
        throw new RuntimeException("Customer type or userId is missing in request");
      response = customerService.updateCustomerById(customerDTO, String.valueOf(userId), lang);
    } catch (Exception e) {
      logger.info("Exception in update Customer Details : " + e.getMessage());
    }
    return response;
  }

  private OrdersV2 setOrderDetails(
      OrdersV2 ordersInfo, OrdersV2UpdateRequestDTO updateRequestInfo) {
    try {
      if (updateRequestInfo.getPackagePlan() != null) {
        ordersInfo.setPackagePlan(
            (packagePlanV2Repository.findById(updateRequestInfo.getPackagePlan()).get()));
      }

      if (updateRequestInfo.getVehicleTransfer() != null) {
        ordersInfo.setVehicleTransfer(updateRequestInfo.getVehicleTransfer());
      }

      if (updateRequestInfo.getOldVinNumber() != null) {
        ordersInfo.setOldVinNumber(updateRequestInfo.getOldVinNumber());
      }

      if (updateRequestInfo.getCustomerDetails() != null) {
        CustomerDTO customerDto = updateRequestInfo.getCustomerDetails();
        ordersInfo.setCustomerName(customerDto.getFirstName());
        ordersInfo.setCustomerNameKana(customerDto.getFirstNameKatakana());
        ordersInfo.setCustomerPhoneNumber(customerDto.getPhoneNumber());
        ordersInfo.setCustomerZipCode(customerDto.getZipCode());
      }
      /** Edit order functionality for dealer */
      if (updateRequestInfo.getDealerDetails() != null) {
        if (updateRequestInfo.getDealerDetails().getCompanyName() != null) {
          ordersInfo.setCompanyName(updateRequestInfo.getDealerDetails().getCompanyName());
        }
        if (updateRequestInfo.getDealerDetails().getDealershipName() != null) {
          ordersInfo.setDealershipName(updateRequestInfo.getDealerDetails().getDealershipName());
        }
        if (updateRequestInfo.getDealerDetails().getPhoneNumber() != null) {
          ordersInfo.setPhoneNumber(updateRequestInfo.getDealerDetails().getPhoneNumber());
        }
        if (updateRequestInfo.getDealerDetails().getCaName() != null) {
          ordersInfo.setCaName(updateRequestInfo.getDealerDetails().getCaName());
        }
        if (updateRequestInfo.getDealerDetails().getCaNameKana() != null) {
          ordersInfo.setCaNameKana(updateRequestInfo.getDealerDetails().getCaNameKana());
        }
        if (updateRequestInfo.getDealerDetails().getCaCode() != null) {
          ordersInfo.setCaCode(updateRequestInfo.getDealerDetails().getCaCode());
        }
      }
    } catch (Exception e) {
      logger.info("Exception in set Order Details : " + e.getMessage());
    }
    return ordersInfo;
  }

  private void sendUpdateMail(User user) {
    logger.info("Sending update Admission to customer {}", user.getId());
    Customer customer = customerRepository.findByUserId(user.getId()).orElse(null);
    if (customer != null) {
      String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
      logger.info("API service URL {}", serviceLocation);
      String url = HTTP + serviceLocation + USED_CAR_UPDATE;

      HttpHeaders headers = new HttpHeaders();
      headers.set(PRINCIPAL_ID, user.getId().toString());
      HttpEntity<String> request = new HttpEntity<>(headers);
      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<Customer> response =
          restTemplate.exchange(url, HttpMethod.GET, request, Customer.class);

      mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"update Admission Mail sent for user "+ response.getBody());
    } else {
      logger.error("Customer details not found to trigger Update Admission Mail");
    }
  }
}
