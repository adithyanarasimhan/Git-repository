package com.nissan.admission.util;

public final class Constants {

  public static final String REGION = "ap-northeast-1";
}
