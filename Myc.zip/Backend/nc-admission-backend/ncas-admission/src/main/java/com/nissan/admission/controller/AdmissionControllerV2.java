package com.nissan.admission.controller;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.nissan.admission.dto.AdmissionSaveRequestV2DTO;
import com.nissan.admission.dto.AdmissionSaveResponseV2DTO;
import com.nissan.admission.service.AWSS3Service;
import com.nissan.admission.service.AdmissionServiceV2;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.entity.AdmissionV2;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.User;
import com.nissan.common.repository.AdmissionV2Repository;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.util.Constants;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Optional;

import static com.nissan.common.util.Constants.*;

@RestController
@RequestMapping("secured/api/v1")
public class AdmissionControllerV2 {

  private static final Logger logger = LoggerFactory.getLogger(AdmissionControllerV2.class);
  private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(AdmissionControllerV2.class);
  private static final String PRINCIPAL_ID = "principalId";
  @Autowired private AdmissionServiceV2 admissionService;
  @Autowired private DealerRepository dealerRepository;
  @Autowired private AdmissionV2Repository admissionV2Repository;
  @Autowired private UserRepository userRepository;
  @Autowired private AWSS3Service awss3Service;

  @PostMapping(value = "{langCode}/usedadmission", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> saveAdmissionV2(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "langCode") String lang,
      @RequestBody AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO) {
    String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
    if (dealer == null) {
      logger.info("dealer not found");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
    }
    AdmissionSaveResponseV2DTO saveResponse =
        admissionService.saveAdmissionInfo(admissionSaveRequestV2DTO, dealer.getDealerId(), lang);
    if (saveResponse != null) {
      logger.info("save admission success");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "Admission done successfully")
              .setData(saveResponse),
          HttpStatus.OK);
    }
    logger.info("error in save admission");
    return new ResponseEntity<>(
        new ResponseDTO(Constants.FAILED, "500", "Could not save admission details"),
        HttpStatus.BAD_REQUEST);
  }

  @GetMapping(value = "/download", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> downloadFile(
      HttpServletRequest httpServletRequest, @RequestParam(required = false) String admissionId)
      throws IOException {
    String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
    if (!StringUtils.isBlank(admissionId)) {
      AdmissionV2 admission = admissionV2Repository.fetchById(Long.parseLong(admissionId));
      User user = admission.getUser();
      principalId = user.getId().toString();
      mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Vehicle inspection doc user id"+ principalId);
    }
    String fileName = awss3Service.getInceptionDocName(principalId);
    final String encodeFile = awss3Service.downloadFile(fileName);
    if (!StringUtils.isEmpty(encodeFile)) {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "Inspection Document fetched successfully")
              .setData(encodeFile),
          HttpStatus.OK);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO(Constants.FAILED, "204", "Inspection Document not fetched"),
          HttpStatus.NOT_FOUND);
    }
  }

  @PostMapping(value = "{langCode}/upload", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> uploadFile(
      HttpServletRequest httpServletRequest,
      @PathVariable(name = "langCode") String lang,
      @RequestParam("userFile") final MultipartFile multipartFile,
      @RequestParam(required = false) String admissionId) {
    String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS,"Vehicle inspection doc admission id"+ admissionId);
    if (!StringUtils.isBlank(admissionId)) {
      AdmissionV2 admission = admissionV2Repository.fetchById(Long.parseLong(admissionId));
      User user = admission.getUser();
      principalId = user.getId().toString();
      logger.info("Vehicle inspection doc user id {}", principalId);
    }
    PutObjectResult result = awss3Service.uploadFile(multipartFile, principalId);
    final String response = multipartFile.getOriginalFilename() + " Uploaded successfully.";
    if (result != null) {
      if (Constants.EN.equals(lang)) {
        return new ResponseEntity<>(
                new ResponseDTO(SUCCESS, STATUS_200, FILE_UPLOAD).setData(response), HttpStatus.OK);
      } else {
        return new ResponseEntity<>(
            new ResponseDTO(SUCCESS, STATUS_200, FILE_UPLOAD_JP).setData(response), HttpStatus.OK);
      }

    } else {
      return new ResponseEntity<>(
          new ResponseDTO(FAILED, STATUS_500, FILE_UPLOAD_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @DeleteMapping(value = "/delete", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> deleteFile(HttpServletRequest httpServletRequest, @RequestParam(required = false) String admissionId) {
    String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
    if (!StringUtils.isBlank(admissionId)) {
      AdmissionV2 admission = admissionV2Repository.fetchById(Long.parseLong(admissionId));
      User user = admission.getUser();
      principalId = user.getId().toString();
      logger.info("Vehicle inspection doc user id {}", principalId);
    }
    String orderNumber = awss3Service.deleteFile(principalId);
    final String response = orderNumber + " Inception Doc deleted successfully.";

    if (!StringUtils.isEmpty(orderNumber)) {
      return new ResponseEntity<>(
          new ResponseDTO("success", "200", "Inspection Document Delete").setData(response),
          HttpStatus.OK);
    } else {
      return new ResponseEntity<>(
          new ResponseDTO("failed", "200", "Inspection Document Delete")
              .setData("Inspection Document Not Found"),
          HttpStatus.OK);
    }
  }

  @PostMapping(value = "{langCode}/homeadmission", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<ResponseDTO> saveAdmissionForCustomer(
      HttpServletRequest httpServletRequest,
      @PathVariable String langCode,
      @RequestBody AdmissionSaveRequestV2DTO admissionSaveRequestV2DTO) {
    String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
    Optional<User> optionalUser = userRepository.findById(Long.valueOf(principalId));
    if (!optionalUser.isPresent()) {
      logger.info("User not found");
      return new ResponseEntity<ResponseDTO>(
          new ResponseDTO(Constants.FAILED, "204", "User not found"), HttpStatus.BAD_REQUEST);
    }
    User user = optionalUser.get();
    Object saveResponse =
        admissionService.saveHomeAdmissionInfo(admissionSaveRequestV2DTO, user, langCode);
    if (saveResponse != null) {
      logger.info("save admission success");
      return new ResponseEntity<>(
          new ResponseDTO(Constants.SUCCESS, "200", "Admission done successfully")
              .setData(saveResponse),
          HttpStatus.OK);
    }
    logger.info("error in save admission");
    return new ResponseEntity<>(
        new ResponseDTO(Constants.FAILED, "500", "Could not save admission details"),
        HttpStatus.BAD_REQUEST);
  }
}
