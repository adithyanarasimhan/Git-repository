package com.nissan.admission.dto;

import com.nissan.common.dto.DealerDTO;
import com.nissan.common.dto.PaymentMethodDto;
import com.nissan.common.dto.ReasonDTO;
import com.nissan.common.dto.ModelDTO;
import lombok.Data;

import java.util.List;

@Data
public class AdmissionFetchResponseDTO {

  private List<ModelDTO> models;
  private List<ReasonDTO> reasonTypesPaper;
  private List<ReasonDTO> reasonTypesNoThanks;
  private List<PaymentMethodDto> paymentTypes;
  private DealerDTO dealerDetails;
  private UsedCarsModelDto usedCar;
}
