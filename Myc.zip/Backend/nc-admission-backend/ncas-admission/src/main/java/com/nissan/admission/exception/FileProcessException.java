package com.nissan.admission.exception;

public class FileProcessException extends RuntimeException {

  private static final long serialVersionUID = 266853955330018736L;

  public FileProcessException(final String message) {
    super(message);
  }

  public FileProcessException(final String message, final Exception e) {
    super(message, e);
  }
}
