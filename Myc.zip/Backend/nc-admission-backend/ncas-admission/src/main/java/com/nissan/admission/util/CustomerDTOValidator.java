package com.nissan.admission.util;

import org.apache.commons.beanutils.BeanUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.InvocationTargetException;

public class CustomerDTOValidator implements ConstraintValidator<CustomerValidator, Object> {

  private String fieldName;
  private String expectedFieldValue;
  private String[] dependFieldName;
  private String message;

  @Override
  public void initialize(CustomerValidator annotation) {
    fieldName = annotation.fieldName();
    expectedFieldValue = annotation.fieldValue();
    dependFieldName = annotation.dependFieldName();
    message = annotation.message();
  }

  @Override
  public boolean isValid(Object value, ConstraintValidatorContext ctx) {

    boolean isValid = true;
    if (value == null) {
      return true;
    }

    try {
      String fieldValue = BeanUtils.getProperty(value, fieldName);
      for (int i = 0; i < dependFieldName.length; i++) {
        String dependFieldValue = BeanUtils.getProperty(value, dependFieldName[i]);
        if (expectedFieldValue.equals(fieldValue) && dependFieldValue == null) {
          ctx.disableDefaultConstraintViolation();
          ctx.buildConstraintViolationWithTemplate("should not be null")
              .addPropertyNode(dependFieldName[i])
              .addConstraintViolation();
          isValid = false;
        }
      }

    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException ex) {
      throw new RuntimeException(ex);
    }
    return isValid;
  }
}
