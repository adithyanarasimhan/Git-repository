package com.nissan.admission.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class MappingDTO {

    @NotBlank(message = "Please enter a valid orderNumber")
    private String orderNumber;
    @NotBlank(message = "Profit system order number cannot be empty")
    @Pattern(regexp = "[a-zA-Z0-9]+", message = "Please enter a valid profit system order number")
    private String profitSystemOrderNumber;

}
