package com.nissan.admission.dto;

import com.nissan.common.dto.ModelV2DTO;
import lombok.Data;

import java.util.List;

@Data
public class UsedCarsModelDto {

  private List<ModelV2DTO> models;
}
