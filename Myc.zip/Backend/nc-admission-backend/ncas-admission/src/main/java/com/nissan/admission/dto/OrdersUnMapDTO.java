package com.nissan.admission.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class OrdersUnMapDTO {
  @NotBlank public String profitSystemOrderNumber;
}
