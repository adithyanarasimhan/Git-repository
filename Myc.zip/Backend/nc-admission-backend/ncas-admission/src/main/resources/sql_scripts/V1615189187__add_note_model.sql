INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url, category, vehicle_type) VALUES
('Note', 'NOTE (December 2020 ~)', 'ノート', 'en', null, true, 'common'),
('ノート（2020年12月発売）', 'ノート（2020年12月発売）', 'ノート', 'jp', null, true, 'common');

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'X (including 2WD / 4WD / AUTECH)', 'X (including 2WD / 4WD / AUTECH)', 'X（2WD/4WD/AUTECH含む）', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'X（2WD/4WD/AUTECH含む）', 'X（2WD/4WD/AUTECH含む）', 'X（2WD/4WD/AUTECH含む）', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'F/S', 'F/S', 'F/S', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'F/S', 'F/S', 'F/S', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en', true, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp', true, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'DOP(Not applicable / No Navi Type)', 'お申込み不可', 'en', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'ディーラーオプション(お申込み不可)', 'お申込み不可', 'jp', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'DOP(Not applicable / No Navi Type)', 'お申込み不可', 'en', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='F/S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'ディーラーオプション(お申込み不可)', 'お申込み不可', 'jp', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='F/S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'Standard plan +', 'スタンダードプラン＋', '7920', '2200', 'en', 'pattern-one', 'pattern-two', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'スタンダードプラン＋', 'スタンダードプラン＋', '7920', '2200', 'jp', 'pattern-one', 'pattern-two', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'Standard plan +', 'スタンダードプラン＋', '7920', '0', 'en', 'pattern-one', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'スタンダードプラン＋', 'スタンダードプラン＋', '7920', '0', 'jp', 'pattern-one', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));