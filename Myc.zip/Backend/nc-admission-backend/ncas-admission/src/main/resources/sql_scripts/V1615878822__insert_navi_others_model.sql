INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en', 'newcar', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp', 'newcar', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));