CREATE TABLE nissan_admin.bank_details (
	id bigserial NOT NULL,
	bank_code varchar(5) NULL,
	bank_name varchar(100) NULL,
	branch_shop_code varchar(5) NULL,
	branch_shop_name varchar(100) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT bank_details_pkey PRIMARY KEY (id)
);