UPDATE nissan_admin.package_plan SET pattern_name='pattern-three' WHERE package_plan_name='basic-operator-service';

UPDATE nissan_admin.package_planv2 SET pattern_name='pattern-five' WHERE package_plan_name='sos';

UPDATE nissan_admin.package_planv2 SET pattern_name='pattern-six' WHERE navi_id IN (SELECT id FROM nissan_admin.naviv2 WHERE grade_id IN (SELECT id FROM nissan_admin.gradev2 WHERE model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' OR model_name='リーフ（2020年1月以前）')));

UPDATE nissan_admin.modelv2 SET category=false WHERE model_name != 'Skyline (From September 2019)' AND model_name != 'スカイライン（2019年9月～）' AND model_name != 'Leaf (from February 2020)' AND model_name != 'リーフ（2020年2月～）' AND category=true;

ALTER TABLE nissan_admin.ordersv2 ALTER COLUMN color_code TYPE varchar(200);