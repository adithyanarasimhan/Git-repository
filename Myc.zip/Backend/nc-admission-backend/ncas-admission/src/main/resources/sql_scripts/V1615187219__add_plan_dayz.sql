INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 's-os', 'SOS', 'en' FROM nissan_admin.grade g WHERE g.model_name='DAYZ' AND lang_code='en';

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'jp' FROM nissan_admin.grade g WHERE g.model_name='デイズ' AND lang_code='jp';


INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name)
    SELECT id, 'sos', 'SOS', 0, 'en', 'pattern-five', 'pattern-one' FROM nissan_admin.navi n WHERE n.lang_code='en' AND n.navi_name='s-os' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='DAYZ' AND lang_code='en');

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name)
    SELECT id, 'sos', 'SOS', 0, 'jp', 'pattern-five', 'pattern-one' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND n.navi_name='s-os' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='デイズ' AND lang_code='jp');



UPDATE nissan_admin.grade SET grade_name='X（2WD/4WD/AUTECH含む）', display_name='X（2WD/4WD/AUTECH含む）' WHERE display_name='X' AND model_name='ノート' AND lang_code='jp';

UPDATE nissan_admin.grade SET grade_name='X (including 2WD / 4WD / AUTECH)', display_name='X (including 2WD / 4WD / AUTECH)' WHERE display_name='X' AND model_name='Note' AND lang_code='en';