CREATE SEQUENCE IF NOT EXISTS nissan_admin.ordersv2_seq
          START WITH 1
          MINVALUE 1
          MAXVALUE 922337203
          CYCLE;

CREATE TABLE IF NOT EXISTS nissan_admin.ordersv2 (
    id bigint NOT NULL DEFAULT nextval('ordersv2_seq'::regclass),
    orders_number character varying(255) COLLATE pg_catalog."default",
    admission_id bigint,
    vin_number character varying(255) COLLATE pg_catalog."default",
    navi_id character varying(255) COLLATE pg_catalog."default",
    registration_date character varying(255) COLLATE pg_catalog."default",
    model_name character varying(255) COLLATE pg_catalog."default",
    variant character varying(255) COLLATE pg_catalog."default",
    navi_type character varying(255) COLLATE pg_catalog."default",
    color_code character varying(255) COLLATE pg_catalog."default",
    color character varying(255) COLLATE pg_catalog."default",
    vehicle_image character varying(255) COLLATE pg_catalog."default",
    plan_id bigint,
    payment_type bigint,
    CONSTRAINT ordersv2_pkey PRIMARY KEY (id),
    CONSTRAINT ordersv2_admission_fkey FOREIGN KEY (admission_id)
            REFERENCES nissan_admin.admission (id) MATCH SIMPLE
            ON UPDATE NO ACTION
            ON DELETE NO ACTION
);