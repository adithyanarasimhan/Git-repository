--Modelv2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.modelv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.modelv2 (
	id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.modelv2_seq'::regclass),
	model_name varchar(100) NULL,
	display_name varchar(100) NULL,
	cw_model_name varchar(100) NULL,
	lang_code varchar(5) NULL,
	url varchar(500) NULL,
	model_display_order int2 NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	ivi bool NULL,
	color_option bool NULL,
	category bool NULL,
	vehicle_type varchar(10) NULL DEFAULT 'common'::character varying,
	CONSTRAINT modelv2_pkey PRIMARY KEY (id)
);

--Gradev2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.gradev2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.gradev2 (
	id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.gradev2_seq'::regclass),
	model_id int8 NOT NULL,
	grade_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_grade_name varchar(300) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	vehicle_type varchar(10) NULL DEFAULT 'common'::character varying,
	CONSTRAINT gradev2_id_key UNIQUE (id),
	CONSTRAINT gradev2_pkey PRIMARY KEY (grade_name, model_id)
);

-- nissan_admin.gradev2 foreign keys

ALTER TABLE nissan_admin.gradev2 ADD CONSTRAINT gradev2_model_fkey FOREIGN KEY (model_id) REFERENCES nissan_admin.modelv2(id);

--Naviv2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.naviv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.naviv2 (
	id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.naviv2_seq'::regclass),
	grade_id int8 NOT NULL,
	navi_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_navi_name varchar(300) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	vehicle_type varchar(10) NULL DEFAULT 'common'::character varying,
	color_option bool NULL,
	CONSTRAINT naviv2_id_key UNIQUE (id),
	CONSTRAINT naviv2_pkey PRIMARY KEY (navi_name, grade_id)
);

-- nissan_admin.naviv2 foreign keys

ALTER TABLE nissan_admin.naviv2 ADD CONSTRAINT naviv2_gradeid_fkey FOREIGN KEY (grade_id) REFERENCES nissan_admin.gradev2(id);

-- package_planv2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.package_planv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.package_planv2 (
	id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.package_planv2_seq'::regclass),
	navi_id int8 NOT NULL,
	package_plan_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_package_plan_name varchar(300) NULL,
	price int8 NULL,
	admin_fee int8 NULL,
	lang_code varchar(5) NULL,
	pattern_name varchar(50) NULL,
	terms_name varchar(50) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	category bool NULL,
	vehicle_type varchar(10) NULL DEFAULT 'usedcar'::character varying,
	description varchar(600) NULL,
	CONSTRAINT package_planv2_id_key UNIQUE (id)
);

-- nissan_admin.package_planv2 foreign keys

ALTER TABLE nissan_admin.package_planv2 ADD CONSTRAINT package_planv2_naviid_fkey FOREIGN KEY (navi_id) REFERENCES nissan_admin.naviv2(id);

--Optionsv2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.optionsv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.optionsv2 (
	id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.optionsv2_seq'::regclass),
	navi_id int8 NOT NULL,
	options_name varchar(100) NOT NULL,
	display_name varchar(100) NULL,
	cw_options_name varchar(100) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	vehicle_type varchar(10) NULL DEFAULT 'common'::character varying,
	CONSTRAINT optionsv2_id_key UNIQUE (id),
	CONSTRAINT optionsv2_pkey PRIMARY KEY (options_name, navi_id)
);

-- nissan_admin.optionsv2 foreign keys

ALTER TABLE nissan_admin.optionsv2 ADD CONSTRAINT optionsv2_naviid_fkey FOREIGN KEY (navi_id) REFERENCES nissan_admin.naviv2(id);

--Color

CREATE SEQUENCE IF NOT EXISTS nissan_admin.color_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.color (
	id bigint NOT NULL DEFAULT nextval('nissan_admin.color_id_seq'::regclass),
	color varchar(100) NULL,
	color_code varchar(100) NULL,
	image_url varchar(500) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	model_name varchar(255) NULL,
	sos_color varchar(255) NULL,
	lang_code varchar(5) NULL DEFAULT 'jp'::character varying,
	cw_model_name varchar(255) NULL,
	color_name varchar(255) NULL,
	cw_color varchar(255) NULL,
	sos_display_name varchar(255) NULL,
	sos_display_color varchar(255) NULL,
	CONSTRAINT color_pkey PRIMARY KEY (id)
);

--Admissionv2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.admissionv2_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.admissionv2 (
	id bigint NOT NULL DEFAULT nextval('nissan_admin.admissionv2_id_seq'::regclass),
	user_id int4 NOT NULL,
	dealer_id varchar(100) NULL,
	status varchar(255) NULL,
	email_send_date timestamp NULL,
	vin_registered_date timestamp NULL,
	nc_id varchar(255) NULL,
	nc_password varchar(255) NULL,
	nc_joined_date timestamp NULL,
	lang_code varchar(5) NULL,
	active bool NULL DEFAULT true,
	status_jp varchar(50) NULL,
	upload_kameri bool NULL,
	cw_status varchar(50) NULL,
	nc_id_generated_date date NULL DEFAULT CURRENT_DATE,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	document_name varchar(255) NULL,
	CONSTRAINT admissionv2_pkey PRIMARY KEY (id)
);


-- nissan_admin.admissionv2 foreign keys

ALTER TABLE nissan_admin.admissionv2 ADD CONSTRAINT admissionv2_user_fkey FOREIGN KEY (user_id) REFERENCES nissan_admin."user"(id);
ALTER TABLE nissan_admin.admissionv2 ADD CONSTRAINT fkpdk96a3u6d9sawhtt9rr5gkn2 FOREIGN KEY (dealer_id) REFERENCES nissan_admin.dealer(dealer_id);

--ordersv2 Table

CREATE SEQUENCE IF NOT EXISTS nissan_admin.ordersv2_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.ordersv2 (
	id bigint NOT NULL DEFAULT nextval('nissan_admin.ordersv2_id_seq'::regclass),
	orders_number varchar(255) NULL,
	admissionv2_id int8 NULL,
	modelv2_id int4 NULL,
	gradev2_id int4 NULL,
	naviv2_id int4 NULL,
	planv2_id int4 NULL,
	optionsv2_id int4 NULL,
	payment_method int4 NULL,
	plan_price varchar(50) NULL,
	vehicle_transfer bool NULL,
	vin_number varchar(255) NULL,
	order_number_ps varchar(20) NULL,
	"source" varchar(100) NULL,
	lang_code varchar(5) NULL,
	active bool NULL DEFAULT true,
	color_id int8 NULL,
	cw_navi_id varchar(100) NULL,
	registration_date varchar(100) NULL,
	company_name varchar(100) NULL,
	dealership_name varchar(50) NULL,
	phone_number varchar(13) NULL,
	ca_name varchar(50) NULL,
	ca_name_kana varchar(50) NULL,
	ca_code varchar(50) NULL,
	cw_vin_number varchar(50) NULL,
	model_name_cw varchar(50) NULL,
	adopter_id varchar(255) NULL,
	charge_start_date timestamp NULL,
	first_registered_date timestamp NULL,
	nc_joined_date timestamp NULL,
	nc_status varchar(255) NULL,
	register_number varchar(255) NULL,
	service_update_date timestamp NULL,
	upload_kameri bool NULL,
	color varchar(30) NULL,
	color_code varchar(200) NULL,
	customer_name varchar(100) NULL,
	customer_name_kana varchar(100) NULL,
	customer_phone_number varchar(30) NULL,
	customer_zipcode varchar(30) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	old_vin varchar(50) NULL,
	first_registration_date varchar(255) NULL,
	vehicle_type varchar(255) NULL,
	old_cw_id varchar(255) NULL,
	vin_search_color_code varchar(255) NULL,
	vin_search_status varchar(255) NULL,
	admission_type int4 NULL,
	withdraw_correct_vin varchar(255) NULL,
	vehicle_number varchar(255) NULL,
	expiry_date varchar(255) NULL,
	CONSTRAINT ordersv2_pkey PRIMARY KEY (id)
);


-- nissan_admin.ordersv2 foreign keys

ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT fk324miaqjfqrkxojnjir2xes8k FOREIGN KEY (color_id) REFERENCES nissan_admin.color(id);
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_admissionv2_fkey FOREIGN KEY (admissionv2_id) REFERENCES nissan_admin.admissionv2(id) ON DELETE CASCADE;
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_gradev2_fkey FOREIGN KEY (gradev2_id) REFERENCES nissan_admin.gradev2(id);
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_modelv2_fkey FOREIGN KEY (modelv2_id) REFERENCES nissan_admin.modelv2(id);
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_naviv2_fkey FOREIGN KEY (naviv2_id) REFERENCES nissan_admin.naviv2(id);
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_optionsv2_fkey FOREIGN KEY (optionsv2_id) REFERENCES nissan_admin.optionsv2(id);
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_payment_method_fkey FOREIGN KEY (payment_method) REFERENCES nissan_admin.payment_method(id);
ALTER TABLE nissan_admin.ordersv2 ADD CONSTRAINT ordersv2_planv2_fkey FOREIGN KEY (planv2_id) REFERENCES nissan_admin.package_planv2(id);

-- Commentv2

CREATE SEQUENCE IF NOT EXISTS nissan_admin.commentv2_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.commentv2 (
	id bigint NOT NULL DEFAULT nextval('nissan_admin.commentv2_id_seq'::regclass),
	reason_id int8 NULL,
	ordersv2_id int8 NULL,
	"comment" varchar(255) NULL,
	lang_code varchar(5) NULL,
	active bool NULL DEFAULT true,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT commentv2_pkey PRIMARY KEY (id)
);

-- nissan_admin.commentv2 foreign keys

ALTER TABLE nissan_admin.commentv2 ADD CONSTRAINT commentv2_ordersv2_id_fkey FOREIGN KEY (ordersv2_id) REFERENCES nissan_admin.ordersv2(id) ON DELETE CASCADE;
ALTER TABLE nissan_admin.commentv2 ADD CONSTRAINT commentv2_reasonid_fkey FOREIGN KEY (reason_id) REFERENCES nissan_admin.reason(id);

--Activitylogv2

CREATE TABLE nissan_admin.activity_logv2 (
	id bigserial NOT NULL,
	message varchar(100) NULL,
	"type" varchar(100) NULL,
	"time" timestamp NULL,
	admission_id int4 NULL,
	message_jp varchar(100) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT activity_logv2_pkey PRIMARY KEY (id)
);


-- nissan_admin.activity_logv2 foreign keys

ALTER TABLE nissan_admin.activity_logv2 ADD CONSTRAINT admission_al_fk FOREIGN KEY (admission_id) REFERENCES nissan_admin.admissionv2(id);

--Bank Details

CREATE TABLE nissan_admin.bank_details (
	id bigserial NOT NULL,
	bank_code bigserial NOT NULL,
	bank_name varchar(100) NULL,
	branch_shop_code bigserial NOT NULL,
	branch_shop_name varchar(100) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT bank_details_pkey PRIMARY KEY (id)
);

--V1610602434__create_navi_reference.sql

CREATE SEQUENCE IF NOT EXISTS nissan_admin.navi_reference_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.navi_reference (
	id bigint NOT NULL DEFAULT nextval('nissan_admin.navi_reference_seq'::regclass),
	adaptor_kind varchar(10) NULL,
	dop_flag varchar(10) NULL,
	CONSTRAINT navi_reference_pkey PRIMARY KEY (id)
);

-- NICOS payment table

CREATE SEQUENCE IF NOT EXISTS nissan_admin.nicos_payment_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;
	
CREATE TABLE nissan_admin.nicos_payment (
	id bigint NOT NULL DEFAULT nextval('nissan_admin.nicos_payment_seq'::regclass),
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	account_holder_katakana varchar(255) NULL,
	account_id varchar(255) NULL,
	account_name varchar(255) NULL,
	account_number varchar(255) NULL,
	account_type varchar(255) NULL,
	bank_code varchar(255) NULL,
	bank_name varchar(255) NULL,
	branch_shop_code varchar(255) NULL,
	branch_shop_name varchar(255) NULL,
	company_code varchar(255) NULL,
	deposit_item varchar(255) NULL,
	customer_id int8 NOT NULL,
	customer_number varchar(255) NULL,
	handling_number varchar(255) NULL,
	result_code int4 NULL,
	status int4 NULL,
	payment_status varchar(255) NULL,
	"version" varchar(255) NULL,
	CONSTRAINT nicos_payment_pkey PRIMARY KEY (id)
);

-- nissan_admin.nicos_payment foreign keys

ALTER TABLE nissan_admin.nicos_payment ADD CONSTRAINT admission_customer_fk FOREIGN KEY (customer_id) REFERENCES nissan_admin.customer(id);

--Phase 1 changes

--V1608544731__alter_dealer_add_dealershipcode.sql

ALTER TABLE nissan_admin.dealer ADD COLUMN dealership_code character varying(25);


--V1608553186__alter_table_tempodotnet_add_props.sql

ALTER TABLE nissan_admin.tempo_net ADD COLUMN dealer_company_phone_number character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN jisseki_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN kanban_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN compass_dealership_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN profit_dealership_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN compass_dealer_company_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN profit_dealer_company_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN profit_dealer_company_code_block_code character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN dealer_company_name character varying(50);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN dealership_name character varying(50);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN regular_closing_day_1 character varying(50);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN regular_closing_day_2 character varying(50);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN new_vehicle_flag character varying(30);
ALTER TABLE nissan_admin.tempo_net ADD COLUMN used_vehicle_flag character varying(30);