ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS vin_search_status character varying(10);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS vin_search_color_code character varying(200);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS old_cw_id character varying(30);