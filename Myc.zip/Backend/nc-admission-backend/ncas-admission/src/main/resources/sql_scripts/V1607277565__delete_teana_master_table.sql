<!-- Delete Teana -->

ALTER TABLE nissan_admin.model ADD COLUMN active boolean DEFAULT true;
UPDATE nissan_admin.model SET active=true;
UPDATE nissan_admin.model SET active=false WHERE model_name IN ('TEANA', 'ティアナ');