<!-- MODEL-->

INSERT INTO nissan_admin.model(model_name, display_name, lang_code, url, category)
VALUES	('Note', 'NOTE (December 2020 ~)', 'en', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE+(November+2020+~)/Note.png', 'IVI'),
        ('ノート', 'ノート（2020年12月～）', 'jp', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE+(November+2020+~)/Note.png', 'IVI');

<!-- GRADE-->

INSERT INTO nissan_admin.grade(model_name, grade_name, display_name, lang_code)
	VALUES 	('Note', 'X', 'X', 'en'),
	        ('ノート', 'X', 'X', 'jp'),
			('Note', 'F/S', 'F/S', 'en'),
	        ('ノート', 'F/S', 'F/S', 'jp');
			
<!-- NAVI-->
			
INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'd-op', 'DOP(NOT APPLICABLE / NO NAVI TYPE)', 'en' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='Note' AND g.lang_code='en' and grade_name='X');


INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'd-op', 'ディーラーオプション（お申込み不可）', 'jp' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND g.model_name='ノート' and grade_name='X');

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'MOP', 'en' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='Note' AND g.lang_code='en' and grade_name='X');

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'メーカーオプション', 'jp' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND g.model_name='ノート' and grade_name='X');
	
INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'd-op', 'NOT APPLICABLE / NO NAVI TYPE', 'en' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='Note' AND g.lang_code='en' and grade_name='F/S');


INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'd-op', 'お申込み不可', 'jp' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND g.model_name='ノート' and grade_name='F/S');
	
<!-- PACKAGE PLAN-->	
INSERT INTO nissan_admin.package_plan (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) SELECT id, 'standard+', 'Standard plan +', 7920, 'en', 'pattern-three', 'pattern-one' FROM nissan_admin.navi n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='Note' AND g.lang_code='en');
	 
	 
INSERT INTO nissan_admin.package_plan (navi_id, package_plan_name, display_name, price, lang_code,pattern_name, terms_name) SELECT id, 'standard+', 'スタンダードプラン＋', 7920, 'jp', 'pattern-three','pattern-one' FROM nissan_admin.navi n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='ノート' AND g.lang_code='jp');


<!-- Add model display order -->
 
UPDATE nissan_admin.model SET model_display_order=3 WHERE model_name IN ('Note','ノート');
UPDATE nissan_admin.model SET model_display_order = model_display_order+1 WHERE model_name NOT IN ('Note','ノート') AND model_display_order>=3

<!-- Terms and Conditions -->

UPDATE nissan_admin.package_plan SET terms_name = 'pattern-one'
