ALTER TABLE nissan_admin.ordersv2
ADD COLUMN IF NOT EXISTS customer_name character varying(100);

ALTER TABLE nissan_admin.ordersv2
ADD COLUMN IF NOT EXISTS customer_name_kana character varying(100);

ALTER TABLE nissan_admin.ordersv2
ADD COLUMN IF NOT EXISTS customer_phone_number character varying(30);

ALTER TABLE nissan_admin.ordersv2
ADD COLUMN IF NOT EXISTS customer_zipcode character varying(30);