ALTER TABLE nissan_admin.package_planv2 DROP COLUMN IF EXISTS description;
ALTER TABLE nissan_admin.package_planv2 ADD COLUMN IF NOT EXISTS description character varying(600);

--DAYZ description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='basic-sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the vehicle initial registration date) (SOS call service usage period: 10 years from vehicle initial registration)' where package_plan_name='basic-sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));


--Roox description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='S' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='S' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='basic-sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the vehicle initial registration date) (SOS call service usage period: 10 years from vehicle initial registration)' where package_plan_name='basic-sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));


--Kicks description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='basic-sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the vehicle initial registration date) (SOS call service usage period: 10 years from vehicle initial registration)' where package_plan_name='basic-sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));


--X-Trail description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エクストレイル' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='X-Trail' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エクストレイル' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='X-Trail' and lang_code='en')));


--Elgrand description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エルグランド' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Elgrand' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エルグランド' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Elgrand' and lang_code='en')));


--TEANA description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XV Navi AVM Package / XL Navi AVM Package' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XL' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XL' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));


--Fuga description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='フーガ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Fuga' and lang_code='en')));


--Cima description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='シーマ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Cima' and lang_code='en')));


--Others description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='その他' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Others' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='その他' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Others' and lang_code='en')));