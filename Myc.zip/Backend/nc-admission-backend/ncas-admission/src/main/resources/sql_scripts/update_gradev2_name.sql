UPDATE nissan_admin.gradev2
SET grade_name='NOGRADE'
WHERE grade_name='All Grades';