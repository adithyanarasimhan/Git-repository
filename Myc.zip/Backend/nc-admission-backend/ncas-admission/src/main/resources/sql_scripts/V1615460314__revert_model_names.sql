UPDATE nissan_admin.modelv2 set model_name='スカイライン（2019年9月～）', display_name='スカイライン（2019年9月～）' WHERE model_name='スカイライン（2019年9月発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Skyline (From September 2019)', display_name='Skyline (From September 2019)' WHERE model_name='Skyline (released in September 2019)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年2月～）', display_name='リーフ（2020年2月～）' WHERE model_name='リーフ（2020年2月発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (from February 2020)', display_name='Leaf (from February 2020)' WHERE model_name='Leaf (released in February 2020)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年1月以前）', display_name='リーフ（2020年1月以前）' WHERE model_name='リーフ（2020年1月以前発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (before January 2020)', display_name='Leaf (before January 2020)' WHERE model_name='Leaf (released before January 2020)' AND lang_code='en';




UPDATE nissan_admin.model set model_name='スカイライン（2019年9月～）', display_name='スカイライン（2019年9月～）' WHERE model_name='スカイライン（2019年9月発売）' AND lang_code='jp';

UPDATE nissan_admin.model set model_name='SKYLINE (September 2019 ~)', display_name='SKYLINE (September 2019 ~)' WHERE model_name='Skyline (released in September 2019)' AND lang_code='en';

UPDATE nissan_admin.model set model_name='リーフ（2020年2月～）', display_name='リーフ（2020年2月～）' WHERE model_name='リーフ（2020年2月発売）' AND lang_code='jp';

UPDATE nissan_admin.model set model_name='LEAF (January 2020 ~)', display_name='LEAF (January 2020 ~)' WHERE model_name='Leaf (released in February 2020)' AND lang_code='en';