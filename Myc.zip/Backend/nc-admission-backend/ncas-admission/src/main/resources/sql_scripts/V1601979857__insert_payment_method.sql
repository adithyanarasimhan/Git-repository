INSERT INTO nissan_admin.payment_method(name, display_name, lang_code, type) VALUES
('digital', 'Digital', 'en', 'digital'),
('paper', 'Paper', 'en', 'direct-debit'),
('digital', 'デジタル', 'jp', 'digital'),
('paper', '紙', 'jp', 'direct-debit');