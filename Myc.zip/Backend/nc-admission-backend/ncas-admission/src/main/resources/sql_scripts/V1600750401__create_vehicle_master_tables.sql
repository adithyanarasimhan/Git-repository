CREATE SEQUENCE IF NOT EXISTS nissan_admin.modelv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE IF NOT EXISTS nissan_admin.modelv2 (
    id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.modelv2_seq'::regclass),
    model_name character varying(100) COLLATE pg_catalog."default",
    display_name character varying(100) COLLATE pg_catalog."default",
	cw_model_name character varying(100) COLLATE pg_catalog."default",
	lang_code character varying(5) COLLATE pg_catalog."default",
    url character varying(500) COLLATE pg_catalog."default",
    category character varying(50) COLLATE pg_catalog."default",
	model_display_order smallint,
	CONSTRAINT modelv2_pkey PRIMARY KEY (id)
);


CREATE SEQUENCE IF NOT EXISTS nissan_admin.gradev2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;


CREATE TABLE IF NOT EXISTS nissan_admin.gradev2 (
        id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.gradev2_seq'::regclass),
		model_id bigint,
		grade_name character varying(300) COLLATE pg_catalog."default",
		display_name character varying(300) COLLATE pg_catalog."default",
		cw_grade_name character varying(300) COLLATE pg_catalog."default",
		lang_code character varying(5) COLLATE pg_catalog."default",
		CONSTRAINT gradev2_model_fkey FOREIGN KEY (model_id)
                    REFERENCES nissan_admin.modelv2 (id) MATCH SIMPLE
                    ON UPDATE NO ACTION
                    ON DELETE NO ACTION,
		CONSTRAINT gradev2_pkey PRIMARY KEY (grade_name, model_id)
);

CREATE SEQUENCE IF NOT EXISTS nissan_admin.naviv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.naviv2
(
    id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.naviv2_seq'::regclass),
    grade_id bigint,
    navi_name character varying(300) COLLATE pg_catalog."default",
    display_name character varying(300) COLLATE pg_catalog."default",
	cw_navi_name character varying(300) COLLATE pg_catalog."default",
    lang_code character varying(5) COLLATE pg_catalog."default",
	CONSTRAINT naviv2_gradeid_fkey FOREIGN KEY (grade_id)
                            REFERENCES nissan_admin.gradev2 (id) MATCH SIMPLE
                            ON UPDATE NO ACTION
                            ON DELETE NO ACTION,
	CONSTRAINT naviv2_pkey PRIMARY KEY (navi_name, grade_id)
);

CREATE SEQUENCE IF NOT EXISTS nissan_admin.package_planv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.package_planv2
(
    id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.package_planv2_seq'::regclass),
	navi_id bigint,
    package_plan_name character varying(300) COLLATE pg_catalog."default",
    display_name character varying(300) COLLATE pg_catalog."default",
	cw_package_plan_name character varying(300) COLLATE pg_catalog."default",
	description character varying(500) COLLATE pg_catalog."default",
    price bigint,
	admin_fee bigint,
    lang_code character varying(5) COLLATE pg_catalog."default",
    pattern_name character varying(50) COLLATE pg_catalog."default",
    terms_name character varying(50) COLLATE pg_catalog."default",
	CONSTRAINT package_planv2_naviid_fkey FOREIGN KEY (navi_id)
								REFERENCES nissan_admin.naviv2 (id) MATCH SIMPLE
								ON UPDATE NO ACTION
								ON DELETE NO ACTION,
	CONSTRAINT package_planv2_pkey PRIMARY KEY (package_plan_name, navi_id)
);


CREATE SEQUENCE IF NOT EXISTS nissan_admin.optionsv2_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.optionsv2
(
    id bigint NOT NULL UNIQUE DEFAULT nextval('nissan_admin.optionsv2_seq'::regclass),
    navi_id bigint,
    options_name character varying(100) COLLATE pg_catalog."default",
    display_name character varying(100) COLLATE pg_catalog."default",
	cw_options_name character varying(100) COLLATE pg_catalog."default",
    lang_code character varying(5) COLLATE pg_catalog."default",
    CONSTRAINT optionsv2_naviid_fkey FOREIGN KEY (navi_id)
                                        REFERENCES nissan_admin.naviv2 (id) MATCH SIMPLE
                                        ON UPDATE NO ACTION
                                        ON DELETE NO ACTION,
	CONSTRAINT optionsv2_pkey PRIMARY KEY (options_name,navi_id)
);