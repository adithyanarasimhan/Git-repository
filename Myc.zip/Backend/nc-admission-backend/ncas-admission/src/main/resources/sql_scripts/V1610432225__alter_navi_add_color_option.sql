ALTER TABLE nissan_admin.modelv2 DROP COLUMN IF EXISTS color_option;

ALTER TABLE nissan_admin.naviv2 ADD COLUMN IF NOT EXISTS color_option boolean default false;

UPDATE nissan_admin.naviv2 n set color_option=true WHERE n.navi_name!='na' AND (n.navi_name='s-os' OR n.navi_name='d-op+s-os' OR n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.model_id IN (SELECT id FROM nissan_admin.modelv2 m WHERE m.category=true)));