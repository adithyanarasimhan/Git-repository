update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE+(September+2019+~)/image.png' where model_name='Skyline (From September 2019)' or model_name='スカイライン（2019年9月～）';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF+(January+2020+~)/image.png' where model_name='Leaf (from February 2020)' or model_name='リーフ（2020年2月～）';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF+(January+2020+~)/image.png' where model_name='Leaf (before January 2020)' or model_name='リーフ（2020年1月以前）';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/image.png' where model_name='X-Trail' or model_name='エクストレイル';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/Kicks/20_P02F_chart_EXT_X_2tone_layer.jpg' where model_name='Kicks' or model_name='キックス';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/image.png' where model_name='Dayz' or model_name='デイズ';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/image.png' where model_name='Roox' or model_name='ルークス';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/image.png' where model_name='Elgrand' or model_name='エルグランド';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/image.png' where model_name='TEANA' or model_name='ティアナ';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/image.png' where model_name='Fuga' or model_name='フーガ';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/CIMA/image.png' where model_name='Cima' or model_name='シーマ';