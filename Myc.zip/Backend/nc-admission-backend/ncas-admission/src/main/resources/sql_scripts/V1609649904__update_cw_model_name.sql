UPDATE nissan_admin.modelv2 set cw_model_name='リーフ' WHERE cw_model_name='リーフ（2020年2月～）' OR cw_model_name='リーフ（2020年1月以前）';

UPDATE nissan_admin.modelv2 set cw_model_name='スカイライン' WHERE cw_model_name='スカイライン（2019年9月～）';