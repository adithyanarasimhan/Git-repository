

-- vehicle_master_data

--Skyline (From September 2019)
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Skyline (From September 2019)', 'Skyline (From September 2019)', 'スカイライン（2019年9月～）', 'en', null),
('スカイライン（2019年9月～）', 'スカイライン（2019年9月～）', 'スカイライン（2019年9月～）', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND lang_code='en'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND lang_code='en'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND lang_code='jp'));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='en'));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='jp'));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='en'));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='jp'));

--Leaf (from February 2020)
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Leaf (from February 2020)', 'Leaf (from February 2020)', 'リーフ（2020年2月～）', 'en', null),
('リーフ（2020年2月～）', 'リーフ（2020年2月～）', 'リーフ（2020年2月～）', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/Other (other than S)', 'X/G/Other (other than S)', 'X/G/その他(S以外)', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));


--Leaf (before January 2020)
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Leaf (before January 2020)', 'Leaf (before January 2020)', 'リーフ（2020年1月以前）', 'en', null),
('リーフ（2020年1月以前）', 'リーフ（2020年1月以前）', 'リーフ（2020年1月以前）', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/Other (other than S)', 'X/G/Other (other than S)', 'X/G/その他(S以外)', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));


--X-Trail
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('X-Trail', 'X-Trail', 'エクストレイル', 'en', null),
('エクストレイル', 'エクストレイル', 'エクストレイル', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'dop', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'dop', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='dop' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='dop' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));


--Kicks
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Kicks', 'Kicks', 'キックス', 'en', null),
('キックス', 'キックス', 'キックス', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'SOS', 'ナビなし（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'ナビなし（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'DOP+SOS', 'ディーラーオプション（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン有）', 'ディーラーオプション（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '5500', '2200', 'en', 'pattern-three', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '5500', '2200', 'jp', 'pattern-three', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

--modify_checksheet

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='m-op' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='X-Trail' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='dop' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='エクストレイル' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-four' where plan.package_plan_name='basic-sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-four' where plan.package_plan_name='basic-sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.package_plan_name='basic' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.package_plan_name='basic' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

--V1601464911__update_dop_navi_name.sql

update nissan_admin.naviv2 set navi_name='d-op' where navi_name='dop';

--V1601979999__insert_vehicle_data.sql

--Dayz
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Dayz', 'Dayz', 'デイズ', 'en', null),
('デイズ', 'デイズ', 'デイズ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'DOP+SOS', 'ディーラーオプション（SOSコールボタン無）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン無）', 'ディーラーオプション（SOSコールボタン無）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '5500', '2200', 'en', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '5500', '2200', 'jp', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));


--Roox
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Roox', 'Roox', 'ルークス', 'en', null),
('ルークス', 'ルークス', 'ルークス', 'jp', null);


INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/Other (other than S)', 'X/G/Other (other than S)', 'X/G/その他(S以外)', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'DOP+SOS', 'ディーラーオプション（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン有）', 'ディーラーオプション（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'SOS', 'ナビなし（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'ナビなし（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '5500', '2200', 'en', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '5500', '2200', 'jp', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));


--Elgrand
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Elgrand', 'Elgrand', 'エルグランド', 'en', null),
('エルグランド', 'エルグランド', 'エルグランド', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));


--TEANA
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('TEANA', 'TEANA', 'ティアナ', 'en', null),
('ティアナ', 'ティアナ', 'ティアナ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XV Navi AVM Package / XL Navi AVM Package', 'XV Navi AVM Package / XL Navi AVM Package', 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XE', 'XE', 'XE', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XE', 'XE', 'XE', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XL', 'XL', 'XL', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XL', 'XL', 'XL', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp'));



INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));


--Fuga
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Fuga', 'Fuga', 'フーガ', 'en', null),
('フーガ', 'フーガ', 'フーガ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));


--Cima
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Cima', 'Cima', 'シーマ', 'en', null),
('シーマ', 'シーマ', 'シーマ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));


--Ariya
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Ariya', 'Ariya', 'アリア', 'en', null),
('アリア', 'アリア', 'アリア', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L4', 'L4', 'L4', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L4', 'L4', 'L4', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L3', 'L3', 'L3', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L3', 'L3', 'L3', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '2200', 'en', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '2200', 'jp', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '2200', 'en', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '2200', 'jp', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));


--V1601980180__update_navi_name.sql

update nissan_admin.naviv2 set navi_name='d-op' where navi_name='dop';

--V1601980239__update_model_image.sql

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE+(September+2019+~)/image.png' where model_name='Skyline (From September 2019)' or model_name='スカイライン（2019年9月～）';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF+(January+2020+~)/image.png' where model_name='Leaf (from February 2020)' or model_name='リーフ（2020年2月～）';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF+(January+2020+~)/image.png' where model_name='Leaf (before January 2020)' or model_name='リーフ（2020年1月以前）';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/image.png' where model_name='X-Trail' or model_name='エクストレイル';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/Kicks/20_P02F_chart_EXT_X_2tone_layer.jpg' where model_name='Kicks' or model_name='キックス';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/image.png' where model_name='Dayz' or model_name='デイズ';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/image.png' where model_name='Roox' or model_name='ルークス';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/image.png' where model_name='Elgrand' or model_name='エルグランド';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/image.png' where model_name='TEANA' or model_name='ティアナ';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/image.png' where model_name='Fuga' or model_name='フーガ';

update nissan_admin.modelv2 set url='https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/CIMA/image.png' where model_name='Cima' or model_name='シーマ';


--V1602651438__insert_others_model.sql

INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Others', 'Others', 'その他', 'en', null),
('その他', 'その他', 'その他', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='na' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='na' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

--Insert Color TABLE
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(1, NULL, 'G01_GAC.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/CIMA/G01_GAC.png', NULL, NULL, NULL, NULL, 'シーマ', '', 'jp', NULL, 'ガーネットブラック（P）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(2, NULL, 'G64_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/G64_QAB.png', NULL, NULL, NULL, NULL, 'エルグランド', '', 'jp', NULL, 'ブリリアントホワイトパール（3P）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(3, NULL, 'G10_CAN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/G10_CAN.png', NULL, NULL, NULL, NULL, 'フーガ', '', 'jp', NULL, 'プレミアムブラウン（M） ', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(4, NULL, 'G07_GAP.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_GAP.png', NULL, NULL, NULL, NULL, 'リーフ（2020年1月以前）', '', 'jp', NULL, 'プレミアムホライズンオレンジ（PM）/スーパーブラック 2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(5, NULL, 'G01_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/G01_QAB.png', NULL, NULL, NULL, NULL, 'ティアナ', '', 'jp', NULL, 'ブリリアントホワイトパール（3P）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(6, NULL, 'G87_RAW(4WD).png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G87_RAW(4WD).png', NULL, NULL, NULL, NULL, 'エクストレイル', '', 'jp', NULL, 'シャイニングブルー（PM）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(7, NULL, 'G04_EBT.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_EBT.png', NULL, NULL, NULL, NULL, 'デイズ', '橙', 'jp', NULL, 'プレミアムサンシャインオレンジ（M）', 'EBT', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(8, NULL, 'G04_GAS.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_GAS.png', NULL, NULL, NULL, NULL, 'デイズ', '黒', 'jp', NULL, 'ブラック（P）', 'GAS', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(9, NULL, 'G04_KBW.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_KBW.png', NULL, NULL, NULL, NULL, 'デイズ', '炭', 'jp', NULL, 'チタニウムグレー（M）', 'KBW', '炭', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(10, NULL, 'G04_LAL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_LAL.png', NULL, NULL, NULL, NULL, 'デイズ', '紫', 'jp', NULL, 'アメジストパープル（P）', 'LAL', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(11, NULL, 'G04_NBR.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_NBR.png', NULL, NULL, NULL, NULL, 'デイズ', '赤', 'jp', NULL, 'スパークリングレッド（PM）', 'NBR', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(12, NULL, 'G04_QBB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_QBB.png', NULL, NULL, NULL, NULL, 'デイズ', '白', 'jp', NULL, 'ホワイトパール（3P） ', 'QBB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(13, NULL, 'G04_RCH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_RCH.png', NULL, NULL, NULL, NULL, 'デイズ', '青', 'jp', NULL, 'アトランティックブルー（PM）', 'RCH', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(14, NULL, 'G04_XCF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCF.png', NULL, NULL, NULL, NULL, 'デイズ', '赤黒', 'jp', NULL, 'スパークリングレッド（PM）/ブラック（P）2トーン', 'XCF', '赤黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(15, NULL, 'G04_XCH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCH.png', NULL, NULL, NULL, NULL, 'デイズ', '茶水色', 'jp', NULL, 'ソーダブルー（M）/アッシュブラウン（M）2トーン', 'XCH', '茶水色', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(16, NULL, 'G04_XCK.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCK.png', NULL, NULL, NULL, NULL, 'デイズ', '白茶', 'jp', NULL, 'アッシュブラウン（M）/フローズンバニラパール（M）2トーン', 'XCK', '白茶', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(17, NULL, 'G04_XDT.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XDT.png', NULL, NULL, NULL, NULL, 'デイズ', '橙白', 'jp', NULL, 'ホワイトパール（3P）/プレミアムサンシャインオレンジ（M）2トーン', 'XDT', '橙白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(18, NULL, 'G04_XFS.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XFS.png', NULL, NULL, NULL, NULL, 'デイズ', '灰', 'jp', NULL, 'チタニウムグレー（M）/ブラック（P）2トーン', 'XFS', '灰', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(19, NULL, 'G02_EAN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAN.png', NULL, NULL, NULL, NULL, 'キックス', '緑', 'jp', NULL, 'チタニウムカーキ（PM）', 'EAN', '緑', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(20, NULL, 'G02_EAV.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAV.png', NULL, NULL, NULL, NULL, 'キックス', '黄', 'jp', NULL, 'サンライトイエロー（P）', 'EAV', '黄', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(21, NULL, 'G02_EBB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EBB.png', NULL, NULL, NULL, NULL, 'キックス', '橙', 'jp', NULL, 'プレミアムホライズンオレンジ（PM） ', 'EBB', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(22, NULL, 'G02_G42.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_G42.png', NULL, NULL, NULL, NULL, 'キックス', '黒', 'jp', NULL, 'ピュアブラック（PM）', 'G42', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(23, NULL, 'G02_GAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_GAB.png', NULL, NULL, NULL, NULL, 'キックス', '黒', 'jp', NULL, 'ナイトベールパープル（TP）', 'GAB', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(24, NULL, 'G02_K23.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_K23.png', NULL, NULL, NULL, NULL, 'キックス', '銀', 'jp', NULL, 'ブリリアントシルバー（M）', 'K23', '銀', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(25, NULL, 'G02_NAH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_NAH.png', NULL, NULL, NULL, NULL, 'キックス', '赤', 'jp', NULL, 'ラディアントレッド（P）', 'NAH', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(26, NULL, 'G02_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_QAB.png', NULL, NULL, NULL, NULL, 'キックス', '白', 'jp', NULL, 'ブリリアントホワイトパール（3PM） ', 'QAB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(27, NULL, 'G02_RAA.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_RAA.png', NULL, NULL, NULL, NULL, 'キックス', '青', 'jp', NULL, 'ダークブルー（PM）', 'RAA', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(28, NULL, 'G02_XDN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XDN.png', NULL, NULL, NULL, NULL, 'キックス', '白黒', 'jp', NULL, 'ブリリアントホワイトパール（3PM）/ピュアブラック（PM） 2トーン', 'XDN', '白黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(29, NULL, 'G02_XFP.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFP.png', NULL, NULL, NULL, NULL, 'キックス', '橙', 'jp', NULL, 'プレミアムホライズンオレンジ（PM）/ピュアブラック（PM）2トーン', 'XFP', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(30, NULL, 'G02_XFY.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFY.png', NULL, NULL, NULL, NULL, 'キックス', '赤黒', 'jp', NULL, 'ラディアントレッド（P）/ピュアブラック（PM）2トーン', 'XFY', '赤黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(31, NULL, 'G02_XFZ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFZ.png', NULL, NULL, NULL, NULL, 'キックス', '炭黒', 'jp', NULL, 'ダークメタルグレー（M）/ピュアブラック（PM）2トーン', 'XFZ', '炭黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(32, NULL, 'G05_CBA.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_CBA.png', NULL, NULL, NULL, NULL, 'ルークス', '茶', 'jp', NULL, 'アッシュブラウン（M）', 'CBA', '茶', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(33, NULL, 'G05_GAS.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_GAS.png', NULL, NULL, NULL, NULL, 'ルークス', '黒', 'jp', NULL, 'ブラック（P）', 'GAS', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(34, NULL, 'G05_HAK.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_HAK.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'jp', NULL, 'フローズンバニラパール（M）', 'HAK', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(35, NULL, 'G05_KBW.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_KBW.png', NULL, NULL, NULL, NULL, 'ルークス', '炭', 'jp', NULL, 'チタニウムグレー（M）', 'KBW', '炭', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(36, NULL, 'G05_LAL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_LAL.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'jp', NULL, 'アメジストパープル（PM）', 'LAL', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(37, NULL, 'G05_NBR.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_NBR.png', NULL, NULL, NULL, NULL, 'ルークス', '赤', 'jp', NULL, 'スパークリングレッド（PM）', 'NBR', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(38, NULL, 'G05_QBB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_QBB.png', NULL, NULL, NULL, NULL, 'ルークス', '白', 'jp', NULL, 'ホワイトパール（3P） ', 'QBB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(39, NULL, 'G05_RCH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_RCH.png', NULL, NULL, NULL, NULL, 'ルークス', '青', 'jp', NULL, 'アトランティックブルー（PM）', 'RCH', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(40, NULL, 'G05_XCF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XCF.png', NULL, NULL, NULL, NULL, 'ルークス', '赤黒', 'jp', NULL, 'スパークリングレッド（PM）/ブラック（P）2トーン ', 'XCF', '赤黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(41, NULL, 'G05_XEL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEL.png', NULL, NULL, NULL, NULL, 'ルークス', '白', 'jp', NULL, 'ホワイトパール（3P）/チタニウムグレー（M）2トーン ', 'XEL', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(42, NULL, 'G05_XEM.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEM.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'jp', NULL, 'アメジストパープル（PM）/フローズンバニラパール（M）2トーン', 'XEM', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(43, NULL, 'G07_GAP.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_GAP.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'プレミアムホライズンオレンジ（PM）/スーパーブラック 2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(44, NULL, 'G07_K23.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_K23.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ブリリアントシルバー（Ｍ）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(45, NULL, 'G07_KAD.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KAD.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ダークメタルグレー（Ｍ）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(46, NULL, 'G07_KH3.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KH3.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'スーパーブラック', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(47, NULL, 'G07_NBF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_NBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ガーネットレッド（ＣＰ）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(48, NULL, 'G07_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_QAB.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ブリリアントホワイトパール（３Ｐ）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(49, NULL, 'G07_RAY.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_RAY.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'オーロラフレアブルーパール（Ｐ）', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(50, NULL, 'G07_XAE.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XAE.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'スーパーブラック/ダークメタルグレー（M） 2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(51, NULL, 'G07_XBJ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBJ.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ブリリアントホワイトパール（３Ｐ） / スーパーブラック　2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(52, NULL, 'G07_XBK.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBK.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ブリリアントホワイトパール（3P）/オーロラフレアブルーパール（P） 2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(53, NULL, 'G07_XBL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBL.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'サンライトイエロー（Ｐ） / スーパーブラック　2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(54, NULL, 'G07_XBT.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBT.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ガーネットレッド（ＣＰ） / スーパーブラック　2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(55, NULL, 'G07_XEH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEH.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ビビッドブルー（M）/スーパーブラック 2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(56, NULL, 'G07_XEX.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEX.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ステルスグレー（P）/スーパーブラック 2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(57, NULL, 'G05_GAQ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_GAQ.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ダークメタルグレー（Ｍ） / スーパーブラック　2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(58, NULL, 'G05_XBF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_XBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'ブリリアントシルバー（Ｍ） / スーパーブラック　2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(59, NULL, 'G09_XGN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G09_XGN.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL, 'オーロラフレアブルーパール（Ｐ） / スーパーブラック　2トーン', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(60, NULL, 'G19_GAG.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_GAG.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '黒', 'jp', NULL, 'メテオフレークブラックパール（Ｐ）', 'GAG', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(61, NULL, 'G19_KAD.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KAD.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', 'グレー', 'jp', NULL, 'ダークメタルグレー（Ｍ）', 'KAD', 'グレー', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(62, NULL, 'G19_KH3.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KH3.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '黒', 'jp', NULL, 'スーパーブラック　', 'KH3', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(63, NULL, 'G19_NBA.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_NBA.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '赤', 'jp', NULL, 'カーマインレッド（ＣＭ）', 'NBA', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(64, NULL, 'G19_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_QAB.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '白', 'jp', NULL, 'ブリリアントホワイトパール（３Ｐ）', 'QAB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(65, NULL, 'G19_RCJ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_RCJ.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '青', 'jp', NULL, 'ディープオーシャンブルー（Ｐ）', 'RCJ', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(66, NULL, 'G28_KBZ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G28_KBZ.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '灰', 'jp', NULL, 'スレートグレー（ＰＭ）', 'KBZ', '灰', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(159, NULL, 'ea_gat.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/ea_gat.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '黒', 'en', NULL, 'Midnight Black (P) 【AUTECH exclusive color】', 'GAT', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(160, NULL, 'ea_xab.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/ea_xab.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '白', 'en', NULL, 'Pure white pearl (3P) / Super black 2 tone 【AUTECH exclusive color】', 'XAB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(161, NULL, 'ea_xgn.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/ea_xgn.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '青', 'en', NULL, 'Aurora Flare Blue Pearl (P) / Super Black 2 Tone【AUTECH Exclusive Color】', 'XGN', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(162, NULL, 'ea_gat.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/ea_gat.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '黒', 'jp', NULL, 'ミッドナイトブラック（P） 【AUTECH専用色】', 'GAT', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(163, NULL, 'ea_xab.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/ea_xab.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '白', 'jp', NULL, 'ピュアホワイトパール（3P） / スーパーブラック　２トーン 【AUTECH専用色】', 'XAB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(164, NULL, 'ea_xgn.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/ea_xgn.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '青', 'jp', NULL, 'オーロラフレアブルーパール（P） / スーパーブラック　２トーン 【AUTECH専用色】', 'XGN', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(67, NULL, '20_B13B_A_BC_ホワイト.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_QAY.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '白', 'jp', NULL, 'ホワイト', 'QAY', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(68, NULL, '20_B13B_A_BC_スーパーブラック.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_KH3.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '黒', 'jp', NULL, 'スーパーブラック', 'KH3', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(74, NULL, '20_B13B_A_BC_バーガンディー.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_EBB.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '紫', 'jp', NULL, 'バーガンディー（ＰＭ）', 'NBQ', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(71, NULL, '20_B13B_A_BC_ダークメタルグレー.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_KAD.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '灰', 'jp', NULL, 'ダークメタルグレー（Ｍ）', 'KAD', '灰', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(77, NULL, '20_B13B_A_BC_オリーブグリーン.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_EBA.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '緑', 'jp', NULL, 'オリーブグリーン（ＴＭ）', 'EBA', '緑', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(72, NULL, '20_B13B_A_BC_ガーネットレッド.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_NBF.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '赤', 'jp', NULL, 'ガーネットレッド（ＣＰ）', 'NBF', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(73, NULL, '20_B13B_A_BC_オーロラフレアブルーパール.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_RAY.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '青', 'jp', NULL, 'オーロラフレアブルーパール（Ｐ）', 'RAY', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(153, NULL, '20_B13B_A_BC_バーガンディー.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_EBB.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '紫', 'en', NULL, ' Burgundy (PM)', 'NBQ', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(76, NULL, '20_B13B_A_BC_プレミアムホライズンオレンジ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_EBB.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '橙', 'jp', NULL, 'プレミアムホライズンオレンジ（ＰＭ）', 'EBB', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(79, NULL, '20_B13B_A_BC_オペラモーブ_ スーパーブラック.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_XGQ.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '桃', 'jp', NULL, 'オペラモーブ（Ｍ） / スーパーブラック　２トーン', 'XGQ', '桃', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(158, NULL, '20_B13B_A_BC_オペラモーブ_ スーパーブラック.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_XGQ.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '桃', 'en', NULL, ' operamauve (M)/ Super Black 2 Tone', 'XGQ', '桃', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(155, NULL, '20_B13B_A_BC_プレミアムホライズンオレンジ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_EBB.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '橙', 'en', NULL, ' Premium Horizon Orange (PM)', 'EBB', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(78, NULL, '20_B13B_A_BC_ビビッドブルー_スーパーブラック.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_XEH.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '青', 'jp', NULL, 'ビビッドブルー（Ｍ） / スーパーブラック　２トーン', 'XEH', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(157, NULL, '20_B13B_A_BC_ビビッドブルー_スーパーブラック.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_XEH.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '青', 'en', NULL, ' Vivid Blue (M) / Super Black 2 Tone', 'XEH', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(75, NULL, '20_B13B_A_BC_オペラモーブ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_NBZ.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '桃', 'jp', NULL, 'オペラモーブ（Ｍ）', 'NBZ', '桃', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(154, NULL, '20_B13B_A_BC_オペラモーブ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_NBZ.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '桃', 'en', NULL, ' operamauve (M)', 'NBZ', '桃', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(69, NULL, '20_B13B_A_BC_ピュアホワイトパール.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_QAC.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '白', 'jp', NULL, 'ピュアホワイトパール（３Ｐ）', 'QAC', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(70, NULL, '20_B13B_A_BC_ブリリアントシルバー.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_K23.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '銀', 'jp', NULL, 'ブリリアントシルバー（Ｍ）', 'K23', '銀', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(156, NULL, '20_B13B_A_BC_オリーブグリーン.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_EBA.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '緑', 'en', NULL, ' Olivegreen', 'EBA', '緑', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(165, NULL, 'rbp.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/rbp.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', 'グレー', 'en', NULL, 'HAGANE Blue (M)', 'RBP', 'グレー', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(166, NULL, 'cas.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/cas.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '茶', 'en', NULL, 'Imperial Amber (P)', 'CAS', '茶', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(167, NULL, 'ray.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/ray.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '青', 'en', NULL, 'Aurora flare blue', 'RAY', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(168, NULL, 'k23.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/k23.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '銀', 'en', NULL, 'Brilliant Silver (M)', 'K23', '銀', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(169, NULL, 'nah.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/nah.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '赤', 'en', NULL, 'Radiant Red (PM)', 'NAH', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(170, NULL, 'rbp.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/rbp.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', 'グレー', 'jp', NULL, 'HAGANEブルー (M)', 'RBP', 'グレー', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(171, NULL, 'cas.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/cas.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '茶', 'jp', NULL, 'インペリアルアンバー (P)', 'CAS', '茶', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(172, NULL, 'ray.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/ray.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '青', 'jp', NULL, 'オーロラフレアブルー', 'RAY', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(173, NULL, 'k23.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/k23.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '銀', 'jp', NULL, 'ブリリアントシルバー (M)', 'K23', '銀', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(174, NULL, 'nah.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/nah.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '赤', 'jp', NULL, 'ラディアントレッド（PM）', 'NAH', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(80, NULL, 'G01_GAC.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/CIMA/G01_GAC.png', NULL, NULL, NULL, NULL, 'シーマ', '', 'en', NULL, 'Garnet Black (P)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(81, NULL, 'G64_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/G64_QAB.png', NULL, NULL, NULL, NULL, 'エルグランド', '', 'en', NULL, 'Brilliant White Pearl (3P)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(82, NULL, 'G10_CAN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/G10_CAN.png', NULL, NULL, NULL, NULL, 'フーガ', '', 'en', NULL, 'Premium brown (M)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(83, NULL, 'G07_GAP.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_GAP.png', NULL, NULL, NULL, NULL, 'リーフ（2020年1月以前）', '', 'en', NULL, 'Premium Horizon Orange (PM) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(84, NULL, 'G01_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/G01_QAB.png', NULL, NULL, NULL, NULL, 'ティアナ', '', 'en', NULL, 'Brilliant White Pearl (3P)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(85, NULL, 'G87_RAW(4WD).png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G87_RAW(4WD).png', NULL, NULL, NULL, NULL, 'エクストレイル', '', 'en', NULL, 'Shining Blue (PM)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(86, NULL, 'G04_EBT.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_EBT.png', NULL, NULL, NULL, NULL, 'デイズ', '橙', 'en', NULL, 'Premium Sunshine Orange (M)', 'EBT', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(87, NULL, 'G04_GAS.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_GAS.png', NULL, NULL, NULL, NULL, 'デイズ', '黒', 'en', NULL, 'Black (P)', 'GAS', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(88, NULL, 'G04_KBW.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_KBW.png', NULL, NULL, NULL, NULL, 'デイズ', '炭', 'en', NULL, 'Titanium Gray (M)', 'KBW', '炭', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(89, NULL, 'G04_LAL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_LAL.png', NULL, NULL, NULL, NULL, 'デイズ', '紫', 'en', NULL, 'Amethyst Purple (P)', 'LAL', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(90, NULL, 'G04_NBR.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_NBR.png', NULL, NULL, NULL, NULL, 'デイズ', '赤', 'en', NULL, 'Sparkling red (PM)', 'NBR', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(91, NULL, 'G04_QBB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_QBB.png', NULL, NULL, NULL, NULL, 'デイズ', '白', 'en', NULL, 'White pearl (3P)', 'QBB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(92, NULL, 'G04_RCH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_RCH.png', NULL, NULL, NULL, NULL, 'デイズ', '青', 'en', NULL, 'Atlantic Blue (PM)', 'RCH', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(93, NULL, 'G04_XCF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCF.png', NULL, NULL, NULL, NULL, 'デイズ', '赤黒', 'en', NULL, 'Sparkling red (PM) / black (P) 2 tones', 'XCF', '赤黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(94, NULL, 'G04_XCH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCH.png', NULL, NULL, NULL, NULL, 'デイズ', '茶水色', 'en', NULL, 'Soda Blue (M) / Ash Brown (M) 2 Tones', 'XCH', '茶水色', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(95, NULL, 'G04_XCK.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCK.png', NULL, NULL, NULL, NULL, 'デイズ', '白茶', 'en', NULL, 'Ash Brown (M) / Frozen Vanilla Pearl (M) 2 Tones', 'XCK', '白茶', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(96, NULL, 'G04_XDT.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XDT.png', NULL, NULL, NULL, NULL, 'デイズ', '橙白', 'en', NULL, 'White Pearl (3P) / Premium Sunshine Orange (M) 2 Tones', 'XDT', '橙白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(97, NULL, 'G04_XFS.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XFS.png', NULL, NULL, NULL, NULL, 'デイズ', '灰', 'en', NULL, 'Titanium Gray (M) / Black (P) 2 Tones', 'XFS', '灰', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(98, NULL, 'G02_EAN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAN.png', NULL, NULL, NULL, NULL, 'キックス', '緑', 'en', NULL, 'Titanium khaki (PM)', 'EAN', '緑', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(99, NULL, 'G02_EAV.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAV.png', NULL, NULL, NULL, NULL, 'キックス', '黄', 'en', NULL, 'Sunlight Yellow (P)', 'EAV', '黄', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(100, NULL, 'G02_EBB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EBB.png', NULL, NULL, NULL, NULL, 'キックス', '橙', 'en', NULL, 'Premium Horizon Orange (PM)', 'EBB', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(101, NULL, 'G02_G42.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_G42.png', NULL, NULL, NULL, NULL, 'キックス', '黒', 'en', NULL, 'Pure Black (PM)', 'G42', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(102, NULL, 'G02_GAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_GAB.png', NULL, NULL, NULL, NULL, 'キックス', '黒', 'en', NULL, 'Knight Veil Purple (TP)', 'GAB', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(103, NULL, 'G02_K23.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_K23.png', NULL, NULL, NULL, NULL, 'キックス', '銀', 'en', NULL, 'Brilliant Silver (M)', 'K23', '銀', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(104, NULL, 'G02_NAH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_NAH.png', NULL, NULL, NULL, NULL, 'キックス', '赤', 'en', NULL, 'Radiant Red (P)', 'NAH', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(105, NULL, 'G02_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_QAB.png', NULL, NULL, NULL, NULL, 'キックス', '白', 'en', NULL, 'Brilliant White Pearl (3PM)', 'QAB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(106, NULL, 'G02_RAA.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_RAA.png', NULL, NULL, NULL, NULL, 'キックス', '青', 'en', NULL, 'Dark blue (PM)', 'RAA', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(107, NULL, 'G02_XDN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XDN.png', NULL, NULL, NULL, NULL, 'キックス', '白黒', 'en', NULL, 'Brilliant White Pearl (3PM) / Pure Black (PM) 2 Tones', 'XDN', '白黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(108, NULL, 'G02_XFP.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFP.png', NULL, NULL, NULL, NULL, 'キックス', '橙', 'en', NULL, 'Premium Horizon Orange (PM) / Pure Black (PM) 2 Tone', 'XFP', '橙', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(109, NULL, 'G02_XFY.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFY.png', NULL, NULL, NULL, NULL, 'キックス', '赤黒', 'en', NULL, 'Radiant Red (P) / Pure Black (PM) 2 Tone', 'XFY', '赤黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(110, NULL, 'G02_XFZ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFZ.png', NULL, NULL, NULL, NULL, 'キックス', '炭黒', 'en', NULL, 'Dark metal gray (M) / pure black (PM) 2 tones', 'XFZ', '炭黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(111, NULL, 'G05_CBA.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_CBA.png', NULL, NULL, NULL, NULL, 'ルークス', '茶', 'en', NULL, 'Ash brown (M)', 'CBA', '茶', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(112, NULL, 'G05_GAS.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_GAS.png', NULL, NULL, NULL, NULL, 'ルークス', '黒', 'en', NULL, 'Black (P)', 'GAS', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(113, NULL, 'G05_HAK.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_HAK.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'en', NULL, 'Frozen vanilla pearl (M)', 'HAK', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(114, NULL, 'G05_KBW.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_KBW.png', NULL, NULL, NULL, NULL, 'ルークス', '炭', 'en', NULL, 'Titanium Gray (M)', 'KBW', '炭', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(115, NULL, 'G05_LAL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_LAL.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'en', NULL, 'Amethyst Purple (PM)', 'LAL', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(116, NULL, 'G05_NBR.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_NBR.png', NULL, NULL, NULL, NULL, 'ルークス', '赤', 'en', NULL, 'Sparkling red (PM)', 'NBR', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(117, NULL, 'G05_QBB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_QBB.png', NULL, NULL, NULL, NULL, 'ルークス', '白', 'en', NULL, 'White pearl (3P)', 'QBB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(118, NULL, 'G05_RCH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_RCH.png', NULL, NULL, NULL, NULL, 'ルークス', '青', 'en', NULL, 'Atlantic Blue (PM)', 'RCH', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(119, NULL, 'G05_XCF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XCF.png', NULL, NULL, NULL, NULL, 'ルークス', '赤黒', 'en', NULL, 'Sparkling red (PM) / black (P) 2 tones', 'XCF', '赤黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(120, NULL, 'G05_XEL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEL.png', NULL, NULL, NULL, NULL, 'ルークス', '白', 'en', NULL, 'White Pearl (3P) / Titanium Gray (M) 2 Tones', 'XEL', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(121, NULL, 'G05_XEM.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEM.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'en', NULL, 'Amethyst Purple (PM) / Frozen Vanilla Pearl (M) 2 Tones', 'XEM', '紫', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(122, NULL, 'G07_GAP.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_GAP.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Premium Horizon Orange (PM) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(123, NULL, 'G07_K23.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_K23.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Brilliant Silver (M)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(124, NULL, 'G07_KAD.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KAD.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Dark metal gray (M)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(125, NULL, 'G07_KH3.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KH3.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Super black', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(126, NULL, 'G07_NBF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_NBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Garnet Red (CP)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(127, NULL, 'G07_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_QAB.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Brilliant White Pearl (3P)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(128, NULL, 'G07_RAY.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_RAY.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Aurora Flare Blue Pearl (P)', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(129, NULL, 'G07_XAE.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XAE.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Super Black / Dark Metal Gray (M) 2 Tones', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(130, NULL, 'G07_XBJ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBJ.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Brilliant White Pearl (3P) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(131, NULL, 'G07_XBK.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBK.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Brilliant White Pearl (3P) / Aurora Flare Blue Pearl (P) 2 Tones', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(132, NULL, 'G07_XBL.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBL.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Sunlight Yellow (P) / Super Black 2 Tones', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(133, NULL, 'G07_XBT.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBT.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Garnet Red (CP) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(134, NULL, 'G07_XEH.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEH.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Vivid Blue (M) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(135, NULL, 'G07_XEX.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEX.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Stealth Gray (P) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(136, NULL, 'G05_GAQ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_GAQ.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Dark metal gray (M) / Super black 2 tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(137, NULL, 'G05_XBF.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_XBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Brilliant Silver (M) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(138, NULL, 'G09_XGN.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G09_XGN.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'en', NULL, 'Aurora Flare Blue Pearl (P) / Super Black 2 Tone', '', '', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(139, NULL, 'G19_GAG.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_GAG.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '黒', 'en', NULL, 'Meteor Flake Black Pearl (P)', 'GAG', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(140, NULL, 'G19_KAD.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KAD.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', 'グレー', 'en', NULL, 'Dark metal gray (M)', 'KAD', 'グレー', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(141, NULL, 'G19_KH3.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KH3.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '黒', 'en', NULL, 'Super black', 'KH3', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(142, NULL, 'G19_NBA.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_NBA.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '赤', 'en', NULL, 'Carmine Red (CM)', 'NBA', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(143, NULL, 'G19_QAB.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_QAB.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '白', 'en', NULL, 'Brilliant White Pearl (3P)', 'QAB', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(144, NULL, 'G19_RCJ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_RCJ.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '青', 'en', NULL, 'Deep Ocean Blue (P)', 'RCJ', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(145, NULL, 'G28_KBZ.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G28_KBZ.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '灰', 'en', NULL, 'Slate gray (PM)', 'KBZ', '灰', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(146, NULL, '20_B13B_A_BC_ホワイト.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_QAY.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '白', 'en', NULL, ' White', 'QAY', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(151, NULL, '20_B13B_A_BC_ガーネットレッド.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_NBF.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '赤', 'en', NULL, ' Garnet Red (CP)', 'NBF', '赤', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(152, NULL, '20_B13B_A_BC_オーロラフレアブルーパール.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_RAY.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '青', 'en', NULL, ' Aurora Flare Blue Pearl (P)', 'RAY', '青', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(148, NULL, '20_B13B_A_BC_ピュアホワイトパール.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_QAC.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '白', 'en', NULL, ' Pure white pearl (3P)', 'QAC', '白', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(149, NULL, '20_B13B_A_BC_ブリリアントシルバー.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_K23.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '銀', 'en', NULL, ' Brilliant Silver (M)', 'K23', '銀', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(147, NULL, '20_B13B_A_BC_スーパーブラック.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_KH3.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '黒', 'en', NULL, ' Super black', 'KH3', '黒', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name, color_name, cw_color, sos_display_name, sos_display_color)
VALUES(150, NULL, '20_B13B_A_BC_ダークメタルグレー.png', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/B13B_KAD.png', NULL, NULL, NULL, NULL, 'ノート（2020年12月発売）', '灰', 'en', NULL, ' Dark metal gray (M)', 'KAD', '灰', NULL);

--V1606801786__insert_nicos_bank_table.sql

-- Added in seperate file Bank Code Master

--new car (with vin changes)

DELETE FROM nissan_admin.package_planv2 where package_plan_name='standard' and lang_code='en' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[HYBRID]　GT/GT Type P/GT Type SP' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Skyline (From September 2019)' and lang_code='en')));

DELETE FROM nissan_admin.package_planv2 where package_plan_name='standard' and lang_code='jp' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[HYBRID]　GT/GT Type P/GT Type SP' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='スカイライン（2019年9月～）' and lang_code='jp')));


DELETE FROM nissan_admin.package_planv2 where package_plan_name='propilot' and lang_code='en' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Skyline (From September 2019)' and lang_code='en')));

DELETE FROM nissan_admin.package_planv2 where package_plan_name='propilot' and lang_code='jp' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='スカイライン（2019年9月～）' and lang_code='jp')));

UPDATE nissan_admin.modelv2 set category=true where model_name='Skyline (From September 2019)' and lang_code='en';
UPDATE nissan_admin.modelv2 set category=true where model_name='スカイライン（2019年9月～）' and lang_code='jp';
UPDATE nissan_admin.modelv2 set category=true where model_name='Leaf (from February 2020)' and lang_code='en';
UPDATE nissan_admin.modelv2 set category=true where model_name='リーフ（2020年2月～）' and lang_code='jp';


--Add vehicle Type Column

UPDATE nissan_admin.naviv2 set vehicle_type='usedcar' where navi_name='na' AND grade_id IN (SELECT id from nissan_admin.gradev2 where grade_name='NOGRADE' AND model_id IN (SELECT id from nissan_admin.modelv2 WHERE model_name='Others' or model_name='その他'));

--Insert package plans for new car with vin
--Skyline
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp')));

--Leaf February
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));

--Leaf january
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));


--DAYZ
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

UPDATE nissan_admin.gradev2 SET grade_name='NOGRADE' WHERE grade_name='All Grades' or grade_name='全グレード';

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '0', '0', 'en', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン無）', 'ディーラーオプション（SOSコールボタン無）', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '0', '0', 'jp', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));


--ROOX
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '0', '0', 'en', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '0', '0', 'jp', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));


--Kicks
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '0', '0', 'en', 'pattern-three', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '0', '0', 'jp', 'pattern-three', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));


--X-TRAIL
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic Service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));


--Elgrand
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic Service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));


--Teana
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));


--Fuga
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));


--Cima
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));

--Others
INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション ', 'en', 'newcar' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op', 'ディーラーオプション ', 'ディーラーオプション ', 'jp', 'newcar' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

--V1609649904__update_cw_model_name.sql

UPDATE nissan_admin.modelv2 set cw_model_name='リーフ' WHERE cw_model_name='リーフ（2020年2月～）' OR cw_model_name='リーフ（2020年1月以前）';

UPDATE nissan_admin.modelv2 set cw_model_name='スカイライン' WHERE cw_model_name='スカイライン（2019年9月～）';

--V1609788007__update_pattern_ivi_flag.sql


UPDATE nissan_admin.package_planv2 SET pattern_name='pattern-five' WHERE package_plan_name='sos';

UPDATE nissan_admin.package_planv2 SET pattern_name='pattern-six' WHERE navi_id IN (SELECT id FROM nissan_admin.naviv2 WHERE grade_id IN (SELECT id FROM nissan_admin.gradev2 WHERE model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' OR model_name='リーフ（2020年1月以前）')));

UPDATE nissan_admin.modelv2 SET category=false WHERE model_name != 'Skyline (From September 2019)' AND model_name != 'スカイライン（2019年9月～）' AND model_name != 'Leaf (from February 2020)' AND model_name != 'リーフ（2020年2月～）' AND category=true;

--V1609788320__insert_env200_model.sql
	
	
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url, vehicle_type) VALUES
('e-NV200', 'e-NV200', 'e-NV200', 'en', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/e-NV200/ME0_P157.jpg', 'common'),
('e-NV200', 'e-NV200', 'e-NV200', 'jp', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/e-NV200/ME0_P157.jpg', 'common');


INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'GX', 'GX', 'GX', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'GX', 'GX', 'GX', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'G', 'G', 'G', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'G', 'G', 'G', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='GX' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='GX' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-six', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-six', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));

--V1610432225__alter_navi_add_color_option.sql

UPDATE nissan_admin.naviv2 n set color_option=true WHERE n.navi_name!='na' AND (n.navi_name='s-os' OR n.navi_name='d-op+s-os' OR n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.model_id IN (SELECT id FROM nissan_admin.modelv2 m WHERE m.category=true)));

--V1610602434__create_navi_reference.sql

INSERT INTO nissan_admin.navi_reference(adaptor_kind, dop_flag) VALUES
('00', '1'), ('07', '2'), ('08', '2'), ('09', '2'), ('10', '1'),
('11', '1'), ('12', '1'), ('13', '1'), ('14', '1'), ('15', '1'), ('16', '1'), ('17', '1'), ('18', '2'), ('19', '2'), ('20', '2'),
('21', '1'), ('22', '1'), ('23', '1'), ('24', '1'), ('25', '2'), ('26', '2'), ('27', '2'), ('28', '2'), ('29', '2'), ('30', ''),
('31', '1'), ('32', '1'), ('33', '2'), ('34', '2'), ('35', '2'), ('36', '2'), ('37', '2'), ('38', '2'), ('39', '2'), ('40', '2'),
('41', '2'), ('42', '1'), ('43', '1'), ('44', '1'), ('45', '2'), ('46', '2'), ('47', '2'), ('49', '1'), ('50', '2'),
('52', '2'), ('53', '2'), ('54', '1'), ('57', '2'), ('58', '2'), ('59', '2'), ('60', '2'),
('61', '1'), ('63', '2'), ('64', '2'), ('65', '2'), ('66', '2'), ('67', '2'), ('68', '2'), ('70', '2'),
('71', '2'), ('72', '1'), ('77', '2'), ('78', '2'), ('79', '2'), ('80', '2'),
('81', '2'), ('82', '2'), ('83', '2'), ('84', '2'), ('85', '2'), ('88', '2'),
('91', '2'), ('99', '1');

--V1615189187__add_note_model.sql

INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url, category, vehicle_type) VALUES
('Note', 'NOTE (December 2020 ~)', 'ノート', 'en', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE+(November+2020+~)/Note.png', true, 'common'),
('ノート（2020年12月発売）', 'ノート（2020年12月発売）', 'ノート', 'jp', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE+(November+2020+~)/Note.png', true, 'common');

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'X (including 2WD / 4WD / AUTECH)', 'X (including 2WD / 4WD / AUTECH)', 'X（2WD/4WD/AUTECH含む）', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'X（2WD/4WD/AUTECH含む）', 'X（2WD/4WD/AUTECH含む）', 'X（2WD/4WD/AUTECH含む）', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'F/S', 'F/S', 'F/S', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'F/S', 'F/S', 'F/S', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en', true, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp', true, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'DOP(Not applicable / No Navi Type)', 'お申込み不可', 'en', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'ディーラーオプション(お申込み不可)', 'お申込み不可', 'jp', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'DOP(Not applicable / No Navi Type)', 'お申込み不可', 'en', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='F/S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, color_option, vehicle_type)
(SELECT id, 'na', 'ディーラーオプション(お申込み不可)', 'お申込み不可', 'jp', false, 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='F/S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'Standard plan +', 'スタンダードプラン＋', '7920', '2200', 'en', 'pattern-one', 'pattern-two', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'スタンダードプラン＋', 'スタンダードプラン＋', '7920', '2200', 'jp', 'pattern-one', 'pattern-two', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'Standard plan +', 'スタンダードプラン＋', '7920', '0', 'en', 'pattern-one', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X (including 2WD / 4WD / AUTECH)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Note' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard+', 'スタンダードプラン＋', 'スタンダードプラン＋', '7920', '0', 'jp', 'pattern-one', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X（2WD/4WD/AUTECH含む）' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ノート（2020年12月発売）' AND lang_code='jp')));


--V1615191282__add_plan_modify_model_names.sql

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 's-os', 'SOS', 'ナビなし（SOSコールボタン有）', 'en', 'common', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'ナビなし（SOSコールボタン有）', 'jp', 'common', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-five', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-five', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-one', 'pattern-five', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-one', 'pattern-five', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));



UPDATE nissan_admin.modelv2 set model_name='スカイライン（2019年9月発売）', display_name='スカイライン（2019年9月発売）' WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Skyline (released in September 2019)', display_name='Skyline (released in September 2019)' WHERE model_name='Skyline (From September 2019)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年2月発売）', display_name='リーフ（2020年2月発売）' WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (released in February 2020)', display_name='Leaf (released in February 2020)' WHERE model_name='Leaf (from February 2020)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年1月以前発売）', display_name='リーフ（2020年1月以前発売）' WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (released before January 2020)', display_name='Leaf (released before January 2020)' WHERE model_name='Leaf (before January 2020)' AND lang_code='en';

--V1615460314__revert_model_names.sql

UPDATE nissan_admin.modelv2 set model_name='スカイライン（2019年9月～）', display_name='スカイライン（2019年9月～）' WHERE model_name='スカイライン（2019年9月発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Skyline (From September 2019)', display_name='Skyline (From September 2019)' WHERE model_name='Skyline (released in September 2019)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年2月～）', display_name='リーフ（2020年2月～）' WHERE model_name='リーフ（2020年2月発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (from February 2020)', display_name='Leaf (from February 2020)' WHERE model_name='Leaf (released in February 2020)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年1月以前）', display_name='リーフ（2020年1月以前）' WHERE model_name='リーフ（2020年1月以前発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (before January 2020)', display_name='Leaf (before January 2020)' WHERE model_name='Leaf (released before January 2020)' AND lang_code='en';

-- Phase2 v2 tables

--V1615460314__revert_model_names.sql

UPDATE nissan_admin.modelv2 set model_name='スカイライン（2019年9月～）', display_name='スカイライン（2019年9月～）' WHERE model_name='スカイライン（2019年9月発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Skyline (From September 2019)', display_name='Skyline (From September 2019)' WHERE model_name='Skyline (released in September 2019)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年2月～）', display_name='リーフ（2020年2月～）' WHERE model_name='リーフ（2020年2月発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (from February 2020)', display_name='Leaf (from February 2020)' WHERE model_name='Leaf (released in February 2020)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年1月以前）', display_name='リーフ（2020年1月以前）' WHERE model_name='リーフ（2020年1月以前発売）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (before January 2020)', display_name='Leaf (before January 2020)' WHERE model_name='Leaf (released before January 2020)' AND lang_code='en';



--V1615878814__update_standard_plus_plan_name.sql

update nissan_admin.package_planv2 set package_plan_name='standard-plus' where package_plan_name='standard+';


--V1615878822__insert_navi_others_model.sql

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en', 'newcar', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp', 'newcar', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

--DAYZ description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='basic-sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the vehicle initial registration date) (SOS call service usage period: 10 years from vehicle initial registration)' where package_plan_name='basic-sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='デイズ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Dayz' and lang_code='en')));


--Roox description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='S' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='S' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='basic-sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the vehicle initial registration date) (SOS call service usage period: 10 years from vehicle initial registration)' where package_plan_name='basic-sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/その他(S以外)' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ルークス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='X/G/Other (other than S)' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Roox' and lang_code='en')));


--Kicks description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='basic-sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the vehicle initial registration date) (SOS call service usage period: 10 years from vehicle initial registration)' where package_plan_name='basic-sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op+s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 set description='無料（SOSコールサービス利用期間：車両初度登録より10年間）' where package_plan_name='sos' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 set description='free (SOS call service usage period: 10 years from the first registration of the vehicle)' where package_plan_name='sos' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='s-os' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));


--X-Trail description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エクストレイル' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='X-Trail' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エクストレイル' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='X-Trail' and lang_code='en')));


--Elgrand description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エルグランド' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Elgrand' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='エルグランド' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Elgrand' and lang_code='en')));


--TEANA description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XV Navi AVM Package / XL Navi AVM Package' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XL' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='ティアナ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='XL' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='TEANA' and lang_code='en')));


--Fuga description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='フーガ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Fuga' and lang_code='en')));


--Cima description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='シーマ' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Cima' and lang_code='en')));


--Others description

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='その他' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='d-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Others' and lang_code='en')));

update nissan_admin.package_planv2 set description='10年無料キャンペーン（車両初度登録年月から）' where package_plan_name='basic' and lang_code='jp' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='その他' and lang_code='jp')));

update nissan_admin.package_planv2 set description='10-year free campaign (from the first registration date of the vehicle)' where package_plan_name='basic' and lang_code='en' and vehicle_type='newcar' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Others' and lang_code='en')));

--V1616039834__data_issue_fixes.sql

update nissan_admin.package_planv2 set terms_name='pattern-two';

update nissan_admin.modelv2 set display_name='ノート（2020年12月～）' where display_name='ノート（2020年12月発売）';

update nissan_admin.naviv2 set vehicle_type='usedcar' where navi_name='na' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and model_id in (select id from nissan_admin.modelv2 where cw_model_name='その他'));

update nissan_admin.naviv2 set display_name='全ナビタイプ' where display_name='お申込み不可' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='その他' and lang_code='jp'));

update nissan_admin.naviv2 set display_name='All navigation types' where display_name='Not applicable / No Navi Type' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='NOGRADE' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Others' and lang_code='en'));

update nissan_admin.package_planv2 set price='3300' where package_plan_name='basic-operator-service' and navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='m-op' and n.grade_id in (select id FROM nissan_admin.gradev2 g where g.grade_name='NOGRADE' and g.model_id in (select id from nissan_admin.modelv2 where cw_model_name='シーマ')));

--Phase 1 changes

--V1601979857__insert_payment_method.sql

INSERT INTO nissan_admin.payment_method(id, name, display_name, lang_code, type) VALUES
(15,'digital', 'Digital', 'en', 'digital'),
(16,'paper', 'Paper', 'en', 'direct-debit'),
(17,'digital', 'デジタル', 'jp', 'digital'),
(18,'paper', '紙', 'jp', 'direct-debit');

--V1609788256__insert_ariya_model.sql

INSERT INTO nissan_admin.model(model_name, display_name, lang_code, url) VALUES
('ARIYA', 'ARIYA', 'en', null),
('アリア', 'アリア', 'jp', null);

INSERT INTO nissan_admin.grade(model_name, grade_name, display_name, lang_code) VALUES
('ARIYA', 'L4', 'L4', 'en'),
('アリア', 'L4', 'L4', 'jp'),
('ARIYA', 'L3', 'L3', 'en'),
('アリア', 'L3', 'L3', 'jp');

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'MOP', 'en' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='ARIYA' AND g.lang_code='en');

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'MOP - 無料プラン', 'jp' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='アリア' AND g.lang_code='jp');
	
INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'propilot', 'Pro Pilot Plan', '24200', 'en' FROM nissan_admin.navi n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='en' AND (g.grade_name='L4' OR g.grade_name='L3'));

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'standard', 'Standard Plan', '6600', 'en' FROM nissan_admin.navi n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.grade_name='L3' AND g.lang_code='en');

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'propilot', 'プロパイロットプラン', '24200', 'jp' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND (n.navi_name='m-op' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND (g.grade_name='L4' OR g.grade_name='L3')));

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'standard', 'スタンダードプラン', '6600', 'jp' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND (n.navi_name='m-op' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND g.grade_name='L3'));
	
--package_plan update pattern-three

UPDATE nissan_admin.package_plan SET pattern_name='pattern-three' WHERE package_plan_name='basic-operator-service';

--V1609819235__update_nicos_card_brand.sql Need to check

UPDATE nissan_admin.card_brand SET card_brand='口座振替' WHERE card_brand='Nicos' AND lang_code='jp';
UPDATE nissan_admin.card_brand SET card_brand='BANK' WHERE card_brand='Nicos' AND lang_code='en';

-- Insert package_plan table

--V1605180128__insert_operator_service_plans.sql

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'Operator Service', 3300, 'en', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='en' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='X-TRAIL' and g.lang_code='en'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'オペレーターサービス', 3300, 'jp', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='jp' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='エクストレイル' and g.lang_code='jp'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'Operator Service', 3300, 'en', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='en' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='ELGRAND' and g.lang_code='en'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'オペレーターサービス', 3300, 'jp', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='jp' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='エルグランド' and g.lang_code='jp'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'Operator Service', 3300, 'en', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='en' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='XV Navi AVM Package / XL Navi AVM Package' and g.model_name='TEANA' and g.lang_code='en'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'オペレーターサービス', 3300, 'jp', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='jp' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' and g.model_name='ティアナ' and g.lang_code='jp'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'Operator Service', 3300, 'en', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='en' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='XE' and g.model_name='TEANA' and g.lang_code='en'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'オペレーターサービス', 3300, 'jp', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='jp' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='XE' and g.model_name='ティアナ' and g.lang_code='jp'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'Operator Service', 3300, 'en', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='en' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='FUGA' and g.lang_code='en'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'オペレーターサービス', 3300, 'jp', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='jp' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='フーガ' and g.lang_code='jp'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'Operator Service', 3300, 'en', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='en' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='CIMA' and g.lang_code='en'));

INSERT INTO nissan_admin.package_plan(navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name) (SELECT id, 'operator-service', 'オペレーターサービス', 3300, 'jp', null, null FROM nissan_admin.navi n where n.navi_name='m-op-free-plan' and n.lang_code='jp' and n.grade_id in (select id from nissan_admin.grade g where g.grade_name='NOGRADE' and g.model_name='シーマ' and g.lang_code='jp'));

--V1608521799__new_car_design_changes.sql


--new car (no vin changes)
UPDATE nissan_admin.package_plan set package_plan_name='basic-operator-service' where package_plan_name='operator-service';
UPDATE nissan_admin.package_plan set display_name='Basic service + operator service' where display_name='Operator Service';
UPDATE nissan_admin.package_plan set display_name='基本サービス + オペレーターサービス' where display_name='オペレーターサービス';


--V1615187219__add_plan_dayz.sql

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 's-os', 'SOS', 'en' FROM nissan_admin.grade g WHERE g.model_name='DAYZ' AND lang_code='en';

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'jp' FROM nissan_admin.grade g WHERE g.model_name='デイズ' AND lang_code='jp';


INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name)
    SELECT id, 'sos', 'SOS', 0, 'en', 'pattern-five', 'pattern-one' FROM nissan_admin.navi n WHERE n.lang_code='en' AND n.navi_name='s-os' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='DAYZ' AND lang_code='en');

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name)
    SELECT id, 'sos', 'SOSコールのみ申込み', 0, 'jp', 'pattern-five', 'pattern-one' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND n.navi_name='s-os' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='デイズ' AND lang_code='jp');


--V1615878814__update_standard_plus_plan_name.sql

update nissan_admin.package_plan set package_plan_name='standard-plus' where package_plan_name='standard+';

--V1616039834__data_issue_fixes.sql

update nissan_admin.package_plan set terms_name='pattern-two' where terms_name is not null;

update nissan_admin.payment_method set display_name='申込書' where display_name='紙';
update nissan_admin.payment_method set display_name='Web申込' where display_name='デジタル';


--New car : No Vin MOP navi added for others model


INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'MOP', 'en' FROM nissan_admin.grade g WHERE g.model_name='Others' AND lang_code='en';
INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'メーカーオプション', 'jp' FROM nissan_admin.grade g WHERE g.model_name='その他' AND lang_code='jp';

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name)
    SELECT id, 'basic-operator-service', 'Basic service + operator service', 3300, 'en', 'pattern-three', 'pattern-two' FROM nissan_admin.navi n WHERE n.lang_code='en' AND n.navi_name='m-op' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='Others' AND lang_code='en');
INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code, pattern_name, terms_name)
    SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', 3300, 'jp', 'pattern-three', 'pattern-two' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND n.navi_name='m-op' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='その他' AND lang_code='jp');

