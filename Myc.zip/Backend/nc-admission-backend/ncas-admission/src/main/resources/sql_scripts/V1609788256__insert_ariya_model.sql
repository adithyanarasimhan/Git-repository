INSERT INTO nissan_admin.model(model_name, display_name, lang_code, url) VALUES
('ARIYA', 'ARIYA', 'en', null),
('アリア', 'アリア', 'jp', null);

INSERT INTO nissan_admin.grade(model_name, grade_name, display_name, lang_code)

INSERT INTO nissan_admin.grade(model_name, grade_name, display_name, lang_code) VALUES
('ARIYA', 'L4', 'L4', 'en'),
('アリア', 'L4', 'L4', 'jp'),
('ARIYA', 'L3', 'L3', 'en'),
('アリア', 'L3', 'L3', 'jp');

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'MOP', 'en' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='ARIYA' AND g.lang_code='en');

INSERT INTO nissan_admin.navi (grade_id, navi_name, display_name, lang_code)
    SELECT id, 'm-op', 'MOP - 無料プラン', 'jp' FROM nissan_admin.grade WHERE id IN (SELECT id FROM nissan_admin.grade g WHERE g.model_name='アリア' AND g.lang_code='jp');

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'propilot', 'Pro Pilot Plan', '24200', 'en' FROM nissan_admin.navi n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='en' AND (g.grade_name='L4' OR g.grade_name='L3'));

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'standard', 'Standard Plan', '6600', 'en' FROM nissan_admin.navi n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.grade_name='L3' AND g.lang_code='en');

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'propilot', 'プロパイロットプラン', '24200', 'jp' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND (n.navi_name='m-op' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND (g.grade_name='L4' OR g.grade_name='L3')));

INSERT INTO nissan_admin.package_plan
    (navi_id, package_plan_name, display_name, price, lang_code)
    SELECT id, 'standard', 'スタンダードプラン', '6600', 'jp' FROM nissan_admin.navi n WHERE n.lang_code='jp' AND (n.navi_name='m-op' AND n.grade_id IN (SELECT id FROM nissan_admin.grade g WHERE g.lang_code='jp' AND g.grade_name='L3'));