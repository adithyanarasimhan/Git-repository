ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS new_vin character varying(50);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS source character varying(25);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS vin_approach boolean DEFAULT false;
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS cw_naviid character varying(50);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS color character varying(30);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS color_code character varying(30);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS registration_date character varying(50);
ALTER TABLE nissan_admin.orders ADD COLUMN IF NOT EXISTS color_id bigint;
ALTER TABLE nissan_admin.orders ADD CONSTRAINT orders_color_fkey FOREIGN KEY (color_id) REFERENCES nissan_admin.color (id);
