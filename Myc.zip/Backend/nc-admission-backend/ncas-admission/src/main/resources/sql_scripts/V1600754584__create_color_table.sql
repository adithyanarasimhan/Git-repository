DROP TABLE IF EXISTS nissan_admin.color;

CREATE SEQUENCE IF NOT EXISTS nissan_admin.color_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE IF NOT EXISTS nissan_admin.color (
        id bigint NOT NULL DEFAULT nextval('nissan_admin.color_id_seq'::regclass),
        color character varying(100) COLLATE pg_catalog."default",
        color_code character varying(100) COLLATE pg_catalog."default",
        image_url character varying(500) COLLATE pg_catalog."default",
        modelv2_id bigint,
        CONSTRAINT color_pkey PRIMARY KEY (id),
        CONSTRAINT color_modelv2_fkey FOREIGN KEY (modelv2_id)
                            REFERENCES nissan_admin.modelv2 (id) MATCH SIMPLE
                            ON UPDATE NO ACTION
                            ON DELETE NO ACTION
);