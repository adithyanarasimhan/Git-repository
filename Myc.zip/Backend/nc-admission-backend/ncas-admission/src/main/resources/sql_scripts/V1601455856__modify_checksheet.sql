update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='m-op' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='X-Trail' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='dop' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='エクストレイル' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-four' where plan.package_plan_name='basic-sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-four' where plan.package_plan_name='basic-sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.package_plan_name='basic' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name='pattern-three' where plan.package_plan_name='basic' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='d-op+s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='Kicks' and lang_code='en')));

update nissan_admin.package_planv2 plan set pattern_name=null where plan.package_plan_name='sos' and plan.navi_id in (select id from nissan_admin.naviv2 n where n.navi_name='s-os' and n.grade_id in (select id from nissan_admin.gradev2 g where g.model_id in (select id from nissan_admin.modelv2 where model_name='キックス' and lang_code='jp')));