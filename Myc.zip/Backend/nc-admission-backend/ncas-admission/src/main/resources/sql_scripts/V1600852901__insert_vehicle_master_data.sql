--Skyline (From September 2019)
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Skyline (From September 2019)', 'Skyline (From September 2019)', 'スカイライン（2019年9月～）', 'en', null),
('スカイライン（2019年9月～）', 'スカイライン（2019年9月～）', 'スカイライン（2019年9月～）', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND lang_code='en'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND lang_code='en'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND lang_code='jp'));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='en'));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='jp'));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='en'));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' OR g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R'AND g.lang_code='jp'));

--Leaf (from February 2020)
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Leaf (from February 2020)', 'Leaf (from February 2020)', 'リーフ（2020年2月～）', 'en', null),
('リーフ（2020年2月～）', 'リーフ（2020年2月～）', 'リーフ（2020年2月～）', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/Other (other than S)', 'X/G/Other (other than S)', 'X/G/その他(S以外)', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));


--Leaf (before January 2020)
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Leaf (before January 2020)', 'Leaf (before January 2020)', 'リーフ（2020年1月以前）', 'en', null),
('リーフ（2020年1月以前）', 'リーフ（2020年1月以前）', 'リーフ（2020年1月以前）', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/Other (other than S)', 'X/G/Other (other than S)', 'X/G/その他(S以外)', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp'));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));


--X-Trail
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('X-Trail', 'X-Trail', 'エクストレイル', 'en', null),
('エクストレイル', 'エクストレイル', 'エクストレイル', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'dop', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'dop', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='dop' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='dop' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));


--Kicks
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Kicks', 'Kicks', 'キックス', 'en', null),
('キックス', 'キックス', 'キックス', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'SOS', 'ナビなし（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'ナビなし（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'DOP+SOS', 'ディーラーオプション（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン有）', 'ディーラーオプション（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '5500', '2200', 'en', 'pattern-three', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '5500', '2200', 'jp', 'pattern-three', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-one' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', 'pattern-two' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));