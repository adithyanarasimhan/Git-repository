ALTER TABLE nissan_admin.ordersv2 ADD COLUMN IF NOT EXISTS company_name character varying(100);
ALTER TABLE nissan_admin.ordersv2 ADD COLUMN IF NOT EXISTS dealership_name character varying(50);
ALTER TABLE nissan_admin.ordersv2 ADD COLUMN IF NOT EXISTS phone_number character varying(13);
ALTER TABLE nissan_admin.ordersv2 ADD COLUMN IF NOT EXISTS ca_name character varying(50);
ALTER TABLE nissan_admin.ordersv2 ADD COLUMN IF NOT EXISTS ca_name_kana character varying(50);
ALTER TABLE nissan_admin.ordersv2 ADD COLUMN IF NOT EXISTS ca_code character varying(50);