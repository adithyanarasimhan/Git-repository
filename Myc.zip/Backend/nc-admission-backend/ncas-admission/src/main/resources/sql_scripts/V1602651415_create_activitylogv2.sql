-- nissan_admin.activity_logv2 definition

-- Drop table

-- DROP TABLE nissan_admin.activity_logv2;

CREATE TABLE nissan_admin.activity_logv2 (
	id bigserial NOT NULL,
	message varchar(100) NULL,
	"type" varchar(100) NULL,
	"time" timestamp NULL,
	admission_id int4 NULL,
	message_jp varchar(100) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT activity_logv2_pkey PRIMARY KEY (id)
);


-- nissan_admin.activity_logv2 foreign keys

ALTER TABLE nissan_admin.activity_logv2 ADD CONSTRAINT admission_al_fk FOREIGN KEY (admission_id) REFERENCES nissan_admin.admissionv2(id);