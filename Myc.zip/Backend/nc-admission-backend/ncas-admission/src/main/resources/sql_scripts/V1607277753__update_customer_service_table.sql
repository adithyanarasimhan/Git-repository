<!-- DAYS, ROOX, KICKS -->

 UPDATE nissan_admin.package_plan SET pattern_name='pattern-five' WHERE id IN (SELECT p.id FROM nissan_admin.package_plan p WHERE p.package_plan_name='sos' and p.navi_id IN
( SELECT id from nissan_admin.navi n WHERE n.navi_name='d-op+s-os' and n.grade_id in
 (select id from nissan_admin.grade  g WHERE g.grade_name='NOGRADE' and g.model_name IN('デイズ','DAYZ'))));

UPDATE nissan_admin.package_plan SET pattern_name='pattern-five' WHERE id IN ( SELECT p.id FROM nissan_admin.package_plan p WHERE p.package_plan_name='sos' and p.navi_id IN
( SELECT id from nissan_admin.navi n WHERE n.navi_name='d-op+s-os' and n.grade_id in
 (select id from nissan_admin.grade  g WHERE g.grade_name IN ('X/G/その他(S以外)','X / G / Others (Other than S)') and g.model_name IN('ルークス','ROOX'))));

 UPDATE nissan_admin.package_plan SET pattern_name='pattern-five' WHERE id IN ( SELECT p.id FROM nissan_admin.package_plan p WHERE p.package_plan_name='sos' and p.navi_id IN
( SELECT id from nissan_admin.navi n WHERE n.navi_name='s-os' and n.grade_id in
 (select id from nissan_admin.grade  g WHERE g.grade_name IN ('X/G/その他(S以外)','X / G / Others (Other than S)') and g.model_name IN('ルークス','ROOX'))));

  UPDATE nissan_admin.package_plan SET pattern_name='pattern-five' WHERE id IN ( SELECT p.id FROM nissan_admin.package_plan p WHERE p.package_plan_name='sos' and p.navi_id IN
( SELECT id from nissan_admin.navi n WHERE n.navi_name='d-op+s-os' and n.grade_id in
 (select id from nissan_admin.grade  g WHERE g.grade_name='NOGRADE'  and g.model_name IN('キックス','Kicks'))));

   UPDATE nissan_admin.package_plan SET pattern_name='pattern-five' WHERE id IN ( SELECT p.id FROM nissan_admin.package_plan p WHERE p.package_plan_name='sos' and p.navi_id IN
( SELECT id from nissan_admin.navi n WHERE n.navi_name IN ('s-os','d-op+s-os') and n.grade_id in
 (select id from nissan_admin.grade  g WHERE g.grade_name='NOGRADE'  and g.model_name IN('キックス','Kicks'))));

