--Dayz
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Dayz', 'Dayz', 'デイズ', 'en', null),
('デイズ', 'デイズ', 'デイズ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'DOP+SOS', 'ディーラーオプション（SOSコールボタン無）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン無）', 'ディーラーオプション（SOSコールボタン無）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '5500', '2200', 'en', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '5500', '2200', 'jp', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));


--Roox
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Roox', 'Roox', 'ルークス', 'en', null),
('ルークス', 'ルークス', 'ルークス', 'jp', null);


INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/Other (other than S)', 'X/G/Other (other than S)', 'X/G/その他(S以外)', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'X/G/その他(S以外)', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'S', 'S', 'S', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'DOP+SOS', 'ディーラーオプション（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン有）', 'ディーラーオプション（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'SOS', 'ナビなし（SOSコールボタン有）', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'ナビなし（SOSコールボタン有）', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '5500', '2200', 'en', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '5500', '2200', 'jp', 'pattern-three', 'pattern-four' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-two', null FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));


--Elgrand
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Elgrand', 'Elgrand', 'エルグランド', 'en', null),
('エルグランド', 'エルグランド', 'エルグランド', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));


--TEANA
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('TEANA', 'TEANA', 'ティアナ', 'en', null),
('ティアナ', 'ティアナ', 'ティアナ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XV Navi AVM Package / XL Navi AVM Package', 'XV Navi AVM Package / XL Navi AVM Package', 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'XV ナビAVM パッケージ/XL ナビAVM パッケージ', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XE', 'XE', 'XE', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XE', 'XE', 'XE', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XL', 'XL', 'XL', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'XL', 'XL', 'XL', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp'));



INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));


--Fuga
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Fuga', 'Fuga', 'フーガ', 'en', null),
('フーガ', 'フーガ', 'フーガ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));


--Cima
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Cima', 'Cima', 'シーマ', 'en', null),
('シーマ', 'シーマ', 'シーマ', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));


--Ariya
INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Ariya', 'Ariya', 'アリア', 'en', null),
('アリア', 'アリア', 'アリア', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L4', 'L4', 'L4', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L4', 'L4', 'L4', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L3', 'L3', 'L3', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'L3', 'L3', 'L3', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '2200', 'en', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '2200', 'jp', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L4' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '2200', 'en', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '2200', 'jp', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Ariya' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', null FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='L3' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='アリア' AND lang_code='jp')));