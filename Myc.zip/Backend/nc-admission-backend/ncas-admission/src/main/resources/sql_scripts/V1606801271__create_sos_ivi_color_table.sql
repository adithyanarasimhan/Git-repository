CREATE TABLE nissan_admin.color (
	id bigserial NOT NULL,
	color varchar(100) NULL,
	color_code varchar(100) NULL,
	image_url varchar(500) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	model_name varchar(255) NULL,
	sos_color varchar(255) NULL,
	lang_code varchar(5) NULL DEFAULT 'jp'::character varying,
	cw_model_name varchar(255) NULL,
	CONSTRAINT color_pkey PRIMARY KEY (id)
);