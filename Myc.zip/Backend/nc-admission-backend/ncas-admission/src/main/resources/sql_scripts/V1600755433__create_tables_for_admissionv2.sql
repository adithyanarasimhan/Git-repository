DROP TABLE IF EXISTS nissan_admin.commentv2;
DROP TABLE IF EXISTS nissan_admin.ordersv2;
DROP TABLE IF EXISTS nissan_admin.admissionv2;

CREATE SEQUENCE IF NOT EXISTS nissan_admin.admissionv2_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE IF NOT EXISTS nissan_admin.admissionv2 (
        id bigint NOT NULL DEFAULT nextval('nissan_admin.admissionv2_id_seq'::regclass),
        user_id int NOT NULL,
        dealer_id character varying(100) COLLATE pg_catalog."default",
		status character varying(255) COLLATE pg_catalog."default",
		email_send_date timestamp without time zone,
		vin_registered_date timestamp without time zone,
		nc_id character varying(255) COLLATE pg_catalog."default",
		nc_password character varying(255) COLLATE pg_catalog."default",
		nc_joined_date timestamp without time zone,
		lang_code character varying(5) COLLATE pg_catalog."default",
		active boolean DEFAULT true,
		status_jp character varying(50) COLLATE pg_catalog."default",
		upload_kameri boolean,
		cw_status character varying(50) COLLATE pg_catalog."default",
		nc_id_generated_date date DEFAULT CURRENT_DATE,
		CONSTRAINT admissionv2_pkey PRIMARY KEY (id),
        CONSTRAINT admissionv2_user_fkey FOREIGN KEY (user_id)
                    REFERENCES nissan_admin.user (id) MATCH SIMPLE
                    ON UPDATE NO ACTION
                    ON DELETE NO ACTION
);

CREATE SEQUENCE IF NOT EXISTS nissan_admin.ordersv2_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE IF NOT EXISTS nissan_admin.ordersv2
(
    id bigint NOT NULL DEFAULT nextval('nissan_admin.ordersv2_id_seq'::regclass),
    orders_number character varying(255) COLLATE pg_catalog."default",
    admissionv2_id bigint,
    modelv2_id integer,
    gradev2_id integer,
    naviv2_id integer,
    planv2_id integer,
    optionsv2_id integer,
    payment_method integer,
    plan_price character varying(50) COLLATE pg_catalog."default",
    vehicle_transfer boolean,
    vin_number character varying(255) COLLATE pg_catalog."default",
    order_number_ps character varying(20) COLLATE pg_catalog."default",
    source character varying(100) COLLATE pg_catalog."default",
    lang_code character varying(5) COLLATE pg_catalog."default",
    active boolean DEFAULT true,
    color_id bigint,
    cw_navi_id character varying(100) COLLATE pg_catalog."default",
    registration_date character varying(100) COLLATE pg_catalog."default",
    company_name character varying(100) COLLATE pg_catalog."default",
    dealership_name character varying(50) COLLATE pg_catalog."default",
    phone_number character varying(13) COLLATE pg_catalog."default",
    ca_name character varying(50) COLLATE pg_catalog."default",
    ca_name_kana character varying(50) COLLATE pg_catalog."default",
    ca_code character varying(50) COLLATE pg_catalog."default",
    cw_vin_number character varying(50) COLLATE pg_catalog."default",
    model_name_cw character varying(50) COLLATE pg_catalog."default",
    adopter_id character varying(255) COLLATE pg_catalog."default",
    charge_start_date timestamp without time zone,
    first_registered_date timestamp without time zone,
    nc_joined_date timestamp without time zone,
    nc_status character varying(255) COLLATE pg_catalog."default",
    register_number character varying(255) COLLATE pg_catalog."default",
    service_update_date timestamp without time zone,
    upload_kameri boolean,
    CONSTRAINT ordersv2_pkey PRIMARY KEY (id),
    CONSTRAINT ordersv2_optionsv2_fkey FOREIGN KEY (optionsv2_id)
        REFERENCES nissan_admin.optionsv2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ordersv2_payment_method_fkey FOREIGN KEY (payment_method)
        REFERENCES nissan_admin.payment_method (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ordersv2_admissionv2_fkey FOREIGN KEY (admissionv2_id)
        REFERENCES nissan_admin.admissionv2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT ordersv2_gradev2_fkey FOREIGN KEY (gradev2_id)
        REFERENCES nissan_admin.gradev2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ordersv2_modelv2_fkey FOREIGN KEY (modelv2_id)
        REFERENCES nissan_admin.modelv2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ordersv2_naviv2_fkey FOREIGN KEY (naviv2_id)
        REFERENCES nissan_admin.naviv2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ordersv2_planv2_fkey FOREIGN KEY (planv2_id)
        REFERENCES nissan_admin.package_planv2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ordersv2_color_fkey FOREIGN KEY (color_id)
            REFERENCES nissan_admin.color (id) MATCH SIMPLE
            ON UPDATE NO ACTION
            ON DELETE NO ACTION
);

CREATE SEQUENCE IF NOT EXISTS nissan_admin.commentv2_id_seq
    START WITH 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CYCLE;

CREATE TABLE nissan_admin.commentv2
(
    id bigint NOT NULL DEFAULT nextval('nissan_admin.commentv2_id_seq'::regclass),
    reason_id bigint,
    ordersv2_id bigint,
    comment character varying(255) COLLATE pg_catalog."default",
    lang_code character varying(5) COLLATE pg_catalog."default",
    active boolean DEFAULT true,
    CONSTRAINT commentv2_pkey PRIMARY KEY (id),
    CONSTRAINT commentv2_ordersv2_id_fkey FOREIGN KEY (ordersv2_id)
        REFERENCES nissan_admin.ordersv2 (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT commentv2_reasonid_fkey FOREIGN KEY (reason_id)
        REFERENCES nissan_admin.reason (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);