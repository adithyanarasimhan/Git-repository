UPDATE nissan_admin.card_brand SET card_brand='口座振替' WHERE card_brand='Nicos' AND lang_code='jp';
UPDATE nissan_admin.card_brand SET card_brand='BANK' WHERE card_brand='Nicos' AND lang_code='en';