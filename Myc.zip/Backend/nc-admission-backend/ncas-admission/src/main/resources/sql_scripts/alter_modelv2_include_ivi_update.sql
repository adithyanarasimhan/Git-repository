ALTER TABLE nissan_admin.modelv2
ADD COLUMN ivi boolean;

UPDATE nissan_admin.modelv2 SET ivi=true where model_name NOT IN ('Skyline- HV37-450001 ~','Skyline- HNV37-550001 ~','Skyline- RV37-100001 ~ ','Leaf - ZE1-090001 ~','Note - E13-000001 ~','Note - FE13-000001 ~','Note - SNE13-000001 ~','Note - FSNE13-000001 ~');