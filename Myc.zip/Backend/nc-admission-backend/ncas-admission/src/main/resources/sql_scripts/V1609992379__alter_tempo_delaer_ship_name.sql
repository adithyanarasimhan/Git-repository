ALTER TABLE nissan_admin.tempo_net DROP COLUMN IF EXISTS dealerShipName;
ALTER TABLE nissan_admin.tempo_net ADD COLUMN IF NOT EXISTS dealership_name character varying(50);