INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(1, 'ダークメタルグレー（Ｍ） / スーパーブラック　2トーン', 'GAQ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_GAQ.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(2, 'ブリリアントシルバー（Ｍ） / スーパーブラック　2トーン', 'XBF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_XBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(3, 'プレミアムホライズンオレンジ（PM）/スーパーブラック 2トーン', 'GAP', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_GAP.png', NULL, NULL, NULL, NULL, 'リーフ（2020年1月以前）', '', 'jp', 'リーフ（2020年1月以前）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(4, 'ブリリアントシルバー（Ｍ）', 'K23', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_K23.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(5, 'ブリリアントシルバー（Ｍ） / スーパーブラック　2トーン', 'XBF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_XBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(6, 'スーパーブラック', 'KH3', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KH3.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(7, 'ガーネットレッド（ＣＰ）', 'NBF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_NBF.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(8, 'ブリリアントホワイトパール（３Ｐ）', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_QAB.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(9, 'オーロラフレアブルーパール（Ｐ）', 'RAY', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_RAY.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(10, 'スーパーブラック/ダークメタルグレー（M） 2トーン', 'XAE', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XAE.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(11, 'ブリリアントホワイトパール（３Ｐ） / スーパーブラック　2トーン', 'XBJ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBJ.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(12, 'ブリリアントホワイトパール（3P）/オーロラフレアブルーパール（P） 2トーン', 'XBK', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBK.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(13, 'サンライトイエロー（Ｐ） / スーパーブラック　2トーン', 'XBL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBL.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(14, 'ガーネットレッド（ＣＰ） / スーパーブラック　2トーン', 'XBT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBT.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(15, 'ビビッドブルー（M）/スーパーブラック 2トーン', 'XEH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEH.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(16, 'ステルスグレー（P）/スーパーブラック 2トーン', 'XEX', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEX.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(17, 'オーロラフレアブルーパール（Ｐ） / スーパーブラック　2トーン', 'XGN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G09_XGN.png', NULL, NULL, NULL, NULL, 'リーフ（2020年2月～）', '', 'jp', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(18, 'メテオフレークブラックパール（Ｐ）', 'GAG', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_GAG.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '黒', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(19, 'ダークメタルグレー（Ｍ）', 'KAD', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KAD.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', 'グレー', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(20, 'スーパーブラック　', 'KH3', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KH3.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '黒', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(21, 'カーマインレッド（ＣＭ）', 'NBA', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_NBA.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '赤', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(22, 'ブリリアントホワイトパール（３Ｐ）', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_QAB.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '白', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(23, 'ディープオーシャンブルー（Ｐ）', 'RCJ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_RCJ.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '青', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(24, 'スレートグレー（ＰＭ）', 'KBZ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G28_KBZ.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '灰', 'jp', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(25, 'ブリリアントホワイトパール（３Ｐ）', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_QAB.png', NULL, NULL, NULL, NULL, 'スカイライン（2019年9月～）', '白', 'jp', NULL);
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(26, 'プレミアムサンシャインオレンジ（M）', 'EBT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_EBT.png', NULL, NULL, NULL, NULL, 'デイズ', '橙', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(27, 'ブラック（P）', 'GAS', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_GAS.png', NULL, NULL, NULL, NULL, 'デイズ', '黒', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(28, 'チタニウムグレー（M）', 'KBW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_KBW.png', NULL, NULL, NULL, NULL, 'デイズ', '炭', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(29, 'アメジストパープル（P）', 'LAL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_LAL.png', NULL, NULL, NULL, NULL, 'デイズ', '紫', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(30, 'スパークリングレッド（PM）', 'NBR', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_NBR.png', NULL, NULL, NULL, NULL, 'デイズ', '赤', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(31, 'ホワイトパール（3P） ', 'QBB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_QBB.png', NULL, NULL, NULL, NULL, 'デイズ', '白', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(32, 'アトランティックブルー（PM）', 'RCH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_RCH.png', NULL, NULL, NULL, NULL, 'デイズ', '青', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(33, 'スパークリングレッド（PM）/ブラック（P）2トーン', 'XCF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCF.png', NULL, NULL, NULL, NULL, 'デイズ', '赤黒', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(34, 'ソーダブルー（M）/アッシュブラウン（M）2トーン', 'XCH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCH.png', NULL, NULL, NULL, NULL, 'デイズ', '茶水色', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(35, 'アッシュブラウン（M）/フローズンバニラパール（M）2トーン', 'XCK', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCK.png', NULL, NULL, NULL, NULL, 'デイズ', '白茶', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(36, 'ホワイトパール（3P）/プレミアムサンシャインオレンジ（M）2トーン', 'XDT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XDT.png', NULL, NULL, NULL, NULL, 'デイズ', '橙白', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(37, 'チタニウムグレー（M）/ブラック（P）2トーン', 'XFS', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XFS.png', NULL, NULL, NULL, NULL, 'デイズ', '灰', 'jp', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(38, 'ブリリアントホワイトパール（3P）', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/G64_QAB.png', NULL, NULL, NULL, NULL, 'エルグランド', '', 'jp', 'エルグランド');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(39, 'プレミアムブラウン（M） ', 'CAN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/G10_CAN.png', NULL, NULL, NULL, NULL, 'フーガ', '', 'jp', 'フーガ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(40, 'チタニウムカーキ（PM）', 'EAN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAN.png', NULL, NULL, NULL, NULL, 'キックス', '緑', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(41, 'サンライトイエロー（P）', 'EAV', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAV.png', NULL, NULL, NULL, NULL, 'キックス', '黄', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(42, 'プレミアムホライズンオレンジ（PM） ', 'EBB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EBB.png', NULL, NULL, NULL, NULL, 'キックス', '橙', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(43, 'ピュアブラック（PM）', 'G42', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_G42.png', NULL, NULL, NULL, NULL, 'キックス', '黒', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(44, 'ナイトベールパープル（TP）', 'GAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_GAB.png', NULL, NULL, NULL, NULL, 'キックス', '黒', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(45, 'ブリリアントシルバー（M）', 'K23', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_K23.png', NULL, NULL, NULL, NULL, 'キックス', '銀', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(46, 'ラディアントレッド（P）', 'NAH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_NAH.png', NULL, NULL, NULL, NULL, 'キックス', '赤', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(47, 'ダークブルー（PM）', 'RAA', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_RAA.png', NULL, NULL, NULL, NULL, 'キックス', '青', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(135, 'ブリリアントホワイトパール（3PM）/ピュアブラック（PM） 2トーン', 'XDN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XDN.png', NULL, NULL, NULL, NULL, 'キックス', '白黒', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(48, 'プレミアムホライズンオレンジ（PM）/ピュアブラック（PM）2トーン', 'XFP', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFP.png', NULL, NULL, NULL, NULL, 'キックス', '橙', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(49, 'ラディアントレッド（P）/ピュアブラック（PM）2トーン', 'XFY', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFY.png', NULL, NULL, NULL, NULL, 'キックス', '赤黒', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(50, 'ダークメタルグレー（M）/ピュアブラック（PM）2トーン', 'XFZ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFZ.png', NULL, NULL, NULL, NULL, 'キックス', '炭黒', 'jp', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(51, 'NOTE', 'XBT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/G87_XBT.png', NULL, NULL, NULL, NULL, 'NOTE', '', 'jp', 'NOTE');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(52, 'アッシュブラウン（M）', 'CBA', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_CBA.png', NULL, NULL, NULL, NULL, 'ルークス', '茶', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(53, 'ブラック（P）', 'GAS', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_GAS.png', NULL, NULL, NULL, NULL, 'ルークス', '黒', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(54, 'フローズンバニラパール（M）', 'HAK', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_HAK.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(55, 'チタニウムグレー（M）', 'KBW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_KBW.png', NULL, NULL, NULL, NULL, 'ルークス', '炭', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(56, 'アメジストパープル（PM）', 'LAL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_LAL.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(57, 'スパークリングレッド（PM）', 'NBR', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_NBR.png', NULL, NULL, NULL, NULL, 'ルークス', '赤', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(58, 'ホワイトパール（3P） ', 'QBB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_QBB.png', NULL, NULL, NULL, NULL, 'ルークス', '白', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(59, 'アトランティックブルー（PM）', 'RCH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_RCH.png', NULL, NULL, NULL, NULL, 'ルークス', '青', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(60, 'スパークリングレッド（PM）/ブラック（P）2トーン ', 'XCF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XCF.png', NULL, NULL, NULL, NULL, 'ルークス', '赤黒', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(61, 'ホワイトパール（3P）/チタニウムグレー（M）2トーン ', 'XEL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEL.png', NULL, NULL, NULL, NULL, 'ルークス', '白', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(62, 'アメジストパープル（PM）/フローズンバニラパール（M）2トーン', 'XEM', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEM.png', NULL, NULL, NULL, NULL, 'ルークス', '紫', 'jp', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(63, 'ブリリアントホワイトパール（3P）', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/G01_QAB.png', NULL, NULL, NULL, NULL, 'ティアナ', '', 'jp', 'ティアナ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(64, 'X-TRAIL', 'RAW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G59_RAW.png', NULL, NULL, NULL, NULL, 'X-TRAIL', '', 'jp', 'X-TRAIL');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(65, 'X-TRAIL', 'RAW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G85_RAW.png', NULL, NULL, NULL, NULL, 'X-TRAIL', '', 'jp', 'X-TRAIL');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(66, 'X-TRAIL', 'RAW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G86_RAW(2WD).png', NULL, NULL, NULL, NULL, 'X-TRAIL', '', 'jp', 'X-TRAIL');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(67, 'シャイニングブルー（PM）', 'RAW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G87_RAW(4WD).png', NULL, NULL, NULL, NULL, 'エクストレイル', '', 'jp', 'エクストレイル');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(68, 'Garnet Black (P)', 'GAC', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/Folder Name/G01_GAC.png', NULL, NULL, NULL, NULL, 'Cima', '', 'en', 'シーマ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(69, 'Brilliant White Pearl (3P)', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/CIMA/G64_QAB.png', NULL, NULL, NULL, NULL, 'Elgrand', '', 'en', 'エルグランド');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(70, 'Premium brown (M)', 'CAN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/G10_CAN.png', NULL, NULL, NULL, NULL, 'Fuga', '', 'en', 'フーガ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(71, 'Premium Horizon Orange (PM) / Super Black 2 Tone', 'GAP', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/G07_GAP.png', NULL, NULL, NULL, NULL, 'Leaf (before January 2020)', '', 'en', 'リーフ（2020年1月以前）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(72, 'Brilliant White Pearl (3P)', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G01_QAB.png', NULL, NULL, NULL, NULL, 'Teana', '', 'en', 'ティアナ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(73, 'Shining Blue (PM)', 'RAW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/G87_RAW(4WD).png', NULL, NULL, NULL, NULL, 'X-Trail', '', 'en', 'エクストレイル');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(74, 'Premium Sunshine Orange (M)', 'EBT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/G04_EBT.png', NULL, NULL, NULL, NULL, 'Dayz', 'Orange', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(75, 'Black (P)', 'GAS', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_GAS.png', NULL, NULL, NULL, NULL, 'Dayz', 'Black', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(76, 'Titanium Gray (M)', 'KBW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_KBW.png', NULL, NULL, NULL, NULL, 'Dayz', 'Charcoal', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(77, 'Amethyst Purple (P)', 'LAL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_LAL.png', NULL, NULL, NULL, NULL, 'Dayz', 'Purple', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(78, 'Sparkling red (PM)', 'NBR', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_NBR.png', NULL, NULL, NULL, NULL, 'Dayz', 'Red', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(79, 'White pearl (3P)', 'QBB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_QBB.png', NULL, NULL, NULL, NULL, 'Dayz', 'White', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(80, 'Atlantic Blue (PM)', 'RCH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_RCH.png', NULL, NULL, NULL, NULL, 'Dayz', 'Blue', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(81, 'Sparkling red (PM) / black (P) 2 tones', 'XCF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCF.png', NULL, NULL, NULL, NULL, 'Dayz', 'Red Black', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(82, 'Soda Blue (M) / Ash Brown (M) 2 Tones', 'XCH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCH.png', NULL, NULL, NULL, NULL, 'Dayz', 'Brown Light blue', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(83, 'Ash Brown (M) / Frozen Vanilla Pearl (M) 2 Tones', 'XCK', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XCK.png', NULL, NULL, NULL, NULL, 'Dayz', 'Light brown', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(84, 'White Pearl (3P) / Premium Sunshine Orange (M) 2 Tones', 'XDT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XDT.png', NULL, NULL, NULL, NULL, 'Dayz', 'Orange white', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(85, 'Titanium Gray (M) / Black (P) 2 Tones', 'XFS', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G04_XFS.png', NULL, NULL, NULL, NULL, 'Dayz', 'Ash', 'en', 'デイズ');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(86, 'Titanium khaki (PM)', 'EAN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/G02_EAN.png', NULL, NULL, NULL, NULL, 'Kicks', 'Green', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(87, 'Sunlight Yellow (P)', 'EAV', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EAV.png', NULL, NULL, NULL, NULL, 'Kicks', 'Yellow', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(88, 'Premium Horizon Orange (PM)', 'EBB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_EBB.png', NULL, NULL, NULL, NULL, 'Kicks', 'Green', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(89, 'Pure Black (PM)', 'G42', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_G42.png', NULL, NULL, NULL, NULL, 'Kicks', 'Black', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(90, 'Knight Veil Purple (TP)', 'GAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_GAB.png', NULL, NULL, NULL, NULL, 'Kicks', 'Black', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(91, 'Brilliant Silver (M)', 'K23', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_K23.png', NULL, NULL, NULL, NULL, 'Kicks', 'Silver', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(92, 'Radiant Red (P)', 'NAH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_NAH.png', NULL, NULL, NULL, NULL, 'Kicks', 'Red', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(93, 'Brilliant White Pearl (3PM)', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_QAB.png', NULL, NULL, NULL, NULL, 'Kicks', 'White', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(94, 'Dark blue (PM)', 'RAA', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_RAA.png', NULL, NULL, NULL, NULL, 'Kicks', 'Blue', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(95, 'Brilliant White Pearl (3PM) / Pure Black (PM) 2 Tones', 'XDN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XDN.png', NULL, NULL, NULL, NULL, 'Kicks', 'Black and White', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(96, 'Premium Horizon Orange (PM) / Pure Black (PM) 2 Tone', 'XFP', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFP.png', NULL, NULL, NULL, NULL, 'Kicks', 'Orange', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(97, 'Radiant Red (P) / Pure Black (PM) 2 Tone', 'XFY', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFY.png', NULL, NULL, NULL, NULL, 'Kicks', 'Red Black', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(98, 'Dark metal gray (M) / pure black (PM) 2 tones', 'XFZ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G02_XFZ.png', NULL, NULL, NULL, NULL, 'Kicks', 'Charcoal Black', 'en', 'キックス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(99, 'Ash brown (M)', 'CBA', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/KICKS/G05_CBA.png', NULL, NULL, NULL, NULL, 'Roox', 'Brown', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(100, 'Black (P)', 'GAS', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_GAS.png', NULL, NULL, NULL, NULL, 'Roox', 'Black', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(101, 'Frozen vanilla pearl (M)', 'HAK', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_HAK.png', NULL, NULL, NULL, NULL, 'Roox', 'Purple', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(102, 'Titanium Gray (M)', 'KBW', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_KBW.png', NULL, NULL, NULL, NULL, 'Roox', 'Charcoal', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(103, 'Amethyst Purple (PM)', 'LAL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_LAL.png', NULL, NULL, NULL, NULL, 'Roox', 'Purple', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(104, 'Sparkling red (PM)', 'NBR', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_NBR.png', NULL, NULL, NULL, NULL, 'Roox', 'Red', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(105, 'White pearl (3P)', 'QBB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_QBB.png', NULL, NULL, NULL, NULL, 'Roox', 'White', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(106, 'Atlantic Blue (PM)', 'RCH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_RCH.png', NULL, NULL, NULL, NULL, 'Roox', 'Blue', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(107, 'Sparkling red (PM) / black (P) 2 tones', 'XCF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XCF.png', NULL, NULL, NULL, NULL, 'Roox', 'Red Black', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(108, 'White Pearl (3P) / Titanium Gray (M) 2 Tones', 'XEL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEL.png', NULL, NULL, NULL, NULL, 'Roox', 'White', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(109, 'Amethyst Purple (PM) / Frozen Vanilla Pearl (M) 2 Tones', 'XEM', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G05_XEM.png', NULL, NULL, NULL, NULL, 'Roox', 'Purple', 'en', 'ルークス');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(110, 'Premium Horizon Orange (PM) / Super Black 2 Tone', 'GAP', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/G07_GAP.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(111, 'Brilliant Silver (M)', 'K23', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_K23.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(112, 'Dark metal gray (M)', 'KAD', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KAD.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(113, 'Super black', 'KH3', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_KH3.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(114, 'Garnet Red (CP)', 'NBF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_NBF.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(115, 'Brilliant White Pearl (3P)', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_QAB.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(116, 'Aurora Flare Blue Pearl (P)', 'RAY', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_RAY.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(117, 'Super Black / Dark Metal Gray (M) 2 Tones', 'XAE', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XAE.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(118, 'Brilliant White Pearl (3P) / Super Black 2 Tone', 'XBJ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBJ.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(119, 'Brilliant White Pearl (3P) / Aurora Flare Blue Pearl (P) 2 Tones', 'XBK', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBK.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(120, 'Sunlight Yellow (P) / Super Black 2 Tones', 'XBL', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBL.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(121, 'Garnet Red (CP) / Super Black 2 Tone', 'XBT', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XBT.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(122, 'Vivid Blue (M) / Super Black 2 Tone', 'XEH', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEH.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(123, 'Stealth Gray (P) / Super Black 2 Tone', 'XEX', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G07_XEX.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(124, 'Dark metal gray (M) / Super black 2 tone', 'GAQ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_GAQ.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(125, 'Brilliant Silver (M) / Super Black 2 Tone', 'XBF', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G05_XBF.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(126, 'Aurora Flare Blue Pearl (P) / Super Black 2 Tone', 'XGN', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G09_XGN.png', NULL, NULL, NULL, NULL, 'Leaf (From February 2020)', '', 'en', 'リーフ（2020年2月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(127, 'Meteor Flake Black Pearl (P)', 'GAG', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF/G19_GAG.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'Black', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(128, 'Dark metal gray (M)', 'KAD', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KAD.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'Gray', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(129, 'Super black', 'KH3', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_KH3.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'Black', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(130, 'Carmine Red (CM)', 'NBA', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_NBA.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'Red', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(131, 'Brilliant White Pearl (3P)', 'QAB', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_QAB.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'White', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(132, 'Deep Ocean Blue (P)', 'RCJ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G19_RCJ.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'Blue', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(133, 'Slate gray (PM)', 'KBZ', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE/G28_KBZ.png', NULL, NULL, NULL, NULL, 'Skyline (From September 2019)', 'Ash', 'en', 'スカイライン（2019年9月～）');
INSERT INTO nissan_admin.color
(id, color, color_code, image_url, created_by, created_date, last_modified_by, last_modified_date, model_name, sos_color, lang_code, cw_model_name)
VALUES(134, '', 'r c', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE/under confirmaing', NULL, NULL, NULL, NULL, 'Note(From December 2020)', '', 'en', 'ノート（2020年12月～）');
