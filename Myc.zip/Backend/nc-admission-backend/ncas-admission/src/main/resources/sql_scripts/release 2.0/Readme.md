### DB changes for Release 2.0 - 29/03/2021

- DDL script for Digital Admission Phase 2 related tables.
- DML script for populating Digital Admission Phase 2 and Phase 1 master data.
- Bank code master data uploaded in below confluence page
https://confluence.aws.na.nissancloud.biz/pages/viewpage.action?spaceKey=APX0091&title=DB+scripts