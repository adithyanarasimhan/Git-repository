INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url, vehicle_type) VALUES
('e-NV200', 'e-NV200', 'e-NV200', 'en', null, 'common'),
('e-NV200', 'e-NV200', 'e-NV200', 'jp', null, 'common');


INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'GX', 'GX', 'GX', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'GX', 'GX', 'GX', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'G', 'G', 'G', 'en', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code, vehicle_type)
(SELECT id, 'G', 'G', 'G', 'jp', 'common' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='GX' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='GX' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'm-op', 'MOP', 'メーカーオプション', 'en', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'm-op', 'メーカーオプション', 'メーカーオプション', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '2200', 'en', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '2200', 'jp', 'pattern-one', 'pattern-six', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-six', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-six', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='G' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='e-NV200' AND lang_code='jp')));