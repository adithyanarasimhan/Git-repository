--new car (no vin changes)
DELETE FROM nissan_admin.package_plan where category='vin';
ALTER TABLE nissan_admin.package_plan DROP COLUMN category;
UPDATE nissan_admin.package_plan set package_plan_name='basic-operator-service' where package_plan_name='operator-service';
UPDATE nissan_admin.package_plan set display_name='Basic service + operator service' where display_name='Operator Service';
UPDATE nissan_admin.package_plan set display_name='基本サービス + オペレーターサービス' where display_name='オペレーターサービス';


truncate nissan_admin.admission cascade;
truncate nissan_admin.admissionv2 cascade;
truncate nissan_admin.activity_logv2;

--new car (with vin changes)

DELETE FROM nissan_admin.package_planv2 where package_plan_name='standard' and lang_code='en' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[HYBRID]　GT/GT Type P/GT Type SP' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Skyline (From September 2019)' and lang_code='en')));

DELETE FROM nissan_admin.package_planv2 where package_plan_name='standard' and lang_code='jp' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[HYBRID]　GT/GT Type P/GT Type SP' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='スカイライン（2019年9月～）' and lang_code='jp')));


DELETE FROM nissan_admin.package_planv2 where package_plan_name='propilot' and lang_code='en' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='en' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' and lang_code='en' and model_id in (select id from nissan_admin.modelv2 where model_name='Skyline (From September 2019)' and lang_code='en')));

DELETE FROM nissan_admin.package_planv2 where package_plan_name='propilot' and lang_code='jp' and navi_id in (select id from nissan_admin.naviv2 where navi_name='m-op' and lang_code='jp' and grade_id in (select id from nissan_admin.gradev2 where grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' and lang_code='jp' and model_id in (select id from nissan_admin.modelv2 where model_name='スカイライン（2019年9月～）' and lang_code='jp')));

UPDATE nissan_admin.modelv2 set category=true where model_name='Skyline (From September 2019)' and lang_code='en';
UPDATE nissan_admin.modelv2 set category=true where model_name='スカイライン（2019年9月～）' and lang_code='jp';
UPDATE nissan_admin.modelv2 set category=true where model_name='Leaf (from February 2020)' and lang_code='en';
UPDATE nissan_admin.modelv2 set category=true where model_name='リーフ（2020年2月～）' and lang_code='jp';

--Add vehicle Type Column

ALTER TABLE nissan_admin.modelv2 ADD COLUMN vehicle_type character varying(10) DEFAULT 'common';
ALTER TABLE nissan_admin.gradev2 ADD COLUMN vehicle_type character varying(10) DEFAULT 'common';
ALTER TABLE nissan_admin.naviv2 ADD COLUMN vehicle_type character varying(10) DEFAULT 'common';
ALTER TABLE nissan_admin.package_planv2 ADD COLUMN vehicle_type character varying(10) DEFAULT 'usedcar';
ALTER TABLE nissan_admin.optionsv2 ADD COLUMN vehicle_type character varying(10) DEFAULT 'common';
ALTER TABLE nissan_admin.ordersv2 ADD COLUMN vehicle_type character varying(10);

UPDATE nissan_admin.naviv2 set vehicle_type='usedcar' where navi_name='na' AND grade_id IN (SELECT id from nissan_admin.gradev2 where grade_name='NOGRADE' AND model_id IN (SELECT id from nissan_admin.modelv2 WHERE model_name='Others' or model_name='その他'));

ALTER TABLE nissan_admin.package_planv2 DROP CONSTRAINT package_planv2_pkey;

--Insert package plans for new car with vin
--Skyline
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'propilot', 'Pro Pilot Plan', 'プロパイロットプラン', '24200', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'propilot', 'プロパイロットプラン', 'プロパイロットプラン', '24200', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[HYBRID]　GT/GT Type P/GT Type SP' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Skyline (From September 2019)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='[TURBO]　GT/GT Type P/GT Type SP/400R' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp')));

--Leaf February
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (from February 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp')));

--Leaf january
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'Standard Plan', 'スタンダードプラン', '6600', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Leaf (before January 2020)' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'standard', 'スタンダードプラン', 'スタンダードプラン', '6600', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp')));


--DAYZ
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

UPDATE nissan_admin.gradev2 SET grade_name='NOGRADE' WHERE grade_name='All Grades' or grade_name='全グレード';

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op', 'ディーラーオプション', 'ディーラーオプション', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '0', '0', 'en', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op+s-os', 'ディーラーオプション（SOSコールボタン無）', 'ディーラーオプション（SOSコールボタン無）', 'jp', 'common' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '0', '0', 'jp', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));


--ROOX
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='S' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '0', '0', 'en', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '0', '0', 'jp', 'pattern-three', 'pattern-four', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/Other (other than S)' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Roox' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', null, 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='X/G/その他(S以外)' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ルークス' AND lang_code='jp')));


--Kicks
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', 'Basic Service + SOS', '基本サービス＋SOSコール申込み', '0', '0', 'en', 'pattern-three', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-sos', '基本サービス＋SOSコール申込み', '基本サービス＋SOSコール申込み', '0', '0', 'jp', 'pattern-three', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op+s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Kicks' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-two', 'pattern-two', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='キックス' AND lang_code='jp')));


--X-TRAIL
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic Service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='X-Trail' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-one', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エクストレイル' AND lang_code='jp')));


--Elgrand
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic Service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Elgrand' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='エルグランド' AND lang_code='jp')));


--Teana
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV Navi AVM Package / XL Navi AVM Package' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XV ナビAVM パッケージ/XL ナビAVM パッケージ' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='TEANA' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='XL' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='ティアナ' AND lang_code='jp')));


--Fuga
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '3300', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Fuga' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '3300', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='フーガ' AND lang_code='jp')));


--Cima
INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', 'Basic service + operator service', '基本サービス + オペレーターサービス', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Cima' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic-operator-service', '基本サービス + オペレーターサービス', '基本サービス + オペレーターサービス', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='m-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='シーマ' AND lang_code='jp')));

--Others
INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op', 'DOP', 'ディーラーオプション ', 'en', 'newcar' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type)
(SELECT id, 'd-op', 'ディーラーオプション ', 'ディーラーオプション ', 'jp', 'newcar' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-three', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='d-op' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));