INSERT INTO nissan_admin.color(color, color_code, image_url) VALUES
('Orange', '#ED8D20', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF+(January+2020+~)/image.png'),
('Garnet Red', '#840000', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE+(September+2019+~)/image.png'),
('Silver', '#E8E3E3', 'https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/TEANA/image.png');