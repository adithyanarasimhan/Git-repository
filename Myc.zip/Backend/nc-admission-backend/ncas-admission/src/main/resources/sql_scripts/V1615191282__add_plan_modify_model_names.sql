INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 's-os', 'SOS', 'ナビなし（SOSコールボタン有）', 'en', 'common', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code, vehicle_type, color_option)
(SELECT id, 's-os', 'ナビなし（SOSコールボタン有）', 'ナビなし（SOSコールボタン有）', 'jp', 'common', true FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));



INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '0', 'en', 'pattern-one', 'pattern-five', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '0', 'jp', 'pattern-one', 'pattern-five', 'newcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOS', 'SOSコールのみ申込み', '0', '2200', 'en', 'pattern-one', 'pattern-five', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Dayz' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name, vehicle_type)
(SELECT id, 'sos', 'SOSコールのみ申込み', 'SOSコールのみ申込み', '0', '2200', 'jp', 'pattern-one', 'pattern-five', 'usedcar' FROM nissan_admin.naviv2 n WHERE n.navi_name='s-os' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='NOGRADE' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='デイズ' AND lang_code='jp')));



UPDATE nissan_admin.modelv2 set model_name='スカイライン（2019年9月発売）', display_name='スカイライン（2019年9月発売）' WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Skyline (released in September 2019)', display_name='Skyline (released in September 2019)' WHERE model_name='Skyline (From September 2019)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年2月発売）', display_name='リーフ（2020年2月発売）' WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (released in February 2020)', display_name='Leaf (released in February 2020)' WHERE model_name='Leaf (from February 2020)' AND lang_code='en';

UPDATE nissan_admin.modelv2 set model_name='リーフ（2020年1月以前発売）', display_name='リーフ（2020年1月以前発売）' WHERE model_name='リーフ（2020年1月以前）' AND lang_code='jp';

UPDATE nissan_admin.modelv2 set model_name='Leaf (released before January 2020)', display_name='Leaf (released before January 2020)' WHERE model_name='Leaf (before January 2020)' AND lang_code='en';



UPDATE nissan_admin.model set model_name='スカイライン（2019年9月発売）', display_name='スカイライン（2019年9月発売）' WHERE model_name='スカイライン（2019年9月～）' AND lang_code='jp';

UPDATE nissan_admin.model set model_name='Skyline (released in September 2019)', display_name='Skyline (released in September 2019)' WHERE model_name='SKYLINE (September 2019 ~)' AND lang_code='en';

UPDATE nissan_admin.model set model_name='リーフ（2020年2月発売）', display_name='リーフ（2020年2月発売）' WHERE model_name='リーフ（2020年2月～）' AND lang_code='jp';

UPDATE nissan_admin.model set model_name='Leaf (released in February 2020)', display_name='Leaf (released in February 2020)' WHERE model_name='LEAF (January 2020 ~)' AND lang_code='en';