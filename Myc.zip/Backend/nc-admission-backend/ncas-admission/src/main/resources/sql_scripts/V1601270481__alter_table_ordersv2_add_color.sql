ALTER TABLE nissan_admin.ordersv2
ADD COLUMN IF NOT EXISTS color character varying(30);

ALTER TABLE nissan_admin.ordersv2
ADD COLUMN IF NOT EXISTS color_code character varying(30);