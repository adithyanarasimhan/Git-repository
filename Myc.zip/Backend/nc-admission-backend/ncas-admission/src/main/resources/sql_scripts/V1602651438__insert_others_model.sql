INSERT INTO nissan_admin.modelv2(model_name, display_name, cw_model_name, lang_code, url) VALUES
('Others', 'Others', 'その他', 'en', null),
('その他', 'その他', 'その他', 'jp', null);

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, 'All Grades', 'All Grades', '全グレード', 'en' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en'));

INSERT INTO nissan_admin.gradev2(model_id, grade_name, display_name, cw_grade_name, lang_code)
(SELECT id, '全グレード', '全グレード', '全グレード', 'jp' FROM nissan_admin.modelv2 WHERE id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp'));


INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'Not applicable / No Navi Type', 'お申込み不可', 'en' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.naviv2 (grade_id, navi_name, display_name, cw_navi_name, lang_code)
(SELECT id, 'na', 'お申込み不可', 'お申込み不可', 'jp' FROM nissan_admin.gradev2 WHERE id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));


INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', 'Basic Service', '基本サービスのみ申込み', '5500', '2200', 'en', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='na' AND n.lang_code='en' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='All Grades' AND g.lang_code='en' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='Others' AND lang_code='en')));

INSERT INTO nissan_admin.package_planv2(navi_id, package_plan_name, display_name, cw_package_plan_name, price, admin_fee, lang_code, terms_name, pattern_name)
(SELECT id, 'basic', '基本サービスのみ申込み', '基本サービスのみ申込み', '5500', '2200', 'jp', 'pattern-one', 'pattern-three' FROM nissan_admin.naviv2 n WHERE n.navi_name='na' AND n.lang_code='jp' AND n.grade_id IN (SELECT id FROM nissan_admin.gradev2 g WHERE g.grade_name='全グレード' AND g.lang_code='jp' AND g.model_id IN (SELECT id FROM nissan_admin.modelv2 WHERE model_name='その他' AND lang_code='jp')));