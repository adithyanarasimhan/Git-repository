package com.nissan.democar.dto;

import com.nissan.common.dto.DealerDTO;
import com.nissan.common.entity.DemoCarModel;
import com.nissan.common.entity.DemoCarPackagePlan;

import lombok.Data;

@Data
public class VinInformationDTO {
    private DemoCarVinDetailsDto vinDetails;
    private DemoCarPackagePlan packagePlan;
    private DemoCarDealerDto dealerDetails;
    private DemoCarModel model;
}
