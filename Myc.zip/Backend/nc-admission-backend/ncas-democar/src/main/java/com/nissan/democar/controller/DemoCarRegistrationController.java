package com.nissan.democar.controller;

import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.VinDetails;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.VinDetailsRepository;
import com.nissan.democar.dto.DemoCarFetchInitialRegDto;
import com.nissan.democar.dto.DemoCarSaveRegInfoDto;
import com.nissan.democar.dto.VinDeleteRequestDto;
import com.nissan.democar.service.VinDetailsService;
import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("secured/api/v1")
public class DemoCarRegistrationController {

    private static final Logger logger = LoggerFactory.getLogger(DemoCarRegistrationController.class);

    @Autowired
    VinDetailsService vinDetailsService;

    @Autowired
    DealerRepository dealerRepository;

    @Autowired
    VinDetailsRepository vinDetailsRepository;

    @GetMapping(value = "{langCode}/get-reg-initial-info")
    public ResponseEntity<ResponseDTO> getInitialInformationFoRegistration(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @RequestParam(name = "vin") String vin) {
        DemoCarFetchInitialRegDto demoCarFetchInitialRegDto = vinDetailsService.fetchInitialRegInfo(vin, langCode);
        if (demoCarFetchInitialRegDto != null) {
            logger.info("vin details retrieved successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "vin details retrieved  successfully");
            response.setData(demoCarFetchInitialRegDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "error in retrieving vin details in NCAS");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "{langCode}/save-reg-info")
    public ResponseEntity<ResponseDTO> saveDetailsForRegistration(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @RequestBody DemoCarSaveRegInfoDto demoCarSaveRegInfoDto) {
        String principalId = httpServletRequest.getHeader("principalId");
        DemoCarSaveRegInfoDto savedDemoCarSaveRegInfoDto = vinDetailsService.saveInfoFoRegistration(demoCarSaveRegInfoDto, principalId);

        if (savedDemoCarSaveRegInfoDto != null) {
            VinDetails vinDetails = vinDetailsRepository.findByVin(savedDemoCarSaveRegInfoDto.getVin());
            logger.info("Registration done successfully");
            String message;
            if ("en".equals(langCode)) {
                message = "Registration done  successfully";
            } else {
                message = "Nissan Connect登録申請が完了しました";
            }
            vinDetailsService.sendNcRegistrationCompleteMail(vinDetails, "", savedDemoCarSaveRegInfoDto.getAdmission().getId());
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", message);
            response.setData(savedDemoCarSaveRegInfoDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "error in doing registration in NCAS");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @DeleteMapping(
            value = "{langCode}/delete-vins",
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO> deleteVins(
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse,
            @PathVariable(name = "langCode") String langCode,
            @RequestBody VinDeleteRequestDto vinDeleteRequestDto) {
        logger.info("Inside deleteVins API");
        String principalId = httpServletRequest.getHeader("principalId");
        String status = vinDetailsService.deleteVins(vinDeleteRequestDto);
        if (Constants.SUCCESS.equals(status)) {
            logger.info("delete vin success");
            return new ResponseEntity<>(
                    new ResponseDTO(Constants.SUCCESS, "200", "Vins Deleted Successfully"), HttpStatus.OK);
        }
        return new ResponseEntity<>(
                new ResponseDTO(Constants.FAILED, "500", "Could not delete Vins"),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @GetMapping(
            value = "{langCode}/download-vins",
            produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<ResponseDTO> downloadVins(
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse,
            @PathVariable(name = "langCode") String langCode,
            @RequestParam(required = false, name = "startDate") String startDate,
            @RequestParam(required = false, name = "endDate") String endDate)
            throws IOException {
        logger.info("Inside download api");
        String principalId = httpServletRequest.getHeader("principalId");
        String status =
                vinDetailsService.downloadVins(
                        httpServletRequest, httpServletResponse, langCode, startDate, endDate);
        if (Constants.SUCCESS.equals(status)) {
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
                    .body(null);
        } else {
            return new ResponseEntity<>(
                    new ResponseDTO(Constants.FAILED, "404", "Csv not fetched"), HttpStatus.NOT_FOUND);
        }
    }


}
