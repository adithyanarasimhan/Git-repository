package com.nissan.democar;

import com.nissan.common.audit.SpringSecurityAuditorAware;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = "${ncas.components.scan}")
@EnableJpaRepositories(basePackages = {"com.nissan.common.repository", "com.nissan.democar.repository"})
@EntityScan(basePackages = {"com.nissan.common.entity","com.nissan.democar.entity"})
@EnableScheduling
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
public class DemoCarApplication {
    @Bean
    public AuditorAware<String> auditorAware() {
        return new SpringSecurityAuditorAware();
    }

    public static void main(String[] args) {
        SpringApplication.run(DemoCarApplication.class, args);
    }
}
