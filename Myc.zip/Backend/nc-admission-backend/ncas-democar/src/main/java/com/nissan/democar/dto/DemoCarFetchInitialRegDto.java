package com.nissan.democar.dto;

import com.nissan.common.dto.ModelDTO;
import lombok.Data;

import java.util.List;

@Data
public class DemoCarFetchInitialRegDto {
    private List<ModelDTO> models;
    private String vin;
    private String dealerName;
    private Boolean ivi;
    private String flagType;
    private Boolean icc;
    private List<String> carPlan;
}
