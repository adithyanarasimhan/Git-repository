package com.nissan.democar.dto;

import lombok.Data;

@Data
public class VinRequestDto {
    private String vinNumber;
    private Long testDriveId;
}
