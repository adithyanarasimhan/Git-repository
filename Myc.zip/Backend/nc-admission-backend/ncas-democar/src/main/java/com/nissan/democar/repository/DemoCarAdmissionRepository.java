package com.nissan.democar.repository;

import com.nissan.common.entity.DemoCarAdmission;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface DemoCarAdmissionRepository extends JpaRepository<DemoCarAdmission, Long>, QuerydslPredicateExecutor<DemoCarAdmission> {

    List<DemoCarAdmission> findByNcIdNotNullAndStatusNot(String status);

    DemoCarAdmission findByVin(String vin);

    DemoCarAdmission findByVinAndStatus(String vin, String status);

    List<DemoCarAdmission> findBySendToNloFalse();
}
