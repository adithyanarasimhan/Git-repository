package com.nissan.democar.service;

import com.nissan.common.dto.ResultDto;

import java.util.List;

public interface DemoCarCommunicationService {

    void receiveDataFromCompass();

    void existenceCheckVinInCw();

    void getNcIdAndPasswordFromCarWings();

    List<ResultDto> getResultDtos(List<String> vinList);

    void checkDemocarExpiry();

    void sendFileToNlo();

}
