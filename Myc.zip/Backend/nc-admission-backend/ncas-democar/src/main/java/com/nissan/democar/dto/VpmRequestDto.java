package com.nissan.democar.dto;

import lombok.Data;

@Data
public class VpmRequestDto {
    private String SysCode;
    private String ApiId;
    private String FormVersion;
    private String Requester;
    private VpmRequestKeyDto RequestKey;
    private VpmRequestItemDto RequestItem;
}
