package com.nissan.democar.dto;

import lombok.Data;

@Data
public class Notifications {
    private String message;
}
