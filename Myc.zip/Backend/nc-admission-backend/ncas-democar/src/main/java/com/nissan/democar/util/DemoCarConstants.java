package com.nissan.democar.util;

public class DemoCarConstants {

    public static final String SOURCE_COMPASS = "Compass";
    public static final String SOURCE_COMPASS_JP = "羅針盤";
    public static final String PAID = "Paid";
    public static final String PAID_JP = "有料";
    public static final String FREE = "Free";
    public static final String ICC_FREE = "Icc_Free";
    public static final String FREE_JP = "無料";
    public static final String SOURCE_UPLOAD = "Upload";
    public static final String SOURCE_UPLOAD_JP = "車台番号から登録";
    public static final String SOURCE_ADD_VIN = "ADD VIN";
    public static final String SOURCE_ADD_VIN_JP = "車台番号から登録";

    public static final String DEMO_CAR_PLAN = "Demo Car";
    public static final String DEMO_CAR_PLAN_JP = "試乗車";
    public static final String COMPANY_CAR_PLAN = "Company Car";
    public static final String COMPANY_CAR_PLAN_JP = "社用車";

    public static final String NOT_LINKED = "Not Linked";
    public static final String TO_BE_PUBLISHED = "To Be Published";
    public static final String PUBLIC = "Public";
    public static final String PRIVATE = "Private";
    public static final String MISMATCH = "Mismatch";

    public static final String STATUS_NOT_LINKED_CW = "Not linked(CW)";
    public static final String STATUS_NOT_LINKED_VPM = "Not Linked (VPM)";
    public static final String STATUS_NOT_LINKED_VPM_JP = "VPMとの連携がされていません";
    public static final String STATUS_NOT_LINKED_CW_JP = "CW未連携";
    public static final String STATUS_NOT_EXIST_CW = "Not exist(CW)";
    public static final String STATUS_NOT_EXIST_VPM = "Not exist(VPM)";
    public static final String STATUS_NOT_EXIST_VPM_JP = "VPMに登録されていません";
    public static final String STATUS_NOT_EXIST_CW_JP = "CW不存在";
    public static final String STATUS_CAN_PUBLISH = "Can Publish";
    public static final String STATUS_CAN_PUBLISH_JP = "公開可能";
    public static final String STATUS_NOT_APPLIED = "Not Applied";
    public static final String STATUS_NOT_APPLIED_JP = "未申請";
    public static final String STATUS_APPLYING = "Applying";
    public static final String STATUS_APPLYING_JP = "申請中";
    public static final String STATUS_IMPORT_FAILURE_CW = "Import Failure(CW)";
    public static final String STATUS_IMPORT_FAILURE_CW_JP = "NC登録失敗";
    public static final String STATUS_APPLYING_WAIT_COMP = "Applying(wait Compass)";
    public static final String STATUS_APPLYING_WAIT_COMP_JP = "申請中(羅針盤未連携)";
    public static final String STATUS_AVAILABLE = "Available";
    public static final String STATUS_AVAILABLE_JP = "貸出可能";
    public static final String STATUS_ON_LOAN = "On Loan";
    public static final String STATUS_ON_LOAN_JP = "貸出中";
    public static final String STATUS_PW_UPDATING = "PW Updating";
    public static final String STATUS_PW_UPDATING_JP = "PW更新中";
    public static final String STATUS_EMAIL_SENT = "Email Sent";
    public static final String STATUS_CANCELLED = "Cancelled";
    public static final String TD_STATUS_RUNNING = "Running";
    public static final String TD_STATUS_EXPIRED = "Expired";

    public static final String FLAG_TYPE_PRIVATE = "非公開";
    public static final String FLAG_TYPE_PUBLIC = "公開";
    public static final String FLAG_TYPE_MISMATCH = "公開非公開フラグエラー";
    public static final String FLAG_TYPE_NOT_LINKED = "未連携";
    public static final String FLAG_TYPE_TO_BE_PUBLISHED = "公開予定";

    public static final String DATE_PATTERN = "yyyy/MM/dd";
    public static final String EN = "en";
}
