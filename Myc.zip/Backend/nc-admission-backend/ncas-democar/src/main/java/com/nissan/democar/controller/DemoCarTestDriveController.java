package com.nissan.democar.controller;

import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.DemoCarAdmission;
import com.nissan.common.entity.VinDetails;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.VinDetailsRepository;
import com.nissan.common.util.Constants;
import com.nissan.democar.dto.*;
import com.nissan.democar.entity.DemoCarTestDrive;
import com.nissan.democar.repository.DemoCarTestDriveRepository;
import com.nissan.democar.service.TestDriveService;
import com.nissan.democar.service.VinDetailsService;
import com.nissan.democar.util.DemoCarConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static com.nissan.common.util.Constants.PRINCIPAL_ID;

@RestController
@RequestMapping("secured/api/v1")
public class DemoCarTestDriveController {

    private static final Logger logger = LoggerFactory.getLogger(DemoCarTestDriveController.class);

    @Autowired
    private TestDriveService testDriveService;

    @Autowired
    VinDetailsService vinDetailsService;
    @Autowired
    VinDetailsRepository vinDetailsRepository;

    @Autowired
    DealerRepository dealerRepository;

    @Autowired
    DemoCarTestDriveRepository demoCarTestDriveRepository;

    @PostMapping(value = "{langCode}/assign_to_customer")
    ResponseEntity<ResponseDTO> assignToCustomer(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @RequestBody AssignToCustomerDto assignToCustomerDto)
            throws ServletException, IOException {
        logger.info("Inside assign_to_customer");
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
        if (dealer == null) {
            logger.info("dealer not found");
            return new ResponseEntity<>(
                    new ResponseDTO(Constants.FAILED, "204", "Dealer not found"), HttpStatus.BAD_REQUEST);
        }
        DemoCarAdmission admission = testDriveService.assignToCustomer(dealer, langCode, assignToCustomerDto);
        if (admission != null) {
            VinDetails vinDetails = vinDetailsRepository.findByVin(admission.getVin());
            List<DemoCarTestDrive> testDrives = demoCarTestDriveRepository.findByAdmissionAndStatus(admission, DemoCarConstants.TD_STATUS_RUNNING);
            String startDate = null;
            String endDate = null;
            if (!CollectionUtils.isEmpty(testDrives)) {
                DemoCarTestDrive testDrive = testDrives.get(0);
                SimpleDateFormat formatter = new SimpleDateFormat(DemoCarConstants.DATE_PATTERN);
                startDate = formatter.format(testDrive.getStartDate()) + " " + testDrive.getStartTime().truncatedTo(ChronoUnit.MINUTES).toString();
                endDate = formatter.format(testDrive.getEndDate()) + " " + testDrive.getEndTime().truncatedTo(ChronoUnit.MINUTES).toString();
            }
            vinDetailsService.sendNcIdAndNcPasswordToCa(admission, vinDetails, startDate, endDate);
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Assigned to Customer");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            ResponseDTO response =
                    new ResponseDTO(Constants.FAILED, "500", "error");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping(value = "{langCode}/get_test_drive_info/{id}")
    ResponseEntity<ResponseDTO> getTestDriveInfo(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @PathVariable(name = "id") Long id)
            throws ServletException, IOException {
        logger.info("Inside get_test_drive_info");
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        TestDriveInfoDto testDriveInfoDto = testDriveService.getTestDriveInfo(langCode, id);
        if (testDriveInfoDto != null) {
            logger.info("Test Drive retrieved  successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Test Drive info retrieved  successfully");
            response.setData(testDriveInfoDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        if (testDriveInfoDto == null) {
            logger.info("No Test  Drive data for this id");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "No Test  Drive data for this id");
            response.setData(testDriveInfoDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "error in retrieving test drive data in NCAS");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @PostMapping(value = "{langCode}/extend_test_drive")
    ResponseEntity<ResponseDTO> extendTestDrive(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @RequestBody ExtendTestDriveDto extendTestDriveDto)
            throws ServletException, IOException {
        logger.info("Inside extend test drive ");
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        boolean status = testDriveService.extendTestDrive(langCode, extendTestDriveDto);
        if (status) {
            logger.info("Extended Test Drive succesfcwssfully");
            return new ResponseEntity<>(
                    new ResponseDTO(Constants.SUCCESS, "200", "Extended Test Drive successfully"), HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "No test drive for the given id");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @GetMapping(value = "{langCode}/get_customer_info/{id}")
    ResponseEntity<ResponseDTO> getCustomerInfo(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @PathVariable(name = "id") Long id)
            throws ServletException, IOException {
        logger.info("Inside get_test_drive_info");
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        CustomerInfoDto customerInfoDto = testDriveService.getCustomerInfo(langCode, id);
        if (customerInfoDto != null) {
            logger.info("Customer Info retrieved  successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Customer Info retrieved  successfully");
            response.setData(customerInfoDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "No customer is found by this Id in NCAS");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @GetMapping(value = "{langCode}/get_ncid_ncpassword/{id}")
    ResponseEntity<ResponseDTO> getNcIAndPassword(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @PathVariable(name = "id") Long id)
            throws ServletException, IOException {
        logger.info("Inside get_test_drive_info");
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        DemoCarNcIdPasswordDto ncIdAndPassword = testDriveService.getNcIdAndPassword(langCode, id);
        if (ncIdAndPassword != null) {
            logger.info("Nc Id and Nc Password retrieved  successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Nc Id and Nc Password retrieved  successfully");
            response.setData(ncIdAndPassword);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }

        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "No record is available in the system");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @GetMapping(value = "{langCode}/test_drive_history/{id}")
    ResponseEntity<ResponseDTO> fetchTestDriveHistory(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @PathVariable(name = "id") Long id)
            throws ServletException, IOException {
        logger.info("Inside test_drive_history");
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        List<TestDriveHistory> testDriveHistory = testDriveService.fetchTestDriveHistory(langCode, id);
        if (testDriveHistory != null && !testDriveHistory.isEmpty()) {
            logger.info("Test Drive History fetched  successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Test Drive History fetched  successfully");
            response.setData(testDriveHistory);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            logger.info("No Test Drive History fetched  successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "No Record found for the admission");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @GetMapping(value = "{langCode}/get_test_drive_details/{id}")
    ResponseEntity<ResponseDTO> getTestDriveDetails(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @PathVariable(name = "id") Long admissionId)
            throws ServletException, IOException {
        logger.info("Inside getTestDriveDetails : {}", admissionId);
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        TestDriveInfoDto testDriveInfoDto = testDriveService.getTestDriveDetails(langCode, admissionId);
        if (testDriveInfoDto != null) {
            logger.info("Test Drive Details retrieved successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Test Drive Details retrieved successfully");
            response.setData(testDriveInfoDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            logger.error("No Test Drive Details for {}", admissionId);
            ResponseDTO response =
                    new ResponseDTO(Constants.FAILED, "500", "No Test  Drive details for this id");
            response.setData(testDriveInfoDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }

    }

    @GetMapping(value = "{langCode}/test-drive/history/details/{id}")
    ResponseEntity<ResponseDTO> getTestDriveHistoryDetails(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @PathVariable(name = "id") Long admissionId)
            throws ServletException, IOException {
        logger.info("Inside getTestDriveDetails : {}", admissionId);
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        TestDriveHistoryDetailsDto testDriveHistoryDetails = testDriveService.getTestDriveHistoryDetails(langCode, admissionId);
        if (testDriveHistoryDetails != null) {
            logger.info("Test Drive History Details retrieved successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "Test Drive Details retrieved successfully");
            response.setData(testDriveHistoryDetails);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            logger.error("No Test Drive Details for {}", admissionId);
            ResponseDTO response =
                    new ResponseDTO(Constants.FAILED, "500", "No Test  Drive details for this id");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }

    }

}
