package com.nissan.democar.repository;

import com.nissan.common.entity.DemoCarGrade;
import com.nissan.common.entity.DemoCarModel;
import com.nissan.common.entity.Model;
import com.nissan.common.entity.ModelV2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface DemoCarModelRepository extends JpaRepository<DemoCarModel, Long>, QuerydslPredicateExecutor<DemoCarModel> {

    DemoCarModel findByCwModelNameAndLangCode(String cwModelName, String langCode);

    List<DemoCarModel> findByOrderByModelDisplayOrderAsc();

    @Query(value = "SELECT * FROM democar_model m where m.lang_code=?1 ORDER BY m.display_order ASC", nativeQuery = true)
    List<DemoCarModel> findByLangCodeOrderByModelDisplayOrderAsc(String langCode);

    DemoCarModel findByModelNameAndLangCode(String modelName, String langCode);
}
