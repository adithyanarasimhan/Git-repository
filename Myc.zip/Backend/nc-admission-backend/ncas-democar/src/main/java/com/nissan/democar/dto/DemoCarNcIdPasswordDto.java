package com.nissan.democar.dto;

import lombok.Data;

@Data
public class DemoCarNcIdPasswordDto {

    private String ncId;

    private String ncPassword;

    private String expirationDate;
}
