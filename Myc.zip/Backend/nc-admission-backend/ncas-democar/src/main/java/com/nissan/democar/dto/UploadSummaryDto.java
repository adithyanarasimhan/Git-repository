package com.nissan.democar.dto;

import lombok.Data;

@Data
public class UploadSummaryDto {
    private int totalRecords;
    private int skippedRecords;
    private int uploadedRecords;
}
