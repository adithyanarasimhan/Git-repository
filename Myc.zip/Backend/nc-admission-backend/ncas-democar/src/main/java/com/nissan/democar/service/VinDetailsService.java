package com.nissan.democar.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nissan.common.dto.DocommoMailDto;
import com.nissan.common.dto.ModelDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.DemoCarAdmission;
import com.nissan.common.entity.VinDetails;
import com.nissan.democar.dto.*;
import org.springframework.web.multipart.MultipartFile;

public interface VinDetailsService {
    Map<String, Object> saveVinDetails(MultipartFile file, String token, DealerEntity dealerEntity, String langCode) throws IOException;

    ListTakeActionVinDetailsDto fetchVinDetails(VinDetailsRequestDto vinDetailsDto, String langCode, String pricipalId);

    VinDetailsDto addSingleVin(VinDetailsDto takeActionVinDetailsDto, DealerEntity dealer, String langCode);

    DemoCarFetchInitialRegDto fetchInitialRegInfo(String vin, String langCode);

    DemoCarSaveRegInfoDto saveInfoFoRegistration(DemoCarSaveRegInfoDto demoCarSaveRegInfoDto, String principalId);

    VinInformationDTO fetchSingleVinDetails(HttpServletRequest httpServletRequest, String vinNumber, String langCode);

    void saveCompassVinDetails(File file) throws IOException;

    String deleteVins(VinDeleteRequestDto vinDeleteRequestDto);

    String downloadVins(HttpServletRequest httpServletRequest,
                        HttpServletResponse httpServletResponse,
                        String lang,
                        String startDate,
                        String endDate) throws IOException;

    List<ModelDTO> getModelInfo(String lang, String vin);

    List<StatusDto> getStatusInfo(String lang);

    void sendNotificationMail(VinDetails vinInfo, String status, Long ncid);

    List<PaidFreeDto> getPaidFreeInfo(String lang);

    List<RegistPattern> getRegistPatternInfo(String lang);

    List<PublicOrPrivateDto> getPublicPrivateInfo(String lang);

    void sendNcIdAndNcPasswordToCa(DemoCarAdmission admission, VinDetails vinInfo, String startDate, String endDate);

    List<VinDetailsDto> publishToCa(List<VinRequestDto> vinRequestList, String lang);

    VinDetailsDto markAsReturned(VinRequestDto returnedVin, String lang);

    void sendMailToDocommo(List<DocommoMailDto> docommoMailDtoList);

    void sendNcRegistrationCompleteMail(VinDetails vinInfo, String status, Long ncid);

}
