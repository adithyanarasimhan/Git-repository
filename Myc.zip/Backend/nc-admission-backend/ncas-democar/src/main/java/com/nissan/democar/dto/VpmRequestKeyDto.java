package com.nissan.democar.dto;

import lombok.Data;

import java.util.List;

@Data
public class VpmRequestKeyDto {
    private String region;
    private List<String> vin;
}
