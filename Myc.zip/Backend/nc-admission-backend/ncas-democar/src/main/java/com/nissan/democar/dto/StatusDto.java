package com.nissan.democar.dto;

import lombok.Data;

@Data
public class StatusDto {
    private String status;
    private String displayName;
}
