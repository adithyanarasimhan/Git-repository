package com.nissan.democar.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.collect.ImmutableList;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.nissan.common.config.CloudMapServiceResolver;
import com.nissan.common.dto.*;
import com.nissan.common.entity.*;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.TempoDotNetRepository;
import com.nissan.common.repository.UserRepository;
import com.nissan.common.repository.VinDetailsRepository;
import com.nissan.common.util.Constants;
import com.nissan.common.util.DemoCarUtil;
import com.nissan.democar.dto.*;
import com.nissan.democar.entity.DemoCarTestDrive;
import com.nissan.democar.repository.*;
import com.nissan.democar.service.VinDetailsService;
import com.nissan.democar.util.*;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.PathBuilder;
import com.querydsl.jpa.impl.JPAQuery;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.Range;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.*;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static com.nissan.common.util.Constants.HTTP;
import static com.nissan.common.util.Constants.PRINCIPAL_ID;
import static java.time.temporal.ChronoUnit.DAYS;

@Service
public class VinDetailsServiceImpl implements VinDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(VinDetailsServiceImpl.class);
    private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(VinDetailsServiceImpl.class);
    public static final String DEMO_CAR = "Demo Car";
    public static final String COMPANY_CAR = "Company Car";
    public static final String NA = "na";
    public static final String BASIC_ICC = "basic+icc";
    public static final String COMPASS_INCONSISTENCY = "/notification/secured/api/v2/en/compassInconsistency";
    public static final String DEMOCAR_NOTIFICATION_MAIL = "/notification/secured/api/v2/en/democar_notification_mail";
    public static final String DEMOCAR_REGISTRATION_MAIL = "/notification/secured/api/v2/en/democar_registration_mail";
    public static final String DEMOCAR_NCID_PWD_MAIL = "/notification/secured/api/v2/en/democar_ncid_nc_password_mail";
    public static final String CAR_WINGS_RESET_PWD = "/carwings/api/v1/en/resetpassword";
    public static final String DOCOMMO_NOTIFICATION_MAIL = "/notification/secured/api/v2/en/docommo_notification_mail";
    public static final String EN = "en";

    @Autowired
    private SimpMessagingTemplate brokerMessagingTemplate;

    private ListeningExecutorService executor = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(10));

    @Autowired
    private VinDetailsRepository vinDetailsRepository;

    @Autowired
    private DemoCarModelRepository modelRepository;

    @Autowired
    private DemoCarGradeRepository gradeRepository;

    @Autowired
    private DemoCarNaviRepository naviRepository;

    @Autowired
    private DemoCarPackagePlanRepository demoCarPackagePlanRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private DealerRepository dealerRepository;

    @Autowired
    private DemoCarModelRepository demoCarModelRepository;

    @Autowired
    CloudMapServiceResolver serviceResolver;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    DemoCarAdmissionRepository demoCarAdmissionRepository;

    @Autowired
    DemoCarTestDriveRepository demoCarTestDriveRepository;

    @Autowired
    UserRepository userRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    TempoDotNetRepository tempoDotNetRepository;

    public static final Map<String, String> SORTING_KEYS =
            new HashMap<String, String>() {
                {
                    put("vin", "vin");
                    put("status", "status");
                    put("model", "modelName");
                    put("enrollmentDate", "enrollmentDate");
                    put("id", "admission");
                    put("naviId", "cwNaviId");
                    put("dealerName", "dealerName");
                    put("dealerShopName", "dealerShopName");
                    put("caName", "caName");
                    put("expirationDate", "expirationDate");
                    put("createdDate", "createdDate");
                }
            };


    @Override
    public Map<String, Object> saveVinDetails(MultipartFile file, String token, DealerEntity dealerEntity, String langCode) throws IOException {
        Map<String, Object> result = new HashMap<>();
        final String label = UUID.randomUUID().toString() + ".xlsx";
        final String filepath = "/tmp/" + label;
        byte[] bytes = file.getBytes();
        File fh = new File("/tmp/");
        if (!fh.exists()) {
            fh.mkdir();
        }
        FileOutputStream writer = new FileOutputStream(filepath);
        writer.write(bytes);
        writer.close();
        logger.info("image bytes received: {}", bytes.length);
        final FileInputStream inputStream = new FileInputStream(filepath);
        DataTable table = ExcelTable.load(() -> inputStream);
        try {
            if (validateTargetColumn(table)) {
                if ("en".equals(langCode)) {
                    throw new RuntimeException("wrong layout");
                } else {
                    throw new RuntimeException("ファイルのレイアウトが間違っています。");
                }
            }
        } catch (
                Exception ex) {
            logger.error("Failed to process the uploaded image", ex);
            result.put("success", false);
            result.put("id", "");
            result.put("message", ex.getMessage());
            return result;
        }
        try {
            executor.submit(() -> {
                try {
                    logger.info("inside thread executor");
                    UploadEvent event = new UploadEvent();
                    event.setState("Uploaded filed received on server");
                    event.setEventType("start");
                    brokerMessagingTemplate.convertAndSend("/topics/" + token + "/event", JSON.toJSONString(event, SerializerFeature.BrowserCompatible));

                    int rowCount = table.rowCount();
                    logger.info("Uploaded VIN count : {}", rowCount);
                    int skippedRecords;
                    int uploadedRecords = 0;
                    for (int i = 0; i < rowCount; ++i) {
                        DataRow row = table.row(i);
                        logger.info("inside each iterator");
                        String vin = row.cell("VIN");
                        String profitDealerCode = row.cell("販売会社コード");
                        String flagType = row.cell("羅針盤公開フラグ");
                        if (StringUtils.isEmpty(flagType)) {
                            event.setState("Error");
                            String errorMessage;
                            if ("en".equals(langCode)) {
                                errorMessage = "private or public flag is null @line number";
                            } else {
                                errorMessage = "PROFIT販社コードに値がありません＠2行目";
                            }

                            skippedRecords = (i + 1) - uploadedRecords;
                            event.setEventType(errorMessage + " " + (i + 1));
                            event.setRowNumber(i + 1);
                            UploadSummaryDto summaryDto = new UploadSummaryDto();
                            summaryDto.setTotalRecords(i + 1);
                            summaryDto.setSkippedRecords(skippedRecords);
                            summaryDto.setUploadedRecords(uploadedRecords);
                            event.setSummary(summaryDto);
                            brokerMessagingTemplate.convertAndSend("/topics/" + token + "/event", JSON.toJSONString(event, SerializerFeature.BrowserCompatible));
                            throw new RuntimeException(errorMessage + (i + 1));
                        }
                        if (StringUtils.isEmpty(profitDealerCode)) {
                            skippedRecords = (i + 1) - uploadedRecords;
                            event.setState("Error");
                            event.setEventType("profit dealer code  is null  @line number" + " " + (i + 1));
                            event.setRowNumber(i + 1);
                            UploadSummaryDto summaryDto = new UploadSummaryDto();
                            summaryDto.setTotalRecords(i + 1);
                            summaryDto.setSkippedRecords(skippedRecords);
                            summaryDto.setUploadedRecords(uploadedRecords);
                            event.setSummary(summaryDto);
                            brokerMessagingTemplate.convertAndSend("/topics/" + token + "/event", JSON.toJSONString(event, SerializerFeature.BrowserCompatible));
                            throw new RuntimeException("profit dealer code  is null  @line number" + "" + (i + 1));
                        }
                        VinDetails existingVin = vinDetailsRepository.findByVin(vin);
                        if (existingVin != null && !existingVin.isActive()) {
                            existingVin.setActive(true);
                            boolean isSuccess = saveVinDetails(existingVin.getVin(), profitDealerCode);
                            if (isSuccess) uploadedRecords++;
                        }
                        if (existingVin == null && !StringUtils.isEmpty(vin)) {
                            boolean isSuccess = saveVinDetails(vin, profitDealerCode);
                            if (isSuccess) uploadedRecords++;
                        }
                        event.setState("In Progress");
                        event.setEventType("progress");
                        event.setRowNumber(i + 1);
                        brokerMessagingTemplate.convertAndSend("/topics/" + token + "/event", JSON.toJSONString(event, SerializerFeature.BrowserCompatible));
                    }
                    skippedRecords = rowCount - uploadedRecords;
                    logger.info("Skipped VIN count : {}", skippedRecords);
                    event.setState("Completed");
                    event.setEventType("Completed");
                    UploadSummaryDto summaryDto = new UploadSummaryDto();
                    summaryDto.setTotalRecords(rowCount);
                    summaryDto.setSkippedRecords(skippedRecords);
                    summaryDto.setUploadedRecords(uploadedRecords);
                    event.setSummary(summaryDto);
                    fh.delete();
                    brokerMessagingTemplate.convertAndSend("/topics/" + token + "/event", JSON.toJSONString(event, SerializerFeature.BrowserCompatible));
                } catch (Exception ex) {
                    logger.error("Failed on saving vin details", ex);
                }
            });
            result.put("success", true);
            result.put("id", label);
            result.put("error", "");
            return result;
        } catch (
                Exception ex) {
            logger.error("Failed to process the uploaded image", ex);
            result.put("success", false);
            result.put("id", "");
            result.put("message", ex.getMessage());
            return result;
        }

    }

    private boolean validateTargetColumn(DataTable table) {
        if (!table.getDataColumns().get(table.getDataColumns().size() - 1).getName().equals("VIN")) {
            return true;
        }
        if (!table.getDataColumns().get(0).getName().equals("販売会社コード")) {
            return true;
        }
        if (!table.getDataColumns().get(3).getName().equals("羅針盤公開フラグ")) {
            return true;
        }
        return false;
    }

    private boolean saveVinDetails(String vin, String profitDealerCode) {
        VinDetails vinDetails = new VinDetails();
        Map<String, String> modelMap = isIvi(vin);
        if (modelMap.get("ivi") != null && !modelMap.get("ivi").isEmpty()) {
            vinDetails.setIvi(true);
        }
        if (!modelMap.get("modelName").isEmpty()) {
            vinDetails.setModelName(modelMap.get("modelName"));
        }
        TempoDotNet tempoDotNet = tempoDotNetRepository.findByProfitDealerCompanyCodeWithBlockCode(profitDealerCode);
        if (null != tempoDotNet) {
            logger.info("TempoDotNet fetched for ProfitDealerCompanyCodeWithBlockCode : {}", profitDealerCode);
            vinDetails.setProfitDealerCode(tempoDotNet.getProfitDealerCompanyCode());
            DealerEntity dealer = dealerRepository.findByCompanyCodeAndDealerShipCode(tempoDotNet.getCaCompanyCode(), tempoDotNet.getProfitDealershipCode());
            if (dealer != null) {
                logger.info("DealerEntity fetched for dealerShipCode : {}", tempoDotNet.getProfitDealershipCode());
                vinDetails.setDealer(dealer);
                vinDetails.setDealerName(dealer.getCompanyName());
                vinDetails.setDealerShopName(dealer.getDealershipName());
            } else {
                logger.error("DealerEntity is not available for dealerShipCode : {}", tempoDotNet.getProfitDealershipCode());
                return false;
            }
        } else {
            logger.error("TempoDotNet is not available for ProfitDealerCompanyCodeWithBlockCode : {}", profitDealerCode);
            return false;
        }
        vinDetails.setVin(vin);
        vinDetails.setCarPlan("Demo Car");
        vinDetails.setActive(true);
        vinDetails.setSource(DemoCarConstants.SOURCE_UPLOAD);
        if (BooleanUtils.isFalse(vinDetails.getIvi())) {
            vinDetails.setStatus(DemoCarConstants.STATUS_CAN_PUBLISH);
        } else {
            vinDetails.setStatus(DemoCarConstants.STATUS_NOT_LINKED_VPM);
        }
        vinDetails.setFlagType(DemoCarConstants.FLAG_TYPE_TO_BE_PUBLISHED);
        vinDetails.setCreatedDate(new Date());
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Saving vindetails: :" + vinDetails.getVin());
        vinDetailsRepository.save(vinDetails);
        return true;
    }


    @Override
    public ListTakeActionVinDetailsDto fetchVinDetails(VinDetailsRequestDto vinDetailsRequestDto, String langCode, String pricipalId) {

        DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(pricipalId));
        if (dealer.getViewTakeAction() == null || dealer.getViewTakeAction()) {
            QVinDetails qVinDetails = QVinDetails.vinDetails;
            QDealerEntity qDealerEntity = QDealerEntity.dealerEntity;
            BooleanBuilder builder = new BooleanBuilder();
            String searchKey = vinDetailsRequestDto.getSearchKey().toUpperCase().trim();
            builder.and(qVinDetails.vin.like("%" + searchKey + "%").or(qVinDetails.modelName.like("%" + searchKey + "%")));
            long totalActiveCount = 0;
            long totalTakeActionCount = 0;
            long totalFilterCount;
            BooleanBuilder activeBuilderTotal = new BooleanBuilder();
            activeBuilderTotal.and(qVinDetails.status.in(DemoCarConstants.STATUS_ON_LOAN, DemoCarConstants.STATUS_AVAILABLE, DemoCarConstants.STATUS_PW_UPDATING));
            activeBuilderTotal.and(qVinDetails.active.eq(true));
            BooleanBuilder inactiveBuilderTotal = new BooleanBuilder();
            inactiveBuilderTotal.and(qVinDetails.status.notIn(DemoCarConstants.STATUS_ON_LOAN, DemoCarConstants.STATUS_AVAILABLE, DemoCarConstants.STATUS_PW_UPDATING));
            inactiveBuilderTotal.and(qVinDetails.active.eq(true));
            if (vinDetailsRequestDto.isActive()) {
                builder.and(qVinDetails.status.in(DemoCarConstants.STATUS_ON_LOAN, DemoCarConstants.STATUS_AVAILABLE, DemoCarConstants.STATUS_PW_UPDATING));
            } else {
                builder.and(qVinDetails.status.notIn(DemoCarConstants.STATUS_ON_LOAN, DemoCarConstants.STATUS_AVAILABLE, DemoCarConstants.STATUS_PW_UPDATING));
            }
            if (!StringUtils.isEmpty(vinDetailsRequestDto.getStatus())) {
                builder.and(qVinDetails.status.eq(vinDetailsRequestDto.getStatus()));
            }
            if (vinDetailsRequestDto.getModel() != null && !(vinDetailsRequestDto.getModel().size() == 0)) {
                builder.and(qVinDetails.modelName.in(vinDetailsRequestDto.getModel()));
            }
            if (vinDetailsRequestDto.getPaidOrFree() != null && !(vinDetailsRequestDto.getPaidOrFree().size() == 0)) {
                List<Boolean> paidFreeLsit = new ArrayList<>();
                vinDetailsRequestDto.getPaidOrFree().forEach(p -> {
                    if (p.equals("Paid")) {
                        paidFreeLsit.add(true);
                    }
                    if (p.equals("Free")) {
                        paidFreeLsit.add(false);
                    }
                });
                builder.and(qVinDetails.ivi.in(paidFreeLsit));
            }
            if (vinDetailsRequestDto.getRegistPattern() != null && !(vinDetailsRequestDto.getRegistPattern().size() == 0)) {
                builder.and(qVinDetails.source.in(vinDetailsRequestDto.getRegistPattern()));
            }
            if (vinDetailsRequestDto.getPublicOrPrivate() != null && !(vinDetailsRequestDto.getPublicOrPrivate().size() == 0)) {
                builder.and(qVinDetails.flagType.in(vinDetailsRequestDto.getPublicOrPrivate()));
            }
            if (dealer != null && "CA".equalsIgnoreCase(dealer.getDealerType())) {
                logger.info("Login dealer type : CA");
                builder.and(qDealerEntity.companyCode.eq(dealer.getCompanyCode()))
                        .and(qDealerEntity.dealershipName.eq(dealer.getDealershipName()))
                        .and(qVinDetails.status.notIn(DemoCarConstants.STATUS_NOT_LINKED_VPM,
                                DemoCarConstants.STATUS_NOT_EXIST_VPM, DemoCarConstants.STATUS_CAN_PUBLISH));
                activeBuilderTotal.and(qDealerEntity.companyCode.eq(dealer.getCompanyCode()))
                        .and(qDealerEntity.dealershipName.eq(dealer.getDealershipName()));

                inactiveBuilderTotal.and(qDealerEntity.companyCode.eq(dealer.getCompanyCode()))
                        .and(qDealerEntity.dealershipName.eq(dealer.getDealershipName()))
                        .and(qVinDetails.status.notIn(DemoCarConstants.STATUS_NOT_LINKED_VPM,
                                DemoCarConstants.STATUS_NOT_EXIST_VPM, DemoCarConstants.STATUS_CAN_PUBLISH));
            }
            builder.and(qVinDetails.active.eq(true));
            JPAQuery<VinDetails> totalActiveQuery = new JPAQuery(entityManager);
            totalActiveCount = totalActiveQuery.from(qVinDetails).join(qVinDetails.dealer, qDealerEntity).where(activeBuilderTotal).fetchCount();
            logger.info("Total Active Count : {} ", totalActiveCount);

            JPAQuery<VinDetails> totalTakeActionQuery = new JPAQuery(entityManager);
            totalTakeActionCount = totalTakeActionQuery.from(qVinDetails).join(qVinDetails.dealer, qDealerEntity).where(inactiveBuilderTotal).fetchCount();
            logger.info("Total Take Action Count : {} ", totalTakeActionCount);

            Pageable pageable = getPagination(vinDetailsRequestDto.getOffset(), vinDetailsRequestDto.getLimit(), vinDetailsRequestDto.getSortBy(), vinDetailsRequestDto.getSortOrder(), langCode);
            JPAQuery<VinDetails> query = new JPAQuery(entityManager);
            query.from(qVinDetails).join(qVinDetails.dealer, qDealerEntity).where(builder);
            totalFilterCount = query.fetchCount();
            logger.info("Total Filtered VIN Count : {} ", totalFilterCount);
            query.offset(pageable.getOffset());
            query.limit(pageable.getPageSize());
            PathBuilder<VinDetails> entityPath = new PathBuilder<>(VinDetails.class, "vinDetails");
            for (Sort.Order order : pageable.getSort()) {
                PathBuilder<Object> path = entityPath.get(order.getProperty());
                query.orderBy(new OrderSpecifier(com.querydsl.core.types.Order.valueOf(order.getDirection().name()), path));
            }
            List<VinDetails> vinDetailsList = query.fetch();
            logger.info("VIN list query fetched.={}", vinDetailsList);
            List<TakeActionVinDetailsDto> takeActionVinDetailsDtoList = new ArrayList<>();
            List<ActiveVinListDto> activeVinListDtoArrayList = new ArrayList<>();
            ListTakeActionVinDetailsDto listTakeActionVinDetailsDto = new ListTakeActionVinDetailsDto();
            if (!vinDetailsRequestDto.isActive()) {
                vinDetailsList.forEach(v -> {
                    TakeActionVinDetailsDto takeActionVinDetailsDto = new TakeActionVinDetailsDto();
                    takeActionVinDetailsDto.setEnrollmentDate(v.getEnrollmentDate());
                    List<StatusDto> statusDtoList = getStatusInfo(langCode);
                    statusDtoList.forEach(s -> {
                        if (v.getStatus() != null && v.getStatus().equals(s.getStatus())) {
                            takeActionVinDetailsDto.setStatusDisplayName(s.getDisplayName());
                            takeActionVinDetailsDto.setStatus(v.getStatus());
                        }
                    });
                    List<RegistPattern> registPatternInfo = getRegistPatternInfo(langCode);
                    logger.info("registPatternInfo={}", registPatternInfo);
                    registPatternInfo.forEach(r -> {
                        if (v.getSource() != null && v.getSource().equals(r.getRegistPattern())) {
                            takeActionVinDetailsDto.setSource(r.getRegistPattern());
                            takeActionVinDetailsDto.setSourceDisplayName(r.getDisplayName());
                        }
                    });
                    takeActionVinDetailsDto.setModel(v.getModel());
                    takeActionVinDetailsDto.setVin(v.getVin());
                    takeActionVinDetailsDto.setCarPlan(v.getCarPlan());
                    List<PublicOrPrivateDto> publicPrivateInfo = getPublicPrivateInfo(langCode);
                    logger.info("publicPrivateInfo={}", publicPrivateInfo);
                    publicPrivateInfo.forEach(r -> {
                        if (v.getFlagType() != null && v.getFlagType().equals(r.getPublicOrPrivate())) {
                            takeActionVinDetailsDto.setFlagType(r.getPublicOrPrivate());
                            takeActionVinDetailsDto.setFlagTypeDisplayName(r.getDisplayName());
                        }
                    });
                    takeActionVinDetailsDto.setIvi(v.getIvi());
                    if (v.getAdmission() != null) {
                        takeActionVinDetailsDto.setNcasNumber(v.getAdmission().getId());
                    }
                    takeActionVinDetailsDto.setNaviId(v.getCwNaviId());
                    if (v.getDealer() != null) {
                        takeActionVinDetailsDto.setCompanyName(v.getDealer().getCompanyName());
                        takeActionVinDetailsDto.setDealershipName(v.getDealer().getDealershipName());
                        takeActionVinDetailsDto.setCaName(v.getCaName());
                    }
                    if (v.getPackagePlan() != null) {
                        takeActionVinDetailsDto.setPackagePlan(v.getPackagePlan());
                    }
                    if (BooleanUtils.isTrue(v.getIcc())) {
                        takeActionVinDetailsDto.setIcc(true);
                    } else {
                        takeActionVinDetailsDto.setIcc(false);
                    }
                    takeActionVinDetailsDto.setEnrollmentDate(v.getEnrollmentDate());
                    if (v.getExpirationDate() != null) {
                        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
                        try {
                            Date date = format.parse(v.getExpirationDate());
                            takeActionVinDetailsDto.setExpirationDate(new SimpleDateFormat("yyyy/MM").format(date));
                        } catch (ParseException e) {
                            logger.info(" getServiceEndDate format exception={}", e);
                        }
                    }
                    takeActionVinDetailsDtoList.add(takeActionVinDetailsDto);
                });
                listTakeActionVinDetailsDto.setVinDetailsList(takeActionVinDetailsDtoList);
                listTakeActionVinDetailsDto.setActiveListCount(totalActiveCount);
                listTakeActionVinDetailsDto.setTakeActionCount(totalTakeActionCount);
                listTakeActionVinDetailsDto.setTotalCount(totalFilterCount);
                return listTakeActionVinDetailsDto;
            } else {
                vinDetailsList.forEach(v -> {
                    ActiveVinListDto activeVinListDto = new ActiveVinListDto();
                    if (v.getAdmission() != null) {
                        activeVinListDto.setNcJoinDate(v.getAdmission().getNcJoinDate());
                        activeVinListDto.setNcasNumber(v.getAdmission().getId());
                    }
                    activeVinListDto.setModel(v.getModel());
                    activeVinListDto.setVin(v.getVin());
                    List<StatusDto> statusDtoList = getStatusInfo(langCode);
                    statusDtoList.forEach(s -> {
                        if (v.getStatus() != null && v.getStatus().equals(s.getStatus())) {
                            activeVinListDto.setStatusDisplayName(s.getDisplayName());
                            activeVinListDto.setStatus(v.getStatus());
                        }
                    });
                    activeVinListDto.setCarPlan(v.getCarPlan());
                    if (v.getPackagePlan() != null) {
                        activeVinListDto.setPackagePlan(v.getPackagePlan());
                    }
                    if (v.getDealer() != null) {
                        activeVinListDto.setCompanyName(v.getDealer().getCompanyName());
                        activeVinListDto.setDealershipName(v.getDealer().getDealershipName());
                        activeVinListDto.setCaName(v.getCaName());
                    }
                    activeVinListDto.setCaNameLending("");
                    activeVinListDto.setIvi(v.getIvi());
                    List<PublicOrPrivateDto> publicPrivateInfo = getPublicPrivateInfo(langCode);
                    logger.info("publicPrivateInfo={}", publicPrivateInfo);
                    publicPrivateInfo.forEach(p -> {
                        if (v.getFlagType() != null && v.getFlagType().equals(p.getPublicOrPrivate())) {
                            logger.info("vindetails={}", v);
                            activeVinListDto.setFlagType(p.getPublicOrPrivate());
                            activeVinListDto.setFlagTypeDisplayName(p.getDisplayName());
                        }
                    });
                    List<RegistPattern> registPatternInfo = getRegistPatternInfo(langCode);
                    logger.info("registPatternInfo={}", registPatternInfo);
                    registPatternInfo.forEach(r -> {
                        if (v.getSource() != null && v.getSource().equals(r.getRegistPattern())) {
                            activeVinListDto.setSource(r.getRegistPattern());
                            activeVinListDto.setSourceDisplayName(r.getDisplayName());
                        }
                    });
                    if (BooleanUtils.isTrue(v.getIcc())) {
                        activeVinListDto.setIcc(true);
                    } else {
                        activeVinListDto.setIcc(false);
                    }

                    if (v.getExpirationDate() != null) {
                        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
                        try {
                            Date date = format.parse(v.getExpirationDate());
                            activeVinListDto.setExpirationMonthNc(new SimpleDateFormat("yyyy/MM").format(date));
                        } catch (ParseException e) {
                            logger.info(" getServiceEndDate format exception={}", e);
                        }
                    }
                    activeVinListDto.setEnrollmentDate(v.getEnrollmentDate());
                    activeVinListDtoArrayList.add(activeVinListDto);
                });
                listTakeActionVinDetailsDto.setVinDetailsList(activeVinListDtoArrayList);
                listTakeActionVinDetailsDto.setActiveListCount(totalActiveCount);
                listTakeActionVinDetailsDto.setTakeActionCount(totalTakeActionCount);
                listTakeActionVinDetailsDto.setTotalCount(totalFilterCount);
                return listTakeActionVinDetailsDto;
            }
        } else {
            ListTakeActionVinDetailsDto listTakeActionVinDetailsDto = new ListTakeActionVinDetailsDto();
            listTakeActionVinDetailsDto.setTotalCount(666);
        }
        return null;
    }

    @Override
    public VinDetailsDto addSingleVin(VinDetailsDto takeActionVinDetailsDto, DealerEntity dealer, String langCode) {
        String vin = takeActionVinDetailsDto.getVin();
        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "saving vin= " + vin);
        VinDetails existingVin = vinDetailsRepository.findByVin(vin);
        if (existingVin == null) {
            VinDetails vinDetails = new VinDetails();
            vinDetails.setVin(takeActionVinDetailsDto.getVin());
            vinDetails.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
            vinDetails.setActive(true);
            vinDetails.setSource(DemoCarConstants.SOURCE_ADD_VIN);
            logger.info("PRINCIPAL ID in add vin flow is={}", dealer.getUserId());
            vinDetails.setDealer(dealer);
            vinDetails.setDealerName(dealer.getCompanyName());
            vinDetails.setDealerShopName(dealer.getDealershipName());
            Map<String, String> modelMap = isIvi(vin);
            if (StringUtils.isNotEmpty(modelMap.get("ivi"))) {
                vinDetails.setIvi(true);
            } else {
                vinDetails.setIvi(false);
            }
            if (!modelMap.get("modelName").isEmpty()) {
                vinDetails.setModelName(modelMap.get("modelName"));
            }
            restrictToAddVinNotNinetyDaysOld(langCode, vinDetails);
            vinDetails.setProfitDealerCode(dealer.getProfitCaCompanyCode());
            vinDetails.setCreatedDate(new Date());
            VinDetails savedVinDetails = vinDetailsRepository.save(vinDetails);
            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "saved vin= " + savedVinDetails);
        } else if (existingVin != null && !existingVin.isActive()) {
            existingVin.setActive(true);
            vinDetailsRepository.save(existingVin);
        } else {
            if ("en".equals(langCode)) {
                throw new RuntimeException("Provided vin is already available in system");
            } else {
                throw new RuntimeException("対象のVINは既に本システムに登録済です");
            }

        }
        return takeActionVinDetailsDto;
    }

    private void restrictToAddVinNotNinetyDaysOld(String langCode, VinDetails vinDetails) {
        if (vinDetails.getModelName() != null) {
            logger.info("Inside restrictToAddVinNotNinetyDaysOld");
            logger.info("model Name={}", vinDetails.getModelName());
            DemoCarModel demoCarModel = demoCarModelRepository.findByModelNameAndLangCode(vinDetails.getModelName(), langCode);
            if (demoCarModel != null && demoCarModel.getCreatedDate() != null) {
                LocalDate createdDate = ((Timestamp) demoCarModel.getCreatedDate()).toLocalDateTime().toLocalDate();
                LocalDate today = LocalDate.now();
                long daysBetween = DAYS.between(createdDate, today);
                if (daysBetween < 90) {
                    if (EN.equals(langCode)) {
                        throw new RuntimeException("VIN cannot be added because it is included in the data to be uploaded by the manufacturer.");
                    } else {
                        throw new RuntimeException("メーカーアップロード予定のデータに含まれているので、VIN追加できません。");
                    }
                }
            }
        }
    }

    @Override
    public DemoCarFetchInitialRegDto fetchInitialRegInfo(String vin, String lngCode) {

        VinDetails vinDetails = vinDetailsRepository.findByVin(vin);
        if (vinDetails == null) {
            throw new RuntimeException("No record found for the given Vin Number");
        } else {
            DemoCarFetchInitialRegDto demoCarFetchInitialRegDto = new DemoCarFetchInitialRegDto();
            List<String> carList = new ArrayList<>();
            carList.add(DEMO_CAR);
            carList.add(COMPANY_CAR);
            demoCarFetchInitialRegDto.setVin(vin);
            demoCarFetchInitialRegDto.setFlagType(vinDetails.getFlagType());
            demoCarFetchInitialRegDto.setIvi(vinDetails.getIvi());
            demoCarFetchInitialRegDto.setIcc(false);
            if (vinDetails.getDealer() != null) {
                demoCarFetchInitialRegDto.setDealerName(vinDetails.getDealer().getCompanyName());
            }
            demoCarFetchInitialRegDto.setCarPlan(carList);
            demoCarFetchInitialRegDto.setModels(getModelInfo(lngCode, vin));
            return demoCarFetchInitialRegDto;
        }
    }

    @Override
    public DemoCarSaveRegInfoDto saveInfoFoRegistration(DemoCarSaveRegInfoDto demoCarSaveRegInfoDto, String
            principalId) {
        VinDetails vinDetails = vinDetailsRepository.findByVin(demoCarSaveRegInfoDto.getVin());
        if (vinDetails != null && DemoCarConstants.STATUS_NOT_APPLIED.equals(vinDetails.getStatus()) && DEMO_CAR.equals(demoCarSaveRegInfoDto.getCarPlan())) {
            if (StringUtils.isEmpty(vinDetails.getFlagType())) {
                vinDetails.setStatus(DemoCarConstants.STATUS_APPLYING_WAIT_COMP);
            } else if (DemoCarConstants.FLAG_TYPE_MISMATCH.equals(vinDetails.getFlagType())) {
                vinDetails.setStatus(DemoCarConstants.STATUS_APPLYING);
                vinDetails.setFlagType(DemoCarConstants.FLAG_TYPE_PRIVATE);
            } else {
                vinDetails.setStatus(DemoCarConstants.STATUS_APPLYING);
            }
            return getVinDetails(demoCarSaveRegInfoDto, vinDetails, principalId);
        } else if (vinDetails != null) {
            vinDetails.setStatus(DemoCarConstants.STATUS_APPLYING);
            vinDetails.setFlagType(demoCarSaveRegInfoDto.getFlagType());
            return getVinDetails(demoCarSaveRegInfoDto, vinDetails, principalId);
        } else {
            throw new RuntimeException("vin does not exist in the system");
        }
    }

    private DemoCarSaveRegInfoDto getVinDetails(DemoCarSaveRegInfoDto demoCarSaveRegInfoDto, VinDetails
            vinDetails, String principalId) {
        DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
        vinDetails.setDealer(dealer);
        vinDetails.setCaName(dealer.getCaName());
        vinDetails.setCarPlan(demoCarSaveRegInfoDto.getCarPlan());
        vinDetails.setIcc(demoCarSaveRegInfoDto.getIcc());
        DemoCarModel model = modelRepository.findById(demoCarSaveRegInfoDto.getModelId()).get();
        vinDetails.setModel(model);
        vinDetails.setGrade(gradeRepository.findById(demoCarSaveRegInfoDto.getGradeId()).get());
        if (demoCarSaveRegInfoDto.getNaviId() != null) {
            vinDetails.setNavi(naviRepository.findById(demoCarSaveRegInfoDto.getNaviId()).get());
        }
        if (demoCarSaveRegInfoDto.getPlanId() != null) {
            vinDetails.setPackagePlan(demoCarPackagePlanRepository.findById(demoCarSaveRegInfoDto.getPlanId()).get());
        }
        vinDetails.setIvi(demoCarSaveRegInfoDto.getIvi());
        vinDetails.setCwNaviId(demoCarSaveRegInfoDto.getCwNaviId());
        vinDetails.setModelName(model.getModelName());
        vinDetails.setEnrollmentDate(LocalDateTime.now(ZoneId.of("japan")));
        vinDetails.setCarPlan(demoCarSaveRegInfoDto.getCarPlan());
        DemoCarAdmission demoCarAdmission = demoCarAdmissionRepository.findByVin(vinDetails.getVin());
        if (demoCarAdmission == null) {
            demoCarAdmission = new DemoCarAdmission();
            demoCarAdmission.setVin(demoCarSaveRegInfoDto.getVin());
            demoCarAdmission.setSendToNlo(false);
            demoCarAdmissionRepository.save(demoCarAdmission);
        }
        vinDetails.setAdmission(demoCarAdmission);
        vinDetails = vinDetailsRepository.save(vinDetails);
        return convertToDemoCarSaveRegInfoDto(vinDetails);
    }

    @Override
    public VinInformationDTO fetchSingleVinDetails(HttpServletRequest httpServletRequest, String vinNumber, String langCode) {
        VinInformationDTO vinInfo = null;
        if (!StringUtils.isEmpty(vinNumber)) {
            VinDetails vinDetails = vinDetailsRepository.findByVin(vinNumber);
            if (vinDetails != null) {
                vinInfo = new VinInformationDTO();
                DemoCarDealerDto dealerDto = null;
                DemoCarVinDetailsDto demDemoCarVinDetailsDto = new DemoCarVinDetailsDto();
                if (vinDetails.getEnrollmentDate() != null) {
                    demDemoCarVinDetailsDto.setEnrollmentDate(vinDetails.getEnrollmentDate().toString());
                }
                demDemoCarVinDetailsDto.setCarPlan(vinDetails.getCarPlan());
                demDemoCarVinDetailsDto.setFlagType(vinDetails.getFlagType());
                List<StatusDto> statusDtoList = getStatusInfo(langCode);
                statusDtoList.forEach(s -> {
                    if (vinDetails.getStatus() != null && vinDetails.getStatus().equals(s.getStatus())) {
                        demDemoCarVinDetailsDto.setStatusDisplayName(s.getDisplayName());
                        demDemoCarVinDetailsDto.setStatus(vinDetails.getStatus());
                    }
                });

                List<RegistPattern> registPatternInfo = getRegistPatternInfo(langCode);
                logger.info("registPatternInfo={}", registPatternInfo);
                registPatternInfo.forEach(r -> {
                    if (vinDetails.getSource() != null && vinDetails.getSource().equals(r.getRegistPattern())) {
                        demDemoCarVinDetailsDto.setSource(r.getRegistPattern());
                        demDemoCarVinDetailsDto.setSourceDisplayName(r.getDisplayName());
                    }
                });
                List<PublicOrPrivateDto> publicPrivateInfo = getPublicPrivateInfo(langCode);
                logger.info("publicPrivateInfo={}", publicPrivateInfo);
                publicPrivateInfo.forEach(r -> {
                    if (vinDetails.getFlagType() != null && vinDetails.getFlagType().equals(r.getPublicOrPrivate())) {
                        demDemoCarVinDetailsDto.setFlagType(r.getPublicOrPrivate());
                        demDemoCarVinDetailsDto.setFlagTypeDisplayName(r.getDisplayName());
                    }
                });

                List<CarPlanDto> carPlanDtoList = getCarPlanInfo(langCode);
                logger.info("carPlanDtoList={}", carPlanDtoList);
                carPlanDtoList.forEach(r -> {
                    if (vinDetails.getCarPlan() != null && vinDetails.getCarPlan().equals(r.getCarPlan())) {
                        demDemoCarVinDetailsDto.setCarPlan(r.getCarPlan());
                        demDemoCarVinDetailsDto.setCarPlanDisplayName(r.getDisplayName());
                    }
                });
                demDemoCarVinDetailsDto.setVin(vinDetails.getVin());
                demDemoCarVinDetailsDto.setIcc(vinDetails.getIcc());
                demDemoCarVinDetailsDto.setIvi(vinDetails.getIvi());
                demDemoCarVinDetailsDto.setNaviId(vinDetails.getCwNaviId());
                demDemoCarVinDetailsDto.setNcExpirationDate(vinDetails.getExpirationDate());
                if (vinDetails.getAdmission() != null) {
                    DemoCarAdmission admission = vinDetails.getAdmission();
                    demDemoCarVinDetailsDto.setNcasNumber(admission.getId().toString());
                    demDemoCarVinDetailsDto.setNcId(admission.getNcId());
                    demDemoCarVinDetailsDto.setNcPassword(admission.getNcPassword());
                }

                if (vinDetails.getNavi() != null) {
                    demDemoCarVinDetailsDto.setNaviDisplayName(vinDetails.getNavi().getDisplayName());
                }

                if (vinDetails.getGrade() != null) {
                    demDemoCarVinDetailsDto.setGradeDisplayName(vinDetails.getGrade().getDisplayName());
                }
                if (null != vinDetails.getModelName()) {
                    demDemoCarVinDetailsDto.setImageUrl(getVinImageUrl(vinDetails.getModelName()));
                }
                vinInfo.setVinDetails(demDemoCarVinDetailsDto);
                vinInfo.setModel(vinDetails.getModel());
                vinInfo.setPackagePlan(vinDetails.getPackagePlan());
                String pricipalId = httpServletRequest.getHeader("principalId");
                if (!StringUtils.isEmpty(pricipalId)) {
                    DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(pricipalId));
                    if (dealer != null) {
                        dealerDto = new DemoCarDealerDto();
                        dealerDto.setProfitDealerCode(dealer.getProfitCaCompanyCode());
                        dealerDto.setDealerShipCode(dealer.getDealerShipCode());
                        dealerDto.setDealershipName(dealer.getCompanyName());
                        dealerDto.setDealerCompanyName(dealer.getCompanyName());
                        dealerDto.setCaCode(dealer.getCaCode());
                        dealerDto.setCaName(dealer.getCaName());
                        dealerDto.setDealerPhoneNumber(dealer.getPhoneNumber());
                        dealerDto.setCaCodeLending(vinDetails.getCaLendingCode());
                        dealerDto.setCaNameLending(vinDetails.getCaLendingName());
                    }
                }
                vinInfo.setDealerDetails(dealerDto);
            }
        }
        return vinInfo;
    }

    private String getVinImageUrl(String modelName) {
        String imageUrl = null;
        switch (modelName) {
            case "DAYZ":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/DAYZ/image.png";
                break;
            case "ROOX":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ROOX/image.png";
                break;
            case "KICKS":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/Kicks/20_P02F_chart_EXT_X_2tone_layer.jpg";
                break;
            case "X-TRAIL":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/X-TRAIL/image.png";
                break;
            case "ELGRAND":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/ELGRAND/image.png";
                break;
            case "FUGA":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/FUGA/image.png";
                break;
            case "CIMA":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/CIMA/image.png";
                break;
            case "SKYLINE(2019/09~)":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/SKYLINE+(September+2019+~)/image.png";
                break;
            case "LEAF(2020/02～)":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/LEAF+(January+2020+~)/image.png";
                break;
            case "NOTE(2020/12～)":
                imageUrl = "https://nissan-digital-admission.s3-ap-northeast-1.amazonaws.com/images/vehicle-models-image/NOTE+(November+2020+~)/Note.png";
                break;
        }
        return imageUrl;
    }

    @Override
    public void saveCompassVinDetails(File file) throws IOException {
        try {
            logger.info("Inside Save Compass flow.");
            executor.submit(() -> {
                try (final FileInputStream inputStream = new FileInputStream(file)) {
                    List<VinDetails> existingVins = vinDetailsRepository.findByIviTrue();
                    logger.info("Existing VIN count : {}", existingVins.size());
                    DataTable table = ExcelTable.load(() -> inputStream);
                    int rowCount = table.rowCount();
                    List<VinDetailsDto> compassVinList = new ArrayList<>();
                    for (int i = 0; i < rowCount; ++i) {
                        DataRow row = table.row(i);
                        VinDetailsDto vinDetails = new VinDetailsDto();
                        vinDetails.setVin(row.cell("SYD_NO"));
                        vinDetails.setProfitDealerCode(row.cell("HS_PROF_CD"));
                        vinDetails.setProfitDealerShopCode(row.cell("PROF_TENPO_CD"));
                        String flagType = "0".equals(row.cell("KOUKAI_KB")) ? DemoCarConstants.FLAG_TYPE_PRIVATE
                                : DemoCarConstants.FLAG_TYPE_PUBLIC;
                        vinDetails.setFlagType(flagType);
                        vinDetails.setManualEnterFlag(row.cell("SHUDOU_FLG"));
                        vinDetails.setCreatedDate(new Date());
                        vinDetails.setSource(DemoCarConstants.SOURCE_COMPASS);
                        vinDetails.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
                        vinDetails.setActive(true);
                        compassVinList.add(vinDetails);
                    }
                    logger.info("Uploaded Compass VIN count (With Duplicates): {}", compassVinList.size());
                    List<VinDetails> uploadedVins = removeDuplicateVins(compassVinList);
                    logger.info("Uploaded Compass VIN count (Without Duplicates): {}", compassVinList.size());
                    List<VinDetails> updateList = getVinUpdateList(existingVins, uploadedVins);
                    for (VinDetails updateVin : updateList) {
                        Map<String, String> modelMap = isIvi(updateVin.getVin());
                        if (modelMap.get("ivi") != null && !modelMap.get("ivi").isEmpty()) {
                            updateVin.setIvi(true);
                        } else {
                            updateVin.setIvi(false);
                        }
                        if (modelMap.get("modelName") != null && !modelMap.get("modelName").isEmpty()) {
                            updateVin.setModelName(modelMap.get("modelName"));
                        }
                        if (StringUtils.isNotEmpty(updateVin.getProfitDealerCode())) {
                            TempoDotNet tempoDotNet = tempoDotNetRepository.findByProfitDealerCompanyCode(updateVin.getProfitDealerCode());
                            if (null != tempoDotNet) {
                                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Compass: TempoDotNet fetched for ProfitDealerCompanyCode : " + updateVin.getProfitDealerCode());
                                DealerEntity dealer = dealerRepository.findByCompanyCodeAndDealerShipCode(tempoDotNet.getCaCompanyCode(), tempoDotNet.getProfitDealershipCode());
                                if (dealer != null) {
                                    logger.info("Compass: DealerEntity fetched for dealerShipCode : {}", tempoDotNet.getProfitDealershipCode());
                                    updateVin.setDealer(dealer);
                                } else {
                                    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Compass: DealerEntity is not available for dealerShipCode :"
                                            + tempoDotNet.getProfitDealershipCode() + "Skipped saving VIN :" + updateVin.getVin());
                                    continue;
                                }
                            } else {
                                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Compass: TempoDotNet is not available for ProfitDealerCompanyCode :"
                                        + updateVin.getProfitDealerCode() + "Skipped saving VIN :" + updateVin.getVin());
                                continue;
                            }
                        } else {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Compass:Skkiped saving - No Profit dealer code for the VIN:" + updateVin.getVin());
                            continue;
                        }
                        vinDetailsRepository.save(updateVin);
                    }
                    logger.info("Updated Compass VINs count : {}", updateList.size());
                    List<VinDetails> deleteList = getVinDeleteList(existingVins, uploadedVins);
                    for (VinDetails deleteVin : deleteList) {
                        vinDetailsRepository.delete(deleteVin);
                    }
                    logger.info("Hard deleted VINs count : {}", deleteList.size());
                    logger.info("Compass file processed successfully.");
                } catch (Exception ex) {
                    logger.error("Failed on saving Compass VIN list", ex);
                }
            });
        } catch (Exception ex) {
            logger.error("Failed to process the Compass file.", ex);
        }
    }


    @Override
    @Transactional
    public String deleteVins(VinDeleteRequestDto vinDeleteRequestDto) {
        List<String> status = new ArrayList<>();
        status.add(DemoCarConstants.STATUS_APPLYING);
        status.add(DemoCarConstants.STATUS_IMPORT_FAILURE_CW);
        status.add(DemoCarConstants.STATUS_AVAILABLE);
        status.add(DemoCarConstants.STATUS_ON_LOAN);
        status.add(DemoCarConstants.STATUS_PW_UPDATING);
        if (vinDeleteRequestDto.getVin().size() != 0) {
            vinDeleteRequestDto.getVin().forEach(vin -> {
                VinDetails vinDetails = vinDetailsRepository.findByVinAndStatusNotIn(vin, status);
                if (vinDetails != null) {
                    vinDetailsRepository.deleteVinById(vinDetails.getId());
                    DemoCarAdmission admission = demoCarAdmissionRepository.findByVin(vin);
                    if (admission != null) {
                        List<DemoCarTestDrive> testDrives = demoCarTestDriveRepository.findByAdmission(admission);
                        if (CollectionUtils.isNotEmpty(testDrives)) {
                            demoCarTestDriveRepository.deleteInBatch(testDrives);
                        }
                        demoCarAdmissionRepository.delete(admission);
                    }
                } else {
                    throw new RuntimeException("vin is not available or restricted for delete" + vin);
                }
            });
        } else {
            throw new RuntimeException("request is empty");
        }

        return Constants.SUCCESS;
    }


    @Override
    public String downloadVins(HttpServletRequest httpServletRequest,
                               HttpServletResponse httpServletResponse,
                               String lang,
                               String startDate,
                               String endDate) throws IOException {
        {
            logger.info("*****Inside download vins");
            String status = Constants.FAILED;
            try {
                String fileName = "vinDetail.csv";
                httpServletResponse.setContentType("text/csv");
                httpServletResponse.setHeader("Content-Disposition", "attachment;filename=" + fileName);
                Writer writer = new OutputStreamWriter(httpServletResponse.getOutputStream());
                ICsvBeanWriter csvWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);
                String[] header = {
                        "Enrollment datetime",
                        "NC Join Date",
                        "Status",
                        "NCAS number",
                        "Profit dealer code",
                        "Dealer company name",
                        "Dealership name",
                        "Dealership code",
                        "Dealer's Tel",
                        "CA name(NC admission)",
                        "CA code(NC admission)",
                        "CA name(Lending)",
                        "CA code(Lending)",
                        "Model",
                        "Package plan",
                        "Package price",
                        "VIN",
                        "Navi ID",
                        "Demo car/Company car",
                        "Public/private",
                        "Regist Pattern",
                        "Paid or free(IVI/not IVI)",
                        "ICC use",
                        "NCID",
                        "NCPW",
                        "Nissan Connect expiration date"
                };
                String[] fieldMapping = {
                        "enrollmentDate",
                        "ncJoinDate",
                        "status",
                        "ncasNumber",
                        "profitDealerCode",
                        "companyName",
                        "dealerShopName",
                        "dealerCode",
                        "dealerPhoneNumber",
                        "caName",
                        "caCode",
                        "caNameLending",
                        "caCodeLending",
                        "model",
                        "packagePlan",
                        "price",
                        "vin",
                        "naviId",
                        "carPlan",
                        "flagType",
                        "source",
                        "ivi",
                        "icc",
                        "ncId",
                        "ncPwd",
                        "expirationDatePwd"
                };
                csvWriter.writeHeader(header);
                logger.info("Header written to csv");
                Timestamp startDateTimeStamp = convertToSqlTimeStamp(startDate);
                Timestamp endDateTimeStamp = convertToSqlTimeStampEndDate(endDate);
                List<DownloadCsvActiveVinListDTO> vinList = null;
                logger.info("total count in vin details={}", vinDetailsRepository.findAll().size());
                vinList = vinDetailsRepository.fetchActiveVinDetails(startDateTimeStamp, endDateTimeStamp);
                logger.info("start date ={} end date={]", startDateTimeStamp, endDateTimeStamp);
                logger.info("total count in download vin details={}", vinList.size());
                for (DownloadCsvActiveVinListDTO vin : vinList) {
                    try {
                        logger.info("*****Successfully writing data in download file");
                        DownloadCsvActiveVinListDTO copyVin = vin;
                        csvWriter.write(vin, fieldMapping);
                    } catch (IOException e) {
                        logger.info("exception in write vin details to csv : " + e.getMessage());
                        e.printStackTrace();
                        return null;
                    }
                }
                csvWriter.close();
                logger.info("file written completed");
                status = Constants.SUCCESS;
                logger.info("status : " + status);
            } catch (Exception e) {
                logger.info("Exception in download vin list : " + e.getMessage());
            }
            return status;
        }
    }

    private List<VinDetails> removeDuplicateVins(List<VinDetailsDto> compassVinList) {
        logger.info("Removing duplicate VINs from Compass.");
        Map<String, VinDetailsDto> uniqueMap = new HashMap<>();
        for (VinDetailsDto vinDto : compassVinList) {
            String vin = vinDto.getVin();
            if (uniqueMap.containsKey(vin)) {
                VinDetailsDto exVin = uniqueMap.get(vin);
                if (!vinDto.getFlagType().equals(exVin.getFlagType())) {
                    if (DemoCarConstants.FLAG_TYPE_PUBLIC.equals(vinDto.getFlagType())) {
                        uniqueMap.put(vin, vinDto);
                    } else {
                        uniqueMap.put(vin, exVin);
                    }
                } else if (!vinDto.getManualEnterFlag().equals(exVin.getManualEnterFlag())) {
                    if ("0".equals(vinDto.getManualEnterFlag())) {
                        uniqueMap.put(vin, vinDto);
                    } else {
                        uniqueMap.put(vin, exVin);
                    }
                } else {
                    uniqueMap.put(vin, vinDto);
                }
            } else {
                uniqueMap.put(vin, vinDto);
            }
        }
        logger.info("Duplicate VINs removed from Compass.");
        return DemoCarModelMapperUtil.mapAll(uniqueMap.values(), VinDetails.class);
    }

    private List<VinDetails> getVinUpdateList(List<VinDetails> existingVins, List<VinDetails> uploadedVins) {
        logger.info("Getting Compass VIN upload list.");
        if (CollectionUtils.isEmpty(existingVins)) {
            logger.info("There are no existing VINs.");
            return uploadedVins;
        }

        List<VinDetails> updateList = new ArrayList<>();
        for (VinDetails upVin : uploadedVins) {
            VinDetails exVin = DemoCarUtil.findVinDetailsByVin(existingVins, upVin.getVin());
            if (exVin != null && exVin.isActive()) {
                if (DemoCarConstants.SOURCE_ADD_VIN.equalsIgnoreCase(exVin.getSource())) {
                    if (DemoCarConstants.STATUS_APPLYING_WAIT_COMP.equalsIgnoreCase(exVin.getStatus())
                            && DemoCarConstants.FLAG_TYPE_PRIVATE.equals(upVin.getFlagType())) {
                        logger.info("CA : Private flag from Compass.");
                        exVin.setFlagType(upVin.getFlagType());
                        exVin.setProfitDealerCode(upVin.getProfitDealerCode());
                        exVin.setProfitDealerShopCode(upVin.getProfitDealerShopCode());
                        exVin.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
                        exVin.setFlagType(DemoCarConstants.FLAG_TYPE_MISMATCH);
                        updateList.add(exVin);
                        Long ncasid = cancelAdmission(exVin.getVin());
                        sendNotificationMail(exVin, Constants.DC_NOTIFICATION_STATUS_PRVATE_FLAG, ncasid);
                    } else if (DemoCarConstants.STATUS_APPLYING_WAIT_COMP.equalsIgnoreCase(exVin.getStatus())) {
                        logger.info("CA : Public flag from Compass.");
                        exVin.setFlagType(upVin.getFlagType());
                        exVin.setProfitDealerCode(upVin.getProfitDealerCode());
                        exVin.setProfitDealerShopCode(upVin.getProfitDealerShopCode());
                        exVin.setStatus(DemoCarConstants.STATUS_APPLYING);
                        updateList.add(exVin);
                    } else if (!isSameRecordFromCompass(upVin, exVin)) {
                        logger.info("CA : Updated VINs from Compass.");
                        exVin.setFlagType(upVin.getFlagType());
                        exVin.setProfitDealerCode(upVin.getProfitDealerCode());
                        exVin.setProfitDealerShopCode(upVin.getProfitDealerShopCode());
                        updateList.add(exVin);
                    }
                } else if (DemoCarConstants.SOURCE_UPLOAD.equalsIgnoreCase(exVin.getSource())) {
                    if (DemoCarConstants.STATUS_NOT_LINKED_VPM.equals(exVin.getStatus()) ||
                            DemoCarConstants.STATUS_NOT_EXIST_VPM.equals(exVin.getStatus()) ||
                            DemoCarConstants.STATUS_CAN_PUBLISH.equals(exVin.getStatus())) {
                        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "FPN : Updated VIN to Not Applied status :" + exVin.getVin());
                        exVin.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
                        exVin.setFlagType(upVin.getFlagType());
                        exVin.setProfitDealerCode(upVin.getProfitDealerCode());
                        exVin.setProfitDealerShopCode(upVin.getProfitDealerShopCode());
                        updateList.add(exVin);

                    } else if (!isSameRecordFromCompass(upVin, exVin)) {
                        logger.info("FPN : Updated VINs from Compass.");
                        exVin.setFlagType(upVin.getFlagType());
                        exVin.setProfitDealerCode(upVin.getProfitDealerCode());
                        exVin.setProfitDealerShopCode(upVin.getProfitDealerShopCode());
                        updateList.add(exVin);
                    }
                } else if (DemoCarConstants.SOURCE_COMPASS.equalsIgnoreCase(exVin.getSource())) {
                    if (!isSameRecordFromCompass(upVin, exVin)) {
                        logger.info("COMPASS : Updated VINs from Compass.");
                        exVin.setFlagType(upVin.getFlagType());
                        exVin.setProfitDealerCode(upVin.getProfitDealerCode());
                        exVin.setProfitDealerShopCode(upVin.getProfitDealerShopCode());
                        updateList.add(exVin);
                    }
                }
            } else if (exVin != null && !exVin.isActive()) {
                vinDetailsRepository.delete(exVin);
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "New VIN from compass(VIN Deleted from UI) :" + exVin.getVin());
                updateList.add(upVin);
            } else {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "New VIN from compass:" + upVin.getVin());
                updateList.add(upVin);
            }
        }
        //update list with : Not Exist (Compass)
        if (!CollectionUtils.isEmpty(existingVins)) {
            for (VinDetails exVin : existingVins) {
                if (exVin.isActive()) {
                    VinDetails upVin = DemoCarUtil.findVinDetailsByVin(uploadedVins, exVin.getVin());
                    if (upVin == null) {
                        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "The VIN is not present in Compass file :" + exVin.getVin());
                        if (!isActiveTabVin(exVin) && DemoCarConstants.SOURCE_UPLOAD.equalsIgnoreCase(exVin.getSource())
                                && exVin.getCreatedDate().after(getDateBeforeXdays(180))
                                && !exVin.getCreatedDate().after(getDateBeforeXdays(90))) {
                            exVin.setFlagType(DemoCarConstants.FLAG_TYPE_NOT_LINKED);
                            updateList.add(exVin);
                        } else if (!isActiveTabVin(exVin) && (DemoCarConstants.SOURCE_ADD_VIN.equalsIgnoreCase(exVin.getSource())
                                && exVin.getCreatedDate().after(getDateBeforeXdays(180)))) {
                            exVin.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
                            exVin.setFlagType(DemoCarConstants.FLAG_TYPE_NOT_LINKED);
                            updateList.add(exVin);
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Updated Not Linked VIN from Compass : {}" + exVin.getVin());
                        } else if (DemoCarConstants.STATUS_APPLYING_WAIT_COMP.equalsIgnoreCase(exVin.getStatus())) {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Not Linked - Applying wait compass VIN : " + exVin.getVin());
                            Long ncasId = cancelAdmission(exVin.getVin());
                            sendNotificationMail(exVin, Constants.DC_NOTIFICATION_STATUS_NO_INFO, ncasId);
                            exVin.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
                            exVin.setFlagType(DemoCarConstants.FLAG_TYPE_NOT_LINKED);
                            updateList.add(exVin);
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Updated Not Linked - Applying wait compass VIN : {}" + exVin.getVin());
                        }
                    }
                }
            }
        }

        return updateList;
    }

    private Long cancelAdmission(String vin) {
        logger.info("Cancelling the Admission.");
        DemoCarAdmission demoCarAdmission = demoCarAdmissionRepository.findByVin(vin);
        if (null == demoCarAdmission) {
            logger.info("The VIN is not registered.");
            return null;
        }
        demoCarAdmission.setStatus(DemoCarConstants.STATUS_CANCELLED);
        demoCarAdmissionRepository.save(demoCarAdmission);
        logger.info("Admission cancelled successfully.");
        return demoCarAdmission.getId();
    }

    @Override
    public void sendNotificationMail(VinDetails vinInfo, String status, Long ncasId) {
        logger.info("Sending notification mail to CA.");
        try {
            DealerEntity dealer = vinInfo.getDealer();
            if (dealer != null) {
                String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
                logger.info("API service URL {}", serviceLocation);
                HttpHeaders headers = new HttpHeaders();
                headers.set("principalId", String.valueOf(dealer.getUserId()));
                Properties body = new Properties();
                body.put("status", status);
                body.put("dealer", dealer.getCompanyName());
                body.put("shopName", dealer.getDealershipName());
                body.put("caName", dealer.getCaName());
                body.put("caMail", dealer.getEmail());
                body.put("ncasId", String.valueOf(ncasId));
                body.put("vin", vinInfo.getVin());
                HttpEntity<Properties> request = new HttpEntity<>(body, headers);
                String url = HTTP + serviceLocation + DEMOCAR_NOTIFICATION_MAIL;
                logger.info("Calling notification mail api : {}", url);
                ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
                if (response != null) {
                    logger.info("Notification mail response body : {}", response.getBody());
                } else {
                    logger.error("Failed to get response from Notification API.");
                }
            } else {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "No dealer is associated with the VIN :" + vinInfo.getVin());
            }
        } catch (Exception ex) {
            logger.error("Failed to send email notification to CA : {}", ex);
        }
    }

    @Override
    public void sendNcRegistrationCompleteMail(VinDetails vinInfo, String status, Long ncasId) {
        logger.info("Sending notification mail to CA.");
        try {
            DealerEntity dealer = vinInfo.getDealer();
            if (dealer != null) {
                String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
                logger.info("API service URL {}", serviceLocation);
                HttpHeaders headers = new HttpHeaders();
                headers.set("principalId", String.valueOf(dealer.getUserId()));
                Properties body = new Properties();
                body.put("status", status);
                body.put("dealer", dealer.getCompanyName());
                body.put("shopName", dealer.getDealershipName());
                body.put("caName", dealer.getCaName());
                body.put("caMail", dealer.getEmail());
                body.put("ncasId", String.valueOf(ncasId));
                body.put("vin", vinInfo.getVin());
                HttpEntity<Properties> request = new HttpEntity<>(body, headers);
                String url = HTTP + serviceLocation + DEMOCAR_REGISTRATION_MAIL;
                logger.info("Calling NC Registration mail api : {}", url);
                ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
                if (response != null) {
                    logger.info("NC Registration mail response body : {}", response.getBody());
                } else {
                    logger.error("Failed to get response from NC Registration API.");
                }
            } else {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "No dealer is associated with the VIN :" + vinInfo.getVin());
            }
        } catch (Exception ex) {
            logger.error("Failed to send email NC Registration to CA : {}", ex);
        }
    }

    @Override
    public List<PaidFreeDto> getPaidFreeInfo(String langCode) {
        List<PaidFreeDto> paidFreeDtoList = new ArrayList<>();
        PaidFreeDto paidFreeDto = new PaidFreeDto();
        paidFreeDto.setPaidOrFree(DemoCarConstants.PAID);
        if ("en".equals(langCode)) {
            paidFreeDto.setDisplayName(DemoCarConstants.PAID);
        } else {
            paidFreeDto.setDisplayName(DemoCarConstants.PAID_JP);
        }
        paidFreeDtoList.add(paidFreeDto);
        PaidFreeDto paidFreeDto1 = new PaidFreeDto();
        if ("en".equals(langCode)) {
            paidFreeDto1.setDisplayName(DemoCarConstants.FREE);
        } else {
            paidFreeDto1.setDisplayName(DemoCarConstants.FREE_JP);
        }
        paidFreeDto1.setPaidOrFree(DemoCarConstants.FREE);
        paidFreeDtoList.add(paidFreeDto1);
        return paidFreeDtoList;
    }

    @Override
    public List<RegistPattern> getRegistPatternInfo(String langCode) {
        List<RegistPattern> registPatternList = new ArrayList<>();
        RegistPattern registPattern = new RegistPattern();
        registPattern.setRegistPattern(DemoCarConstants.SOURCE_ADD_VIN);
        if ("en".equals(langCode)) {
            registPattern.setDisplayName(DemoCarConstants.SOURCE_ADD_VIN);
        } else {
            registPattern.setDisplayName(DemoCarConstants.SOURCE_ADD_VIN_JP);
        }
        registPatternList.add(registPattern);
        RegistPattern registPattern1 = new RegistPattern();
        if ("en".equals(langCode)) {
            registPattern1.setDisplayName(DemoCarConstants.SOURCE_UPLOAD);
        } else {
            registPattern1.setDisplayName(DemoCarConstants.SOURCE_UPLOAD_JP);
        }
        registPattern1.setRegistPattern(DemoCarConstants.SOURCE_UPLOAD);
        registPatternList.add(registPattern1);
        RegistPattern registPattern2 = new RegistPattern();
        registPattern2.setRegistPattern(DemoCarConstants.SOURCE_COMPASS);
        if ("en".equals(langCode)) {
            registPattern2.setDisplayName(DemoCarConstants.SOURCE_COMPASS);
        } else {
            registPattern2.setDisplayName(DemoCarConstants.SOURCE_COMPASS_JP);
        }
        registPatternList.add(registPattern2);
        return registPatternList;
    }

    private List<CarPlanDto> getCarPlanInfo(String langCode) {
        List<CarPlanDto> carPlanDtoList = new ArrayList<>();
        CarPlanDto carPlanDto = new CarPlanDto();
        carPlanDto.setCarPlan(DemoCarConstants.DEMO_CAR_PLAN);
        if ("en".equals(langCode)) {
            carPlanDto.setDisplayName(DemoCarConstants.DEMO_CAR_PLAN);
        } else {
            carPlanDto.setDisplayName(DemoCarConstants.DEMO_CAR_PLAN_JP);
        }
        carPlanDtoList.add(carPlanDto);
        CarPlanDto carPlanDto1 = new CarPlanDto();
        carPlanDto1.setCarPlan(DemoCarConstants.COMPANY_CAR_PLAN);
        if ("en".equals(langCode)) {
            carPlanDto1.setDisplayName(DemoCarConstants.COMPANY_CAR_PLAN);
        } else {
            carPlanDto1.setDisplayName(DemoCarConstants.COMPANY_CAR_PLAN_JP);
        }
        carPlanDtoList.add(carPlanDto1);
        return carPlanDtoList;
    }


    @Override
    public List<PublicOrPrivateDto> getPublicPrivateInfo(String langCode) {
        List<PublicOrPrivateDto> publicOrPrivateDtoList = new ArrayList<>();
        PublicOrPrivateDto publicOrPrivateDto = new PublicOrPrivateDto();
        publicOrPrivateDto.setPublicOrPrivate(DemoCarConstants.FLAG_TYPE_NOT_LINKED);
        if ("en".equals(langCode)) {
            publicOrPrivateDto.setDisplayName(DemoCarConstants.NOT_LINKED);
        } else {
            publicOrPrivateDto.setDisplayName(DemoCarConstants.FLAG_TYPE_NOT_LINKED);
        }
        publicOrPrivateDtoList.add(publicOrPrivateDto);
        PublicOrPrivateDto publicOrPrivateDto1 = new PublicOrPrivateDto();
        publicOrPrivateDto1.setPublicOrPrivate(DemoCarConstants.FLAG_TYPE_TO_BE_PUBLISHED);
        if ("en".equals(langCode)) {
            publicOrPrivateDto1.setDisplayName(DemoCarConstants.TO_BE_PUBLISHED);
        } else {
            publicOrPrivateDto1.setDisplayName(DemoCarConstants.FLAG_TYPE_TO_BE_PUBLISHED);
        }
        publicOrPrivateDtoList.add(publicOrPrivateDto1);
        PublicOrPrivateDto publicOrPrivateDto2 = new PublicOrPrivateDto();
        publicOrPrivateDto2.setPublicOrPrivate(DemoCarConstants.FLAG_TYPE_PRIVATE);
        if ("en".equals(langCode)) {
            publicOrPrivateDto2.setDisplayName(DemoCarConstants.PRIVATE);
        } else {
            publicOrPrivateDto2.setDisplayName(DemoCarConstants.FLAG_TYPE_PRIVATE);
        }
        publicOrPrivateDtoList.add(publicOrPrivateDto2);
        PublicOrPrivateDto publicOrPrivateDto3 = new PublicOrPrivateDto();
        publicOrPrivateDto3.setPublicOrPrivate(DemoCarConstants.FLAG_TYPE_PUBLIC);
        if ("en".equals(langCode)) {
            publicOrPrivateDto3.setDisplayName(DemoCarConstants.PUBLIC);
        } else {
            publicOrPrivateDto3.setDisplayName(DemoCarConstants.FLAG_TYPE_PUBLIC);
        }
        publicOrPrivateDtoList.add(publicOrPrivateDto3);
        PublicOrPrivateDto publicOrPrivateDto4 = new PublicOrPrivateDto();
        publicOrPrivateDto4.setPublicOrPrivate(DemoCarConstants.FLAG_TYPE_MISMATCH);
        if ("en".equals(langCode)) {
            publicOrPrivateDto4.setDisplayName(DemoCarConstants.MISMATCH);
        } else {
            publicOrPrivateDto4.setDisplayName(DemoCarConstants.FLAG_TYPE_MISMATCH);
        }
        publicOrPrivateDtoList.add(publicOrPrivateDto4);
        return publicOrPrivateDtoList;
    }

    @Override
    public void sendNcIdAndNcPasswordToCa(DemoCarAdmission admission, VinDetails vinDetails, String startDate, String endDate) {

        logger.info("Sending ncid and nc password mail to CA.");
        try {
            DealerEntity dealer = vinDetails.getDealer();
            if (dealer != null) {
                String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
                logger.info("API service URL {}", serviceLocation);
                HttpHeaders headers = new HttpHeaders();
                headers.set("principalId", String.valueOf(dealer.getUserId()));
                Properties body = new Properties();
                body.put("vin", vinDetails.getVin());
                body.put("dealer", dealer.getCompanyName());
                body.put("shopName", dealer.getDealershipName());
                body.put("caName", dealer.getCaName());
                logger.info("admission={} ", admission);
                body.put("ncasId", admission.getId().toString());
                body.put("ncPassword", admission.getNcPassword());
                body.put("ncid", admission.getNcId());
                body.put("caMail", dealer.getEmail());
                String validity = startDate + " ~ " + endDate;
                body.put("validity", validity);
                HttpEntity<Properties> request = new HttpEntity<>(body, headers);
                String url = HTTP + serviceLocation + DEMOCAR_NCID_PWD_MAIL;
                logger.info("Calling notification mail api : {}", url);
                ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
                if (Constants.SUCCESS.equals(response.getBody())) {
                    logger.info("ncid and nc password mail  sent to CA.");
                } else {
                    logger.info("Failed to send ncid and nc password mail  sent to CA.");
                }
            } else {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "No dealer is associated with the VIN :" + vinDetails.getVin());
            }
        } catch (Exception ex) {
            logger.error("Failed to send ncid and nc password mail  sent to CA. : {}", ex);
        }

    }

    @Override
    public void sendMailToDocommo(List<DocommoMailDto> docommoMailDtoList) {
        logger.info("Sending  mail to docommo.");
        try {
            String serviceLocation = serviceResolver.resolve(Constants.NOTIFICATION_SERVICE);
            logger.info("API service URL {}", serviceLocation);
            HttpHeaders headers = new HttpHeaders();
            headers.set("principalId", "123");
            HttpEntity<List<DocommoMailDto>> request = new HttpEntity<>(docommoMailDtoList, headers);
            String url = HTTP + serviceLocation + DOCOMMO_NOTIFICATION_MAIL;
            logger.info("Calling notification mail api : {}", url);
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            if (Constants.SUCCESS.equals(response.getBody())) {
                logger.info("Notification mail sent to docommo.");
            } else {
                logger.info("Failed to send email notification to docommo.");
            }
        } catch (Exception ex) {
            logger.error("Failed to send email notification to docommo : {}", ex);
        }
    }

    private boolean isSameRecordFromCompass(VinDetails upVin, VinDetails exVin) {
        return upVin.getFlagType().equals(exVin.getFlagType())
                && upVin.getProfitDealerCode().equals(exVin.getProfitDealerCode())
                && upVin.getProfitDealerShopCode().equals(exVin.getProfitDealerShopCode());
    }

    private List<VinDetails> getVinDeleteList(List<VinDetails> existingVins, List<VinDetails> uploadedVins) {
        List<VinDetails> deleteList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(existingVins)) {
            for (VinDetails exVin : existingVins) {
                VinDetails upVin = DemoCarUtil.findVinDetailsByVin(uploadedVins, exVin.getVin());
                if (exVin.getCreatedDate().before(getDateBeforeXdays(180)) && upVin == null
                        && !isActiveVehicle(exVin)) {
                    deleteList.add(exVin);
                } else if (upVin == null && DemoCarConstants.SOURCE_UPLOAD.equals(exVin.getSource()) &&
                        isCompassLinked(exVin) && !isActiveVehicle(exVin)) {
                    deleteList.add(exVin);
                }
            }
        }
        return deleteList;
    }

    private boolean isCompassLinked(VinDetails exVin) {
        return DemoCarConstants.FLAG_TYPE_PUBLIC.equals(exVin.getFlagType())
                || DemoCarConstants.FLAG_TYPE_PRIVATE.equals(exVin.getFlagType());
    }

    private boolean isActiveVehicle(VinDetails exVin) {
        return DemoCarConstants.STATUS_AVAILABLE.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_ON_LOAN.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_APPLYING.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_PW_UPDATING.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_APPLYING_WAIT_COMP.equalsIgnoreCase(exVin.getStatus());

    }

    private boolean isActiveTabVin(VinDetails exVin) {
        return DemoCarConstants.STATUS_AVAILABLE.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_ON_LOAN.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_APPLYING.equalsIgnoreCase(exVin.getStatus())
                || DemoCarConstants.STATUS_PW_UPDATING.equalsIgnoreCase(exVin.getStatus());

    }

    private Date getDateBeforeXdays(int days) {
        return Date.from(LocalDateTime.now().minusDays(days).atZone(ZoneId.systemDefault()).toInstant());
    }

    private TakeActionVinDetailsDto convertToDto(VinDetails vinDetails) {
        return modelMapper.map(vinDetails, TakeActionVinDetailsDto.class);
    }

    private DemoCarSaveRegInfoDto convertToDemoCarSaveRegInfoDto(VinDetails vinDetails) {
        modelMapper.getConfiguration().setAmbiguityIgnored(true);
        return modelMapper.map(vinDetails, DemoCarSaveRegInfoDto.class);
    }

    private Map<String, String> isIvi(String vin) {
        Map<String, String> modelMap = new HashMap<>();
        String vinFirst = vin.substring(0, vin.indexOf("-"));
        String vinSecond = vin.substring(vin.indexOf("-") + 1);
        if ("HV37".equals(vinFirst)) {
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(450001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "SKYLINE(2019/09~)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }

        if ("HNV37".equals(vinFirst)) {
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(550001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "SKYLINE(2019/09~)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }

        if ("RV37".equals(vinFirst)) {
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(100001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "SKYLINE(2019/09~)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }

        if ("ZE1".equals(vinFirst)) {
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(90001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "LEAF(2020/02～)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }

        if ("E13".equals(vinFirst)) {
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(000001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "NOTE(2020/12～)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }

        if ("FE13".equals(vinFirst)) {
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(000001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "NOTE(2020/12～)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }
        if ("SNE13".equals(vinFirst)) {
            // String vinThird = vinSecond.substring(1);
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(000001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "NOTE(2020/12～)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }
        if ("FSNE13".equals(vinFirst)) {
            // String vinThird = vinSecond.substring(1);
            Integer vinSecondNumber = Integer.parseInt(vinSecond);
            Range<Integer> iviRange = Range.between(000001, 999999);
            if (iviRange.contains(vinSecondNumber)) {
                modelMap.put("modelName", "NOTE(2020/12～)");
                modelMap.put("ivi", "yes");
                return modelMap;
            }
        }
        if (StringUtils.isNotEmpty(getModelName(vinFirst))) {
            modelMap.put("modelName", getModelName(vinFirst));
        } else {
            modelMap.put("modelName", "");
        }
        return modelMap;
    }

    private String getModelName(String vinFirst) {
        final ImmutableList<String> daysModelList =
                ImmutableList.of("B43W", "B44W", "B45W", "B46W", "B47W", "B48W");
        final ImmutableList<String> rooxModelList =
                ImmutableList.of("B44A", "B45A", "B47A", "B48A");
        final ImmutableList<String> kicksModelList =
                ImmutableList.of("P15");
        final ImmutableList<String> xtrailModelList =
                ImmutableList.of("T32", "NT32", "HT32", "HNT32");
        final ImmutableList<String> elgrandModelList =
                ImmutableList.of("PE52", "PNE52", "TE52", "TNE52");
        final ImmutableList<String> teanaModelList =
                ImmutableList.of("L33");
        final ImmutableList<String> fugaModelList =
                ImmutableList.of("Y51", "KY51", "KNY51", "HY51");
        final ImmutableList<String> cimaModelList =
                ImmutableList.of("HGY51");
        if (daysModelList.contains(vinFirst)) {
            return "DAYZ";
        }
        if (rooxModelList.contains(vinFirst)) {
            return "ROOX";
        }
        if (kicksModelList.contains(vinFirst)) {
            return "KICKS";
        }
        if (xtrailModelList.contains(vinFirst)) {
            return "X-TRAIL";
        }
        if (elgrandModelList.contains(vinFirst)) {
            return "ELGRAND";
        }
        if (teanaModelList.contains(vinFirst)) {
            return "TEANA";
        }
        if (fugaModelList.contains(vinFirst)) {
            return "FUGA";
        }
        if (cimaModelList.contains(vinFirst)) {
            return "CIMA";
        }
        return null;
    }

    private Pageable getPagination(
            Integer offset, Integer limit, String sortBy, String sortOrder, String lang) {
        Sort.Direction direction =
                (sortOrder != null && Constants.SORT_ASCENDING.equals(sortOrder))
                        ? Sort.Direction.ASC
                        : Sort.Direction.DESC;
        sortBy = (sortBy != null && "status".equals(sortBy) && "jp".equals(lang)) ? "statusJp" : sortBy;
        sortBy =
                (sortBy != null && sortBy.length() > 0 && SORTING_KEYS.containsKey(sortBy))
                        ? SORTING_KEYS.get(sortBy)
                        : SORTING_KEYS.get("createdDate");
        return PageRequest.of(offset, limit, direction, sortBy);
    }

    @Transactional
    public List<ModelDTO> getModelInfo(String lang, String vin) {
        VinDetails vinDetails = vinDetailsRepository.findByVin(vin);
        DemoCarModel model = null;
        if (vinDetails != null) {
            model = modelRepository.findByModelNameAndLangCode(vinDetails.getModelName(), lang);
        }
        if (model != null) {
            List<ModelDTO> modelDTOS = new ArrayList<>();
            modelDTOS.add(convertModelEntityToDTO(model));
            return modelDTOS;
        }
        return modelRepository.findByLangCodeOrderByModelDisplayOrderAsc(lang).stream()
                .map(this::convertModelEntityToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<StatusDto> getStatusInfo(String langCode) {
        List<StatusDto> status = new ArrayList<>();
        StatusDto statusDto1 = new StatusDto();
        statusDto1.setStatus(DemoCarConstants.STATUS_NOT_LINKED_VPM);
        if ("en".equals(langCode)) {
            statusDto1.setDisplayName(DemoCarConstants.STATUS_NOT_LINKED_VPM);
        } else {
            statusDto1.setDisplayName(DemoCarConstants.STATUS_NOT_LINKED_VPM_JP);
        }
        status.add(statusDto1);
        StatusDto statusDto2 = new StatusDto();
        if ("en".equals(langCode)) {
            statusDto2.setDisplayName(DemoCarConstants.STATUS_NOT_EXIST_VPM);
        } else {
            statusDto2.setDisplayName(DemoCarConstants.STATUS_NOT_EXIST_VPM_JP);
        }
        statusDto2.setStatus(DemoCarConstants.STATUS_NOT_EXIST_VPM);
        status.add(statusDto2);
        StatusDto statusDto3 = new StatusDto();
        statusDto3.setStatus(DemoCarConstants.STATUS_CAN_PUBLISH);
        if ("en".equals(langCode)) {
            statusDto3.setDisplayName(DemoCarConstants.STATUS_CAN_PUBLISH);
        } else {
            statusDto3.setDisplayName(DemoCarConstants.STATUS_CAN_PUBLISH_JP);
        }
        status.add(statusDto3);
        StatusDto statusDto4 = new StatusDto();
        statusDto4.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
        if ("en".equals(langCode)) {
            statusDto4.setDisplayName(DemoCarConstants.STATUS_NOT_APPLIED);
        } else {
            statusDto4.setDisplayName(DemoCarConstants.STATUS_NOT_APPLIED_JP);
        }
        status.add(statusDto4);
        StatusDto statusDto5 = new StatusDto();
        statusDto5.setStatus(DemoCarConstants.STATUS_APPLYING);
        if ("en".equals(langCode)) {
            statusDto5.setDisplayName(DemoCarConstants.STATUS_APPLYING);
        } else {
            statusDto5.setDisplayName(DemoCarConstants.STATUS_APPLYING_JP);
        }
        status.add(statusDto5);
        StatusDto statusDto6 = new StatusDto();
        statusDto6.setStatus(DemoCarConstants.STATUS_IMPORT_FAILURE_CW);
        if ("en".equals(langCode)) {
            statusDto6.setDisplayName(DemoCarConstants.STATUS_IMPORT_FAILURE_CW);
        } else {
            statusDto6.setDisplayName(DemoCarConstants.STATUS_IMPORT_FAILURE_CW_JP);
        }
        status.add(statusDto6);
        StatusDto statusDto8 = new StatusDto();
        statusDto8.setStatus(DemoCarConstants.STATUS_APPLYING_WAIT_COMP);
        if ("en".equals(langCode)) {
            statusDto8.setDisplayName(DemoCarConstants.STATUS_APPLYING_WAIT_COMP);
        } else {
            statusDto8.setDisplayName(DemoCarConstants.STATUS_APPLYING_WAIT_COMP_JP);
        }
        status.add(statusDto8);
        StatusDto statusDto11 = new StatusDto();
        statusDto11.setStatus(DemoCarConstants.STATUS_AVAILABLE);
        if ("en".equals(langCode)) {
            statusDto11.setDisplayName(DemoCarConstants.STATUS_AVAILABLE);
        } else {
            statusDto11.setDisplayName(DemoCarConstants.STATUS_AVAILABLE_JP);
        }
        status.add(statusDto11);
        StatusDto statusDto12 = new StatusDto();
        statusDto12.setStatus(DemoCarConstants.STATUS_ON_LOAN);
        if ("en".equals(langCode)) {
            statusDto12.setDisplayName(DemoCarConstants.STATUS_ON_LOAN);
        } else {
            statusDto12.setDisplayName(DemoCarConstants.STATUS_ON_LOAN_JP);
        }
        status.add(statusDto12);
        StatusDto statusDto13 = new StatusDto();
        statusDto13.setStatus(DemoCarConstants.STATUS_PW_UPDATING);
        if ("en".equals(langCode)) {
            statusDto13.setDisplayName(DemoCarConstants.STATUS_PW_UPDATING);
        } else {
            statusDto13.setDisplayName(DemoCarConstants.STATUS_PW_UPDATING_JP);
        }
        status.add(statusDto13);
        return status;
    }

    private ModelDTO convertModelEntityToDTO(final DemoCarModel model) {
        final ModelDTO modelDTO = new ModelDTO();
        modelDTO.setId(model.getId());
        modelDTO.setName(model.getModelName());
        modelDTO.setDisplayName(model.getDisplayName());
        modelDTO.setImgUrl(model.getUrl());
        modelDTO.setGrades(getGradeListByModelId(model.getId()));
        return modelDTO;
    }

    @Transactional
    private List<GradeDTO> getGradeListByModelId(final Long modelName) {
        return gradeRepository.getGradesByModelId(modelName).stream()
                .map(this::convertGradeEntityToGradeDTO)
                .collect(Collectors.toList());
    }

    private GradeDTO convertGradeEntityToGradeDTO(final DemoCarGrade grade) {
        final GradeDTO gradeDTO = new GradeDTO();
        gradeDTO.setId(grade.getId());
        gradeDTO.setModelName(grade.getModel().getModelName());
        gradeDTO.setName(grade.getGradeName());
        gradeDTO.setDisplayName(grade.getDisplayName());
        gradeDTO.setNaviTypes(getNaviListByGradeName(grade.getId()));
        return gradeDTO;
    }

    @Transactional
    private List<NaviDTO> getNaviListByGradeName(final long gradeId) {
        return naviRepository.getNaviListByGradeId(gradeId).stream()
                .map(this::convertNaviEntityToDTO)
                .collect(Collectors.toList());
    }

    private NaviDTO convertNaviEntityToDTO(final DemoCarNavi navi) {
        if (navi != null) {
            final NaviDTO naviDTO = new NaviDTO();
            naviDTO.setId(navi.getId());
            naviDTO.setGradeId(navi.getGrade().getId());
            naviDTO.setName(navi.getNaviName());
            naviDTO.setDisplayName(navi.getDisplayName());
            naviDTO.setPackagePlans(getPlanListByNaviName(navi));
            return naviDTO;
        }
        return null;
    }


    @Transactional
    private List<PackagePlanDTO> getPlanListByNaviName(final DemoCarNavi navi) {
        return demoCarPackagePlanRepository
                .getPackageListByNaviId(navi.getId()).stream()
                .map(this::convertPackagePlanEntityToDTO)
                .collect(Collectors.toList());
    }

    private PackagePlanDTO convertPackagePlanEntityToDTO(final DemoCarPackagePlan packagePlan) {
        if (packagePlan != null) {
            final PackagePlanDTO packagePlanDTO = new PackagePlanDTO();
            packagePlanDTO.setId(packagePlan.getId());
            packagePlanDTO.setName(packagePlan.getPackagePlanName());
            packagePlanDTO.setDisplayName(packagePlan.getDisplayName());
            packagePlanDTO.setNaviId(packagePlan.getNavi().getId());
            packagePlanDTO.setPrice(packagePlan.getPrice());
            packagePlanDTO.setCarPlan(packagePlan.getCarPlan());
            packagePlanDTO.setTcPattern(packagePlan.getTermsName());
            if (packagePlan.getDescription() != null && BASIC_ICC.equals(packagePlan.getDescription())) {
                packagePlanDTO.setIccFee(DemoCarConstants.ICC_FREE);
            } else if (0 == packagePlan.getIccFee()) {
                packagePlanDTO.setIccFee(DemoCarConstants.FREE);
            } else {
                packagePlanDTO.setIccFee(packagePlan.getIccFee().toString());
            }
            return packagePlanDTO;
        }
        return null;
    }

    private Timestamp convertToSqlTimeStamp(String date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date parsedTimeStamp = dateFormat.parse(date);
        Timestamp timestamp = new Timestamp(parsedTimeStamp.getTime());
        return timestamp;
    }

    private Timestamp convertToSqlTimeStampEndDate(String date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date parsedTimeStamp = dateFormat.parse(date);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(parsedTimeStamp);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
        return timestamp;
    }

    @Override
    public List<VinDetailsDto> publishToCa(List<VinRequestDto> vinRequestList, String langCode) {
        List<VinDetailsDto> vinList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(vinRequestList)) {
            vinRequestList.forEach(vinInfo -> {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Publishing VIN : " + vinInfo.getVinNumber());
                VinDetails existingVin = vinDetailsRepository.findByVin(vinInfo.getVinNumber());
                if (null == existingVin) {
                    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "The VIN is not exist in NCAS : " + vinInfo.getVinNumber());
                } else {
                    existingVin.setStatus(DemoCarConstants.STATUS_NOT_APPLIED);
                    VinDetails vin = vinDetailsRepository.save(existingVin);
                    VinDetailsDto vinDetailsDto = DemoCarModelMapperUtil.map(vin, VinDetailsDto.class);
                    if (DemoCarConstants.EN.equals(langCode)) {
                        vinDetailsDto.setStatusDisplayName(DemoCarConstants.STATUS_NOT_APPLIED);
                    } else {
                        vinDetailsDto.setStatusDisplayName(DemoCarConstants.STATUS_NOT_APPLIED_JP);
                    }
                    vinList.add(vinDetailsDto);
                }
            });
        }
        return vinList;
    }

    @Override
    public VinDetailsDto markAsReturned(VinRequestDto returnedVin, String lang) {
        VinDetailsDto vinDetailsDto = null;
        try {
            Optional<DemoCarTestDrive> testDrive = demoCarTestDriveRepository.findById(returnedVin.getTestDriveId());
            if (!testDrive.isPresent()) {
                logger.info("The Test drive with ID : {} is not exist in NCAS", returnedVin.getTestDriveId());
                return null;
            }
            DemoCarTestDrive demoCarTestDrive = testDrive.get();
            demoCarTestDrive.setStatus(DemoCarConstants.TD_STATUS_EXPIRED);
            demoCarTestDriveRepository.save(demoCarTestDrive);
            DemoCarAdmission demoCarAdmission = demoCarTestDrive.getAdmission();
            if (null == demoCarAdmission) {
                logger.info("Admission coudn't find in NCAS for Test Drive : {}", demoCarTestDrive.getId());
                return null;
            }
            demoCarAdmission.setStatus(DemoCarConstants.STATUS_AVAILABLE);
            demoCarAdmissionRepository.save(demoCarAdmission);
            logger.info("Admission updated successfully to Available status.");

            final VinDetails vin = vinDetailsRepository.findByVin(demoCarAdmission.getVin());
            if (null == vin) {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "The VIN is not exist in NCAS : " + demoCarAdmission.getVin());
                return null;
            }
            vin.setStatus(DemoCarConstants.STATUS_PW_UPDATING);
            vinDetailsRepository.save(vin);
            Map resetResponse = sendResetPasswordRequest(vin, demoCarAdmission);
            if (resetResponse != null && "0".equals(resetResponse.get("responseCd"))) {
                vin.setStatus(DemoCarConstants.STATUS_AVAILABLE);
                vinDetailsRepository.save(vin);
                demoCarAdmission.setNcPassword(resetResponse.get("ncPw").toString());
                demoCarAdmissionRepository.save(demoCarAdmission);
                sendNotificationMail(vin, Constants.DC_NOTIFICATION_STATUS_RETURN_MANUALLY, demoCarAdmission.getId());
                logger.info("Password reset success.");
            } else {
                Timer timer = new Timer();
                int begin = 5 * (60 * 1000);
                int timeInterval = 5 * (60 * 1000);
                timer.schedule(new TimerTask() {
                    int counter = 0;

                    @Override
                    public void run() {
                        logger.info("Retrying password reset : {}", counter + 1);
                        Map resetResponse = sendResetPasswordRequest(vin, demoCarAdmission);
                        if (resetResponse != null && "0".equals(resetResponse.get("responseCd"))) {
                            logger.info("Retrying : reset password success.");
                            vin.setStatus(DemoCarConstants.STATUS_AVAILABLE);
                            vinDetailsRepository.save(vin);
                            demoCarAdmission.setNcPassword(resetResponse.get("ncPw").toString());
                            demoCarAdmissionRepository.save(demoCarAdmission);
                            sendNotificationMail(vin, Constants.DC_NOTIFICATION_STATUS_RETURN_MANUALLY, demoCarAdmission.getId());
                        } else {
                            logger.info("Retrying : reset password failed.");
                        }
                        counter++;
                        if (counter >= 3 || (resetResponse != null && "0".equals(resetResponse.get("responseCd")))) {
                            timer.cancel();
                        }
                    }
                }, begin, timeInterval);

            }
            vinDetailsDto = DemoCarModelMapperUtil.map(vin, VinDetailsDto.class);
        } catch (Exception e) {
            logger.error("Failed to update the VIN as Returned : {}", returnedVin.getTestDriveId());
            return null;
        }
        return vinDetailsDto;
    }

    private Map sendResetPasswordRequest(VinDetails vin, DemoCarAdmission demoCarAdmission) {
        LinkedHashMap linkedHashMap = null;
        try {
            String serviceLocation = serviceResolver.resolve(Constants.CARWINGS_SERVICE);
            String url = HTTP + serviceLocation + CAR_WINGS_RESET_PWD;
            logger.info("CW Reset password URL {}", url);
            HttpHeaders headers = new HttpHeaders();
            headers.set(PRINCIPAL_ID, "2");
            headers.setContentType(MediaType.APPLICATION_JSON);
            RestTemplate restTemplate = new RestTemplate();
            ResetPasswordRequestDTO resetPasswordRequestDTO = new ResetPasswordRequestDTO();
            resetPasswordRequestDTO.setVin(vin.getVin());
            resetPasswordRequestDTO.setCwId(demoCarAdmission.getCwId());
            HttpEntity<ResetPasswordRequestDTO> request = new HttpEntity<>(resetPasswordRequestDTO, headers);
            ResponseEntity<ResponseDTO> response = restTemplate.exchange(url, HttpMethod.POST, request,
                    ResponseDTO.class);
            if (response != null && response.getBody() != null) {
                logger.info("response from cw for Reset password response", response.getBody().getData());
                linkedHashMap = (LinkedHashMap) response.getBody().getData();
                logger.info("response from cw for Reset password map response", linkedHashMap.get("responseCd"));
            }
        } catch (Exception ex) {
            logger.error("Failed to send Reset password request", ex);
            return null;
        }
        return linkedHashMap;
    }

}
