package com.nissan.democar.util;

import com.jcraft.jsch.*;
import com.nissan.common.config.SecretsManager;
import com.nissan.common.entity.JobDetails;
import com.nissan.common.repository.JobDetailRepository;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import org.apache.commons.io.FileUtils;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
public class SftpNloUpload {

    public static final String SFTP = "sftp";
    private static final Logger logger = LoggerFactory.getLogger(SftpNloUpload.class);
    public static final String STRICT_HOST_KEY_CHECKING = "StrictHostKeyChecking";
    public static final String NO = "no";
    public static final String SUCCESS = "success";
    public static final String FAILED = "failed";
    public static final String SYSTEM = "system";

    @Value("${nlo.sftp.server.username}")
    private String userName;

    @Value("${nlo.sftp.server.hostname}")
    private String remoteHost;

    @Value("${nlo.sftp.server.privateKey}")
    private String NloRSAKey;

    @Autowired
    JobDetailRepository jobDetailRepository;

    private Session setupJsch() throws JSchException, IOException {
        SecretsManager secretsManager = new SecretsManager();
        ByteBuffer byteBuffer = secretsManager.getCertificate(NloRSAKey);
        InputStream inputStream = new ByteArrayInputStream(byteBuffer.array());
        File somethingFile = File.createTempFile("nlo", ".pem");
        try {
            somethingFile.setReadable(true);
            FileUtils.copyInputStreamToFile(inputStream, somethingFile);
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        JSch jsch = new JSch();
        jsch.addIdentity(somethingFile.getPath());
        Session jschSession = jsch.getSession(userName, remoteHost, 22);
        jschSession.setConfig(STRICT_HOST_KEY_CHECKING, NO);
        return jschSession;
    }


    public void upload(String path) throws IOException {
        Session sftpSession = null;
        try {
            logger.info("inside sftp upload");
            sftpSession = setupJsch();
            sftpSession.connect();

            ChannelSftp channelSftp = (ChannelSftp) sftpSession.openChannel(SFTP);
            channelSftp.connect();
            logger.info("contents of the file are ");
            try {
                /** Create an object of file reader class with CSV file as a parameter. */
                FileReader filereader = new FileReader(path);

                /** create csvReader object and skip first Line */
                CSVReader csvReader = new CSVReaderBuilder(filereader).withSkipLines(1).build();
                List<String[]> allData = csvReader.readAll();
                logger.info("size of all data {}", allData.size());
                /** print Data */
                for (String[] row : allData) {
                    for (String cell : row) {
                        logger.info(cell);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            channelSftp.put(path, "/export/internalput/in5/COM22423");
            channelSftp.exit();
            logger.info("inside sftp upload saving job details");
            jobDetailRepository.save(createJobDetail(SUCCESS, path));

            logger.info("file path before ={}", path);
            Path fileToDeletePath = Paths.get(path);
            logger.info("file path  ={}", fileToDeletePath);
            logger.info("file uploaded successfully to the sftp server");
        } catch (JSchException | SftpException e) {
            jobDetailRepository.save(createJobDetail(FAILED, path));
            logger.error("exception occurred when uploading file to sftp server={}", e.getMessage());
        } finally {
            if (sftpSession != null) {
                sftpSession.disconnect();
            }
        }
    }

    private JobDetails createJobDetail(String status, String localFile) {
        JobDetails jobDetails = new JobDetails();
        jobDetails.setFileName(localFile);
        jobDetails.setStatus(status);
        jobDetails.setCreatedDate(new Date());
        jobDetails.setCreatedBy(SYSTEM);
        jobDetails.setLastModifiedDate(new Date());
        jobDetails.setLastModifiedBy(SYSTEM);
        return jobDetails;
    }

    private String createDirectoryForCurrentDate(ChannelSftp channelSftp) {
        logger.info("Inside createDirectoryForCurrentDate");
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateTimeInfo = dateFormat.format(new Date());
        try {
            channelSftp.cd(dateTimeInfo);
            logger.info("Directory {} already exists", dateTimeInfo);
        } catch (SftpException e) {
            try {
                channelSftp.mkdir(dateTimeInfo);
                channelSftp.cd(dateTimeInfo);
                logger.info("Directory {} created successfully", dateTimeInfo);
            } catch (SftpException ex) {
                logger.error("Directory {} could not be created", dateTimeInfo);
                ex.printStackTrace();
            }
        }
        String pwd = channelSftp.lpwd();
        logger.info("present working directory : {}", pwd);
        return pwd;
    }
}
