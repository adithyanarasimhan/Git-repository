package com.nissan.democar.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;

import com.google.common.collect.ImmutableList;
import com.nissan.common.dto.ModelDTO;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.repository.DealerRepository;
import com.nissan.democar.dto.*;
import com.nissan.democar.util.DemoCarConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.nissan.common.dto.ResponseDTO;
import com.nissan.common.util.Constants;
import com.nissan.democar.service.VinDetailsService;

import static com.nissan.common.util.Constants.PRINCIPAL_ID;

@RestController
@RequestMapping("secured/api/v1")
public class DemoCarHomeController {

    private static final Logger logger = LoggerFactory.getLogger(DemoCarHomeController.class);
    @Autowired
    private VinDetailsService vinDetailsService;

    @Autowired
    private DealerRepository dealerRepository;


    @PostMapping(value = "{langCode}/upload-vinlist")
    ResponseEntity<ResponseDTO> uploadVinList(HttpServletRequest httpServletRequest, @RequestParam(name = "file") MultipartFile file,
                                              @RequestParam(name = "token") String token, @PathVariable(name = "langCode") String langCode)
            throws ServletException, IOException {
        logger.info("upload-excel invoked.");
        if (file.getSize() == 0) {
            throw new RuntimeException("Please select file to upload");
        }
        String principalId = httpServletRequest.getHeader(PRINCIPAL_ID);
        DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
        Map<String, Object> result = vinDetailsService.saveVinDetails(file, token, dealer, langCode);
        Boolean status = (Boolean) result.get("success");
        String message = (String) result.get("message");
        if (status) {
            String infoMessage;
            if ("en".equals(langCode)) {
                infoMessage = "file uploaded successfully";
            } else {
                infoMessage = "ファイルのアップロードが完了しました";
            }
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", infoMessage);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            ResponseDTO response =
                    new ResponseDTO(Constants.FAILED, "500", message);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping(value = "{langCode}/add-vin")
    ResponseEntity<ResponseDTO> addVin(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode, @RequestBody VinDetailsDto takeActionVinDetailsDto)
            throws ServletException, IOException {
        logger.info("add vin invoked.");
        String principalId = httpServletRequest.getHeader("principalId");
        DealerEntity dealer = dealerRepository.findByUserId(Long.valueOf(principalId));
        VinDetailsDto vinDetails = vinDetailsService.addSingleVin(takeActionVinDetailsDto, dealer, langCode);
        if (vinDetails != null) {
            logger.info("vin got inserted successfully");
            String infoMessage;
            if ("en".equals(langCode)) {
                infoMessage = "vin got inserted successfully";
            } else {
                infoMessage = "VIN追加が完了しました";
            }
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", infoMessage);
            response.setData(vinDetails);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "error in inserting vin in NCAS");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @PostMapping(value = "{langCode}/get-vinlist", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO> fetchVinInformation(
            HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang, @RequestBody VinDetailsRequestDto vinDetailsRequestDto) {
        logger.info("inside fetchVinInformation");
        String pricipalId = httpServletRequest.getHeader("principalId");
        ListTakeActionVinDetailsDto listTakeActionVinDetailsDto = vinDetailsService.fetchVinDetails(vinDetailsRequestDto, lang, pricipalId);
        if (listTakeActionVinDetailsDto != null && listTakeActionVinDetailsDto.getTotalCount() == 666) {
            logger.info("not authorised  to view this list");
            ResponseDTO response =
                    new ResponseDTO(Constants.FAILED, "403", "User is not able to view this resource");
            response.setData(listTakeActionVinDetailsDto);
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        } else if (listTakeActionVinDetailsDto != null) {
            logger.info("vin list fetched successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "vin list fetched successfully");
            response.setData(listTakeActionVinDetailsDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            logger.info("No Vin Available");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "No Vin Available");
            response.setData(new ArrayList<>());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    /**
     * Method to fetch VIN informations such as VIN details, Package plan and Dealer information
     *
     * @param httpServletRequest
     * @param lang
     * @param vinRequestDto
     * @return
     */
    @PostMapping(value = "{langCode}/get-vin", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO> fetchSingleVinInformation(
            HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang, @RequestBody VinRequestDto vinRequestDto) {
        logger.info("inside fetchSingleVinInformation");
        VinInformationDTO vinInfo = vinDetailsService.fetchSingleVinDetails(httpServletRequest, vinRequestDto.getVinNumber(), lang);
        if (vinInfo != null) {
            logger.info("vin informations fetched successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "vin details fetched successfully");
            response.setData(vinInfo);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        logger.info("The VIN is not available");
        ResponseDTO response =
                new ResponseDTO(Constants.SUCCESS, "200", "The VIN is not available");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "{langCode}/get-models-status")
    public ResponseEntity<ResponseDTO> getAllModelsAndStatus(HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String langCode) {

        List<ModelDTO> modelInfo = vinDetailsService.getModelInfo(langCode, "");

        DemoCarModelsAndStatusDto demoCarModelsAndStatusDto = new DemoCarModelsAndStatusDto();
        demoCarModelsAndStatusDto.setModelInfo(modelInfo);
        List<StatusDto> status = vinDetailsService.getStatusInfo(langCode);
        List<RegistPattern> registPattern = vinDetailsService.getRegistPatternInfo(langCode);
        List<PaidFreeDto> paidOrFree = vinDetailsService.getPaidFreeInfo(langCode);
        List<PublicOrPrivateDto> publicOrPrivate = vinDetailsService.getPublicPrivateInfo(langCode);
        demoCarModelsAndStatusDto.setStatus(status);
        demoCarModelsAndStatusDto.setRegistPattern(registPattern);
        demoCarModelsAndStatusDto.setPaidOrFree(paidOrFree);
        demoCarModelsAndStatusDto.setPublicOrPrivate(publicOrPrivate);
        if (demoCarModelsAndStatusDto != null) {
            logger.info("vin models ans status retrieved successfully");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "vin model ans status  retrieved  successfully");
            response.setData(demoCarModelsAndStatusDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "error in retrieving vin models");
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Method to publish the VIN by  FPN to CA
     *
     * @param httpServletRequest
     * @param lang
     * @param vinRequestDto
     * @return
     */
    @PostMapping(value = "{langCode}/publish-to-ca", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO> publishToCa(
            HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang, @RequestBody List<VinRequestDto> vinRequestList) {
        logger.info("inside publishToCa");
        List<VinDetailsDto> vinDetails = vinDetailsService.publishToCa(vinRequestList, lang);
        if (vinDetails != null) {
            logger.info("The VIN is published to CA");
            ResponseDTO response =
                    new ResponseDTO(Constants.SUCCESS, "200", "The VIN is published to CA");
            response.setData(vinDetails);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        logger.info("The VIN is not published");
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "The VIN is not published");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Method to mark the VIN as returned
     *
     * @param httpServletRequest
     * @param lang
     * @param vinRequestDto
     * @return
     */
    @PostMapping(value = "{langCode}/mark-as-returned", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseDTO> markAsReturned(
            HttpServletRequest httpServletRequest, @PathVariable(name = "langCode") String lang, @RequestBody VinRequestDto returnedVin) {
        logger.info("gradlew .");
        VinDetailsDto vinDetails = vinDetailsService.markAsReturned(returnedVin, lang);
        if (vinDetails != null) {
            logger.info("The VIN is marked as returned");
            if ("en".equals(lang)) {
                ResponseDTO response =
                        new ResponseDTO(Constants.SUCCESS, "200", "The VIN is marked as returned");
                response.setData(vinDetails);
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                ResponseDTO response =
                        new ResponseDTO(Constants.SUCCESS, "200", "車を返却しました。");
                response.setData(vinDetails);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        }
        logger.info("Failed to mark as returned");
        ResponseDTO response =
                new ResponseDTO(Constants.FAILED, "500", "Failed to mark as returned");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
