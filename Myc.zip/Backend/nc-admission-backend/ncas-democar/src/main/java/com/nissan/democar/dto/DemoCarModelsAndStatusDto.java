package com.nissan.democar.dto;

import com.nissan.common.dto.ModelDTO;
import lombok.Data;

import java.util.List;

@Data
public class DemoCarModelsAndStatusDto {

    List<ModelDTO> modelInfo;
    List<StatusDto> status;
    List<RegistPattern> registPattern;
    List<PaidFreeDto> paidOrFree;
    List<PublicOrPrivateDto> publicOrPrivate;

}
