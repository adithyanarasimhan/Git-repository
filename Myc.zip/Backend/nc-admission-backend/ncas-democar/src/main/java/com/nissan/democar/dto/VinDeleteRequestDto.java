package com.nissan.democar.dto;

import lombok.Data;

import java.util.List;

@Data
public class VinDeleteRequestDto {
    private List<String> vin;
}
