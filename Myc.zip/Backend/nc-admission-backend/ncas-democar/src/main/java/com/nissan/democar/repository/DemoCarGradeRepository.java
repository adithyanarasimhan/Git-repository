package com.nissan.democar.repository;

import com.nissan.common.entity.DemoCarGrade;
import com.nissan.common.entity.GradeV2;
import com.nissan.common.entity.VinDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface DemoCarGradeRepository extends JpaRepository<DemoCarGrade, Long>, QuerydslPredicateExecutor<DemoCarGrade> {

    @Query(value = "SELECT * FROM democar_grade WHERE model_id =?1", nativeQuery = true)
    List<DemoCarGrade> getGradesByModelId(Long modelId);

    DemoCarGrade findByModelIdAndCwGradeNameAndLangCode(Long modelId, String cwGradeName, String langCode);
}
