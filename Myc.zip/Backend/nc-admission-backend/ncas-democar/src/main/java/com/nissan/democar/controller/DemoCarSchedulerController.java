package com.nissan.democar.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nissan.democar.service.DemoCarCommunicationService;

@RestController
@RequestMapping("secured/api/v1")
public class DemoCarSchedulerController {

    private static final Logger logger = LoggerFactory.getLogger(DemoCarSchedulerController.class);

    @Autowired
    private DemoCarCommunicationService demoCarCommunicationService;

    @GetMapping(value = "{langCode}/compass", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 1 * * *", zone = "Asia/Tokyo")
    public void receiveDataFromCompass() {
        demoCarCommunicationService.receiveDataFromCompass();
    }

    @GetMapping(value = "{langCode}/existenceCheckVinInCw", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 2 * * *", zone = "Asia/Tokyo")
    public void existenceCheckForVinInCW() throws Exception {
        demoCarCommunicationService.existenceCheckVinInCw();
    }

    @GetMapping(value = "{langCode}/getNcIdAndPasswordFromCw", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 30 7 * * *", zone = "Asia/Tokyo")
    public void getNcIdAndPasswordFromCarWings() throws Exception {
        demoCarCommunicationService.getNcIdAndPasswordFromCarWings();
    }

    @GetMapping(value = "{langCode}/checkDemocarExpiry", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 * * * * *", zone = "Asia/Tokyo")
    public void checkDemocarExpiry() throws Exception {
        demoCarCommunicationService.checkDemocarExpiry();
    }

    @GetMapping(value = "{langCode}/sendFileToNlo", produces = MediaType.APPLICATION_JSON_VALUE)
    @Scheduled(cron = "0 0 8 * * *", zone = "Asia/Tokyo")
    public void sendFileToNlo() throws Exception {
        demoCarCommunicationService.sendFileToNlo();
    }

}
