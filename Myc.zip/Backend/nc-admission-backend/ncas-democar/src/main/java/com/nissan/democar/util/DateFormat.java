package com.nissan.democar.util;

import java.sql.Date;
import java.time.LocalDate;

public class DateFormat {

  public static Date getCurrentTimeStamp() {
    return Date.valueOf(LocalDate.now());
  }
}
