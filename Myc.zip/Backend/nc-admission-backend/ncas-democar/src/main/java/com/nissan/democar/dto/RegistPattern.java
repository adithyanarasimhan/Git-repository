package com.nissan.democar.dto;

import lombok.Data;

@Data
public class RegistPattern {
    private String registPattern;
    private String displayName;
}
