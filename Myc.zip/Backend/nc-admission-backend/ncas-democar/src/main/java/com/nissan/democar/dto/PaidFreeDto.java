package com.nissan.democar.dto;

import lombok.Data;

@Data
public class PaidFreeDto {
    private String paidOrFree;
    private String displayName;
}
