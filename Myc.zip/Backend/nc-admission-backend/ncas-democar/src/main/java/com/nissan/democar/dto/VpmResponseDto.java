package com.nissan.democar.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class VpmResponseDto {
    @JsonProperty("SysCode")
    private String sysCode;
    @JsonProperty("ApiId")
    private String apiId;
    @JsonProperty("FormVersion")
    private String formVersion;
    @JsonProperty("Requester")
    private String requester;
    @JsonProperty("Data")
    private List<Datum> data;
}
