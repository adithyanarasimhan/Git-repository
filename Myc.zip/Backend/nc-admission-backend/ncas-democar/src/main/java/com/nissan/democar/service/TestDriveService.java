package com.nissan.democar.service;

import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.DemoCarAdmission;
import com.nissan.democar.dto.*;

import java.util.List;

public interface TestDriveService {

    DemoCarAdmission assignToCustomer(DealerEntity dealer, String langCode, AssignToCustomerDto assignToCustomerDto);

    TestDriveInfoDto getTestDriveInfo(String langCode, Long id);

    boolean extendTestDrive(String langCode, ExtendTestDriveDto extendTestDriveDto);

    CustomerInfoDto getCustomerInfo(String langCode, Long id);

    DemoCarNcIdPasswordDto getNcIdAndPassword(String langCode, Long id);

    List<TestDriveHistory> fetchTestDriveHistory(String langCode, Long id);

    TestDriveInfoDto getTestDriveDetails(String langCode, Long admissionId);

    TestDriveHistoryDetailsDto getTestDriveHistoryDetails(String langCode, Long testDriveId);
}