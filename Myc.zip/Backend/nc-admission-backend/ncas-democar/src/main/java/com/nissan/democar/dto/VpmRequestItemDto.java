package com.nissan.democar.dto;

import lombok.Data;

import java.util.List;

@Data
public class VpmRequestItemDto {
    private List<String> item_name;
}

