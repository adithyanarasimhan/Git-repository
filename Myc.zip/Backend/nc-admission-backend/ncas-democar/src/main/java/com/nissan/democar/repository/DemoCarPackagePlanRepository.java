package com.nissan.democar.repository;

import com.nissan.common.entity.DemoCarNavi;
import com.nissan.common.entity.DemoCarPackagePlan;
import com.nissan.common.entity.PackagePlanV2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface DemoCarPackagePlanRepository extends JpaRepository<DemoCarPackagePlan, Long>, QuerydslPredicateExecutor<DemoCarPackagePlan> {

    @Query(value = "SELECT * FROM democar_package_plan WHERE navi_id =?1", nativeQuery = true)
    List<DemoCarPackagePlan> getPackageListByNaviId(long naviId);
}
