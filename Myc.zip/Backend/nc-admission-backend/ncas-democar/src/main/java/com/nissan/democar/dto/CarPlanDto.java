package com.nissan.democar.dto;

import lombok.Data;

@Data
public class CarPlanDto {
    private String carPlan;
    private String displayName;
}
