package com.nissan.democar.dto;

import com.nissan.common.entity.DemoCarAdmission;
import lombok.Data;

@Data
public class DemoCarSaveRegInfoDto {
    private String vin;
    private String carPlan;
    private String dealerCode;
    private String flagType;
    private Boolean ivi;
    private Boolean icc;
    private boolean active;
    private Long modelId;
    private Long gradeId;
    private Long naviId;
    private Long planId;
    private String cwNaviId;
    private String status;
    private DemoCarAdmission admission;
}
