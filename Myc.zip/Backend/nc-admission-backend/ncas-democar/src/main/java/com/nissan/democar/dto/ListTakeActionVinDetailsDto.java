package com.nissan.democar.dto;

import com.nissan.common.dto.ActiveVinListDto;
import com.nissan.common.dto.TakeActionVinDetailsDto;
import lombok.Data;

import java.util.List;

@Data
public class ListTakeActionVinDetailsDto {
    private List<?> vinDetailsList;
    private long activeListCount;
    private long takeActionCount;
    private long totalCount;
}
