package com.nissan.democar.dto;

import lombok.Data;

import java.util.List;

@Data
public class VinDetailsRequestDto {
    private String searchKey;
    private Integer limit;
    private String sortBy;
    private Integer offset;
    private boolean active;
    private String sortOrder;
    private String status;
    private List<String> model;
    private List<String> registPattern;
    private List<String> paidOrFree;
    private List<String> publicOrPrivate;
}
