package com.nissan.democar.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import com.nissan.common.entity.DemoCarAdmission;
import com.nissan.democar.entity.DemoCarTestDrive;

public interface DemoCarTestDriveRepository extends JpaRepository<DemoCarTestDrive, Long>, QuerydslPredicateExecutor<DemoCarTestDrive> {
    
	List<DemoCarTestDrive> findByAdmission(DemoCarAdmission admission);
	
	List<DemoCarTestDrive> findByAdmissionAndStatus(DemoCarAdmission admission, String status);
    
	@Query("SELECT dt.id FROM DemoCarTestDrive dt where ((dt.endDate < current_date)  or (dt.endDate = current_date and dt.endTime < current_time)) and dt.status='Running'")
	List<Long> fetchExpiredTestDrives();

}
