package com.nissan.democar.dto;

import lombok.Data;

@Data
public class DemoCarVinDetailsDto {

    private String enrollmentDate;

    private String ncJoinedDate;

    private String status;

    private String ncasNumber;

    private String vin;

    private String naviId;

    private String carPlan;

    private String flagType;

    private String source;

    private Boolean icc;

    private Boolean ivi;

    private String ncId;

    private String ncPassword;

    private String gradeDisplayName;

    private String naviDisplayName;

    private String statusDisplayName;

    private String modelName;

    private String imageUrl;

    private String ncExpirationDate;

    private String sourceDisplayName;

    private String flagTypeDisplayName;

    private String carPlanDisplayName;
}
