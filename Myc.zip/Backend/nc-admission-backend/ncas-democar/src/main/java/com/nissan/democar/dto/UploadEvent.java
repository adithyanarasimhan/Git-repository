package com.nissan.democar.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadEvent {
    private String eventType = "progress";
    private int rowNumber;
    private UploadSummaryDto summary;
    private Object state;
}
