package com.nissan.democar.service.impl;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.nissan.common.config.CloudMapServiceResolver;
import com.nissan.common.config.SecretsManager;
import com.nissan.common.dto.*;
import com.nissan.common.entity.DealerEntity;
import com.nissan.common.entity.DemoCarAdmission;
import com.nissan.common.entity.VinDetails;
import com.nissan.common.repository.DealerRepository;
import com.nissan.common.repository.VinDetailsRepository;
import com.nissan.common.util.Constants;
import com.nissan.common.util.CustomMappingStrategy;
import com.nissan.common.util.DemoCarUtil;
import com.nissan.common.util.SftpOperationsUtil;
import com.nissan.democar.dto.*;
import com.nissan.democar.repository.DemoCarAdmissionRepository;
import com.nissan.democar.repository.DemoCarTestDriveRepository;
import com.nissan.democar.service.DemoCarCommunicationService;
import com.nissan.democar.service.VinDetailsService;
import com.nissan.democar.util.DemoCarConstants;
import com.nissan.democar.util.SftpNloUpload;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

import static com.nissan.common.util.Constants.HTTP;
import static com.nissan.common.util.Constants.PRINCIPAL_ID;

@Service
public class DemoCarCommunicationServiceImpl implements DemoCarCommunicationService {

    private static final Logger logger = LoggerFactory.getLogger(DemoCarCommunicationServiceImpl.class);
    private static final org.owasp.esapi.Logger mylogger = ESAPI.getLogger(DemoCarCommunicationServiceImpl.class);

    @Autowired
    private Environment env;

    @Autowired
    private SftpOperationsUtil sftpOperationsUtil;

    @Autowired
    private VinDetailsService vinDetailsService;

    @Autowired
    private VinDetailsRepository vinDetailsRepository;
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    CloudMapServiceResolver serviceResolver;

    @Autowired
    private DemoCarAdmissionRepository demoCarAdmissionRepository;

    @Autowired
    DemoCarTestDriveRepository demoCarTestDriveRepository;

    @Autowired
    DealerRepository dealerRepository;

    @Value("${key.store.vpm}")
    private String vpmKeyStore;

    @Value("${vpm.password}")
    private String vpmPassword;

    @Value("${vpm.url}")
    private String vpmUrl;

    @Value("${file.characterFormat}")
    private String fileCharacterFormat;

    @Value("${nlo.sftp.bucket.enabled}")
    private boolean s3BucketEnabledForNlo;

    @Value("${nlo.sftp.bucket.name}")
    private String bucketName;

    @Value("${nlo.sftp.bucket.folder}")
    private String folderName;

    @Value("${awsAccessKey}")
    public String awsAccessKey;

    @Value("${awsSecretKey}")
    public String awsSecretKey;

    @Autowired
    SftpNloUpload sftpNloUpload;


    public static final String CAR_WINGS_GET_MEMBER_INFO = "/carwings/api/v1/en/memberinfo";

    private RestTemplate vpmRestTemplate()
            throws IOException, NoSuchAlgorithmException, KeyManagementException, KeyStoreException,
            CertificateException {
        SecretsManager secretsManager = new SecretsManager();
        ByteBuffer byteBuffer = secretsManager.getCertificate(vpmKeyStore);
        InputStream inputStream = new ByteArrayInputStream(byteBuffer.array());
        File somethingFile = File.createTempFile("vpm_keystore", ".jks");
        try {
            FileUtils.copyInputStreamToFile(inputStream, somethingFile);
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        SSLContext sslContext =
                SSLContextBuilder.create()
                        .loadTrustMaterial(
                                ResourceUtils.getFile(somethingFile.getPath()), vpmPassword.toCharArray())
                        .build();
        CloseableHttpClient client = HttpClients.custom().setSslcontext(sslContext).build();
        HttpComponentsClientHttpRequestFactory requestFactory =
                new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(client);
        return new RestTemplate(requestFactory);
    }

    @Override
    public void receiveDataFromCompass() {
        logger.info("Inside receiveDataFromCompass");
        try {
            LocalDateTime currentDateTime = LocalDateTime.now();
            Timestamp endDate = Timestamp.valueOf(currentDateTime);
            LocalDateTime localdateTime = currentDateTime.minusHours(24);
            Timestamp startDate = Timestamp.valueOf(localdateTime);
            logger.info("startDate : {} endDate : {}", startDate, endDate);
            SftpPropertiesDTO sftpProperties = new SftpPropertiesDTO();
            sftpProperties.setUsername(env.getProperty("compass.sftp.server.username"));
            sftpProperties.setHost(env.getProperty("compass.sftp.server.host"));
            sftpProperties.setPort(Integer.parseInt(env.getProperty("compass.sftp.server.port")));
            sftpProperties.setPrivateKey(env.getProperty("compass.sftp.server.privateKey"));
            sftpProperties.setRoot(env.getProperty("compass.sftp.server.root"));
            sftpProperties.setFileExtension(".tar.gz");
            File zipFile = sftpOperationsUtil.downloadLatestFile(sftpProperties);
            if (zipFile != null) {
                File csvFile = DemoCarUtil.unGzipUnTar(zipFile);
                File xlsxFile = File.createTempFile("compassexcel", ".xlsx");
                DemoCarUtil.convertCsvToXLSX(csvFile, xlsxFile);
                vinDetailsService.saveCompassVinDetails(xlsxFile);
                sftpOperationsUtil.deleteExpiredFiles(sftpProperties, 14);
            }
        } catch (Exception e) {
            logger.error("Failed to save VIN details : {}", e.getMessage());
        }

    }

    @Override
    public void existenceCheckVinInCw() {
        try {
            RestTemplate vpmRestTemplate = vpmRestTemplate();
            logger.info("In existence check in VPM");
            List<String> statusList = ImmutableList.of(DemoCarConstants.STATUS_NOT_EXIST_VPM, DemoCarConstants.STATUS_NOT_LINKED_VPM);
            List<VinDetails> vinDetailsList = vinDetailsRepository.findByStatusInAndIviTrue(statusList);
            logger.info("Not linked(VPM) vin list count={}", vinDetailsList.size());
            List<String> vinList = new ArrayList<>();
            vinDetailsList.forEach(v -> {
                vinList.add(v.getVin());
            });
            Map<String, Object> requestMap = new LinkedHashMap<>();
            requestMap.put("SysCode", "VPM");
            requestMap.put("ApiId", "00701");
            requestMap.put("FormVersion", "0.1");
            requestMap.put("Requester", "72");
            Map<String, Object> requestKeyMap = new LinkedHashMap<>();
            requestKeyMap.put("region", "JPN");
            requestKeyMap.put("vin", vinList);
            requestMap.put("RequestKey", requestKeyMap);
            Map<String, Object> RequestItem = new LinkedHashMap<>();
            RequestItem.put("item_name", ImmutableList.of("vin"));
            requestMap.put("RequestItem", RequestItem);
            ObjectMapper mapper = new ObjectMapper();
            String resultString = mapper.writeValueAsString(requestMap);
            logger.info("VPM RequestMapstring={} ", resultString);
            VpmRequestDto vpmRequestDto = new VpmRequestDto();
            vpmRequestDto.setSysCode("VPM");
            vpmRequestDto.setApiId("00702");
            vpmRequestDto.setFormVersion("0.1");
            vpmRequestDto.setRequester("72");
            VpmRequestKeyDto vpmRequestKeyDto = new VpmRequestKeyDto();
            vpmRequestKeyDto.setRegion("JPN");
            vpmRequestKeyDto.setVin(vinList);

            vpmRequestDto.setRequestKey(vpmRequestKeyDto);
            VpmRequestItemDto vpmRequestItemDto = new VpmRequestItemDto();
            vpmRequestItemDto.setItem_name(ImmutableList.of("vin"));
            vpmRequestDto.setRequestItem(vpmRequestItemDto);
            String result = mapper.writeValueAsString(vpmRequestDto);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> requestEntity = new HttpEntity<>(resultString, headers);
            ResponseEntity<String> response =
                    vpmRestTemplate.exchange(vpmUrl, HttpMethod.POST, requestEntity, String.class);
            if (response != null) {
                mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "response body=" + response.getBody());
                VpmResponseDto responseDto = mapper.readValue(response.getBody(), VpmResponseDto.class);
                logger.info("VpmResponseDto={} ", responseDto);
                if (responseDto != null) {
                    List<Datum> vinCollection = responseDto.getData();
                    logger.info("vin count from VPM={}", vinCollection.size());
                    List<String> vinListFromVPM = new ArrayList<>();
                    for (Datum data : vinCollection) {
                        vinListFromVPM.add(data.getVin());
                    }
                    vinList.forEach(v -> {
                        mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Inside VPM checking vin= " + v);
                        VinDetails vinDetails = vinDetailsRepository.findByVin(v);
                        if (!CollectionUtils.isEmpty(vinListFromVPM) && vinListFromVPM.contains(v)) {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Vin  exist in CW= " + v);
                            vinDetails.setStatus(DemoCarConstants.STATUS_CAN_PUBLISH);
                            vinDetailsRepository.save(vinDetails);
                        } else if (vinDetails.getNumberOfRetryWithCw() == null) {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "null case Vin not  exist in CW= " + v);
                            vinDetails.setNumberOfRetryWithCw(1);
                            vinDetailsRepository.save(vinDetails);
                        } else if (vinDetails.getNumberOfRetryWithCw() == 31 && vinDetails.getNumberOfRetryWithCw() == 61) {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Vin not exist in CW= " + v);
                            logger.info("Vin not exist in vinDetails={},={}", vinDetails, vinDetails.getNumberOfRetryWithCw());
                            vinDetails.setStatus(DemoCarConstants.STATUS_NOT_EXIST_VPM);
                            vinDetailsRepository.save(vinDetails);
                        } else if (vinDetails.getNumberOfRetryWithCw() > 31) {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "> 31 Vin Vin not exist in CW= " + v);
                            vinDetails.setStatus(DemoCarConstants.STATUS_NOT_LINKED_VPM);
                            vinDetailsRepository.save(vinDetails);
                        } else {
                            mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "else Vin not exist in CW= " + v);
                            vinDetails.setNumberOfRetryWithCw(vinDetails.getNumberOfRetryWithCw() + 1);
                            vinDetailsRepository.save(vinDetails);
                        }
                    });

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        }
    }


    @Override
    @Transactional
    public void getNcIdAndPasswordFromCarWings() {
        try {
            logger.info("In get NCID/Password from CW");
            List<VinDetails> vinDetailsList = vinDetailsRepository.findByStatus("Applying");
            logger.info("Applying vin list count : {}", vinDetailsList.size());
            List<String> vinList = new ArrayList<>();
            vinDetailsList.forEach(v -> vinList.add(v.getVin()));
            ObjectMapper mapper = new ObjectMapper();
            List<ResultDto> resultDtoList = getResultDtos(vinList);
            logger.info("NCID/Password result count : {}", resultDtoList.size());
            List<DocommoMailDto> docommoMailDtoList = new ArrayList<>();
            List<ResultDto> resultDtoListMapper = mapper.convertValue(resultDtoList,
                    new TypeReference<List<ResultDto>>() {
                    });
            resultDtoListMapper.forEach(result -> {
                logger.info("result from CW={}", result);
                String importStatus = null;
                VinDetails vin = vinDetailsRepository.findByVin(result.getVin());
                if (Constants.CARWINGS_STATUS_CODE_ZERO.equals(result.getResponseCd()) && Constants.CARWINGS_STATUS_SA.equals(result.getStatus())) {

                    logger.info("Inside SA status ={}", result);

                    DemoCarAdmission demoCarAdmission = demoCarAdmissionRepository.findByVin(result.getVin());

                    logger.info("CW status : {}", result.getStatus());
                    demoCarAdmission.setNcId(result.getNcId());
                    demoCarAdmission.setNcPassword(result.getNcPw());
                    demoCarAdmission.setVin(result.getVin());
                    demoCarAdmission.setCwId(result.getUserId());
                    demoCarAdmission.setIccId(result.getIccId());
                    demoCarAdmission.setStatus(DemoCarConstants.STATUS_AVAILABLE);
                    try {
                        if (result.getNcJoinDate() != null) {
                            DateFormat format = new SimpleDateFormat("yyyymmdd");

                            Date date = format.parse(result.getNcJoinDate());
                            demoCarAdmission.setNcJoinDate(new SimpleDateFormat("yyyy/MM/dd").format(date));
                        }
                        importStatus = Constants.DC_NOTIFICATION_STATUS_CW_IMPORT_SUCCESS;
                        vin.setStatus(DemoCarConstants.STATUS_AVAILABLE);
                        if (result.getServiceEndDate() != null) {
                            DateFormat format = new SimpleDateFormat("yyyymmdd");
                            Date date = format.parse(result.getServiceEndDate());
                            String expirationDate = new SimpleDateFormat("yyyy/mm/dd").format(date);
                            vin.setExpirationDate(expirationDate);
                            demoCarAdmission.setNcPasswordExpirationDate(expirationDate);
                        }
                    } catch (ParseException e) {
                        logger.info(" parse format exception={}", e);
                    }
                    demoCarAdmission = demoCarAdmissionRepository.save(demoCarAdmission);
                    vinDetailsRepository.save(vin);
                    logger.info("sending notification mail to CA ");
                    vinDetailsService.sendNotificationMail(vin, importStatus, demoCarAdmission.getId());
                    if (BooleanUtils.isTrue(vin.getIvi())) {
                        DocommoMailDto docommoMailDto = new DocommoMailDto();
                        docommoMailDto.setNCID(result.getNcId());
                        docommoMailDto.setApplicability("1");
                        docommoMailDto.setICCID(result.getIccId());
                        docommoMailDtoList.add(docommoMailDto);
                    }
                    mylogger.info(org.owasp.esapi.Logger.SECURITY_SUCCESS, "Updated VIN status to Available : " + vin.getVin());
                } else {
                    logger.info("CW status : {}", result.getStatus());
                    logger.info("CW response code : {}", result.getResponseCd());
                    importStatus = Constants.DC_NOTIFICATION_STATUS_CW_IMPORT_FAILED;
                    vin.setStatus(DemoCarConstants.STATUS_IMPORT_FAILURE_CW);
                    mylogger.info(org.owasp.esapi.Logger.SECURITY_FAILURE, "CW import failed for the VIN" + vin.getVin());
                }

                logger.info("Get NCID/Password flow completed.");
            });
            logger.info("sending mail to Doccommo");
            vinDetailsService.sendMailToDocommo(docommoMailDtoList);
        } catch (Exception e) {
            logger.error("Failed to get NCID/Password from Carwings : {}", e);
        }
    }


    @Override
    public List<ResultDto> getResultDtos(List<String> vinList) {
        String serviceLocation = serviceResolver.resolve(Constants.CARWINGS_SERVICE);
        logger.info("DemocarCommunicationService API service URL {}", serviceLocation);
        String url = HTTP + serviceLocation + CAR_WINGS_GET_MEMBER_INFO;
        logger.info("DemocarCommunicationService CW member info  URL {}", url);
        HttpHeaders headers = new HttpHeaders();
        headers.set(PRINCIPAL_ID, "2");
        headers.setContentType(MediaType.APPLICATION_JSON);
        RestTemplate restTemplate = new RestTemplate();
        MemberInfoRequestDto memberInfoRequestDto = new MemberInfoRequestDto();
        memberInfoRequestDto.setVin(vinList);
        logger.info("DemocarCommunicationService CW member request  object", memberInfoRequestDto);
        HttpEntity<MemberInfoRequestDto> request = new HttpEntity<>(memberInfoRequestDto, headers);
        ResponseEntity<ResponseDTO> response =
                restTemplate.exchange(url, HttpMethod.POST, request, ResponseDTO.class);
        ResponseDTO body = response.getBody();
        List<ResultDto> resultDtos = (List<ResultDto>) body.getData();
        logger.info("memberinfo response from CW in Existence check api={}", resultDtos);
        return resultDtos;
    }

    @Override
    public void checkDemocarExpiry() {
        logger.info("Checking democar expiry.");
        List<Long> expiredTestDrives = demoCarTestDriveRepository.fetchExpiredTestDrives();
        expiredTestDrives.forEach(td -> {
            logger.info("Expired Test Drive found : {}", td);
            VinRequestDto returnVin = new VinRequestDto();
            returnVin.setTestDriveId(td);
            vinDetailsService.markAsReturned(returnVin, "en");
        });
    }

    @Override
    public void sendFileToNlo() {
        String fileName = getFileName("NCAS_NLO_");
        Path myPath = Paths.get(System.getProperty("user.home") + File.separator + fileName);
        BufferedWriter writer = null;
        Charset charset = null;
        if (fileCharacterFormat.equals("Shift_JIS")) {
            charset = Charset.forName("Shift_JIS");
        } else {
            charset = StandardCharsets.UTF_8;
        }
        try {
            writer =
                    Files.newBufferedWriter(
                            myPath, charset, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            StatefulBeanToCsv<NloDto> beanToCsv =
                    getNloWriter(writer);
            List<NloDto> nloDtoList = new ArrayList<>();
            int i = 0;
            List<DemoCarAdmission> admissions = demoCarAdmissionRepository.findBySendToNloFalse();
            logger.info("number of admissions ={}", admissions.size());
            for (DemoCarAdmission admission : admissions) {
                logger.info("iterating each  admission={} with NCID={} for NLO", admission.getId(), admission.getNcId());
                if (admission.getNcId() != null) {
                    logger.info("admission={}", admission.getId());
                    VinDetails vinDetails = vinDetailsRepository.findByVin(admission.getVin());
                    logger.info("vindetails={}", vinDetails);
                    NloDto nloDto = new NloDto();
                    nloDto.setNo(i);
                    nloDto.setVin(admission.getVin());
                    nloDto.setNaviId(vinDetails.getCwNaviId());
                    nloDto.setRequestFlag("1");
                    nloDto.setCarPlan(vinDetails.getCarPlan());
                    nloDto.setProfitDealerCode(vinDetails.getProfitDealerCode());
                    DealerEntity dealerEntity = null;
                    if (vinDetails.getProfitDealerCode() != null) {
                        dealerEntity = dealerRepository.findByDealerShipCode(vinDetails.getProfitDealerCode());
                    }
                    logger.info("DealerEntity={}", dealerEntity);
                    if (dealerEntity != null) {
                        nloDto.setDealerName(dealerEntity.getDealershipName());
                    }
                    logger.info("setting ncid and password");
                    nloDto.setNcId(admission.getNcId());
                    nloDto.setNcPw(admission.getNcPassword());
                    logger.info("setting ivi");
                    if (BooleanUtils.isTrue(vinDetails.getIvi())) {
                        nloDto.setIvOrDop("IVI");
                    } else {
                        nloDto.setIvOrDop("DOP");
                    }
                    nloDto.setVinRegistDate(admission.getVinRegDate());
                    nloDtoList.add(nloDto);
                    admission.setSendToNlo(true);
                    demoCarAdmissionRepository.save(admission);
                    i++;
                }
            }

            beanToCsv.write(nloDtoList);
            writer.flush();
            writer.close();
            sftpNloUpload.upload(myPath.toString());
            if (s3BucketEnabledForNlo) {
                String s3Key = folderName + myPath.toFile().getName();
                byte[] fileContent = FileUtils.readFileToByteArray(myPath.toFile());
                byte[] encodedFile = Base64.getEncoder().encode(fileContent);
                InputStream stream = new ByteArrayInputStream(encodedFile);
                ObjectMetadata metadata = new ObjectMetadata();
                metadata.setContentLength(stream.available());
                AWSCredentials credentials = new BasicAWSCredentials(awsAccessKey, awsSecretKey);
                AmazonS3 s3 =
                        AmazonS3Client.builder()
                                .withRegion(Regions.AP_NORTHEAST_1)
                                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                                .build();
                s3.putObject(bucketName, s3Key, stream, metadata);
            }
        } catch (IOException e) {
            logger.info("exception in sending file to NLO");
        } catch (CsvRequiredFieldEmptyException e) {
            e.printStackTrace();
        } catch (CsvDataTypeMismatchException e) {
            e.printStackTrace();
        }
    }

    private String getFileName(String name) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateTimeInfo = dateFormat.format(new Date());
        return name.concat(String.format("_%s" + "." + "csv", dateTimeInfo));
    }

    private StatefulBeanToCsv<NloDto> getNloWriter(
            BufferedWriter writer) {
        StatefulBeanToCsv<NloDto> beanToCsv = null;
        try {
            final CustomMappingStrategy<NloDto> mappingStrategy =
                    new CustomMappingStrategy<>();
            mappingStrategy.setType(NloDto.class);
            beanToCsv =
                    new StatefulBeanToCsvBuilder<NloDto>(writer)
                            .withMappingStrategy(mappingStrategy)
                            .build();
        } catch (Exception e) {
            logger.info("exception in writing to csv={}", e);
        }
        return beanToCsv;
    }
}
