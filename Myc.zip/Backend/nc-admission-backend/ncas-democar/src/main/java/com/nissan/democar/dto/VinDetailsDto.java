package com.nissan.democar.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import com.nissan.common.dto.PackagePlanDTO;
import com.nissan.common.entity.DealerEntity;

import lombok.Data;

@Data
public class VinDetailsDto {
    private String vin;
    private Long ncasNumber;
    private String profitDealerCode;
    private String flagType;
    private Boolean ivi;
    private Boolean icc;
    private String carPlan;
    private String naviId;
    private String profitDealerShopCode;
    private String imageUrl;
    private String status;
    private String source;
    private String cwNaviId;
    private LocalDateTime enrollmentDate;
    private boolean active;
    private LocalDate expirationDate;
    private Date createdDate;
    private String manualEnterFlag;
    private PackagePlanDTO packagePlan;
    private String gradeDisplayName;
    private String naviDisplayName;
    private String modelName;
    private String statusDisplayName;
    private DealerEntity dealer;
    private String flagTypeDisplayName;
}
