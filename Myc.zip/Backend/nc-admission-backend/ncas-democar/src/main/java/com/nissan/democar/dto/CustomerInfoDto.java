package com.nissan.democar.dto;

import lombok.Data;

@Data
public class CustomerInfoDto {

    private String firstName;

    private String firstNameKanji;

    private String LastName;

    private String LastNameKanji;

    private String phoneNumber;


}
