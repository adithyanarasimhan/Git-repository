package com.nissan.democar.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Data
public class TestDriveHistory {

    private Long id;

    private String customerName;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private Date startDate;

    private LocalTime startTime;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private Date endDate;

    private LocalTime endTime;

    private String phoneNumber;
}
