package com.nissan.democar.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Data
public class ExtendTestDriveDto {
    private Long id;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private Date extendedDate;

    private LocalTime extendedTime;
    
}
