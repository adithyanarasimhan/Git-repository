package com.nissan.democar.dto;

import lombok.Data;

@Data
public class Datum {
    private String vin;
}
