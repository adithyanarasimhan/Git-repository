package com.nissan.democar.dto;

import lombok.Data;

@Data
public class PublicOrPrivateDto {
    private String publicOrPrivate;
    private String displayName;
}
