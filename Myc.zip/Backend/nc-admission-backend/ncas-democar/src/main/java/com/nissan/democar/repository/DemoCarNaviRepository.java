package com.nissan.democar.repository;

import com.nissan.common.entity.DemoCarModel;
import com.nissan.common.entity.DemoCarNavi;
import com.nissan.common.entity.NaviV2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

public interface DemoCarNaviRepository extends JpaRepository<DemoCarNavi, Long>, QuerydslPredicateExecutor<DemoCarNavi> {

    @Query(value = "SELECT * FROM democar_navi where grade_id=?1", nativeQuery = true)
    List<DemoCarNavi> getNaviListByGradeId(long gradeId);

    DemoCarNavi findByGradeIdAndCwNaviNameAndLangCode(Long gradeId, String cwNaviName, String langCode);
}
