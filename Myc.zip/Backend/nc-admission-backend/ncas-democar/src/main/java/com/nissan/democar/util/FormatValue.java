package com.nissan.democar.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FormatValue {

  public static Map<String, String> formatZipCode(String zipCode) {
    Map<String, String> map = new HashMap<>();
    String firstThreeDigits = zipCode.substring(0, 3);
    String lastFourDigits = zipCode.substring(zipCode.length() - 4);
    map.put("firstThreeDigits", firstThreeDigits);
    map.put("lastFourDigits", lastFourDigits);
    return map;
  }

  public static Map<String, String> formatPhoneNumber(String phone) {
    Map<String, String> map = new HashMap<>();
    String firstThreeDigits = phone.substring(0, 3);
    String middleFourDigits = phone.substring(3, 7);
    String lastFourDigits = phone.substring(phone.length() - 4);

    map.put("firstThreeDigits", firstThreeDigits);
    map.put("middleFourDigits", middleFourDigits);
    map.put("lastFourDigits", lastFourDigits);
    return map;
  }

  public static Map<String, String> formatPhoneNumberTenDigits(String phone) {
    Map<String, String> map = new HashMap<>();
    String firstThreeDigits = phone.substring(0, 3);
    String middleFourDigits = phone.substring(3, 6);
    String lastFourDigits = phone.substring(phone.length() - 4);

    map.put("firstThreeDigits", firstThreeDigits);
    map.put("middleFourDigits", middleFourDigits);
    map.put("lastFourDigits", lastFourDigits);
    return map;
  }

  public static Map<String, String> formatCardNumber(String cardNumber) {
    Map<String, String> map = new HashMap<>();
    String firstThreeDigits = cardNumber.substring(0, 4);
    String firstMiddleFourDigits = cardNumber.substring(4, 8);
    String secondMiddleFourDigits = cardNumber.substring(8, 12);
    String lastFourDigits = cardNumber.substring(12, cardNumber.length());

    map.put("firstThreeDigits", firstThreeDigits);
    map.put("firstMiddleFourDigits", firstMiddleFourDigits);
    map.put("secondMiddleFourDigits", secondMiddleFourDigits);
    map.put("lastFourDigits", lastFourDigits);
    return map;
  }

  public static String replaceNullWithValues(Long value) {
    if (value == null) {
      return "";
    } else {
      return String.valueOf(value);
    }
    }

  public static String replaceNullOptionalPhoneNumber(String value) {
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }

  public static String formatDate(Date date) {
    if(date!=null){
    DateFormat df=new SimpleDateFormat("yyyy-MM-dd");
    return df.format(date);
    }else{
      return "";
    }
  }

  public static String formatDateMinutes(Date date) {
    if(date!=null){
      DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      return df.format(date);
    }else{
      return "";
    }
  }

  public static String formatLocalDate(LocalDate date) {
    if(date!=null){
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      return formatter.format(date);
    }else{
      return "";
    }
  }

  public static String formatYearMonth(Date date) {
    if(date!=null){
      DateFormat df=new SimpleDateFormat("yyyy-MM");
      return df.format(date);
    }else{
      return "";
    }
  }
}
