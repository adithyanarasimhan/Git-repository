package com.nissan.democar.dto;

import com.nissan.common.dto.ActiveVinListDto;
import com.nissan.common.dto.TakeActionVinDetailsDto;
import lombok.Data;

import java.util.List;

@Data
public class ListActiveVinDetailsDto {

    private List<ActiveVinListDto> vinDetailsList;
    private long activeListCount;
    private long takeActionCount;
    private long totalCount;
}
