package com.nissan.democar.entity;

import com.nissan.common.entity.DemoCarAdmission;
import com.nissan.common.entity.DemoCarCustomer;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

@Data
@Entity
@Table(name = "democar_test_drive")
@EntityListeners(AuditingEntityListener.class)
public class DemoCarTestDrive {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE})
    @JoinColumn(name = "admission_id", referencedColumnName = "id")
    private DemoCarAdmission admission;

    @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    private DemoCarCustomer customer;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "start_time")
    private LocalTime startTime;

    @Column(name = "end_date")
    private Date endDate;

    @Column(name = "end_time")
    private LocalTime endTime;

    @Column(name = "status")
    private String status;
    
}
