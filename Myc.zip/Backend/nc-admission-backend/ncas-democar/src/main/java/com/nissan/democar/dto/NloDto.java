package com.nissan.democar.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.Date;

@Data
public class NloDto {
    @CsvBindByName(column = "No")
    @CsvBindByPosition(position = 0)
    private int no;
    @CsvBindByName(column = "VIN")
    @CsvBindByPosition(position = 1)
    private String vin;
    @CsvBindByName(column = "navi ID")
    @CsvBindByPosition(position = 2)
    private String naviId;
    @CsvBindByName(column = "申請フラグ",locale = "ja")
    @CsvBindByPosition(position = 3)
    private String requestFlag;
    @CsvBindByName(column = "用途",locale = "ja")
    @CsvBindByPosition(position = 4)
    private String carPlan;
    @CsvBindByName(column = "PROFIT販社コード",locale = "ja")
    @CsvBindByPosition(position = 5)
    private String profitDealerCode;
    @CsvBindByName(column = "販社名",locale = "ja")
    @CsvBindByPosition(position = 6)
    private String dealerName;
    @CsvBindByName(column = "NCID")
    @CsvBindByPosition(position = 7)
    private String ncId;
    @CsvBindByName(column = "NCPW")
    @CsvBindByPosition(position = 8)
    private String ncPw;
    @CsvBindByName(column = "IVI/DOP")
    @CsvBindByPosition(position = 9)
    private String ivOrDop;
    @CsvBindByName(column = "登録完了日",locale = "ja")
    @CsvBindByPosition(position = 10)
    private String vinRegistDate;
}
