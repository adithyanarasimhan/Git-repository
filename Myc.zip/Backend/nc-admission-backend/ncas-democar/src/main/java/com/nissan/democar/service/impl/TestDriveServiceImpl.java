package com.nissan.democar.service.impl;

import com.nissan.common.entity.*;
import com.nissan.common.repository.DemoCarCustomerRepository;
import com.nissan.common.repository.VinDetailsRepository;
import com.nissan.democar.dto.*;
import com.nissan.democar.entity.DemoCarTestDrive;
import com.nissan.democar.repository.DemoCarAdmissionRepository;
import com.nissan.democar.repository.DemoCarTestDriveRepository;
import com.nissan.democar.service.DemoCarCommunicationService;
import com.nissan.democar.service.TestDriveService;
import com.nissan.democar.util.DemoCarConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.util.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TestDriveServiceImpl implements TestDriveService {

    private static final Logger logger = LoggerFactory.getLogger(TestDriveServiceImpl.class);

    @Autowired
    DemoCarCustomerRepository demoCarCustomerRepository;

    @Autowired
    DemoCarAdmissionRepository demoCarAdmissionRepository;

    @Autowired
    DemoCarTestDriveRepository demoCarTestDriveRepository;

    @Autowired
    VinDetailsRepository vinDetailsRepository;

    @Autowired
    DemoCarCommunicationService demoCarCommunicationService;


    @Override
    @Transactional
    public DemoCarAdmission assignToCustomer(DealerEntity dealer, String langCode, AssignToCustomerDto assignToCustomerDto) {
        logger.info("inside assign to customer ");
        DemoCarAdmission demoCarAdmission = demoCarAdmissionRepository.findById(assignToCustomerDto.getAdmissionId()).get();
        VinDetails vinDetails = vinDetailsRepository.findByVin(demoCarAdmission.getVin());
        DemoCarCustomer demoCarCustomer = new DemoCarCustomer();
        demoCarCustomer.setFirstName(assignToCustomerDto.getFirstName());
        demoCarCustomer.setLastName(assignToCustomerDto.getFamilyName());
        demoCarCustomer.setFirstNameKanji(assignToCustomerDto.getFirstNameKatakana());
        demoCarCustomer.setLastNameKanji(assignToCustomerDto.getFamilyNameKatakana());
        demoCarCustomer.setPhoneNumber(assignToCustomerDto.getPhoneNumber());
        demoCarCustomerRepository.save(demoCarCustomer);
        List<DemoCarTestDrive> byAdmissionAndStatus = demoCarTestDriveRepository.findByAdmissionAndStatus(demoCarAdmission, DemoCarConstants.TD_STATUS_RUNNING);
        if (byAdmissionAndStatus != null && !byAdmissionAndStatus.isEmpty()) {
            byAdmissionAndStatus.forEach(t -> {
                t.setStatus(DemoCarConstants.TD_STATUS_EXPIRED);
                demoCarTestDriveRepository.save(t);
            });
        }
        DemoCarTestDrive demoCarTestDrive = new DemoCarTestDrive();
        demoCarTestDrive.setAdmission(demoCarAdmission);
        demoCarTestDrive.setCustomer(demoCarCustomer);
        demoCarTestDrive.setStartDate(assignToCustomerDto.getStartDate());
        demoCarTestDrive.setStartTime(assignToCustomerDto.getStartTime());
        demoCarTestDrive.setEndDate(assignToCustomerDto.getEndDate());
        demoCarTestDrive.setEndTime(assignToCustomerDto.getEndTime());
        demoCarTestDrive.setStatus(DemoCarConstants.TD_STATUS_RUNNING);
        demoCarTestDriveRepository.save(demoCarTestDrive);
        demoCarAdmission.setCustomer(demoCarCustomer);
        demoCarAdmission.setStatus(DemoCarConstants.STATUS_ON_LOAN);
        demoCarAdmissionRepository.save(demoCarAdmission);
        logger.info("saving admission={}", demoCarAdmission.getId());
        if (demoCarAdmission.getCustomer() != null) {
            logger.info("saving admission cutomer={}", demoCarAdmission.getCustomer().getId());
        } else {
            logger.info("saving admission cutomer is null");
        }
        vinDetails.setStatus(DemoCarConstants.STATUS_ON_LOAN);
        vinDetails.setCaLendingCode(dealer.getCaCode());
        vinDetails.setCaLendingName(dealer.getCaName());
        vinDetailsRepository.save(vinDetails);
        logger.info("saving vinDetails={}", vinDetails);
        return demoCarAdmission;
    }

    @Override
    public TestDriveInfoDto getTestDriveInfo(String langCode, Long id) {
        Optional<DemoCarTestDrive> testDrive = demoCarTestDriveRepository.findById(id);
        if (testDrive.isPresent()) {
            DemoCarTestDrive demoCarTestDrive = testDrive.get();
            TestDriveInfoDto testDriveInfoDto = new TestDriveInfoDto();
            testDriveInfoDto.setId(demoCarTestDrive.getId());
            testDriveInfoDto.setStartDate(demoCarTestDrive.getStartDate());
            testDriveInfoDto.setStartTime(demoCarTestDrive.getStartTime().toString());
            testDriveInfoDto.setEndDate(demoCarTestDrive.getEndDate());
            testDriveInfoDto.setEndTime(demoCarTestDrive.getEndTime().toString());
            return testDriveInfoDto;
        }

        return null;
    }

    @Override
    public boolean extendTestDrive(String langCode, ExtendTestDriveDto extendTestDriveDto) {
        Optional<DemoCarTestDrive> testDrive = demoCarTestDriveRepository.findById(extendTestDriveDto.getId());
        if (testDrive.isPresent()) {
            DemoCarTestDrive demoCarTestDrive = testDrive.get();
            demoCarTestDrive.setEndDate(extendTestDriveDto.getExtendedDate());
            demoCarTestDrive.setEndTime(extendTestDriveDto.getExtendedTime());
            demoCarTestDriveRepository.save(demoCarTestDrive);
            return true;
        }
        return false;
    }

    @Override
    public CustomerInfoDto getCustomerInfo(String langCode, Long id) {
        Optional<DemoCarAdmission> optionalDemoCarAdmission = demoCarAdmissionRepository.findById(id);
        if (optionalDemoCarAdmission.isPresent()) {
            DemoCarAdmission admission = optionalDemoCarAdmission.get();
            if (admission.getCustomer() != null) {
                Optional<DemoCarCustomer> customer = demoCarCustomerRepository.findById(admission.getCustomer().getId());
                if (customer.isPresent()) {
                    DemoCarCustomer demoCarCustomer = customer.get();
                    CustomerInfoDto customerInfoDto = new CustomerInfoDto();
                    customerInfoDto.setFirstName(demoCarCustomer.getFirstName());
                    customerInfoDto.setFirstNameKanji(demoCarCustomer.getFirstNameKanji());
                    customerInfoDto.setLastName(demoCarCustomer.getLastName());
                    customerInfoDto.setLastNameKanji(demoCarCustomer.getLastNameKanji());
                    customerInfoDto.setPhoneNumber(demoCarCustomer.getPhoneNumber());
                    return customerInfoDto;
                }
            }
        }
        return null;
    }

    @Override
    public DemoCarNcIdPasswordDto getNcIdAndPassword(String langCode, Long id) {
        DemoCarNcIdPasswordDto demoCarNcIdPasswordDto = null;
        Optional<DemoCarAdmission> admission = demoCarAdmissionRepository.findById(id);
        if (admission.isPresent()) {
            VinDetails vinDetails = vinDetailsRepository.findByVin(admission.get().getVin());
            DemoCarAdmission demoCarAdmission = admission.get();
            demoCarNcIdPasswordDto = new DemoCarNcIdPasswordDto();
            demoCarNcIdPasswordDto.setNcId(demoCarAdmission.getNcId());
            demoCarNcIdPasswordDto.setNcPassword(demoCarAdmission.getNcPassword());
            demoCarNcIdPasswordDto.setExpirationDate(vinDetails.getExpirationDate());
            return demoCarNcIdPasswordDto;
        }
        return null;
    }

    @Override
    public List<TestDriveHistory> fetchTestDriveHistory(String langCode, Long id) {

        Optional<DemoCarAdmission> demoCarAdmission = demoCarAdmissionRepository.findById(id);
        if (demoCarAdmission.isPresent()) {
            List<DemoCarTestDrive> testDrives = demoCarTestDriveRepository.findByAdmission(demoCarAdmission.get());
            List<TestDriveHistory> testDriveHistoryList = new ArrayList<>();
            testDrives.forEach(t -> {
                TestDriveHistory testDriveHistory = new TestDriveHistory();
                testDriveHistory.setId(t.getId());
                String customerName = null;
                if ("en".equals(langCode)) {
                    customerName = t.getCustomer().getFirstName() + " " + t.getCustomer().getLastName();
                } else {
                    customerName = t.getCustomer().getLastName() + t.getCustomer().getFirstName();
                }
                testDriveHistory.setCustomerName(customerName);
                testDriveHistory.setStartDate(t.getStartDate());
                testDriveHistory.setStartTime(t.getStartTime());
                testDriveHistory.setEndDate(t.getEndDate());
                testDriveHistory.setEndTime(t.getEndTime());
                testDriveHistory.setPhoneNumber(t.getCustomer().getPhoneNumber());
                testDriveHistoryList.add(testDriveHistory);
            });
            return testDriveHistoryList;
        }
        return null;
    }

    @Override
    public TestDriveInfoDto getTestDriveDetails(String langCode, Long admissionId) {
        Optional<DemoCarAdmission> admissionOpt = demoCarAdmissionRepository.findById(admissionId);
        if (!admissionOpt.isPresent()) {
            logger.info("Admission is not exist with id : {}", admissionId);
            return null;
        }
        DemoCarAdmission admission = admissionOpt.get();
        List<DemoCarTestDrive> demoCarTestDrive = demoCarTestDriveRepository.findByAdmissionAndStatus(admission,
                DemoCarConstants.TD_STATUS_RUNNING);
        if (demoCarTestDrive == null || demoCarTestDrive.isEmpty()) {
            logger.info("Couldn't find Test drive with Running status for Admission : {}", admissionId);
            return null;
        }
        DemoCarTestDrive testDrive = demoCarTestDrive.get(0);
        TestDriveInfoDto testDriveInfoDto = new TestDriveInfoDto();
        testDriveInfoDto.setId(testDrive.getId());
        testDriveInfoDto.setStartDate(testDrive.getStartDate());
        testDriveInfoDto.setStartTime(testDrive.getStartTime().toString());
        testDriveInfoDto.setEndDate(testDrive.getEndDate());
        testDriveInfoDto.setEndTime(testDrive.getEndTime().toString());
        return testDriveInfoDto;
    }

    @Override
    public TestDriveHistoryDetailsDto getTestDriveHistoryDetails(String langCode, Long testDriveId) {

        Optional<DemoCarTestDrive> testDriveOptional = demoCarTestDriveRepository.findById(testDriveId);

        if (testDriveOptional.isPresent()) {
            TestDriveHistoryDetailsDto testDriveHistoryDetailsDto = new TestDriveHistoryDetailsDto();
            DemoCarTestDrive testDrive = testDriveOptional.get();
            TestDriveInfoDto testDriveInfoDto = new TestDriveInfoDto();
            testDriveInfoDto.setStartDate(testDrive.getStartDate());
            testDriveInfoDto.setStartTime(testDrive.getStartTime().toString());
            testDriveInfoDto.setEndDate(testDrive.getEndDate());
            testDriveInfoDto.setEndTime(testDrive.getEndTime().toString());
            testDriveHistoryDetailsDto.setTestDrive(testDriveInfoDto);
            if (testDrive.getCustomer() != null) {
                DemoCarCustomer customer = testDrive.getCustomer();
                CustomerInfoDto customerInfoDto = new CustomerInfoDto();
                customerInfoDto.setFirstName(customer.getFirstName());
                customerInfoDto.setFirstNameKanji(customer.getFirstNameKanji());
                customerInfoDto.setLastName(customer.getLastName());
                customerInfoDto.setLastNameKanji(customer.getLastNameKanji());
                customerInfoDto.setPhoneNumber(customer.getPhoneNumber());
                testDriveHistoryDetailsDto.setCustomer(customerInfoDto);
            }
            return testDriveHistoryDetailsDto;
        }
        return null;
    }
}
