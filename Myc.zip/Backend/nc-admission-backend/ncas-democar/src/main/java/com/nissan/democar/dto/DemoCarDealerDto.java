package com.nissan.democar.dto;

import lombok.Data;

@Data
public class DemoCarDealerDto {
    private String profitDealerCode;
    private String dealerCompanyName;
    private String dealerShipCode;
    private String dealershipName;
    private String dealerPhoneNumber;
    private String caName;
    private String caCode;
    private String caNameLending;
    private String caCodeLending;

}
