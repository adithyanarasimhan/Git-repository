ALTER TABLE nissan_admin.vin_details
ADD COLUMN cw_navi_id varchar(100);