INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(12, 'KICKS', 'KICKS', '', 'en', '', 0, '', NULL, '', NULL, 6);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(13, 'X-TRAIL', 'X-TRAIL', '', 'en', '', 0, '', NULL, '', NULL, 7);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(14, 'ELGRAND', 'ELGRAND', '', 'en', '', 0, '', NULL, '', NULL, 8);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(15, 'FUGA', 'FUGA', '', 'en', '', 0, '', NULL, '', NULL, 9);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(16, 'CIMA', 'CIMA', '', 'en', '', 0, '', NULL, '', NULL, 10);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(17, 'OTHERS', 'OTHERS', '', 'en', '', 0, '', NULL, '', NULL, 11);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(18, 'SKYLINE(2019/09~)', 'SKYLINE(2019/09~)', '', 'en', '', 0, '', NULL, '', NULL, 1);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(21, 'DAYZ', 'DAYZ', '', 'en', '', 0, '', NULL, '', NULL, 4);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(22, 'ROOX', 'ROOX', '', 'en', '', 0, '', NULL, '', NULL, 5);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(20, 'NOTE(2020/12～)', 'NOTE(2020/12～)', '', 'en', '', 0, '', NULL, '', NULL, 3);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(19, 'LEAF(2020/02～)', 'LEAF(2020/02～)', '', 'en', '', 0, '', NULL, '', NULL, 2);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(23, 'DAYZ', 'デイズ', '', 'jp', '', 0, '', NULL, '', NULL, 4);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(24, 'KICKS', 'キックス', '', 'jp', '', 0, '', NULL, '', NULL, 6);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(25, 'X-TRAIL', 'X-エクストレイル', '', 'jp', '', 0, '', NULL, '', NULL, 7);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(26, 'ELGRAND', 'エルグランド', '', 'jp', '', 0, '', NULL, '', NULL, 8);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(27, 'FUGA', 'フーガ', '', 'jp', '', 0, '', NULL, '', NULL, 9);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(28, 'CIMA', 'シーマ', '', 'jp', '', 0, '', NULL, '', NULL, 10);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(29, 'OTHERS', 'その他', '', 'jp', '', 0, '', NULL, '', NULL, 11);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(30, 'ROOX', 'デイズ', '', 'jp', '', 0, '', NULL, '', NULL, 5);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(31, 'LEAF(2020/02～)', 'リーフ（2020年2月～）', '', 'jp', '', 0, '', NULL, '', NULL, 2);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(32, 'SKYLINE(2019/09~)', 'スカイライン（2019年9月～）', '', 'jp', '', 0, '', NULL, '', NULL, 1);
INSERT INTO nissan_admin.democar_model
(id, model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date, display_order)
VALUES(33, 'NOTE（2020/12～）', 'ノート（2020年12月～）', '', 'jp', '', 0, '', NULL, '', NULL, 3);


INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(2, 18, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(3, 18, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(4, 19, 'S', 'S', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(5, 19, 'X/G/other(than S)', 'X/G/other(than S)', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(6, 20, 'X', 'X', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(7, 20, 'F/S', 'F/S', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(8, 12, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(9, 13, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(10, 14, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(11, 15, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(12, 16, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(13, 17, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(14, 21, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(15, 22, 'NOGRADE', 'All Grades', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(16, 32, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(17, 32, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(18, 31, 'S', 'S', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(19, 31, 'X/G/other(than S)', 'X/G/その他(S以外)', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(20, 33, 'X', 'X', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(21, 33, 'F/S', 'F/S', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(22, 23, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(23, 30, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(24, 24, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(25, 25, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(26, 26, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(27, 27, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(28, 28, 'NOGRADE', '全グレード', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_grade
(id, model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(29, 29, 'NOGRADE', '全グレード', '', 'en', '', NULL, '', NULL);


INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(1, 2, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(2, 3, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(4, 5, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(5, 6, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(8, 8, 'd-op', 'DOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(10, 10, 'd-op', 'DOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(11, 11, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(13, 12, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(16, 15, 'd-op', 'DOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(17, 4, 'na', 'Not applicable / No Navi Type', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(6, 6, 'na', 'Not applicable / No Navi Type', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(7, 7, 'na', 'Not applicable / No Navi Type', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(19, 10, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(9, 9, 'm-op', 'MOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(15, 14, 'd-op', 'DOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(14, 13, 'd-op', 'DOP', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(21, 16, 'm-op', 'メーカーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(22, 17, 'm-op', 'メーカーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(23, 18, 'na', 'お申込み不可', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(24, 19, 'm-op', 'メーカーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(25, 20, 'm-op', 'メーカーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(26, 20, 'd-op', 'ディーラーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(27, 21, 'd-op', 'ディーラーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(28, 22, 'd-op', 'ディーラーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(29, 23, 'd-op', 'ディーラーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(30, 24, 'd-op', 'ディーラーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(31, 25, 'm-op', 'メーカーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(32, 26, 'm-op', 'メーカーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(33, 26, 'd-op', 'ディーラーオプション', '', 'jp', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(34, 27, 'm-op', 'メーカーオプション', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(35, 28, 'm-op', 'メーカーオプション', '', 'en', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_navi
(id, grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(36, 29, 'd-op', 'ディーラーオプション', '', 'en', '', NULL, '', NULL);


INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(1, 1, 'propilot', 'Pro Pilot Plan', '', '', 'Demo Car', 10750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(3, 2, 'standard', 'Standard plan', '', '', 'Demo Car', 2750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(5, 4, 'standard', 'Standard plan', '', '', 'Demo Car', 2750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(7, 5, 'standard', 'Standard plan', '', '', 'Demo Car', 2750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(12, 8, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(13, 8, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(14, 9, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(15, 9, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(16, 10, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(17, 10, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(18, 11, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(19, 11, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(21, 13, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(22, 13, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(23, 14, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(24, 14, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(25, 15, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(26, 15, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(27, 16, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(28, 16, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(2, 1, 'propilot', 'Pro Pilot Plan', '', '', 'Company Car', 10750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(4, 2, 'standard', 'Standard plan', '', '', 'Company Car', 2750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(8, 5, 'standard', 'Standard plan', '', '', 'Company Car', 2750, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(33, 19, 'basic+os', 'Basic service + operater service', '', '', 'Company Car', 0, 0, 'en', NULL, 'pattern-two', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(34, 19, 'basic+os', 'Basic service + operater service', '', '', 'Demo Car', 0, 0, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(29, 1, 'propilot', 'Pro Pilot Plan + docomo in car connect', '', '', 'Company Car', 19750, 9000, 'en', NULL, 'pattern-two', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(30, 2, 'standard', 'Standard plan + docomo in car connect', '', '', 'Company Car', 11750, 9000, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(31, 4, 'standard', 'Standard plan + docomo in car connect', '', '', 'Company Car', 11750, 9000, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(32, 5, 'standard', 'Standard plan + docomo in car connect', '', '', 'Company Car', 11750, 9000, 'en', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(35, 21, 'propilot', 'プロパイロットプラン', '', '', 'Demo Car', 10750, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(36, 21, 'propilot', 'プロパイロットプラン + docomo in car connect', '', '', 'Company Car', 10750, 9000, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(37, 22, 'standard', 'スタンダードプラン', '', '', 'Demo Car', 2750, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(38, 22, 'standard', 'スタンダードプラン + docomo in car connect', '', '', 'Company Car', 2750, 9000, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(39, 24, 'standard', 'スタンダードプラン', '', '', 'Demo Car', 2750, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(40, 24, 'standard', 'スタンダードプラン + docomo in car connect', '', '', 'Company Car', 2750, 9000, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(41, 25, 'standard', 'スタンダードプラン', '', '', 'Demo Car', 2750, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(42, 25, 'standard', 'スタンダードプラン + docomo in car connect', '', '', 'Company Car', 2750, 9000, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(43, 28, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(44, 28, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(45, 29, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(46, 29, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(47, 30, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(48, 30, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(49, 31, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(50, 31, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(51, 32, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(52, 32, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(53, 33, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(54, 33, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(55, 34, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(56, 34, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(57, 35, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(58, 35, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(59, 36, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Company Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
INSERT INTO nissan_admin.democar_package_plan
(id, navi_id, package_plan_name, display_name, cw_package_plan_name, description, car_plan, price, icc_fee, lang_code, pattern_name, terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(60, 36, 'basic+os', '基本サービス＋オペレータサービス', '', '', 'Demo Car', 0, 0, 'jp', NULL, 'pattern-one', '', NULL, '', NULL);
