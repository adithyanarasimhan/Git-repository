### DB changes for Release 2.0 - 29/03/2021

- DDL script for Democar related tables.
- DML script for populating Democar master data.