ALTER TABLE nissan_admin.vin_details
ADD COLUMN no_of_retry_cw int4;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN admission_id int4 NULL;

ALTER TABLE nissan_admin.vin_details
DROP COLUMN created_ca;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN dealer_id varchar(100) NULL;