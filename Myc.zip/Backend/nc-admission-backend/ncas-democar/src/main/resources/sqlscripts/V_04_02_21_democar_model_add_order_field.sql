ALTER TABLE nissan_admin.democar_model
ADD COLUMN display_order int4 NULL;