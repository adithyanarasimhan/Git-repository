ALTER TABLE nissan_admin.vin_details
ADD COLUMN enrollment_date timestamp;