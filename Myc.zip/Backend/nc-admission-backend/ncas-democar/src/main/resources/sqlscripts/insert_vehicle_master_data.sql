INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('SKYLINE(2019/09~)','SKYLINE(2019/09~)', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('LEAF(2020/02～)','LEAF(2020/02～）', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('NOTE(2020/12～)','NOTE(2020/12～）', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('DAYZ','DAYZ', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('ROOX','ROOX', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('KICKS','KICKS', '', 'en', '', 0, '', null, '', null);


INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('X-TRAIL','X-TRAIL', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('ELGRAND','ELGRAND', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('FUGA','FUGA', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('CIMA','CIMA', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_model
(model_name, display_name, cw_model_name, lang_code, url, model_display_order, created_by, created_date, last_modified_by, last_modified_date)
VALUES('OTHERS','OTHERS', '', 'en', '', 0, '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(12, '[HYBRID]　GT/GT Type P/GT Type SP', '[HYBRID]　GT/GT Type P/GT Type SP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(12, '[TURBO]　GT/GT Type P/GT Type SP/400R', '[TURBO]　GT/GT Type P/GT Type SP/400R', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(13, 'S', 'S', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(13, 'X/G/other(than S)', 'X/G/other(than S)', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(14, 'X', 'X', '', 'en', '', null, '', null);


INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(14, 'F/S', 'F/S', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(15, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(16, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(17, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(18, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(19, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);


INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(20, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(21, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_grade
(model_id, grade_name, display_name, cw_grade_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(22, 'NOGRADE', 'All Grades', '', 'en', '', null, '', null);


INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(15, 'm-op', 'MOP', '', 'en', '', null, '', null);


INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(16, 'm-op', 'MOP', '', 'en', '', null, '', null);


INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(17, 'na', 'Not applicable / No Navi Type', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(18, 'm-op', 'MOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(19, 'm-op', 'MOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(19, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(20, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(21, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(22, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(23, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(24, 'm-op', 'MOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(25, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(25, 'm-op', 'MOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(26, 'm-op', 'MOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(27, 'm-op', 'MOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_navi
(grade_id, navi_name, display_name, cw_navi_name, lang_code, created_by, created_date, last_modified_by, last_modified_date)
VALUES(28, 'd-op', 'DOP', '', 'en', '', null, '', null);

INSERT INTO nissan_admin.democar_package_plan
(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Demo Car', 10750, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Demo Car', 10750, 9000,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Company Car', 10750, 9000,'en', 'pattern-two', '', null, '', null);

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Company Car', 19750, 9000,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Company Car', 10750, 9000,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Demo Car', 2750, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Demo Car', 2750, 9000,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-one', '', null, '', null);

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Company Car', 11750, 9000,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(3, 'na', 'Not Applicable /No', '', '','', 0, 0,'en', '', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Demo Car', 2750, 0,'en', 'pattern-one', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Demo Car', 2750, 9000,'en', 'pattern-two', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-one', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-two', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Demo Car', 2750, 0,'en', 'pattern-one', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Demo Car', 2750, 9000,'en', 'pattern-two', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-one', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-two', '', null, '', null);





	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(8, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(8, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(8, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(8, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(9, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(9, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(9, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(9, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(10, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(10, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(10, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(10, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(11, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(11, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(11, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(11, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(12, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
    	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
    	VALUES(12, 'basic+os', 'Basic service + operater service', '', '','Demo Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(12, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(12, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);



	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(13, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(13, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(13, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(13, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(14, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(14, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(14, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(14, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);



INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(15, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(15, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(15, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-one', '', null, '', null);

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(15, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);
	
	INSERT INTO nissan_admin.democar_package_plan
    	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
    	VALUES(16, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);
    	
    	INSERT INTO nissan_admin.democar_package_plan
            	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
            	VALUES(16, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-two', '', null, '', null);
        

INSERT INTO nissan_admin.democar_package_plan
    	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
    	VALUES(16, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-one', '', null, '', null);


INSERT INTO nissan_admin.democar_package_plan
    	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
    	VALUES(16, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-two', '', null, '', null);



UPDATE nissan_admin.democar_navi set navi_name='na', display_name='Not applicable / No Navi Type' where id=6;

UPDATE nissan_admin.democar_navi set navi_name='na' , display_name='Not applicable / No Navi Type' where id=7;

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Company Car', 19750, 9000,'en', 'pattern-two', '', null, '', null);

	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Company Car', 11750, 9000,'en', 'pattern-one', '', null, '', null);

	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Company Car', 11750, 9000,'en', 'pattern-one', '', null, '', null);
	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Company Car', 11750, 9000,'en', 'pattern-one', '', null, '', null);