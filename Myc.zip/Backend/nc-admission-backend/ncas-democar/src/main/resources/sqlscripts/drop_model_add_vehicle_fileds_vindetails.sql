	ALTER TABLE nissan_admin.vin_details 
DROP COLUMN model;

	ALTER TABLE nissan_admin.vin_details 
DROP COLUMN navi_id;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN model_id int4;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN grade_id int4;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN navi_id int4;


ALTER TABLE nissan_admin.vin_details
ADD COLUMN plan_id int4;