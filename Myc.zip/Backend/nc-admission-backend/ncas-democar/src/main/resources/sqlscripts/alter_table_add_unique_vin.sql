ALTER TABLE nissan_admin.vin_details 
ADD CONSTRAINT vindetails_vin_unique UNIQUE (vin);