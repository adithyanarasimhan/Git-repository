ALTER TABLE nissan_admin.vin_details
ADD COLUMN dealer_name varchar(100);

ALTER TABLE nissan_admin.vin_details
ADD COLUMN dealer_shop_name varchar(100);

ALTER TABLE nissan_admin.vin_details
ADD COLUMN caName varchar(100);