ALTER TABLE nissan_admin.vin_details 
DROP COLUMN vehicle_type;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN active bool;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN model varchar(100);

ALTER TABLE nissan_admin.vin_details
ADD COLUMN expiration_date timestamp;

ALTER TABLE nissan_admin.vin_details
ADD COLUMN status varchar(100);


