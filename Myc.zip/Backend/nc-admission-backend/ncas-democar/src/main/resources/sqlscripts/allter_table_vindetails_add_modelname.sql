ALTER TABLE nissan_admin.vin_details
ADD COLUMN model_name varchar(100);