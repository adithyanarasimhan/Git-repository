

INSERT INTO nissan_admin.democar_package_plan
(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Demo Car', 10750, 0,'en', 'pattern-one', '', null, '', null);

	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(1, 'propilot', 'Pro Pilot Plan', '', '','Company Car', 10750, 9000,'en', 'pattern-one', '', null, '', null);

	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Demo Car', 2750, 0,'en', 'pattern-one', '', null, '', null);

	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(2, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-one', '', null, '', null);

	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(3, 'na', 'Not Applicable /No', '', '','', 0, 0,'en', '', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Demo Car', 2750, 0,'en', 'pattern-one', '', null, '', null);


	

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(4, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-one', '', null, '', null);



	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Demo Car', 2750, 0,'en', 'pattern-one', '', null, '', null);


	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(5, 'standard', 'Standard plan', '', '','Company Car', 2750, 9000,'en', 'pattern-one', '', null, '', null);


	



	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(6, 'na', 'Not Applicable /No', '', '','', 0, 0,'', '', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(6, 'na', 'Not Applicable /No', '', '','', 0, 0,'en', '', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(6, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(7, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(7, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(8, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(8, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(9, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(9, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

		INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(10, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(10, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

		INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(11, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(11, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

		INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(12, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	


	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(13, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(13, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(14, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);

		INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(14, 'basic+os', 'Basic service + operater service', '', '','Company Car',0 , 0,'en', 'pattern-one', '', null, '', null);
	

INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(15, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);


INSERT INTO nissan_admin.democar_package_plan
	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
	VALUES(15, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-one', '', null, '', null);


	INSERT INTO nissan_admin.democar_package_plan
    	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
    	VALUES(16, 'basic+os', 'Basic service + operater service', '', '','Demo Car', 0, 0,'en', 'pattern-one', '', null, '', null);
    	
    	
INSERT INTO nissan_admin.democar_package_plan
    	(navi_id, package_plan_name, display_name, cw_package_plan_name, description,car_plan, price, icc_fee, lang_code,terms_name, created_by, created_date, last_modified_by, last_modified_date)
    	VALUES(16, 'basic+os', 'Basic service + operater service', '', '','Company Car', 0, 0,'en', 'pattern-one', '', null, '', null);






