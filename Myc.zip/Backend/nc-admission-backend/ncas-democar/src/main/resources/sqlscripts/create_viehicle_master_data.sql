CREATE TABLE nissan_admin.democar_model (
	id bigserial NOT NULL,
	model_name varchar(100) NOT NULL,
	display_name varchar(100) NULL,
	cw_model_name varchar(100) NULL,
	lang_code varchar(5) NULL,
	url varchar(500) NULL,
	model_display_order int2 NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_model_id_key UNIQUE (id),
	CONSTRAINT democar_model_pkey PRIMARY KEY (model_name),
	CONSTRAINT uk_6tnk56bg7qssdxlnatj4cnhm UNIQUE (model_name)
);

CREATE TABLE nissan_admin.democar_grade (
	id bigserial NOT NULL,
	model_id int8 NOT NULL,
	grade_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_grade_name varchar(300) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_grade_id_key UNIQUE (id),
	CONSTRAINT democar_grade_pkey PRIMARY KEY (grade_name,model_id)
);

ALTER TABLE nissan_admin.democar_grade ADD CONSTRAINT democar_grade_model_fkey FOREIGN KEY (model_id) REFERENCES nissan_admin.democar_model(id);

CREATE TABLE nissan_admin.democar_navi (
	id bigserial NOT NULL,
	grade_id int8 NOT NULL,
	navi_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_navi_name varchar(300) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_naviv_id_key UNIQUE (id),
	CONSTRAINT democar_navi_pkey PRIMARY KEY (navi_name,grade_id)
);
ALTER TABLE nissan_admin.democar_navi ADD CONSTRAINT democar_navi_gradeid_fkey FOREIGN KEY (grade_id) REFERENCES nissan_admin.democar_grade(id);

-- nissan_admin.democar_package_plan definition

-- Drop table

-- DROP TABLE nissan_admin.democar_package_plan;

CREATE TABLE nissan_admin.democar_package_plan (
	id bigserial NOT NULL,
	navi_id int8 NOT NULL,
	package_plan_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_package_plan_name varchar(300) NULL,
	description varchar(500) NULL,
	car_plan varchar(500) NULL,
	price int8 NULL,
	icc_fee int8 NULL,
	lang_code varchar(5) NULL,
	pattern_name varchar(50) NULL,
	terms_name varchar(50) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_package_plan_id_key UNIQUE (id)
--	CONSTRAINT democar_package_plan_pkey PRIMARY KEY (package_plan_name,navi_id)
);


-- nissan_admin.democar_package_plan foreign keys

--ALTER TABLE nissan_admin.democar_package_plan ADD CONSTRAINT democar_package_plan_naviid_fkey FOREIGN KEY (navi_id) REFERENCES nissan_admin.democar_navi(id);

--ALTER TABLE nissan_admin.democar_package_plan DROP CONSTRAINT democar_package_plan_pkey;




