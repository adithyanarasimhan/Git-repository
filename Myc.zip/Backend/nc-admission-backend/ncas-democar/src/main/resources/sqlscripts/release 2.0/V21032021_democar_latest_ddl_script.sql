DROP TABLE IF EXISTS nissan_admin.vin_details
 
DROP TABLE IF EXISTS nissan_admin.democar_admission;

DROP TABLE IF EXISTS nissan_admin.democar_test_drive;

DROP TABLE IF EXISTS nissan_admin.democar_customer ;

CREATE TABLE nissan_admin.democar_admission (
	id bigserial NOT NULL,
	nc_id varchar(255) NULL,
	nc_password varchar(255) NULL,
	status varchar(255) NULL,
	vin varchar(255) NULL,
	nc_joined_date varchar(255) NULL,
	cw_id varchar(255) NULL,
	customer_id int8 NULL,
	send_to_nlo bool NULL,
	vin_reg_date varchar(255) NULL,
	iccid varchar(255) NULL,
	nc_pw_expiration_date varchar(255) NULL,
	CONSTRAINT democar_admission_pkey PRIMARY KEY (id),
	CONSTRAINT democar_admission_vin_unique UNIQUE (vin)
);


-- nissan_admin.democar_admission foreign keys

ALTER TABLE nissan_admin.democar_admission ADD CONSTRAINT fkmru5rpdn236ojfok5q6bpfp8r FOREIGN KEY (customer_id) REFERENCES nissan_admin.democar_customer(id);

CREATE TABLE nissan_admin.vin_details (
	id bigserial NOT NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	car_plan varchar(255) NULL,
	flag_type varchar(255) NULL,
	icc bool NULL,
	ivi bool NULL,
	profit_dealer_code varchar(255) NULL,
	vin varchar(255) NULL,
	active bool NULL,
	expiration_date varchar(255) NULL,
	status varchar(100) NULL,
	model_id int4 NULL,
	grade_id int4 NULL,
	navi_id int4 NULL,
	plan_id int4 NULL,
	cw_navi_id varchar(100) NULL,
	vehicle_type varchar(255) NULL,
	enrollment_date timestamp NULL,
	image_url varchar(255) NULL,
	profit_dealer_shop_code varchar(255) NULL,
	"source" varchar(255) NULL,
	model_name varchar(255) NULL,
	created_ca varchar(255) NULL,
	ca_name varchar(255) NULL,
	dealer_name varchar(255) NULL,
	dealer_shop_name varchar(255) NULL,
	no_of_retry_cw int4 NULL,
	admission_id int8 NULL,
	dealer_id varchar(255) NULL,
	ca_lending_code varchar(255) NULL,
	ca_lending_name varchar(255) NULL,
	CONSTRAINT vin_details_pkey PRIMARY KEY (id),
	CONSTRAINT vindetails_vin_unique UNIQUE (vin)
);


-- nissan_admin.vin_details foreign keys

ALTER TABLE nissan_admin.vin_details ADD CONSTRAINT fk1wdx0b112e11chh56n3qwnvxw FOREIGN KEY (dealer_id) REFERENCES nissan_admin.dealer(dealer_id);
ALTER TABLE nissan_admin.vin_details ADD CONSTRAINT fkl61vo74etwpi8kg2tnjlshh2v FOREIGN KEY (admission_id) REFERENCES nissan_admin.democar_admission(id);

CREATE TABLE nissan_admin.democar_customer (
	id bigserial NOT NULL,
	first_name varchar(255) NULL,
	first_name_kanji varchar(255) NULL,
	last_name varchar(255) NULL,
	last_name_kanji varchar(255) NULL,
	phone_number varchar(255) NULL,
	CONSTRAINT democar_customer_pkey PRIMARY KEY (id)
);

CREATE TABLE nissan_admin.democar_test_drive (
	id bigserial NOT NULL,
	end_date timestamp NULL,
	end_time time NULL,
	start_date timestamp NULL,
	start_time time NULL,
	admission_id int8 NULL,
	customer_id int8 NULL,
	status varchar(255) NULL,
	CONSTRAINT democar_test_drive_pkey PRIMARY KEY (id)
);


-- nissan_admin.democar_test_drive foreign keys

ALTER TABLE nissan_admin.democar_test_drive ADD CONSTRAINT fk3wg1mprqfehmv8btly3jdkslk FOREIGN KEY (customer_id) REFERENCES nissan_admin.democar_customer(id);
ALTER TABLE nissan_admin.democar_test_drive ADD CONSTRAINT fkfe9ijs6xgs9hovea1dks0m1ix FOREIGN KEY (admission_id) REFERENCES nissan_admin.democar_admission(id);

DROP TABLE IF EXISTS nissan_admin.democar_package_plan;	

CREATE TABLE nissan_admin.democar_package_plan (
	id bigserial NOT NULL,
	navi_id int8 NOT NULL,
	package_plan_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_package_plan_name varchar(300) NULL,
	description varchar(500) NULL,
	car_plan varchar(500) NULL,
	price int8 NULL,
	icc_fee int8 NULL,
	lang_code varchar(5) NULL,
	pattern_name varchar(50) NULL,
	terms_name varchar(50) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_package_plan_id_key UNIQUE (id)
);

 DROP TABLE IF EXISTS nissan_admin.democar_navi;

CREATE TABLE nissan_admin.democar_navi (
	id bigserial NOT NULL,
	grade_id int8 NOT NULL,
	navi_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_navi_name varchar(300) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_navi_pkey PRIMARY KEY (navi_name, grade_id),
	CONSTRAINT democar_naviv_id_key UNIQUE (id)
);


DROP TABLE IF EXISTS nissan_admin.democar_grade;
 
 
CREATE TABLE nissan_admin.democar_grade (
	id bigserial NOT NULL,
	model_id int8 NOT NULL,
	grade_name varchar(300) NOT NULL,
	display_name varchar(300) NULL,
	cw_grade_name varchar(300) NULL,
	lang_code varchar(5) NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT democar_grade_id_key UNIQUE (id),
	CONSTRAINT democar_grade_pkey PRIMARY KEY (grade_name, model_id)
);

 DROP TABLE IF EXISTS nissan_admin.democar_model;

CREATE TABLE nissan_admin.democar_model (
	id bigserial NOT NULL,
	model_name varchar(100) NOT NULL,
	display_name varchar(100) NULL,
	cw_model_name varchar(100) NULL,
	lang_code varchar(5) NULL,
	url varchar(500) NULL,
	model_display_order int2 NULL,
	created_by varchar(255) NULL,
	created_date timestamp NULL,
	last_modified_by varchar(255) NULL,
	last_modified_date timestamp NULL,
	display_order int4 NULL,
	CONSTRAINT democar_model_id_key UNIQUE (id)
);


ALTER TABLE nissan_admin.democar_grade ADD CONSTRAINT democar_grade_model_fkey FOREIGN KEY (model_id) REFERENCES nissan_admin.democar_model(id);

ALTER TABLE nissan_admin.democar_navi ADD CONSTRAINT democar_navi_gradeid_fkey FOREIGN KEY (grade_id) REFERENCES nissan_admin.democar_grade(id);


